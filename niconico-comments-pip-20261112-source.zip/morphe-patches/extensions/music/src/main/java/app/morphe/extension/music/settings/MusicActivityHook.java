/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * Original hard forked code:
 * https://github.com/ReVanced/revanced-patches/commit/724e6d61b2ecd868c1a9a37d465a688e83a74799
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to Morphe contributions.
 */

package app.morphe.extension.music.settings;

import static app.morphe.extension.shared.StringRef.str;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.preference.PreferenceFragment;
import android.view.View;
import android.widget.Toolbar;

import app.morphe.extension.music.settings.preference.MusicPreferenceFragment;
import app.morphe.extension.music.settings.search.MusicSearchViewController;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceType;
import app.morphe.extension.shared.ResourceUtils;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.settings.BaseActivityHook;
import app.morphe.extension.shared.settings.preference.AbstractPreferenceFragment;
import app.morphe.extension.shared.spoof.SpoofAppVersionPatch;
import app.morphe.extension.shared.theme.ThemeUtils;

/**
 * Hooks {@code com.google.android.gms.common.api.GoogleApiActivity}
 * to inject a custom {@link MusicPreferenceFragment} with a toolbar and search.
 */
@SuppressWarnings({"deprecation", "RedundantSuppression"})
public class MusicActivityHook extends BaseActivityHook {

    @SuppressLint("StaticFieldLeak")
    public static MusicSearchViewController searchViewController;

    private static final boolean USE_BOLD_ICONS = Settings.SETTINGS_INITIALIZED.get()
            && !SpoofAppVersionPatch.isSpoofingToLessThan("8.40.00");

    static {
        Utils.setAppIsUsingBoldIcons(USE_BOLD_ICONS);
    }

    /**
     * Injection point.
     * <p>
     * Otherwise the dark mode status falls back to the device theme until the settings are
     * opened, and the extension draws with dark colors on the dark app.
     */
    @SuppressWarnings("unused")
    public static void onMainActivityCreate() {
        Utils.setIsDarkModeEnabled(true);
    }

    /**
     * Injection point.
     */
    @SuppressWarnings("unused")
    public static void initialize(Activity parentActivity) {
        // Prevent opening multiple settings activities if menu is double tapped quickly.
        if (Utils.isFastClick()) {
            parentActivity.finish();
            return;
        }

        // Must touch the Music settings to ensure the settings class is loaded and
        // the values can be found when setting the UI preferences.
        // Logging anything under non debug ensures this is set.
        Logger.printInfo(() -> "Remember repeat state enabled: " + Settings.REMEMBER_REPEAT_STATE.get());

        // YT Music always uses dark mode.
        Utils.setIsDarkModeEnabled(true);

        BaseActivityHook.initialize(new MusicActivityHook(), parentActivity);
    }

    /**
     * Sets the fixed theme for the activity.
     */
    @Override
    protected void customizeActivityTheme(Activity activity) {
        // Override the default YouTube Music theme to increase start padding of list items.
        // Custom style located in resources/music/values/style.xml
        activity.setTheme(ResourceUtils.getIdentifierOrThrow(
                ResourceType.STYLE, "Theme.Morphe.YouTubeMusic.Settings"));
    }

    /**
     * Returns the fixed background color for the toolbar.
     */
    @Override
    protected int getToolbarBackgroundColor() {
        return ResourceUtils.getColor("ytm_color_black");
    }

    /**
     * Returns the navigation icon with a color filter applied.
     */
    @Override
    protected Drawable getNavigationIcon() {
        Drawable navigationIcon = MusicPreferenceFragment.getBackButtonDrawable();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            navigationIcon.setColorFilter(new BlendModeColorFilter(
                    ThemeUtils.getAppForegroundColor(), BlendMode.SRC_IN));
        } else {
            navigationIcon.setColorFilter(ThemeUtils.getAppForegroundColor(), PorterDuff.Mode.SRC_IN);
        }

        return navigationIcon;
    }

    /**
     * Returns the click listener that finishes the activity when the navigation icon is clicked.
     */
    @Override
    protected View.OnClickListener getNavigationClickListener(Activity activity) {
        return view -> {
            if (searchViewController != null && searchViewController.isSearchActive()) {
                searchViewController.closeSearch();
            } else {
                activity.finish();
            }
        };
    }

    /**
     * Adds search view components to the toolbar for {@link MusicPreferenceFragment}.
     *
     * @param activity The activity hosting the toolbar.
     * @param toolbar  The configured toolbar.
     * @param fragment The PreferenceFragment associated with the activity.
     */
    @Override
    protected void onPostToolbarSetup(Activity activity, Toolbar toolbar, PreferenceFragment fragment) {
        if (fragment instanceof MusicPreferenceFragment) {
            searchViewController = MusicSearchViewController.addSearchViewComponents(
                    activity, toolbar, (MusicPreferenceFragment) fragment);
        }
    }

    /**
     * Creates a new {@link MusicPreferenceFragment} for the activity.
     */
    @Override
    protected PreferenceFragment createPreferenceFragment() {
        return new MusicPreferenceFragment();
    }

    /**
     * Injection point.
     * <p>
     * Overrides {@link Activity#finish()} of the injection Activity.
     *
     * @return if the original activity finish method should be allowed to run.
     */
    @SuppressWarnings("unused")
    public static boolean handleFinish(Activity activity) {
        return MusicSearchViewController.handleFinish(searchViewController)
                || AbstractPreferenceFragment.showRestartDialogIfNeeded(activity);
    }

    /**
     * Injection point.
     */
    @SuppressWarnings("unused")
    public static boolean useBoldIcons(boolean original) {
        return USE_BOLD_ICONS;
    }
}
