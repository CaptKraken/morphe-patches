## [2.3.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v2.3.0-dev.1...v2.3.0-dev.2) (2026-11-12)

### ✨ New Features

* **YouTube - DeArrow:** Tap DeArrow icon to show original video thumbnail ([4965002](https://github.com/MorpheApp/morphe-patches/commit/49650028440fd8788f9e84fd54457cbc173c1b20)), closes [#2629](https://github.com/MorpheApp/morphe-patches/issues/2629)
* **YouTube & YouTube Music - Settings:** Add "Mark all settings as seen" setting to remove all new setting dots ([890f20f](https://github.com/MorpheApp/morphe-patches/commit/890f20f2b929c59e2de290e88cc84cf2df6faaff))
* **YouTube Music - Downloads:** Native offline downloads support ([#4698](https://github.com/MorpheApp/morphe-patches/issues/4698)) ([9ddd181](https://github.com/MorpheApp/morphe-patches/commit/9ddd181e8542cd62e874ad813b2a79acb1293008))
* **YouTube Music - Hide layout components:** Add "Hide 'Your downloads' shelf" setting ([d99ae84](https://github.com/MorpheApp/morphe-patches/commit/d99ae8474535bab62e3bf9a7857f61e7fbca227a))
* **YouTube Music:** Add `A-B loop` patch ([#4685](https://github.com/MorpheApp/morphe-patches/issues/4685)) ([c3a57a6](https://github.com/MorpheApp/morphe-patches/commit/c3a57a6bb681a9149f58be6ce7aa64e2dc8ba4a3))

### 🐛 Bug Fixes

* **Spoof video streams:** "isOfflinePlayerResponse failure" error is shown with feed video inline playback ([19b97df](https://github.com/MorpheApp/morphe-patches/commit/19b97df9147689e74e1fd84e92d045b4fcb3e2a7))
* **Spoof video streams:** Quality selected in the quality menu is used for the next videos instead of the automatic quality ([#4711](https://github.com/MorpheApp/morphe-patches/issues/4711)) ([f5afc79](https://github.com/MorpheApp/morphe-patches/commit/f5afc7946e8a189424d0d558055a426a1f3e2e99))
* **Spoof video streams:** Show startup dialog if system WebView app is disabled or outdated ([#4733](https://github.com/MorpheApp/morphe-patches/issues/4733)) ([c21df57](https://github.com/MorpheApp/morphe-patches/commit/c21df57e7d1342d183a72b7e2c75d8fe25a94cb3))
* **YouTube - Ambient mode:** Enhanced Ambient mode covers part of a zoomed video ([#4690](https://github.com/MorpheApp/morphe-patches/issues/4690)) ([779bde2](https://github.com/MorpheApp/morphe-patches/commit/779bde21f7f962208231a19985d0626623eafe99))
* **YouTube - Feed view count:** View count badge takes the view count from the metadata of the video, and the loading spinner is removed, as the view count is known at once ([9d64e06](https://github.com/MorpheApp/morphe-patches/commit/9d64e0664ab12bfbb8f9e7b60246327a23db1f05))
* **YouTube - Hide ads:** Ad slots of every video are kept in memory until the app closes, which can run the app out of memory after many videos ([8c9ac12](https://github.com/MorpheApp/morphe-patches/commit/8c9ac12ba63e694a3417cfbe6f58580fd4f1730c))
* **YouTube - Hide layout components:** "Hide horizontal shelves" does not hide the newer horizontal shelves, such as "Watch it again" of the home feed ([#4682](https://github.com/MorpheApp/morphe-patches/issues/4682)) ([70b9e77](https://github.com/MorpheApp/morphe-patches/commit/70b9e77e41980ca1f8b15f2fe36c479614d902c8))
* **YouTube - Hide layout components:** Keyword filter does not hide Shorts of [@handle](https://github.com/handle) keywords ([69ebf94](https://github.com/MorpheApp/morphe-patches/commit/69ebf94b02ffbb3a3c72486fefceb44ae11e3691))
* **YouTube - Hide Shorts components:** Shorts are shown above an empty black bar when "Hide preview comment" hides the comment bar below them, such as the Shorts of a channel ([#4696](https://github.com/MorpheApp/morphe-patches/issues/4696)) ([1483b3b](https://github.com/MorpheApp/morphe-patches/commit/1483b3bdc0a818b10c18bf41084206fcae7c319f))
* **YouTube - Hide Shorts components:** Shorts opened from a channel have no navigation bar when "Hide preview comment" hides the comment bar shown in its place ([#4696](https://github.com/MorpheApp/morphe-patches/issues/4696)) ([79148a1](https://github.com/MorpheApp/morphe-patches/commit/79148a18ac3d5cadbf08eb26ebb12f0f99477e6b))
* **YouTube - Override YouTube Music buttons:** Song does not open in the music app on Android 10 and lower, and third-party clients open without the song ([#4716](https://github.com/MorpheApp/morphe-patches/issues/4716)) ([e8049df](https://github.com/MorpheApp/morphe-patches/commit/e8049df6fcad053dce5c03afcc0795ac3e1807f5))
* **YouTube - Playback speed:** Holding a Short shows "2x" but keeps the Shorts speed when the tap and hold speed is not 2.0x, and a held Short now plays at the tap and hold speed ([#4684](https://github.com/MorpheApp/morphe-patches/issues/4684)) ([4b87946](https://github.com/MorpheApp/morphe-patches/commit/4b87946e8b52242d8100115353ba96271b5ad1e7))
* **YouTube - Remove background playback restrictions:** Video does not resume when returning to the app if background playback is off in the YouTube settings ([ed10e78](https://github.com/MorpheApp/morphe-patches/commit/ed10e783513eff119b3206c5798798a94aff448f)), closes [#4639](https://github.com/MorpheApp/morphe-patches/issues/4639)
* **YouTube - Restore old video action bar:** Tapping the channel name below the video title opens the channel instead of the description ([93d0d70](https://github.com/MorpheApp/morphe-patches/commit/93d0d701cbc91180162712e9ff6854597fc8ab80))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count of a card that enters the list is missing for a moment when the card showed a live video before ([824eef3](https://github.com/MorpheApp/morphe-patches/commit/824eef3c08953ef97bc40ef81cf827294b09f8b5))
* **YouTube - Seekbar:** "More videos" button in fullscreen does nothing until the device is rotated, after a tap with "Tap to seek" ([#4726](https://github.com/MorpheApp/morphe-patches/issues/4726)) ([00a6293](https://github.com/MorpheApp/morphe-patches/commit/00a6293ab251f301e640ea373189eb3b0659699c))
* **YouTube - Video quality:** Live stream stutters after selecting a quality ([#4262](https://github.com/MorpheApp/morphe-patches/issues/4262)) ([c7d4585](https://github.com/MorpheApp/morphe-patches/commit/c7d458515ae090db77b299984542ba74cf6fcf81))
* **YouTube:** Restore fullscreen landscape on Android 16 ([#4701](https://github.com/MorpheApp/morphe-patches/issues/4701)) ([827d658](https://github.com/MorpheApp/morphe-patches/commit/827d65876fd0e77f7de0a905c2d3f9b9dbc72d98))

## [2.3.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v2.2.0...v2.3.0-dev.1) (2026-11-11)

### ✨ New Features

* **YouTube - Add to queue:** Add queue flyout item to feed Shorts cards, add queue flyout item only if no existing flyout queue exists ([#4686](https://github.com/MorpheApp/morphe-patches/issues/4686)) ([c3ecaeb](https://github.com/MorpheApp/morphe-patches/commit/c3ecaeb59430cc9e168b39c77c8dfb1a56570992))
* **YouTube - Ambient mode:** Add "Dim while scrolling" and "Dim duration" settings to Enhanced Ambient mode ([#4677](https://github.com/MorpheApp/morphe-patches/issues/4677)) ([0ef4a87](https://github.com/MorpheApp/morphe-patches/commit/0ef4a87e28bb6bc66af7a0d40584bf42ea32f430))
* **YouTube - Hide Shorts layout components:** Add "Hide Shorts push notifications" setting ([#4422](https://github.com/MorpheApp/morphe-patches/issues/4422)) ([6236845](https://github.com/MorpheApp/morphe-patches/commit/623684567af0d2b7ae9579366755b86a6dabb5ec))
* **YouTube - Loop count:** Choose how many times a video loops before the next video ([#4516](https://github.com/MorpheApp/morphe-patches/issues/4516)) ([db973d4](https://github.com/MorpheApp/morphe-patches/commit/db973d488d5b14d2d5b8f492c8b77cee29823730))
* **YouTube Music - Enable audio/video switch:** Add "Always play the song version" setting ([#4595](https://github.com/MorpheApp/morphe-patches/issues/4595)) ([69ac226](https://github.com/MorpheApp/morphe-patches/commit/69ac226775c423df0a61886dd8280d600020e6fe))
* **YouTube Music - Hide layout components:** Add "Hide 'You may also like' section" setting ([#4688](https://github.com/MorpheApp/morphe-patches/issues/4688)) ([a5d9266](https://github.com/MorpheApp/morphe-patches/commit/a5d9266c2cf678a1a14ef527cc08c7fabde0bc7e))
* **YouTube Music - Miniplayer :** Add glass miniplayer, independent glass controls, spinning vinyl artwork, and dedicated miniplayer settings screen ([#4621](https://github.com/MorpheApp/morphe-patches/issues/4621)) ([71caa5c](https://github.com/MorpheApp/morphe-patches/commit/71caa5ca85fdad48d06b59fc4d40c83a62551aa3))
* **YouTube Music - Third-party lyrics:** Add spring scroll physics, instrumental gap indicators, retimed sync, and jump to current button ([#4566](https://github.com/MorpheApp/morphe-patches/issues/4566)) ([f202bf3](https://github.com/MorpheApp/morphe-patches/commit/f202bf343d32841a3afa9f1610fb4ad50564c726))
* **YouTube Music:** Add `Disable audio ducking` patch ([#4618](https://github.com/MorpheApp/morphe-patches/issues/4618)) ([963fa87](https://github.com/MorpheApp/morphe-patches/commit/963fa8771d4ccf6bc7470c5b2e06901eacef28cc))

### 🐛 Bug Fixes

* **YouTube - Ambient mode:** Comment box still turns white with Enhanced Ambient mode ([#4633](https://github.com/MorpheApp/morphe-patches/issues/4633)) ([2bde36e](https://github.com/MorpheApp/morphe-patches/commit/2bde36ef46f1f27d5e2fda01e46fce43cc845abc))
* **YouTube - Ambient mode:** Enhanced Ambient mode flickers on some devices ([#4679](https://github.com/MorpheApp/morphe-patches/issues/4679)) ([afc5025](https://github.com/MorpheApp/morphe-patches/commit/afc5025f0c8e3a9baa7fc8290318268b96ad2ce8))
* **YouTube - Ambient mode:** Enhanced Ambient mode stays dark after returning to the app ([#4675](https://github.com/MorpheApp/morphe-patches/issues/4675)) ([840d95d](https://github.com/MorpheApp/morphe-patches/commit/840d95d01064c6dac3d51ff4546b66be55cd9077))
* **YouTube - Custom font:** Custom font is not used by texts without a font of their own, such as the view count below the video title, the comments and the like ratio of the feed ([97560e9](https://github.com/MorpheApp/morphe-patches/commit/97560e94d3aa9cabef28615de371ba5db37fc746))
* **YouTube - Downloads:** Downloaded videos do not allow fullscreen gestures ([#4641](https://github.com/MorpheApp/morphe-patches/issues/4641)) ([133f4a9](https://github.com/MorpheApp/morphe-patches/commit/133f4a9d02a3f9474747ad8654cc4a35fee4fff8))
* **YouTube - Downloads:** Resume downloads from the saved position ([#4600](https://github.com/MorpheApp/morphe-patches/issues/4600)) ([1612c14](https://github.com/MorpheApp/morphe-patches/commit/1612c1465541c1201435d55a8b1c7d679b0a88b9))
* **YouTube - Feed card layout:** Horizontal shelves, such as the history of the You tab, are shown without the padding of the cards for a moment, also when they are loaded again ([1ede8f3](https://github.com/MorpheApp/morphe-patches/commit/1ede8f3d14c596d43478b2c8c2060abef70dc911))
* **YouTube - Feed card layout:** Shorts shelf of the channel home is not drawn as a card, the shelves of the channel home do not have the spacing of the cards of the feed, and shelf headers lose the background of the card while partly scrolled out of the list ([12ad18e](https://github.com/MorpheApp/morphe-patches/commit/12ad18e41622007028f04253f40ee07d907e6a4a))
* **YouTube - Feed video actions:** Watch later button of the previous video is shown on a card that the list reuses for another video or a row of Shorts, until its texts are shown ([01b2be4](https://github.com/MorpheApp/morphe-patches/commit/01b2be43a658d62de7812b9211aa909e55c58c8f))
* **YouTube - Feed view count:** View count badge of a card that enters from the bottom shows a loading spinner until the texts below the title are shown, when the feed has no separate view count text ([3b67c64](https://github.com/MorpheApp/morphe-patches/commit/3b67c64785c270a4b555ea6b429931514542e8b2))
* **YouTube - Hide ads:** Video does not start when the player waits for a pre-roll ad ([#4670](https://github.com/MorpheApp/morphe-patches/issues/4670)) ([aec3865](https://github.com/MorpheApp/morphe-patches/commit/aec386556c4e92a5e463d57cf45ef92e4dda6743))
* **YouTube - Litho filter:** After a filtered Short is removed from a grid of Shorts, the Shorts after it keep the spacing of their old column ([9dafd8d](https://github.com/MorpheApp/morphe-patches/commit/9dafd8db5de1ebf7eed49d79998a23da7a7d2106))
* **YouTube - Navigation bar:** "Hide in feeds" of the filter bar does not hide the filters of Home with the layout that shows Subscriptions as a tab at the top of Home ([650f084](https://github.com/MorpheApp/morphe-patches/commit/650f0847a632a3b1d70478c3e10f4183ae2aefda))
* **YouTube - Navigation bar:** "Hide in feeds" of the filter bar still does not hide the category tabs of Home, because they also open the Home feed ([576f7c6](https://github.com/MorpheApp/morphe-patches/commit/576f7c6186deb6cb777d977d1b0676437deef15d))
* **YouTube - Navigation bar:** Filters of Home are missing with the layout that shows Subscriptions as a tab at the top of Home ([530a26a](https://github.com/MorpheApp/morphe-patches/commit/530a26aba4bd1f042fe17ca9dbbc59f446f86e6e))
* **YouTube - Playback in feeds:** Keep an imported mode instead of copying the app's mode back on the next start ([#4657](https://github.com/MorpheApp/morphe-patches/issues/4657)) ([09d9ad2](https://github.com/MorpheApp/morphe-patches/commit/09d9ad22b9e7d7c17fdf757720595e3edff8f25d))
* **YouTube - Remove background playback restrictions:** Playback notification can be missing and the audio stops in the background when the video thumbnail is not loaded ([e7dabdf](https://github.com/MorpheApp/morphe-patches/commit/e7dabdf40f8dd530f21db7ba76ed694d676c62b1))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count of a card that enters from the bottom is shown only once the texts below its thumbnail are shown ([338e97e](https://github.com/MorpheApp/morphe-patches/commit/338e97e14063dcae024bc2b8bbbfd8f7d3d855be))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count of a Short that is partly shown waits for the title of the Short, which is drawn last; it is now placed without the title ([f28bbfe](https://github.com/MorpheApp/morphe-patches/commit/f28bbfe177ec9f183981a7b384d7afac53047dba))
* **YouTube - Spoof video streams:** Only shorten stream ranges for PriorityDataSource transfers ([#4638](https://github.com/MorpheApp/morphe-patches/issues/4638)) ([e85a558](https://github.com/MorpheApp/morphe-patches/commit/e85a55853f15e5c5c2245e8fbcbdd766d932740a))
* **YouTube - Spoof video streams:** Resolve error message of "isOfflinePlayerResponse failure" ([171d6ad](https://github.com/MorpheApp/morphe-patches/commit/171d6adf91c9b58f1d874255ea4a3d5d447027ce))
* **YouTube Music - Crossfade:** Equalizer apps detach from the outgoing track during the fade ([#4622](https://github.com/MorpheApp/morphe-patches/issues/4622)) ([0618b8d](https://github.com/MorpheApp/morphe-patches/commit/0618b8d6f3087dcd01bd6d69f156f6859fcd008c))
* **YouTube Music - Crossfade:** Volume normalization is lost after a crossfade ([#4629](https://github.com/MorpheApp/morphe-patches/issues/4629)) ([c359b45](https://github.com/MorpheApp/morphe-patches/commit/c359b451a3419878de704d59cd85b6cc1cf6c4d8))
* **YouTube Music - Downloads:** Some playlists cannot be downloaded in-app ([#4665](https://github.com/MorpheApp/morphe-patches/issues/4665)) ([8e02565](https://github.com/MorpheApp/morphe-patches/commit/8e0256593281e70947828750c6966e9112250359))
* **YouTube Music - Enable audio/video switch:** Toggle opens a Mix or switches to the wrong song ([#4594](https://github.com/MorpheApp/morphe-patches/issues/4594)) ([e42c32d](https://github.com/MorpheApp/morphe-patches/commit/e42c32d1225b401d7d70bed49f7bdf10bc387d45))
* **YouTube Music - Third-party lyrics:** Downloads patch breaks YouTube Music lyrics ([#4673](https://github.com/MorpheApp/morphe-patches/issues/4673)) ([abf0dd2](https://github.com/MorpheApp/morphe-patches/commit/abf0dd2e483ca3f45f54ecedf10751d8bad536c5))

## [2.2.0](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0...v2.2.0) (2026-11-10)

### ✨ New Features

* Add "Show in-app notification for patch updates" setting ([#4178](https://github.com/MorpheApp/morphe-patches/issues/4178)) ([c8741dd](https://github.com/MorpheApp/morphe-patches/commit/c8741dd7b49ddb7ed322393efa3df06f5a25807f))
* **Debugging:** Add verbose debug logging setting ([#4547](https://github.com/MorpheApp/morphe-patches/issues/4547)) ([ae2f2e0](https://github.com/MorpheApp/morphe-patches/commit/ae2f2e08a210ff29bd9cd017f3bd10a965876a81))
* **Reddit:** Add `High quality avatars` patch ([#4477](https://github.com/MorpheApp/morphe-patches/issues/4477)) ([1f00c87](https://github.com/MorpheApp/morphe-patches/commit/1f00c87d284c19d962371943637e85770a12b8e7))
* **YouTube - Add to queue:** Enhance native playlist support ([#4404](https://github.com/MorpheApp/morphe-patches/issues/4404)) ([c1f633c](https://github.com/MorpheApp/morphe-patches/commit/c1f633c3b27729b514c3679a150ef48f6459a866))
* **YouTube - Ambient mode:** Add "Enhanced Ambient mode" setting ([#4576](https://github.com/MorpheApp/morphe-patches/issues/4576)) ([0eb6a0a](https://github.com/MorpheApp/morphe-patches/commit/0eb6a0a73471b4a7804a5c358d2ab7bf29bed595))
* **YouTube - Disable continue watching prompt:** Replace the setting with "'Continue watching?' prompt", with a mode that always shows the autoplay countdown at the end of the video ([772363e](https://github.com/MorpheApp/morphe-patches/commit/772363e4b2f94dc8f166c43fe29b6cea4a536e2e))
* **YouTube - Keyword content filter:** Filter videos/comments with more precision, simplify keyword declaration, fix certain keywords incorrectly hiding all videos ([#4530](https://github.com/MorpheApp/morphe-patches/issues/4530)) ([d238387](https://github.com/MorpheApp/morphe-patches/commit/d2383876134056f94d293c1253bf0d68da355f4a))
* **YouTube - Niconico comments:** Add "Show in portrait" and "Separate settings for portrait" settings ([#4515](https://github.com/MorpheApp/morphe-patches/issues/4515)) ([c6097b3](https://github.com/MorpheApp/morphe-patches/commit/c6097b373ee5f095f1d5417d3f465883454e3c4f))
* **YouTube - Niconico comments:** Add Reset confirmation and settings button to quick settings ([#4543](https://github.com/MorpheApp/morphe-patches/issues/4543)) ([310b0d4](https://github.com/MorpheApp/morphe-patches/commit/310b0d4d22851a7ed11979b09b2f06de5ce08134))
* **YouTube - Niconico comments:** Keep comments from running into each other ([#4497](https://github.com/MorpheApp/morphe-patches/issues/4497)) ([cf20941](https://github.com/MorpheApp/morphe-patches/commit/cf209419a0d34d528e31919c7e5c2d55c7da2f95))
* **YouTube - On-the-go player:** Show On-the-go lock screen controls ([#4570](https://github.com/MorpheApp/morphe-patches/issues/4570)) ([9d173c6](https://github.com/MorpheApp/morphe-patches/commit/9d173c6e5f006392855745321fae9f2eaffed128))
* **YouTube - Playlist improvements:** Extend refinements to all playlists and add long-press reordering ([#4584](https://github.com/MorpheApp/morphe-patches/issues/4584)) ([8784dab](https://github.com/MorpheApp/morphe-patches/commit/8784dab04c1072b09eb84ac16f87695165d1da4c))
* **YouTube - Return YouTube Dislike:** Show the feed thumbnail like count at the top left of the thumbnail ([7aede05](https://github.com/MorpheApp/morphe-patches/commit/7aede054815aab155d3dcf034863e7eb6128578f))
* **YouTube - Spoof video streams:** Add "Android VR Experimental" client, which uses the latest Android VR app version ([59262c1](https://github.com/MorpheApp/morphe-patches/commit/59262c14f25029e5e23704d47c97d097a7045410))
* **YouTube Music - Navigation bar:** Add "Glass navigation bar" setting ([#4542](https://github.com/MorpheApp/morphe-patches/issues/4542)) ([8b3c1da](https://github.com/MorpheApp/morphe-patches/commit/8b3c1da5a699f362e6b0d046360a32f50c0e8d5b))
* **YouTube Music - Third-party lyrics:** Lyrics panel detection various fixes ([#4562](https://github.com/MorpheApp/morphe-patches/issues/4562)) ([9bb5b73](https://github.com/MorpheApp/morphe-patches/commit/9bb5b73de923fc5ffe307a7e68b5ddfb2c31b553))
* **YouTube Music - Third-party lyrics:** ttml, ruby, romanization enhancement ([#4439](https://github.com/MorpheApp/morphe-patches/issues/4439)) ([c7c8bb7](https://github.com/MorpheApp/morphe-patches/commit/c7c8bb728cfc43dfa9abaeb572f878fb7a2099af))
* **YouTube:** Add "Custom seekbar thumb" setting ([#4494](https://github.com/MorpheApp/morphe-patches/issues/4494)) ([abcc9b1](https://github.com/MorpheApp/morphe-patches/commit/abcc9b18e4c6bb0d4d398a261ca8336d25cf5eb6))
* **YouTube:** Add `On-the-go player` patch ([#4511](https://github.com/MorpheApp/morphe-patches/issues/4511)) ([18374c0](https://github.com/MorpheApp/morphe-patches/commit/18374c09c9766ecddfa454017d21f6b9322ef89a))

### 🐛 Bug Fixes

* **Spoof video streams:** "OAuth2 is temporarily not available" toast when the app starts before the network is ready with Android VR ([77a4626](https://github.com/MorpheApp/morphe-patches/commit/77a462669134df8f1162530bd5173b4e726adac0))
* **Spoof video streams:** Android VR buffers more before starting a video than the app player config ([369f555](https://github.com/MorpheApp/morphe-patches/commit/369f555c10d1ac4e7565131abbd2267fde4d193e))
* **Spoof video streams:** First video after app launch, or a video that falls back to another client, starts slowly while the JavaScript engine, access token, and visitor id are prepared ([75a14c7](https://github.com/MorpheApp/morphe-patches/commit/75a14c78dee1e7ac93f3d8a63ab7798b8a47e81d))
* **Spoof video streams:** Playback freezes if the server sends a SABR error instead of a stream range ([#4538](https://github.com/MorpheApp/morphe-patches/issues/4538)) ([256dc71](https://github.com/MorpheApp/morphe-patches/commit/256dc712122fdfee7cae04cbab7f76e20176d2e8))
* **YouTube - Add to queue:** Turning off "Override feed flyout queue button" is lost after it was replaced by "Play next in queue type" ([fb5cf05](https://github.com/MorpheApp/morphe-patches/commit/fb5cf051f0dce6bf7751e3f57faa0a7d912b1d00))
* **YouTube - Ambient mode:** Black band under the player after the page scrolls ([#4610](https://github.com/MorpheApp/morphe-patches/issues/4610)) ([8789c82](https://github.com/MorpheApp/morphe-patches/commit/8789c82dea8c4e246274149ce51195b2ec033eb8))
* **YouTube - Ambient mode:** Comment box turns white with Enhanced Ambient mode ([#4603](https://github.com/MorpheApp/morphe-patches/issues/4603)) ([45a0312](https://github.com/MorpheApp/morphe-patches/commit/45a0312b765192f9ae27170332ef2efd6f154f0d))
* **YouTube - Ambient mode:** With "Enhanced Ambient mode", the cards of "Feed card layout" are partly translucent and the list shows through the sticky filter chips ([ee7199b](https://github.com/MorpheApp/morphe-patches/commit/ee7199bb6cd12cedc6a539044643835a57c7b25f))
* **YouTube - Ask flyout menu:** Select suggestions with negative IDs ([#4496](https://github.com/MorpheApp/morphe-patches/issues/4496)) ([cd29774](https://github.com/MorpheApp/morphe-patches/commit/cd29774fcaddf138038dfc1137c4c5526d223b8a))
* **YouTube - Change form factor:** Home feed turns into a list on tablets with the Phone device layout on 21.30+ ([#4545](https://github.com/MorpheApp/morphe-patches/issues/4545)) ([b6c8204](https://github.com/MorpheApp/morphe-patches/commit/b6c8204d5c2db718a9e31be27fc2836ec0f62050))
* **YouTube - Disable double tap actions:** Two-finger double tap seeks instead of skipping chapters on 21.11+ ([bf91aa5](https://github.com/MorpheApp/morphe-patches/commit/bf91aa5a39b243b3fff31eba1c6b11201b1ea8fb))
* **YouTube - Disable double tap actions:** Two-finger double tap seeks instead of skipping chapters on accounts whose server config turns the chapter skip off ([6bdf46e](https://github.com/MorpheApp/morphe-patches/commit/6bdf46e6f12da2a73481b4ba4a4bda2e74dd4be9))
* **YouTube - Disable fullscreen gestures:** Pinch-to-zoom takes the two finger double tap that skips chapters ([48592df](https://github.com/MorpheApp/morphe-patches/commit/48592dffca8418f95093bb13b6d8d9b43c98ed6a))
* **YouTube - Disable video codecs:** Use VP9 codec by default for devices that lack AV1 hardware decoding ([a23110e](https://github.com/MorpheApp/morphe-patches/commit/a23110e2ae67bccc3c4462a8cc50c331d2e67d5d))
* **YouTube - Feed card layout:** Cards sometimes go back to the classic layout while the app rewrites its template cache ([240377e](https://github.com/MorpheApp/morphe-patches/commit/240377efe966a990fb6d82e9ac2df93bdc77c833))
* **YouTube - Feed card layout:** Playlist and podcast shelves of the channel home are not drawn as cards ([a483420](https://github.com/MorpheApp/morphe-patches/commit/a4834205e6de9a76f1bfbf9f032f822ac39d61e0))
* **YouTube - Feed card layout:** Replies of the comments opened from the cards do not open ([23c7d1d](https://github.com/MorpheApp/morphe-patches/commit/23c7d1d9942d571f65d34466a69adc2073f39d87))
* **YouTube - Feed view count:** View count badge flashes on the Shorts of the search results while they scroll into view ([5999bde](https://github.com/MorpheApp/morphe-patches/commit/5999bde01cca71dc03a05071a7fc0428618d8b86))
* **YouTube - GmsCore support:** Bedtime and break reminders turn on again after switching account or clearing app data, as every account is treated as a teen account ([a64cecc](https://github.com/MorpheApp/morphe-patches/commit/a64cecc3a3258ae3c88e36c4ae111aed7f1e351d))
* **YouTube - GmsCore support:** Every account gets the bedtime, break and Shorts feed limit reminders of a supervised account ([4011b15](https://github.com/MorpheApp/morphe-patches/commit/4011b15b9c4c461c9971cf1896e205bb60bae1fa))
* **YouTube - Hide layout components:** "Channel tab filter" with the Home tab leaves the Home feed blank on 21.44+ ([b02995c](https://github.com/MorpheApp/morphe-patches/commit/b02995c93cd94d92a766bed41c81be94b2361983))
* **YouTube - Hide layout components:** "Hide channel bar" leaves an empty bordered box in the fullscreen engagement panel ([dd40ae2](https://github.com/MorpheApp/morphe-patches/commit/dd40ae2b8762e95958443f02d1a2bf797811648a))
* **YouTube - Hide layout components:** "Hide channel buttons" does not hide the YouTube Music banner of a channel in the search results with the Automotive device layout ([9afdd0f](https://github.com/MorpheApp/morphe-patches/commit/9afdd0f8c1f9981fd554f32d6d379ca46b924193))
* **YouTube - Hide layout components:** "Hide feed flyout menu" leaves empty rows in the popup menus and does not hide the items of the toolbar menu, such as on a playlist page ([b492056](https://github.com/MorpheApp/morphe-patches/commit/b4920563a857b58b1fb1d150fd2da63ad9b31aff))
* **YouTube - Hide layout components:** Keyword filter hides every comment when a keyword is also a text of the comment section, such as "AI" ([acb4e58](https://github.com/MorpheApp/morphe-patches/commit/acb4e5839e6e10f7b1d39d08008d221a4455f76c))
* **YouTube - Hide layout components:** Post content disappears after tapping "Read more" ([#4563](https://github.com/MorpheApp/morphe-patches/issues/4563)) ([f7b7c07](https://github.com/MorpheApp/morphe-patches/commit/f7b7c0708b9c2046b895de8a390ab52d62141e5b))
* **YouTube - Hide player flyout menu components:** "Additional settings", "Ambient mode", "Stable volume" and "Listen with YouTube Music" items are not hidden when their icon has no name in the buffer ([0031ac6](https://github.com/MorpheApp/morphe-patches/commit/0031ac6e6d2bb2619967f2f88ab9060cffd840db))
* **YouTube - Hide player flyout menu components:** "Hide 'On-the-go' menu" does not work on 21.x ([e6c1ce2](https://github.com/MorpheApp/morphe-patches/commit/e6c1ce2fe53f8990746e6fdf058b6e146632b37b))
* **YouTube - Hide video action buttons:** "Hide Ask button" does not hide the Ask button of the portrait action bar ([e022ec5](https://github.com/MorpheApp/morphe-patches/commit/e022ec5af430a54b87479c4ec6f8e818da059db5))
* **YouTube - Morphe snackbar:** Reduced snackbar queue timeout to 3 seconds ([75ce67c](https://github.com/MorpheApp/morphe-patches/commit/75ce67c4151066f6441410e5bf8e4b9a9094ace5))
* **YouTube - Navigation bar:** "Hide Microphone button" does not hide the microphone of the Home search bar ([a184951](https://github.com/MorpheApp/morphe-patches/commit/a184951b4377a5182eb3dd26a34c5c23e1aade86))
* **YouTube - Navigation bar:** Glass navigation bar cuts the first and the last button on tablets, where the buttons have a minimum width ([88d4844](https://github.com/MorpheApp/morphe-patches/commit/88d4844e7886d27e0d2c3719c8f61589ca81a7a1))
* **YouTube - Navigation bar:** Incognito and connection status bar covers the bottom edge of the glass navigation bar ([711afdd](https://github.com/MorpheApp/morphe-patches/commit/711afdd57087ab18724dda359b554f8c7a56f124))
* **YouTube - Niconico comments:** Chat status messages are shown as comments ([#4499](https://github.com/MorpheApp/morphe-patches/issues/4499)) ([241100c](https://github.com/MorpheApp/morphe-patches/commit/241100c448e4f9a2397137967fcf81bbe43e647e))
* **YouTube - On-the-go player:** Dismiss player flyout menu when On-the-go item is selected ([#4631](https://github.com/MorpheApp/morphe-patches/issues/4631)) ([bc2c21c](https://github.com/MorpheApp/morphe-patches/commit/bc2c21c4733a915312c3e33007171e51bd6e92b2))
* **YouTube - On-the-go player:** Seekbar thumb is cut off at the start and end of the video ([e85b5f0](https://github.com/MorpheApp/morphe-patches/commit/e85b5f03e186e8bdafee4df77e73ba1115388482))
* **YouTube - Open system share sheet:** Playing video enters picture-in-picture when the share sheet opens, and Mixes are shared with a link that does not open ([59e9e83](https://github.com/MorpheApp/morphe-patches/commit/59e9e831d4e74d185cd1f2d74fdf5b6b68f814a0))
* **YouTube - Restore old video action bar:** The like button has no icon with the chosen "Video action bar layout", and buttons sent without an icon now use the icon the server sent before or the app icon ([62e68ad](https://github.com/MorpheApp/morphe-patches/commit/62e68add1ff586f1947b6bcb59dc415fd652fb45))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like and view counts are missing on Shorts cards, and the like count is missing on the watch history ([8238200](https://github.com/MorpheApp/morphe-patches/commit/8238200a3f738e26d212045e07fd53b96e072403))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like and view counts are sometimes missing when the card or the vote fetch is slow ([9f947b5](https://github.com/MorpheApp/morphe-patches/commit/9f947b591854ad90f1c9d6496b68d1961b748595))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on cards with the thumbnail beside the texts, such as the search results on tablets ([0a1a178](https://github.com/MorpheApp/morphe-patches/commit/0a1a1786224293b1a70e0db06df90093668dea06))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the cards of grid rows, such as the channel pages and the feed on tablets ([3e24ded](https://github.com/MorpheApp/morphe-patches/commit/3e24ded40baddb084bcd81822102bdb57eff723a))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the small thumbnails of list rows, such as the channel videos on phones ([342c1a9](https://github.com/MorpheApp/morphe-patches/commit/342c1a9c57e2c7f2033155c5bbd4f53c23ac74d2))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the videos of rows that show many videos in one element, such as the Videos and Live tabs of a channel ([bd94959](https://github.com/MorpheApp/morphe-patches/commit/bd9495981bf36c273f3d6785ad93b0a9f4040da6))
* **YouTube - Seekbar:** Full screen seek preview does not cover the sides of a video zoomed to fill the screen ([4e83c67](https://github.com/MorpheApp/morphe-patches/commit/4e83c6722ff069dcf594453111ad63e7c0b617e4))
* **YouTube - Seekbar:** Seek preview shows a strip of the previous frame on its left side, which grows and shrinks while seeking ([ae97c40](https://github.com/MorpheApp/morphe-patches/commit/ae97c40ed423f19492668676bd1713c64fab1c76))
* **YouTube - Settings:** App crashes when opening the settings on 21.45, which reuses the registers the settings hooks read the fragment from ([61be996](https://github.com/MorpheApp/morphe-patches/commit/61be99601a35f6282b85923e878debd207de9108))
* **YouTube - SponsorBlock:** Video does not end after a segment at the end of the video is skipped ([4c7a0c2](https://github.com/MorpheApp/morphe-patches/commit/4c7a0c2d10a11e97e7bfa2113c6beeb552a90c54))
* **YouTube - Swipe controls:** Autoplay stops at the end screen after using only swipe controls or volume keys in fullscreen ([7004af9](https://github.com/MorpheApp/morphe-patches/commit/7004af9cbb0244ed7a4b8951b1376e02e703b40b))
* **YouTube Music - Downloads:** Match the renamed page header of older versions ([#4503](https://github.com/MorpheApp/morphe-patches/issues/4503)) ([1822fd7](https://github.com/MorpheApp/morphe-patches/commit/1822fd74e931d604b5085b4ed1932ddd1498c691))
* **YouTube Music - Theme:** Bottom sheets do not follow theme ([bc81be7](https://github.com/MorpheApp/morphe-patches/commit/bc81be76d80d1fcbd453ff90580c53e0d69e0939))
* **YouTube Music - Third-party lyrics:** LRC lyrics with line timestamps detected as unsynchronized ([#4611](https://github.com/MorpheApp/morphe-patches/issues/4611)) ([219265e](https://github.com/MorpheApp/morphe-patches/commit/219265e52e6383d53438989901bac3c69a25d2bf))
* **YouTube Music - Third-party lyrics:** Resolve build, lint, and static analysis warnings ([c5da4c6](https://github.com/MorpheApp/morphe-patches/commit/c5da4c673399deb4ae4629b5fd6979d1e0e2221a))
* **YouTube Music:** Resolve lyrics panel, button, and translation language/locale failures ([#4552](https://github.com/MorpheApp/morphe-patches/issues/4552)) ([5df3d94](https://github.com/MorpheApp/morphe-patches/commit/5df3d94b445f225f4903eeee07809af26fe2fa84))
* **YouTube:** App crash when patching `21.28.208` ([bdeda41](https://github.com/MorpheApp/morphe-patches/commit/bdeda410c0337d8043e03b8fa67c0881dabd30d1))
* **YouTube:** Patches fail to read the watch next response after other patches change it in place, playlist requests reuse failed results, network failures show error toasts, and clean up unused, duplicated and one-caller code ([2705d3a](https://github.com/MorpheApp/morphe-patches/commit/2705d3a85639d5be746c86eb16dd8695804abf8f))
* **YouTube:** The second feature flag that hides the navigation bar while the keyboard is open is not turned off, so pages keep its wrong padding ([2a01da0](https://github.com/MorpheApp/morphe-patches/commit/2a01da0ab5a6099a6c6d1f9995e826532cd36f6e))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.45.51` ([bd5baed](https://github.com/MorpheApp/morphe-patches/commit/bd5baedb2ca4321d7752f7a3f6894515af459321))
* **YouTube:** Add experimental support for `21.45.82` ([6896a6b](https://github.com/MorpheApp/morphe-patches/commit/6896a6bc4a0878ac9a586471df58e6617d97de07))

## [2.2.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v2.2.0-dev.4...v2.2.0-dev.5) (2026-11-10)

### ✨ New Features

* **Debugging:** Add verbose debug logging setting ([#4547](https://github.com/MorpheApp/morphe-patches/issues/4547)) ([ae2f2e0](https://github.com/MorpheApp/morphe-patches/commit/ae2f2e08a210ff29bd9cd017f3bd10a965876a81))
* **YouTube - Disable continue watching prompt:** Replace the setting with "'Continue watching?' prompt", with a mode that always shows the autoplay countdown at the end of the video ([772363e](https://github.com/MorpheApp/morphe-patches/commit/772363e4b2f94dc8f166c43fe29b6cea4a536e2e))
* **YouTube - Spoof video streams:** Add "Android VR Experimental" client, which uses the latest Android VR app version ([59262c1](https://github.com/MorpheApp/morphe-patches/commit/59262c14f25029e5e23704d47c97d097a7045410))

### 🐛 Bug Fixes

* **Spoof video streams:** "OAuth2 is temporarily not available" toast when the app starts before the network is ready with Android VR ([77a4626](https://github.com/MorpheApp/morphe-patches/commit/77a462669134df8f1162530bd5173b4e726adac0))
* **Spoof video streams:** Android VR buffers more before starting a video than the app player config ([369f555](https://github.com/MorpheApp/morphe-patches/commit/369f555c10d1ac4e7565131abbd2267fde4d193e))
* **Spoof video streams:** First video after app launch, or a video that falls back to another client, starts slowly while the JavaScript engine, access token, and visitor id are prepared ([75a14c7](https://github.com/MorpheApp/morphe-patches/commit/75a14c78dee1e7ac93f3d8a63ab7798b8a47e81d))
* **YouTube - Ambient mode:** Black band under the player after the page scrolls ([#4610](https://github.com/MorpheApp/morphe-patches/issues/4610)) ([8789c82](https://github.com/MorpheApp/morphe-patches/commit/8789c82dea8c4e246274149ce51195b2ec033eb8))
* **YouTube - Ambient mode:** Comment box turns white with Enhanced Ambient mode ([#4603](https://github.com/MorpheApp/morphe-patches/issues/4603)) ([45a0312](https://github.com/MorpheApp/morphe-patches/commit/45a0312b765192f9ae27170332ef2efd6f154f0d))
* **YouTube - Ambient mode:** With "Enhanced Ambient mode", the cards of "Feed card layout" are partly translucent and the list shows through the sticky filter chips ([ee7199b](https://github.com/MorpheApp/morphe-patches/commit/ee7199bb6cd12cedc6a539044643835a57c7b25f))
* **YouTube - Hide layout components:** "Channel tab filter" with the Home tab leaves the Home feed blank on 21.44+ ([b02995c](https://github.com/MorpheApp/morphe-patches/commit/b02995c93cd94d92a766bed41c81be94b2361983))
* **YouTube - Hide video action buttons:** "Hide Ask button" does not hide the Ask button of the portrait action bar ([e022ec5](https://github.com/MorpheApp/morphe-patches/commit/e022ec5af430a54b87479c4ec6f8e818da059db5))
* **YouTube - SponsorBlock:** Video does not end after a segment at the end of the video is skipped ([4c7a0c2](https://github.com/MorpheApp/morphe-patches/commit/4c7a0c2d10a11e97e7bfa2113c6beeb552a90c54))
* **YouTube Music - Third-party lyrics:** LRC lyrics with line timestamps detected as unsynchronized ([#4611](https://github.com/MorpheApp/morphe-patches/issues/4611)) ([219265e](https://github.com/MorpheApp/morphe-patches/commit/219265e52e6383d53438989901bac3c69a25d2bf))

## [2.2.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v2.2.0-dev.3...v2.2.0-dev.4) (2026-11-09)

### 🐛 Bug Fixes

* **YouTube:** App crash when patching `21.28.208` ([bdeda41](https://github.com/MorpheApp/morphe-patches/commit/bdeda410c0337d8043e03b8fa67c0881dabd30d1))

## [2.2.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v2.2.0-dev.2...v2.2.0-dev.3) (2026-11-09)

### ✨ New Features

* **YouTube - Add to queue:** Enhance native playlist support ([#4404](https://github.com/MorpheApp/morphe-patches/issues/4404)) ([c1f633c](https://github.com/MorpheApp/morphe-patches/commit/c1f633c3b27729b514c3679a150ef48f6459a866))
* **YouTube - Ambient mode:** Add "Enhanced Ambient mode" setting ([#4576](https://github.com/MorpheApp/morphe-patches/issues/4576)) ([0eb6a0a](https://github.com/MorpheApp/morphe-patches/commit/0eb6a0a73471b4a7804a5c358d2ab7bf29bed595))
* **YouTube - On-the-go player:** Show On-the-go lock screen controls ([#4570](https://github.com/MorpheApp/morphe-patches/issues/4570)) ([9d173c6](https://github.com/MorpheApp/morphe-patches/commit/9d173c6e5f006392855745321fae9f2eaffed128))
* **YouTube - Playlist improvements:** Extend refinements to all playlists and add long-press reordering ([#4584](https://github.com/MorpheApp/morphe-patches/issues/4584)) ([8784dab](https://github.com/MorpheApp/morphe-patches/commit/8784dab04c1072b09eb84ac16f87695165d1da4c))
* **YouTube - Return YouTube Dislike:** Show the feed thumbnail like count at the top left of the thumbnail ([7aede05](https://github.com/MorpheApp/morphe-patches/commit/7aede054815aab155d3dcf034863e7eb6128578f))
* **YouTube Music - Third-party lyrics:** Lyrics panel detection various fixes ([#4562](https://github.com/MorpheApp/morphe-patches/issues/4562)) ([9bb5b73](https://github.com/MorpheApp/morphe-patches/commit/9bb5b73de923fc5ffe307a7e68b5ddfb2c31b553))

### 🐛 Bug Fixes

* **YouTube - Disable fullscreen gestures:** Pinch-to-zoom takes the two finger double tap that skips chapters ([48592df](https://github.com/MorpheApp/morphe-patches/commit/48592dffca8418f95093bb13b6d8d9b43c98ed6a))
* **YouTube - Feed card layout:** Playlist and podcast shelves of the channel home are not drawn as cards ([a483420](https://github.com/MorpheApp/morphe-patches/commit/a4834205e6de9a76f1bfbf9f032f822ac39d61e0))
* **YouTube - Feed card layout:** Replies of the comments opened from the cards do not open ([23c7d1d](https://github.com/MorpheApp/morphe-patches/commit/23c7d1d9942d571f65d34466a69adc2073f39d87))
* **YouTube - Feed view count:** View count badge flashes on the Shorts of the search results while they scroll into view ([5999bde](https://github.com/MorpheApp/morphe-patches/commit/5999bde01cca71dc03a05071a7fc0428618d8b86))
* **YouTube - Hide layout components:** Post content disappears after tapping "Read more" ([#4563](https://github.com/MorpheApp/morphe-patches/issues/4563)) ([f7b7c07](https://github.com/MorpheApp/morphe-patches/commit/f7b7c0708b9c2046b895de8a390ab52d62141e5b))
* **YouTube - On-the-go player:** Seekbar thumb is cut off at the start and end of the video ([e85b5f0](https://github.com/MorpheApp/morphe-patches/commit/e85b5f03e186e8bdafee4df77e73ba1115388482))
* **YouTube - Restore old video action bar:** The like button has no icon with the chosen "Video action bar layout", and buttons sent without an icon now use the icon the server sent before or the app icon ([62e68ad](https://github.com/MorpheApp/morphe-patches/commit/62e68add1ff586f1947b6bcb59dc415fd652fb45))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like and view counts are missing on Shorts cards, and the like count is missing on the watch history ([8238200](https://github.com/MorpheApp/morphe-patches/commit/8238200a3f738e26d212045e07fd53b96e072403))
* **YouTube - Swipe controls:** Autoplay stops at the end screen after using only swipe controls or volume keys in fullscreen ([7004af9](https://github.com/MorpheApp/morphe-patches/commit/7004af9cbb0244ed7a4b8951b1376e02e703b40b))
* **YouTube Music - Theme:** Bottom sheets do not follow theme ([bc81be7](https://github.com/MorpheApp/morphe-patches/commit/bc81be76d80d1fcbd453ff90580c53e0d69e0939))
* **YouTube Music - Third-party lyrics:** Resolve build, lint, and static analysis warnings ([c5da4c6](https://github.com/MorpheApp/morphe-patches/commit/c5da4c673399deb4ae4629b5fd6979d1e0e2221a))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.45.82` ([6896a6b](https://github.com/MorpheApp/morphe-patches/commit/6896a6bc4a0878ac9a586471df58e6617d97de07))

## [2.2.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v2.2.0-dev.1...v2.2.0-dev.2) (2026-11-08)

### ✨ New Features

* Add "Show in-app notification for patch updates" setting ([#4178](https://github.com/MorpheApp/morphe-patches/issues/4178)) ([c8741dd](https://github.com/MorpheApp/morphe-patches/commit/c8741dd7b49ddb7ed322393efa3df06f5a25807f))
* **YouTube - Keyword content filter:** Filter videos/comments with more precision, simplify keyword declaration, fix certain keywords incorrectly hiding all videos ([#4530](https://github.com/MorpheApp/morphe-patches/issues/4530)) ([d238387](https://github.com/MorpheApp/morphe-patches/commit/d2383876134056f94d293c1253bf0d68da355f4a))
* **YouTube - Niconico comments:** Add "Show in portrait" and "Separate settings for portrait" settings ([#4515](https://github.com/MorpheApp/morphe-patches/issues/4515)) ([c6097b3](https://github.com/MorpheApp/morphe-patches/commit/c6097b373ee5f095f1d5417d3f465883454e3c4f))
* **YouTube - Niconico comments:** Add Reset confirmation and settings button to quick settings ([#4543](https://github.com/MorpheApp/morphe-patches/issues/4543)) ([310b0d4](https://github.com/MorpheApp/morphe-patches/commit/310b0d4d22851a7ed11979b09b2f06de5ce08134))
* **YouTube Music - Navigation bar:** Add "Glass navigation bar" setting ([#4542](https://github.com/MorpheApp/morphe-patches/issues/4542)) ([8b3c1da](https://github.com/MorpheApp/morphe-patches/commit/8b3c1da5a699f362e6b0d046360a32f50c0e8d5b))
* **YouTube:** Add `On-the-go player` patch ([#4511](https://github.com/MorpheApp/morphe-patches/issues/4511)) ([18374c0](https://github.com/MorpheApp/morphe-patches/commit/18374c09c9766ecddfa454017d21f6b9322ef89a))

### 🐛 Bug Fixes

* **Spoof video streams:** Playback freezes if the server sends a SABR error instead of a stream range ([#4538](https://github.com/MorpheApp/morphe-patches/issues/4538)) ([256dc71](https://github.com/MorpheApp/morphe-patches/commit/256dc712122fdfee7cae04cbab7f76e20176d2e8))
* **YouTube - Change form factor:** Home feed turns into a list on tablets with the Phone device layout on 21.30+ ([#4545](https://github.com/MorpheApp/morphe-patches/issues/4545)) ([b6c8204](https://github.com/MorpheApp/morphe-patches/commit/b6c8204d5c2db718a9e31be27fc2836ec0f62050))
* **YouTube - Disable double tap actions:** Two-finger double tap seeks instead of skipping chapters on accounts whose server config turns the chapter skip off ([6bdf46e](https://github.com/MorpheApp/morphe-patches/commit/6bdf46e6f12da2a73481b4ba4a4bda2e74dd4be9))
* **YouTube - Disable video codecs:** Use VP9 codec by default for devices that lack AV1 hardware decoding ([a23110e](https://github.com/MorpheApp/morphe-patches/commit/a23110e2ae67bccc3c4462a8cc50c331d2e67d5d))
* **YouTube - Feed card layout:** Cards sometimes go back to the classic layout while the app rewrites its template cache ([240377e](https://github.com/MorpheApp/morphe-patches/commit/240377efe966a990fb6d82e9ac2df93bdc77c833))
* **YouTube - GmsCore support:** Bedtime and break reminders turn on again after switching account or clearing app data, as every account is treated as a teen account ([a64cecc](https://github.com/MorpheApp/morphe-patches/commit/a64cecc3a3258ae3c88e36c4ae111aed7f1e351d))
* **YouTube - Hide layout components:** "Hide channel buttons" does not hide the YouTube Music banner of a channel in the search results with the Automotive device layout ([9afdd0f](https://github.com/MorpheApp/morphe-patches/commit/9afdd0f8c1f9981fd554f32d6d379ca46b924193))
* **YouTube - Hide layout components:** "Hide feed flyout menu" leaves empty rows in the popup menus and does not hide the items of the toolbar menu, such as on a playlist page ([b492056](https://github.com/MorpheApp/morphe-patches/commit/b4920563a857b58b1fb1d150fd2da63ad9b31aff))
* **YouTube - Hide layout components:** Keyword filter hides every comment when a keyword is also a text of the comment section, such as "AI" ([acb4e58](https://github.com/MorpheApp/morphe-patches/commit/acb4e5839e6e10f7b1d39d08008d221a4455f76c))
* **YouTube - Hide player flyout menu components:** "Hide 'On-the-go' menu" does not work on 21.x ([e6c1ce2](https://github.com/MorpheApp/morphe-patches/commit/e6c1ce2fe53f8990746e6fdf058b6e146632b37b))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like and view counts are sometimes missing when the card or the vote fetch is slow ([9f947b5](https://github.com/MorpheApp/morphe-patches/commit/9f947b591854ad90f1c9d6496b68d1961b748595))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the videos of rows that show many videos in one element, such as the Videos and Live tabs of a channel ([bd94959](https://github.com/MorpheApp/morphe-patches/commit/bd9495981bf36c273f3d6785ad93b0a9f4040da6))
* **YouTube - Seekbar:** Seek preview shows a strip of the previous frame on its left side, which grows and shrinks while seeking ([ae97c40](https://github.com/MorpheApp/morphe-patches/commit/ae97c40ed423f19492668676bd1713c64fab1c76))
* **YouTube Music:** Resolve lyrics panel, button, and translation language/locale failures ([#4552](https://github.com/MorpheApp/morphe-patches/issues/4552)) ([5df3d94](https://github.com/MorpheApp/morphe-patches/commit/5df3d94b445f225f4903eeee07809af26fe2fa84))
* **YouTube:** Patches fail to read the watch next response after other patches change it in place, playlist requests reuse failed results, network failures show error toasts, and clean up unused, duplicated and one-caller code ([2705d3a](https://github.com/MorpheApp/morphe-patches/commit/2705d3a85639d5be746c86eb16dd8695804abf8f))

## [2.2.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0...v2.2.0-dev.1) (2026-11-07)

### ✨ New Features

* **Reddit:** Add `High quality avatars` patch ([#4477](https://github.com/MorpheApp/morphe-patches/issues/4477)) ([1f00c87](https://github.com/MorpheApp/morphe-patches/commit/1f00c87d284c19d962371943637e85770a12b8e7))
* **YouTube - Niconico comments:** Keep comments from running into each other ([#4497](https://github.com/MorpheApp/morphe-patches/issues/4497)) ([cf20941](https://github.com/MorpheApp/morphe-patches/commit/cf209419a0d34d528e31919c7e5c2d55c7da2f95))
* **YouTube Music - Third-party lyrics:** ttml, ruby, romanization enhancement ([#4439](https://github.com/MorpheApp/morphe-patches/issues/4439)) ([c7c8bb7](https://github.com/MorpheApp/morphe-patches/commit/c7c8bb728cfc43dfa9abaeb572f878fb7a2099af))
* **YouTube:** Add "Custom seekbar thumb" setting ([#4494](https://github.com/MorpheApp/morphe-patches/issues/4494)) ([abcc9b1](https://github.com/MorpheApp/morphe-patches/commit/abcc9b18e4c6bb0d4d398a261ca8336d25cf5eb6))

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Turning off "Override feed flyout queue button" is lost after it was replaced by "Play next in queue type" ([fb5cf05](https://github.com/MorpheApp/morphe-patches/commit/fb5cf051f0dce6bf7751e3f57faa0a7d912b1d00))
* **YouTube - Ask flyout menu:** Select suggestions with negative IDs ([#4496](https://github.com/MorpheApp/morphe-patches/issues/4496)) ([cd29774](https://github.com/MorpheApp/morphe-patches/commit/cd29774fcaddf138038dfc1137c4c5526d223b8a))
* **YouTube - Disable double tap actions:** Two-finger double tap seeks instead of skipping chapters on 21.11+ ([bf91aa5](https://github.com/MorpheApp/morphe-patches/commit/bf91aa5a39b243b3fff31eba1c6b11201b1ea8fb))
* **YouTube - GmsCore support:** Every account gets the bedtime, break and Shorts feed limit reminders of a supervised account ([4011b15](https://github.com/MorpheApp/morphe-patches/commit/4011b15b9c4c461c9971cf1896e205bb60bae1fa))
* **YouTube - Hide layout components:** "Hide channel bar" leaves an empty bordered box in the fullscreen engagement panel ([dd40ae2](https://github.com/MorpheApp/morphe-patches/commit/dd40ae2b8762e95958443f02d1a2bf797811648a))
* **YouTube - Hide player flyout menu components:** "Additional settings", "Ambient mode", "Stable volume" and "Listen with YouTube Music" items are not hidden when their icon has no name in the buffer ([0031ac6](https://github.com/MorpheApp/morphe-patches/commit/0031ac6e6d2bb2619967f2f88ab9060cffd840db))
* **YouTube - Morphe snackbar:** Reduced snackbar queue timeout to 3 seconds ([75ce67c](https://github.com/MorpheApp/morphe-patches/commit/75ce67c4151066f6441410e5bf8e4b9a9094ace5))
* **YouTube - Navigation bar:** "Hide Microphone button" does not hide the microphone of the Home search bar ([a184951](https://github.com/MorpheApp/morphe-patches/commit/a184951b4377a5182eb3dd26a34c5c23e1aade86))
* **YouTube - Navigation bar:** Glass navigation bar cuts the first and the last button on tablets, where the buttons have a minimum width ([88d4844](https://github.com/MorpheApp/morphe-patches/commit/88d4844e7886d27e0d2c3719c8f61589ca81a7a1))
* **YouTube - Navigation bar:** Incognito and connection status bar covers the bottom edge of the glass navigation bar ([711afdd](https://github.com/MorpheApp/morphe-patches/commit/711afdd57087ab18724dda359b554f8c7a56f124))
* **YouTube - Niconico comments:** Chat status messages are shown as comments ([#4499](https://github.com/MorpheApp/morphe-patches/issues/4499)) ([241100c](https://github.com/MorpheApp/morphe-patches/commit/241100c448e4f9a2397137967fcf81bbe43e647e))
* **YouTube - Open system share sheet:** Playing video enters picture-in-picture when the share sheet opens, and Mixes are shared with a link that does not open ([59e9e83](https://github.com/MorpheApp/morphe-patches/commit/59e9e831d4e74d185cd1f2d74fdf5b6b68f814a0))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on cards with the thumbnail beside the texts, such as the search results on tablets ([0a1a178](https://github.com/MorpheApp/morphe-patches/commit/0a1a1786224293b1a70e0db06df90093668dea06))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the cards of grid rows, such as the channel pages and the feed on tablets ([3e24ded](https://github.com/MorpheApp/morphe-patches/commit/3e24ded40baddb084bcd81822102bdb57eff723a))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is missing on the small thumbnails of list rows, such as the channel videos on phones ([342c1a9](https://github.com/MorpheApp/morphe-patches/commit/342c1a9c57e2c7f2033155c5bbd4f53c23ac74d2))
* **YouTube - Seekbar:** Full screen seek preview does not cover the sides of a video zoomed to fill the screen ([4e83c67](https://github.com/MorpheApp/morphe-patches/commit/4e83c6722ff069dcf594453111ad63e7c0b617e4))
* **YouTube - Settings:** App crashes when opening the settings on 21.45, which reuses the registers the settings hooks read the fragment from ([61be996](https://github.com/MorpheApp/morphe-patches/commit/61be99601a35f6282b85923e878debd207de9108))
* **YouTube Music - Downloads:** Match the renamed page header of older versions ([#4503](https://github.com/MorpheApp/morphe-patches/issues/4503)) ([1822fd7](https://github.com/MorpheApp/morphe-patches/commit/1822fd74e931d604b5085b4ed1932ddd1498c691))
* **YouTube:** The second feature flag that hides the navigation bar while the keyboard is open is not turned off, so pages keep its wrong padding ([2a01da0](https://github.com/MorpheApp/morphe-patches/commit/2a01da0ab5a6099a6c6d1f9995e826532cd36f6e))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.45.51` ([bd5baed](https://github.com/MorpheApp/morphe-patches/commit/bd5baedb2ca4321d7752f7a3f6894515af459321))

## [2.1.0](https://github.com/MorpheApp/morphe-patches/compare/v2.0.0...v2.1.0) (2026-11-06)

### ✨ New Features

* **Debugging:** Block/force offline feature flags ([#4416](https://github.com/MorpheApp/morphe-patches/issues/4416)) ([f775c62](https://github.com/MorpheApp/morphe-patches/commit/f775c62ed56f575c65c53df25bfbcc634fefbdf8))
* **GmsCore support:** Support video/audio casting to other devices (Requires latest MicroG-RE) ([#3899](https://github.com/MorpheApp/morphe-patches/issues/3899)) ([87f41aa](https://github.com/MorpheApp/morphe-patches/commit/87f41aae43c3c957c64ac570731343040975c584))
* **YouTube - Captions:** Add bilingual captions with synchronized blocks ([#4213](https://github.com/MorpheApp/morphe-patches/issues/4213)) ([0dd8f39](https://github.com/MorpheApp/morphe-patches/commit/0dd8f39adf7bd2960bec992fa661c9a700051a0a))
* **YouTube - Captions:** Prefer uploaded bilingual subtitles ([#4376](https://github.com/MorpheApp/morphe-patches/issues/4376)) ([a688883](https://github.com/MorpheApp/morphe-patches/commit/a68888349a433423c57a9f4d1d3b592d445e3b8c))
* **YouTube - Copy text:** Add option to select text of descriptions and posts ([#4317](https://github.com/MorpheApp/morphe-patches/issues/4317)) ([37f6321](https://github.com/MorpheApp/morphe-patches/commit/37f632113ea6e7740a9b11c3d3e715335498fd30))
* **YouTube - Downloads:** Export in-app videos to device storage ([#4211](https://github.com/MorpheApp/morphe-patches/issues/4211)) ([9130f66](https://github.com/MorpheApp/morphe-patches/commit/9130f6626f2468d8b75a8befd5856002686279f3))
* **YouTube - Feed card layout:** Add "Default" to "Feed card layout", which keeps the layout that the server sends ([55c8bc0](https://github.com/MorpheApp/morphe-patches/commit/55c8bc0951c151a18e8b6a4c060faceec127fc31))
* **YouTube - Feed video actions:** Watch later button shows a check mark if the video is saved, and removes the video when tapped ([a976db8](https://github.com/MorpheApp/morphe-patches/commit/a976db85f337ce742fbd9a154b26d9745930738c))
* **YouTube - Hide layout components:** Add "Hide comments preview" to "Post buttons" ([b7a1db3](https://github.com/MorpheApp/morphe-patches/commit/b7a1db3936c9fc956df915a5d76955b8aae0213c))
* **YouTube - Hide layout components:** Add "Post buttons" settings to choose the layout of the post buttons and hide them ([b4bbd85](https://github.com/MorpheApp/morphe-patches/commit/b4bbd85e60400ebd42549463f60dacabe3e3a3fc))
* **YouTube - Minimal miniplayer:** Add "Docked miniplayer" setting ([f89b66f](https://github.com/MorpheApp/morphe-patches/commit/f89b66f2e5c63637346def8aae49858d76bb14dd))
* **YouTube - Minimal miniplayer:** Add "Expand with swipe up" setting ([e0e36ba](https://github.com/MorpheApp/morphe-patches/commit/e0e36ba3d11e2bd56ba561292887a6c9f626ff72))
* **YouTube - Navigation bar:** Add "Enable glass navigation bar" setting ([#4338](https://github.com/MorpheApp/morphe-patches/issues/4338)) ([6d74097](https://github.com/MorpheApp/morphe-patches/commit/6d740979fb0cb83459d9f6bae36b2416430ca534))
* **YouTube - Navigation bar:** Add "Glass navigation bar size" setting, and fit the glass navigation bar to its buttons ([#4424](https://github.com/MorpheApp/morphe-patches/issues/4424)) ([0295f21](https://github.com/MorpheApp/morphe-patches/commit/0295f21b1f6fe7cdbe55e574d96bc5e8ba5576bf))
* **YouTube - Navigation bar:** Add "Navigation buttons order" and "Toolbar buttons order" settings ([#4374](https://github.com/MorpheApp/morphe-patches/issues/4374)) ([b2f9e19](https://github.com/MorpheApp/morphe-patches/commit/b2f9e193450e9b970404bb14fb20b97b93d684f7))
* **YouTube - Navigation bar:** Add "Show Watch later button" setting ([#4320](https://github.com/MorpheApp/morphe-patches/issues/4320)) ([338a4dc](https://github.com/MorpheApp/morphe-patches/commit/338a4dc8101f45ca36619a1aa48da7baf90f8ea5))
* **YouTube - Navigation bar:** Added a Glass navigation bar lit rim ([afc5afe](https://github.com/MorpheApp/morphe-patches/commit/afc5afea438ecc3e2b65dadab8a0a5f56bf6d275))
* **YouTube - Niconico comments:** Add "Display area" setting ([#4425](https://github.com/MorpheApp/morphe-patches/issues/4425)) ([65bf16b](https://github.com/MorpheApp/morphe-patches/commit/65bf16b2a80d302246386917293db9099b2bf87b))
* **YouTube - Niconico comments:** Add "Max refresh rate" setting ([#4399](https://github.com/MorpheApp/morphe-patches/issues/4399)) ([090a861](https://github.com/MorpheApp/morphe-patches/commit/090a8619ec12e0f4f010ce2eec5c38e127b5459c))
* **YouTube - Niconico comments:** Add "Show timed comments with chat replay" setting ([#4458](https://github.com/MorpheApp/morphe-patches/issues/4458)) ([84b599e](https://github.com/MorpheApp/morphe-patches/commit/84b599e3f7dd8956689b7738c597b9295b66e6a2))
* **YouTube - Niconico comments:** Add reset button to quick settings ([#4339](https://github.com/MorpheApp/morphe-patches/issues/4339)) ([030d3fc](https://github.com/MorpheApp/morphe-patches/commit/030d3fc75315fb353d47cfb42fa2867c8b757813))
* **YouTube - Niconico comments:** Add video type selection ([#4327](https://github.com/MorpheApp/morphe-patches/issues/4327)) ([e6dbce0](https://github.com/MorpheApp/morphe-patches/commit/e6dbce04f115d7ddd65393b55f0aa9177a6e5591))
* **YouTube - Niconico comments:** Show timed comments on videos without a chat ([#4430](https://github.com/MorpheApp/morphe-patches/issues/4430)) ([c4fceb9](https://github.com/MorpheApp/morphe-patches/commit/c4fceb9879f86667ed0029a142c80e741ed2284b))
* **YouTube - Restore old video action bar:** Add the "Classic Two-Rows" layout to "Video action bar layout", and remove "Enable tablet layout in player" ([73eeadb](https://github.com/MorpheApp/morphe-patches/commit/73eeadb72c35913399e4fc9f5e1abb2ebecf22b4))
* **YouTube - Restore old video action bar:** Replace the setting with "Video action bar layout", with the Default, Classic and Minimal layouts ([545cd37](https://github.com/MorpheApp/morphe-patches/commit/545cd37cc0716ff447508ffa2e31ad599800b012))
* **YouTube - Series tracking:** Add "Mark watched when moving to the next episode" setting ([#4415](https://github.com/MorpheApp/morphe-patches/issues/4415)) ([c8b83c4](https://github.com/MorpheApp/morphe-patches/commit/c8b83c420da32b33049463a1c10b67de54027c6a))
* **YouTube - Swipe controls:** Add swipe to seek ([#4364](https://github.com/MorpheApp/morphe-patches/issues/4364)) ([d211d79](https://github.com/MorpheApp/morphe-patches/commit/d211d79e44bae50663523ee7c0eb89c47b145ec6))
* **YouTube - Theme:** Add setting to configure 'Glow' splash screen duration, and allow tapping to skip animation ([05a808a](https://github.com/MorpheApp/morphe-patches/commit/05a808a64c02d283f84654a9507874a3db0f0122))
* **YouTube - Translate live chat:** Add DeepL provider and fix Google rate limiting issue ([#4313](https://github.com/MorpheApp/morphe-patches/issues/4313)) ([aa84d03](https://github.com/MorpheApp/morphe-patches/commit/aa84d037b9547a6bd7848ceabc65293a2811c8dd))
* **YouTube / YouTube Music - Hide layout components:** Add "Hide GIF button" and "Hide GIFs and images" comment settings ([#4289](https://github.com/MorpheApp/morphe-patches/issues/4289)) ([7044284](https://github.com/MorpheApp/morphe-patches/commit/7044284d0b0dd9ea1334652f91923a3f1721e18e))
* **YouTube Music - Downloads:** Add album and playlist downloads ([#4398](https://github.com/MorpheApp/morphe-patches/issues/4398)) ([156b0c9](https://github.com/MorpheApp/morphe-patches/commit/156b0c94d488d30e8f495cfb844c24d1028e3530))
* **YouTube Music - Downloads:** Mark the downloaded songs in the lists ([#4414](https://github.com/MorpheApp/morphe-patches/issues/4414)) ([6d24106](https://github.com/MorpheApp/morphe-patches/commit/6d241067409d8ad414004f78a62790739cfd3347))
* **YouTube Music - Downloads:** Offline fullscreen player ([#4436](https://github.com/MorpheApp/morphe-patches/issues/4436)) ([4390b82](https://github.com/MorpheApp/morphe-patches/commit/4390b82f54008fdc1a9d1422bbfc4b9aa673d334))
* **YouTube Music - SoundProof:** Add SoundProof AI blocker ([#4451](https://github.com/MorpheApp/morphe-patches/issues/4451)) ([c638cc4](https://github.com/MorpheApp/morphe-patches/commit/c638cc4c21457439617a0006254405dd9236dc6c))
* **YouTube Music - Third-party lyrics:** Add reactive dynamic background layout refinements, and automatic ruby generation ([#4208](https://github.com/MorpheApp/morphe-patches/issues/4208)) ([2d9e39f](https://github.com/MorpheApp/morphe-patches/commit/2d9e39fe1dedb1462a95f9e6e7f920bf6e9b693c))
* **YouTube Music:** Add `Playlist tags` patch ([#4304](https://github.com/MorpheApp/morphe-patches/issues/4304)) ([11c4350](https://github.com/MorpheApp/morphe-patches/commit/11c43500376877be24235de6c3c9e3ba23bb6e07))
* **YouTube Music:** Add playlist creation from downloaded music tracks ([#4232](https://github.com/MorpheApp/morphe-patches/issues/4232)) ([931f427](https://github.com/MorpheApp/morphe-patches/commit/931f4273fa89c6e47a3e6d9850184f8401ce2141))
* **YouTube:** Add `Change PiP actions` patch ([#4175](https://github.com/MorpheApp/morphe-patches/issues/4175)) ([d9fc859](https://github.com/MorpheApp/morphe-patches/commit/d9fc85939f31340a2678e38375f2290a8d49da7f))
* **YouTube:** Add `Snackbar` patch ([#4177](https://github.com/MorpheApp/morphe-patches/issues/4177)) ([6ce8208](https://github.com/MorpheApp/morphe-patches/commit/6ce82088309c83bd1aa413c4ec5fa11ad6d6f470))
* **YouTube:** Add `Translate live chat` patch ([#4222](https://github.com/MorpheApp/morphe-patches/issues/4222)) ([9b598a2](https://github.com/MorpheApp/morphe-patches/commit/9b598a2ce7ff17b2f453fc56f730a734bba1a4e7))
* **YouTube:** Remove the new setting dot once the setting is opened or changed ([7e8766c](https://github.com/MorpheApp/morphe-patches/commit/7e8766c5fb46fdeab4807bff1786b510f29e8f32))
* **YouTube:** Show at most one Morphe snackbar message each second ([3569fbc](https://github.com/MorpheApp/morphe-patches/commit/3569fbc184b58d4da4ac19d404da928ec4ba9d1f))

### 🐛 Bug Fixes

* **Spoof video streams:** Do not block get_watch, initplayback, or Onesie requests ([#4373](https://github.com/MorpheApp/morphe-patches/issues/4373)) ([9d38c68](https://github.com/MorpheApp/morphe-patches/commit/9d38c684386881683d257713591cc0a3281fe587))
* **Spoof video streams:** Do not fetch streams again if a fetch for the same video is in progress ([14cfd47](https://github.com/MorpheApp/morphe-patches/commit/14cfd47d0a5bd0ccf7d388506678fa5e68dd8361))
* **Spoof video streams:** Video opened from the search results can load forever when another video is fetched at the same time ([#4334](https://github.com/MorpheApp/morphe-patches/issues/4334)) ([25cde38](https://github.com/MorpheApp/morphe-patches/commit/25cde38f3cf00c015b4bc4d6cd0d56daf7a2914b))
* **YouTube  - Save to Watch later:** Implement the refinements for Watch Later screen ([#4324](https://github.com/MorpheApp/morphe-patches/issues/4324)) ([ee68a99](https://github.com/MorpheApp/morphe-patches/commit/ee68a993a266ee03566c3cf097bca8f0af3354f7))
* **YouTube - Change start page:** Top bar and navigation bar show the default buttons for 20 seconds without a cached guide ([2e18f68](https://github.com/MorpheApp/morphe-patches/commit/2e18f6885a4cec85da277f219c61fe69e9585ff8))
* **YouTube - Disable fullscreen gestures:** Pinch-to-zoom does not work in Shorts ([3b99355](https://github.com/MorpheApp/morphe-patches/commit/3b993553d457ad4a324ae95038cd4b7688a7087b))
* **YouTube - Downloads:** App can crash when downloading Short in-app ([bae1787](https://github.com/MorpheApp/morphe-patches/commit/bae1787e9d2f56e5d5dc845d1916cc46b5c8c288))
* **YouTube - Downloads:** Captions of in-app downloads show escaped punctuation ([#4450](https://github.com/MorpheApp/morphe-patches/issues/4450)) ([da8f656](https://github.com/MorpheApp/morphe-patches/commit/da8f656061aecced5a87a8f88cea56e5768f0386))
* **YouTube - Downloads:** Playback speed is unavailable for in-app downloads ([119468c](https://github.com/MorpheApp/morphe-patches/commit/119468c2f30441a52f0bb05c77b29b0b31e16863))
* **YouTube - Downloads:** Use default export folder if the picked folder is missing ([e34115d](https://github.com/MorpheApp/morphe-patches/commit/e34115deb3ef00634a387e58c092744e5a7b6952))
* **YouTube - Feed card layout:** "getUri failure" toast and cards not converted while the app rewrites its template cache ([93b36be](https://github.com/MorpheApp/morphe-patches/commit/93b36be598e98eb9939987bc613337388f9998e5))
* **YouTube - Feed card layout:** Cards lose their rounded corners when scrolled back into view, and their corners and padding don't match the cards after the display density changes ([aeb07d3](https://github.com/MorpheApp/morphe-patches/commit/aeb07d3556a7335a54406f9afeb86aa21b6e86d5))
* **YouTube - Feed card layout:** Cards lose their rounded corners while scrolling and their margin doubles once fully shown ([63f1fc2](https://github.com/MorpheApp/morphe-patches/commit/63f1fc213af17508587a93a30c480396747233d1))
* **YouTube - Feed card layout:** Cards of the watch page grid on tablets have square corners ([515186d](https://github.com/MorpheApp/morphe-patches/commit/515186da601bce2b6c2c524c61b4f5258e998a2d))
* **YouTube - Feed card layout:** Classic layout does not apply to mixes, playlists and posts ([fac7d56](https://github.com/MorpheApp/morphe-patches/commit/fac7d5658a63381fc3f072c7e684b026930109e6))
* **YouTube - Feed card layout:** Comment button of the cards opens the video instead of only the comments panel ([9adfb63](https://github.com/MorpheApp/morphe-patches/commit/9adfb637d3e7e5d1cd4cf26cda07d04a31094258))
* **YouTube - Feed card layout:** Feed videos disappear and come back on scroll when the app drops the cached template version ([be4a66a](https://github.com/MorpheApp/morphe-patches/commit/be4a66a0d6031df4562a214ebfb05cb4122b2d6d))
* **YouTube - Feed card layout:** Feed videos have no save items in the menu when the cards with a save button are converted to the classic layout ([1d34aae](https://github.com/MorpheApp/morphe-patches/commit/1d34aaed6681270670bf8a618b89a3bd1f3dae14))
* **YouTube - Feed card layout:** Playlists converted to cards have no background below the thumbnail ([3a07c14](https://github.com/MorpheApp/morphe-patches/commit/3a07c14994018225fdc9add3494c8e6f2f3b6d8f))
* **YouTube - Feed card layout:** Playlists have no background below the thumbnail with the new server layout of the cards ([571a3f9](https://github.com/MorpheApp/morphe-patches/commit/571a3f9df78aee3624f4b1b91ac7c89b2fa24e2b))
* **YouTube - Feed card layout:** Server experiments of the account change the converted cards, such as removing their menu button ([aec41a5](https://github.com/MorpheApp/morphe-patches/commit/aec41a5e49d1ca3586a48d3dbf015930e8e4f29b))
* **YouTube - Feed video actions:** Inline watch later button performClick logic superseeded by direct app command ([7f343df](https://github.com/MorpheApp/morphe-patches/commit/7f343df16754bec9a4e102076c450bbf585c94a8))
* **YouTube - Feed video actions:** Tap and hold on the Watch later button can show the video menu instead of the Save to playlist panel ([810fcdb](https://github.com/MorpheApp/morphe-patches/commit/810fcdbab73e3afaf449cf7934fd1312d9338091))
* **YouTube - Feed view count:** Badge is shown when the text below the title already shows the view count ([f5faf04](https://github.com/MorpheApp/morphe-patches/commit/f5faf04e505baa84ea57b0de1a77b8dbed5ad891))
* **YouTube - Feed view count:** Badge of a card that enters from the bottom is hidden between the loading spinner and the view count, when the view count is on a row below the channel ([c9a1a63](https://github.com/MorpheApp/morphe-patches/commit/c9a1a635a3e44b5ecb8562b66fb9dece755c57ab))
* **YouTube - Feed view count:** Badge of a vertical thumbnail is in the middle of the thumbnail until the title row is drawn ([5d01f60](https://github.com/MorpheApp/morphe-patches/commit/5d01f6024e78c66ca64d2c19cdb1b3d2c987daac))
* **YouTube - Feed view count:** Loading spinner is shown on cards whose title row is not drawn yet, such as long thumbnails ([0b58b9d](https://github.com/MorpheApp/morphe-patches/commit/0b58b9db57f3c6140e237a59f097ba1434d93335))
* **YouTube - Feed view count:** View count of the previous video is shown for a moment when a list reuses a card, such as in the notifications ([86cd350](https://github.com/MorpheApp/morphe-patches/commit/86cd3501924a494b128b41f56b4c849b54d27fcc))
* **YouTube - Force fullscreen landscape:** Setting is shown on large screens with Android 16 and later, which ignore the orientation it requests ([79e201f](https://github.com/MorpheApp/morphe-patches/commit/79e201f81c3c158aedc5b613caaee6c363b50d78))
* **YouTube - GmsCore Support:** Allow casting to audio only devices ([#4268](https://github.com/MorpheApp/morphe-patches/issues/4268)) ([ec04b15](https://github.com/MorpheApp/morphe-patches/commit/ec04b153109ec227d52a75f471b3c886606f4f5e))
* **YouTube - Hide ads:** Ads are shown in the Shorts feed when a channel is in the ad whitelist ([067aee9](https://github.com/MorpheApp/morphe-patches/commit/067aee9be70f204fd2c5b85ccaef1471c9127280))
* **YouTube - Hide layout components:** "Hide Explore button" not working in incognito mode ([61e1e9f](https://github.com/MorpheApp/morphe-patches/commit/61e1e9f16adb4c3bce954526441257095814d7df))
* **YouTube - Hide layout components:** Comment box, composer and reply buttons open the channel guidelines sheet with "Hide Community Guidelines" ([7e9903d](https://github.com/MorpheApp/morphe-patches/commit/7e9903d19cb96334285d8035a31e167990f49936))
* **YouTube - Hide layout components:** Downloads item of the You tab cannot be hidden ([e3b17aa](https://github.com/MorpheApp/morphe-patches/commit/e3b17aab860c6220368fbb9c74f7e5b2be0b591d))
* **YouTube - Hide layout components:** Filtered download item of the feed flyout menu appears until its download state is loaded ([be60b7c](https://github.com/MorpheApp/morphe-patches/commit/be60b7c67fd17d9554cca2d1001f2255ba95c903))
* **YouTube - Hide layout components:** Pages of the Explore menu, such as Movies and Memberships, are empty or miss their shelves with "Hide horizontal shelves" ([a8acc59](https://github.com/MorpheApp/morphe-patches/commit/a8acc59cfca6b0a5c42edd2d33fd2bcd01f6283f))
* **YouTube - Hide layout components:** Prevent shelves from hiding on Charts, Memberships, and Playables pages ([a61f9b4](https://github.com/MorpheApp/morphe-patches/commit/a61f9b455e4846bfc4de63fc25f4326466bbdec2))
* **YouTube - Hide player flyout menu components:** Fix player flyout menu items not hiding ([#4260](https://github.com/MorpheApp/morphe-patches/issues/4260)) ([74dc44b](https://github.com/MorpheApp/morphe-patches/commit/74dc44b5924c0baa7937cdef000f529e5418b09e))
* **YouTube - Hide video action buttons:** "Hide Subscribe button" and "Hide channel and Subscribe button" don't hide the channel bar above the action bar ([74fe9a3](https://github.com/MorpheApp/morphe-patches/commit/74fe9a3bb9671fe7fd2887db34c375cb9d2ff9f1))
* **YouTube - Minimal miniplayer:** Bar is black beside the video while the player collapses in the light theme ([e47fc6f](https://github.com/MorpheApp/morphe-patches/commit/e47fc6f9353699849990878413763d1af3be70f9))
* **YouTube - Minimal miniplayer:** Bar keeps a larger gap above the snackbar than the snackbar keeps above the navigation bar ([49dbd6a](https://github.com/MorpheApp/morphe-patches/commit/49dbd6a6222e0f6c768626b2c2f7d1f9b4a6b5dd))
* **YouTube - Minimal miniplayer:** Snackbar covers the bar instead of moving it up like the default miniplayer ([94775a9](https://github.com/MorpheApp/morphe-patches/commit/94775a9336ce259873720c2fe7ba2acb79556826))
* **YouTube - Morphe snackbar:** Increased snackbar queue timeout to 5 seconds ([67b7f76](https://github.com/MorpheApp/morphe-patches/commit/67b7f7693bbc0b7addccc2621a0d078bb52f99f0))
* **YouTube - Navigation bar:** Black band around the glass navigation bar on Android 11 and older, and with Hide status bar before Android 15 ([af8dc88](https://github.com/MorpheApp/morphe-patches/commit/af8dc88ead85f5ff076b78bfe51574ab6c032973))
* **YouTube - Navigation bar:** Black band behind the translucent or glass navigation bar with Hide status bar ([9897de9](https://github.com/MorpheApp/morphe-patches/commit/9897de9cafe156e0df23399dd583d1b687af076b))
* **YouTube - Navigation bar:** Glass navigation bar has the wrong height with 3-button navigation ([#4452](https://github.com/MorpheApp/morphe-patches/issues/4452)) ([6d6c523](https://github.com/MorpheApp/morphe-patches/commit/6d6c523eb5157b222d824d2dcd40465e7bce2b81))
* **YouTube - Navigation bar:** Glass navigation bar is too tall with layout updates disabled ([#4426](https://github.com/MorpheApp/morphe-patches/issues/4426)) ([25970b1](https://github.com/MorpheApp/morphe-patches/commit/25970b18c64c375f50844bfc51b4303178dedc28))
* **YouTube - Navigation bar:** Glass navigation bar is white around the capsule in the Shorts player with the light theme ([#4447](https://github.com/MorpheApp/morphe-patches/issues/4447)) ([0223075](https://github.com/MorpheApp/morphe-patches/commit/0223075c47e48d1280bf9b242dacb06ab2096363))
* **YouTube - Navigation bar:** Glass navigation bar is wider than its buttons, so the first and the last button are not aligned with the ends of the bar ([93f9010](https://github.com/MorpheApp/morphe-patches/commit/93f90107ebd5c328865b9e9bf1e048b581c576f6))
* **YouTube - Navigation bar:** Glass navigation bar size preview draws the labels over the icons when the labels are hidden, and shows placeholders instead of the button icons ([59fdfe5](https://github.com/MorpheApp/morphe-patches/commit/59fdfe57b906b4df1902832c85cf62f8d2779d52))
* **YouTube - Navigation bar:** Swap create with notifications button does not change the toolbar of the You tab ([3c03bbb](https://github.com/MorpheApp/morphe-patches/commit/3c03bbb585c9bcfa05f2cc4d1252e341e0904cb5))
* **YouTube - Navigation bar:** Swiping the miniplayer does not cancel autoplay with Disable auto hide navigation bar ([136d5bc](https://github.com/MorpheApp/morphe-patches/commit/136d5bcbe4672192be5e3486ee100fe8529453a6))
* **YouTube - Navigation bar:** Video button of the create button in the channel page toolbar does nothing ([41cd7ae](https://github.com/MorpheApp/morphe-patches/commit/41cd7ae70f7086a5dd1071b8a9e460293580ab80))
* **YouTube - Niconico comments:** Keep a high refresh rate while comments move ([#4377](https://github.com/MorpheApp/morphe-patches/issues/4377)) ([5046880](https://github.com/MorpheApp/morphe-patches/commit/50468807ab6de322bf16a425519c14b7021960df))
* **YouTube - Niconico comments:** Make quick settings scrollable in landscape ([#4325](https://github.com/MorpheApp/morphe-patches/issues/4325)) ([5d10b9d](https://github.com/MorpheApp/morphe-patches/commit/5d10b9de895cb6a24090133aa8e264151f569126))
* **YouTube - Niconico comments:** Move comments smoothly before the first video state is reported ([#4378](https://github.com/MorpheApp/morphe-patches/issues/4378)) ([76ec46d](https://github.com/MorpheApp/morphe-patches/commit/76ec46dfb32b29204f13d672d56b41b75254a8e7))
* **YouTube - Playback speed:** Holding a Short does not play it at 2.0x when a default Shorts speed is set ([8e32e0f](https://github.com/MorpheApp/morphe-patches/commit/8e32e0f4bb1964811cdbdff1579dbbfce9d22a65))
* **YouTube - Playback speed:** Holding a Short does not play it at the custom tap and hold speed when a default Shorts speed is set ([ad00990](https://github.com/MorpheApp/morphe-patches/commit/ad0099088f806428f1bf890297bd005c6e6c1484))
* **YouTube - Playback speed:** Pitch presets can set an out of range pitch, speed icon shows without pitch controls ([d0b9847](https://github.com/MorpheApp/morphe-patches/commit/d0b98475e4b2d196340d9244ab3bc72df94eac76))
* **YouTube - Premium-style queue:** Fix dragging videos to the end ([#4315](https://github.com/MorpheApp/morphe-patches/issues/4315)) ([010d9e6](https://github.com/MorpheApp/morphe-patches/commit/010d9e6d0960a643685ae79bc09978739ece14cc))
* **YouTube - Remove background playback restrictions:** Video does not resume when a Short opened over it is closed ([f8c8139](https://github.com/MorpheApp/morphe-patches/commit/f8c813916c48d0428c8a3e4def40aca58060db81))
* **YouTube - Restore original titles:** Update titles during background playback ([#4347](https://github.com/MorpheApp/morphe-patches/issues/4347)) ([ed67be3](https://github.com/MorpheApp/morphe-patches/commit/ed67be3d6dbb988702c23733a54342dd22fef169))
* **YouTube - Save to Watch later:** Item is missing from the flyout menus without a save item, such as the main feed ([0afe955](https://github.com/MorpheApp/morphe-patches/commit/0afe9559915f6f6baa559d9b7ae13a612ae87525))
* **YouTube - Search comments:** Improved the check of the comments panels ([ec1c31d](https://github.com/MorpheApp/morphe-patches/commit/ec1c31d1c7e7a85d714ddc2a9ae62b0aad49e1a1))
* **YouTube - Search comments:** Search button wasn't shown in the post comments panel ([a54518a](https://github.com/MorpheApp/morphe-patches/commit/a54518adbb5f1a861b2b0cffda3add454f7dd3dc))
* **YouTube - Seekbar:** Shorts seekbar disappears after opening Shorts again or after the settings ([19f0db3](https://github.com/MorpheApp/morphe-patches/commit/19f0db3904a3a925ebb144f0e2d0292180135f4e))
* **YouTube - Seekbar:** Videos with their own seekbar style show an image as the seekbar handle and ignore the seekbar color ([e0dcffb](https://github.com/MorpheApp/morphe-patches/commit/e0dcffbb32401e5929ccdbc3d2a2c55506a4e2a8))
* **YouTube - Series tracking:** Thumbnails reload while a video plays ([#4420](https://github.com/MorpheApp/morphe-patches/issues/4420)) ([cb687aa](https://github.com/MorpheApp/morphe-patches/commit/cb687aaa1441f99b65be5dd61d75f9b46405bedf))
* **YouTube - Settings:** New setting dot not displayed correctly on RTL languages ([585d552](https://github.com/MorpheApp/morphe-patches/commit/585d55240ad8f7d3e2918b4b15295141b42a1cba))
* **YouTube - Skip live Shorts:** A live stream opened in the regular player skips the Short behind it ([dddbfbd](https://github.com/MorpheApp/morphe-patches/commit/dddbfbde288573d88db5162596edf609904a549d))
* **YouTube - Swipe controls:** Fix double tap to skip chapters ([#4219](https://github.com/MorpheApp/morphe-patches/issues/4219)) ([602533c](https://github.com/MorpheApp/morphe-patches/commit/602533c6f54e5590cd581e977b185b7feaa26eb6))
* **YouTube - Theme:** App crashes on launch with Android 8.0 when the device uses a night configuration and the app uses the light theme ([a290229](https://github.com/MorpheApp/morphe-patches/commit/a290229ef9ffea037a2997fc46962ab12957634c))
* **YouTube - Theme:** Status bar shows white icons on the light theme colors other than white ([d81b7c1](https://github.com/MorpheApp/morphe-patches/commit/d81b7c1eb4e8ff26ed00816a72fc63b5f20b7578))
* **YouTube - Translate posts:** Patch may crash on devices older than Android 10 ([589c3ab](https://github.com/MorpheApp/morphe-patches/commit/589c3abbe540026426f3336b04c2f13cd692b127))
* **YouTube - Video quality:** Quality selected for a regular video in the miniplayer is lost after opening Shorts ([624bb5d](https://github.com/MorpheApp/morphe-patches/commit/624bb5d66ce8d6d531f4430cbd67a682c87e7f48))
* **YouTube Music - Downloads:** Dowloading with flyout menu shows premium popup ([#4382](https://github.com/MorpheApp/morphe-patches/issues/4382)) ([4b6c282](https://github.com/MorpheApp/morphe-patches/commit/4b6c282157b9d6ba8564d4042ce888d1108dba1c))
* **YouTube Music - Downloads:** Download can fail with "Audio stream unavailable" with TV spoof client ([2406f60](https://github.com/MorpheApp/morphe-patches/commit/2406f60bc256a6dc1848e74b5fd544aec6bb4267))
* **YouTube Music - Downloads:** Downloads screen freezes with a large catalogue ([#4396](https://github.com/MorpheApp/morphe-patches/issues/4396)) ([e429778](https://github.com/MorpheApp/morphe-patches/commit/e4297782630de4216fe6eb03f7eee84c0ba9252f))
* **YouTube Music - Downloads:** Offline playback audio focus handling ([#4314](https://github.com/MorpheApp/morphe-patches/issues/4314)) ([509306c](https://github.com/MorpheApp/morphe-patches/commit/509306cdcd85be088e6a97b2b56e4d34cbb400e3))
* **YouTube Music - Downloads:** Offline playback crashes with a large queue ([#4397](https://github.com/MorpheApp/morphe-patches/issues/4397)) ([ba12903](https://github.com/MorpheApp/morphe-patches/commit/ba12903f57a6c7c61fb4f6a02e46b96fbef1b412))
* **YouTube Music - Hide flyout menu components:** Fix patching 9.44.52 ([8fdd7fe](https://github.com/MorpheApp/morphe-patches/commit/8fdd7fe91d3b19b03d9ec99dc8f5ecf5ed1534b1))
* **YouTube Music - Miniplayer previous and next buttons:** Buttons are missing with the deferred player layout ([683f805](https://github.com/MorpheApp/morphe-patches/commit/683f805c45f9be7fe993df346e52984952a30944))
* **YouTube Music - Settings:** App crashes when opening settings with 9.44.52 ([4647eea](https://github.com/MorpheApp/morphe-patches/commit/4647eea4233d4f10d5c832adca797a3e67dbb677))
* **YouTube Music - Third-party lyrics:** Support tabbed lyrics panels ([#4267](https://github.com/MorpheApp/morphe-patches/issues/4267)) ([a56766b](https://github.com/MorpheApp/morphe-patches/commit/a56766b47feedad72cac55e1d28a507d2f8edbf4))
* **YouTube Music - Third-party lyrics:** Various minor bug fixes ([#4323](https://github.com/MorpheApp/morphe-patches/issues/4323)) ([f3a64b6](https://github.com/MorpheApp/morphe-patches/commit/f3a64b6c6833667a734512de5b904ed3597c324b))
* **YouTube Music:** Download albums and playlists offered Premium ([#4464](https://github.com/MorpheApp/morphe-patches/issues/4464)) ([a80aa75](https://github.com/MorpheApp/morphe-patches/commit/a80aa75cece6a6ca64119ac9044511a31dad9740))
* **YouTube Music:** Non-experimental targets do not patch ([2ca8ae1](https://github.com/MorpheApp/morphe-patches/commit/2ca8ae1098f2a1c964ddb26703fa9b0b178c736d))
* **YouTube:** App crashes at launch without the Theme patch ([85b2b81](https://github.com/MorpheApp/morphe-patches/commit/85b2b81a44b262425c1e583c929eb3b4613fb920))
* **YouTube:** Channel whitelist and AiSList report items are missing from the Shorts player flyout menu ([acda216](https://github.com/MorpheApp/morphe-patches/commit/acda21652dbbd533d3395c4ebbe33601d361cbd2))
* **YouTube:** Consolidate "Hide cast button" into a single setting ([5daa6d6](https://github.com/MorpheApp/morphe-patches/commit/5daa6d6e372d0b72d31f5fa4faea6a74049a92a8))
* **YouTube:** Crash on Android 12 when closing a settings screen with a new setting ([77911d1](https://github.com/MorpheApp/morphe-patches/commit/77911d167ceeaa6da1501c64072e189a642a846c))
* **YouTube:** Fix delayed Subscriptions header on 21.28 & 21.30 ([#4278](https://github.com/MorpheApp/morphe-patches/issues/4278)) ([35c1189](https://github.com/MorpheApp/morphe-patches/commit/35c1189c40298860d830e8a9167523ec1f7e0ca6))
* **YouTube:** Flyout menu items can run the action of another item, such as Save to playlist adding the video to the queue ([44badd3](https://github.com/MorpheApp/morphe-patches/commit/44badd3d71c535436590b39fa56262d336369499))
* **YouTube:** Flyout menus are polled every 10 ms on the main thread, even if a menu is never shown ([3afaf21](https://github.com/MorpheApp/morphe-patches/commit/3afaf21be27495d8fcdeddb90aded1549f8352b9))
* **YouTube:** Home can be rendered with RenderNext, which the Litho filters and hooks don't see ([c1dcad4](https://github.com/MorpheApp/morphe-patches/commit/c1dcad4033c61b4b79f87861999fad246badd3d7))
* **YouTube:** Player flyout menu components do not hide ([#4203](https://github.com/MorpheApp/morphe-patches/issues/4203)) ([4c69ca3](https://github.com/MorpheApp/morphe-patches/commit/4c69ca3f52a1c1143fd82c0b00a610aba8b933ea))
* **YouTube:** Small comments card is shown below the player time bar ([3c58196](https://github.com/MorpheApp/morphe-patches/commit/3c581960c07724d73e4b3a0b3821108dd2939a9d))
* **YouTube:** Snackbars are shown with an empty space above the navigation bar, as high as the system navigation buttons ([0eb5a08](https://github.com/MorpheApp/morphe-patches/commit/0eb5a08d127dabbc4375ed0f97c22296824f9b57))
* **YouTube:** Update experimental target version name ([0f25ad3](https://github.com/MorpheApp/morphe-patches/commit/0f25ad37c62124744f9dce20f1700678cbc45f38))
* **YouTube:** Watch page action buttons and videos disappear or stay over the list after scrolling while the page loads ([8770def](https://github.com/MorpheApp/morphe-patches/commit/8770def2b49bd40d2637b6ba8f18a598395affed))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.45.0` ([8e61eea](https://github.com/MorpheApp/morphe-patches/commit/8e61eeac77f77edc4f4957b4c4ef23c67d9c200e))
* **YouTube Music:** Add experimental support for `9.44.52` ([cfd507d](https://github.com/MorpheApp/morphe-patches/commit/cfd507d0329987016aa61b6bc6952b2bbc8a3237))
* **YouTube:** Add experimental support for `21.44.523` ([#4185](https://github.com/MorpheApp/morphe-patches/issues/4185)) ([9fbc6a3](https://github.com/MorpheApp/morphe-patches/commit/9fbc6a3d664a080d3ba759cd9f3d9f45eb18ab60))

## [2.1.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.11...v2.1.0-dev.12) (2026-11-06)

### ✨ New Features

* **YouTube - Niconico comments:** Add "Show timed comments with chat replay" setting ([#4458](https://github.com/MorpheApp/morphe-patches/issues/4458)) ([84b599e](https://github.com/MorpheApp/morphe-patches/commit/84b599e3f7dd8956689b7738c597b9295b66e6a2))
* **YouTube - Niconico comments:** Show timed comments on videos without a chat ([#4430](https://github.com/MorpheApp/morphe-patches/issues/4430)) ([c4fceb9](https://github.com/MorpheApp/morphe-patches/commit/c4fceb9879f86667ed0029a142c80e741ed2284b))
* **YouTube Music - Downloads:** Mark the downloaded songs in the lists ([#4414](https://github.com/MorpheApp/morphe-patches/issues/4414)) ([6d24106](https://github.com/MorpheApp/morphe-patches/commit/6d241067409d8ad414004f78a62790739cfd3347))
* **YouTube Music - Downloads:** Offline fullscreen player ([#4436](https://github.com/MorpheApp/morphe-patches/issues/4436)) ([4390b82](https://github.com/MorpheApp/morphe-patches/commit/4390b82f54008fdc1a9d1422bbfc4b9aa673d334))
* **YouTube Music - SoundProof:** Add SoundProof AI blocker ([#4451](https://github.com/MorpheApp/morphe-patches/issues/4451)) ([c638cc4](https://github.com/MorpheApp/morphe-patches/commit/c638cc4c21457439617a0006254405dd9236dc6c))
* **YouTube Music:** Add `Playlist tags` patch ([#4304](https://github.com/MorpheApp/morphe-patches/issues/4304)) ([11c4350](https://github.com/MorpheApp/morphe-patches/commit/11c43500376877be24235de6c3c9e3ba23bb6e07))

### 🐛 Bug Fixes

* **YouTube - Disable fullscreen gestures:** Pinch-to-zoom does not work in Shorts ([3b99355](https://github.com/MorpheApp/morphe-patches/commit/3b993553d457ad4a324ae95038cd4b7688a7087b))
* **YouTube - Downloads:** Captions of in-app downloads show escaped punctuation ([#4450](https://github.com/MorpheApp/morphe-patches/issues/4450)) ([da8f656](https://github.com/MorpheApp/morphe-patches/commit/da8f656061aecced5a87a8f88cea56e5768f0386))
* **YouTube - Downloads:** Playback speed is unavailable for in-app downloads ([119468c](https://github.com/MorpheApp/morphe-patches/commit/119468c2f30441a52f0bb05c77b29b0b31e16863))
* **YouTube - Feed card layout:** Cards lose their rounded corners when scrolled back into view, and their corners and padding don't match the cards after the display density changes ([aeb07d3](https://github.com/MorpheApp/morphe-patches/commit/aeb07d3556a7335a54406f9afeb86aa21b6e86d5))
* **YouTube - Navigation bar:** Black band around the glass navigation bar on Android 11 and older, and with Hide status bar before Android 15 ([af8dc88](https://github.com/MorpheApp/morphe-patches/commit/af8dc88ead85f5ff076b78bfe51574ab6c032973))
* **YouTube - Navigation bar:** Glass navigation bar has the wrong height with 3-button navigation ([#4452](https://github.com/MorpheApp/morphe-patches/issues/4452)) ([6d6c523](https://github.com/MorpheApp/morphe-patches/commit/6d6c523eb5157b222d824d2dcd40465e7bce2b81))
* **YouTube - Navigation bar:** Glass navigation bar is white around the capsule in the Shorts player with the light theme ([#4447](https://github.com/MorpheApp/morphe-patches/issues/4447)) ([0223075](https://github.com/MorpheApp/morphe-patches/commit/0223075c47e48d1280bf9b242dacb06ab2096363))
* **YouTube - Navigation bar:** Glass navigation bar size preview draws the labels over the icons when the labels are hidden, and shows placeholders instead of the button icons ([59fdfe5](https://github.com/MorpheApp/morphe-patches/commit/59fdfe57b906b4df1902832c85cf62f8d2779d52))
* **YouTube - Playback speed:** Pitch presets can set an out of range pitch, speed icon shows without pitch controls ([d0b9847](https://github.com/MorpheApp/morphe-patches/commit/d0b98475e4b2d196340d9244ab3bc72df94eac76))
* **YouTube Music - Miniplayer previous and next buttons:** Buttons are missing with the deferred player layout ([683f805](https://github.com/MorpheApp/morphe-patches/commit/683f805c45f9be7fe993df346e52984952a30944))
* **YouTube Music:** Download albums and playlists offered Premium ([#4464](https://github.com/MorpheApp/morphe-patches/issues/4464)) ([a80aa75](https://github.com/MorpheApp/morphe-patches/commit/a80aa75cece6a6ca64119ac9044511a31dad9740))
* **YouTube:** Home can be rendered with RenderNext, which the Litho filters and hooks don't see ([c1dcad4](https://github.com/MorpheApp/morphe-patches/commit/c1dcad4033c61b4b79f87861999fad246badd3d7))

## [2.1.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.10...v2.1.0-dev.11) (2026-11-05)

### ✨ New Features

* **Debugging:** Block/force offline feature flags ([#4416](https://github.com/MorpheApp/morphe-patches/issues/4416)) ([f775c62](https://github.com/MorpheApp/morphe-patches/commit/f775c62ed56f575c65c53df25bfbcc634fefbdf8))
* **YouTube - Captions:** Prefer uploaded bilingual subtitles ([#4376](https://github.com/MorpheApp/morphe-patches/issues/4376)) ([a688883](https://github.com/MorpheApp/morphe-patches/commit/a68888349a433423c57a9f4d1d3b592d445e3b8c))
* **YouTube - Hide layout components:** Add "Hide comments preview" to "Post buttons" ([b7a1db3](https://github.com/MorpheApp/morphe-patches/commit/b7a1db3936c9fc956df915a5d76955b8aae0213c))
* **YouTube - Hide layout components:** Add "Post buttons" settings to choose the layout of the post buttons and hide them ([b4bbd85](https://github.com/MorpheApp/morphe-patches/commit/b4bbd85e60400ebd42549463f60dacabe3e3a3fc))
* **YouTube - Navigation bar:** Add "Glass navigation bar size" setting, and fit the glass navigation bar to its buttons ([#4424](https://github.com/MorpheApp/morphe-patches/issues/4424)) ([0295f21](https://github.com/MorpheApp/morphe-patches/commit/0295f21b1f6fe7cdbe55e574d96bc5e8ba5576bf))
* **YouTube - Niconico comments:** Add "Display area" setting ([#4425](https://github.com/MorpheApp/morphe-patches/issues/4425)) ([65bf16b](https://github.com/MorpheApp/morphe-patches/commit/65bf16b2a80d302246386917293db9099b2bf87b))
* **YouTube - Niconico comments:** Add "Max refresh rate" setting ([#4399](https://github.com/MorpheApp/morphe-patches/issues/4399)) ([090a861](https://github.com/MorpheApp/morphe-patches/commit/090a8619ec12e0f4f010ce2eec5c38e127b5459c))
* **YouTube - Series tracking:** Add "Mark watched when moving to the next episode" setting ([#4415](https://github.com/MorpheApp/morphe-patches/issues/4415)) ([c8b83c4](https://github.com/MorpheApp/morphe-patches/commit/c8b83c420da32b33049463a1c10b67de54027c6a))
* **YouTube:** Add `Snackbar` patch ([#4177](https://github.com/MorpheApp/morphe-patches/issues/4177)) ([6ce8208](https://github.com/MorpheApp/morphe-patches/commit/6ce82088309c83bd1aa413c4ec5fa11ad6d6f470))

### 🐛 Bug Fixes

* **YouTube - Feed card layout:** "getUri failure" toast and cards not converted while the app rewrites its template cache ([93b36be](https://github.com/MorpheApp/morphe-patches/commit/93b36be598e98eb9939987bc613337388f9998e5))
* **YouTube - Feed card layout:** Cards lose their rounded corners while scrolling and their margin doubles once fully shown ([63f1fc2](https://github.com/MorpheApp/morphe-patches/commit/63f1fc213af17508587a93a30c480396747233d1))
* **YouTube - Feed card layout:** Cards of the watch page grid on tablets have square corners ([515186d](https://github.com/MorpheApp/morphe-patches/commit/515186da601bce2b6c2c524c61b4f5258e998a2d))
* **YouTube - Feed card layout:** Playlists have no background below the thumbnail with the new server layout of the cards ([571a3f9](https://github.com/MorpheApp/morphe-patches/commit/571a3f9df78aee3624f4b1b91ac7c89b2fa24e2b))
* **YouTube - Feed card layout:** Server experiments of the account change the converted cards, such as removing their menu button ([aec41a5](https://github.com/MorpheApp/morphe-patches/commit/aec41a5e49d1ca3586a48d3dbf015930e8e4f29b))
* **YouTube - Hide video action buttons:** "Hide Subscribe button" and "Hide channel and Subscribe button" don't hide the channel bar above the action bar ([74fe9a3](https://github.com/MorpheApp/morphe-patches/commit/74fe9a3bb9671fe7fd2887db34c375cb9d2ff9f1))
* **YouTube - Navigation bar:** Black band behind the translucent or glass navigation bar with Hide status bar ([9897de9](https://github.com/MorpheApp/morphe-patches/commit/9897de9cafe156e0df23399dd583d1b687af076b))
* **YouTube - Navigation bar:** Glass navigation bar is too tall with layout updates disabled ([#4426](https://github.com/MorpheApp/morphe-patches/issues/4426)) ([25970b1](https://github.com/MorpheApp/morphe-patches/commit/25970b18c64c375f50844bfc51b4303178dedc28))
* **YouTube - Navigation bar:** Video button of the create button in the channel page toolbar does nothing ([41cd7ae](https://github.com/MorpheApp/morphe-patches/commit/41cd7ae70f7086a5dd1071b8a9e460293580ab80))
* **YouTube - Seekbar:** Shorts seekbar disappears after opening Shorts again or after the settings ([19f0db3](https://github.com/MorpheApp/morphe-patches/commit/19f0db3904a3a925ebb144f0e2d0292180135f4e))
* **YouTube - Series tracking:** Thumbnails reload while a video plays ([#4420](https://github.com/MorpheApp/morphe-patches/issues/4420)) ([cb687aa](https://github.com/MorpheApp/morphe-patches/commit/cb687aaa1441f99b65be5dd61d75f9b46405bedf))
* **YouTube - Settings:** New setting dot not displayed correctly on RTL languages ([585d552](https://github.com/MorpheApp/morphe-patches/commit/585d55240ad8f7d3e2918b4b15295141b42a1cba))
* **YouTube - Skip live Shorts:** A live stream opened in the regular player skips the Short behind it ([dddbfbd](https://github.com/MorpheApp/morphe-patches/commit/dddbfbde288573d88db5162596edf609904a549d))
* **YouTube:** App crashes at launch without the Theme patch ([85b2b81](https://github.com/MorpheApp/morphe-patches/commit/85b2b81a44b262425c1e583c929eb3b4613fb920))
* **YouTube:** Watch page action buttons and videos disappear or stay over the list after scrolling while the page loads ([8770def](https://github.com/MorpheApp/morphe-patches/commit/8770def2b49bd40d2637b6ba8f18a598395affed))

## [2.1.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.9...v2.1.0-dev.10) (2026-11-04)

### 🐛 Bug Fixes

* **YouTube Music:** Non-experimental targets do not patch ([2ca8ae1](https://github.com/MorpheApp/morphe-patches/commit/2ca8ae1098f2a1c964ddb26703fa9b0b178c736d))

## [2.1.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.8...v2.1.0-dev.9) (2026-11-04)

### ✨ New Features

* **YouTube - Swipe controls:** Add swipe to seek ([#4364](https://github.com/MorpheApp/morphe-patches/issues/4364)) ([d211d79](https://github.com/MorpheApp/morphe-patches/commit/d211d79e44bae50663523ee7c0eb89c47b145ec6))
* **YouTube Music - Downloads:** Add album and playlist downloads ([#4398](https://github.com/MorpheApp/morphe-patches/issues/4398)) ([156b0c9](https://github.com/MorpheApp/morphe-patches/commit/156b0c94d488d30e8f495cfb844c24d1028e3530))

### 🐛 Bug Fixes

* **Spoof video streams:** Do not block get_watch, initplayback, or Onesie requests ([#4373](https://github.com/MorpheApp/morphe-patches/issues/4373)) ([9d38c68](https://github.com/MorpheApp/morphe-patches/commit/9d38c684386881683d257713591cc0a3281fe587))
* **YouTube Music - Downloads:** Dowloading with flyout menu shows premium popup ([#4382](https://github.com/MorpheApp/morphe-patches/issues/4382)) ([4b6c282](https://github.com/MorpheApp/morphe-patches/commit/4b6c282157b9d6ba8564d4042ce888d1108dba1c))
* **YouTube Music - Downloads:** Downloads screen freezes with a large catalogue ([#4396](https://github.com/MorpheApp/morphe-patches/issues/4396)) ([e429778](https://github.com/MorpheApp/morphe-patches/commit/e4297782630de4216fe6eb03f7eee84c0ba9252f))
* **YouTube Music - Downloads:** Offline playback crashes with a large queue ([#4397](https://github.com/MorpheApp/morphe-patches/issues/4397)) ([ba12903](https://github.com/MorpheApp/morphe-patches/commit/ba12903f57a6c7c61fb4f6a02e46b96fbef1b412))

## [2.1.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.7...v2.1.0-dev.8) (2026-11-04)

### ✨ New Features

* **YouTube - Feed card layout:** Add "Default" to "Feed card layout", which keeps the layout that the server sends ([55c8bc0](https://github.com/MorpheApp/morphe-patches/commit/55c8bc0951c151a18e8b6a4c060faceec127fc31))
* **YouTube - Navigation bar:** Add "Enable glass navigation bar" setting ([#4338](https://github.com/MorpheApp/morphe-patches/issues/4338)) ([6d74097](https://github.com/MorpheApp/morphe-patches/commit/6d740979fb0cb83459d9f6bae36b2416430ca534))
* **YouTube - Navigation bar:** Add "Navigation buttons order" and "Toolbar buttons order" settings ([#4374](https://github.com/MorpheApp/morphe-patches/issues/4374)) ([b2f9e19](https://github.com/MorpheApp/morphe-patches/commit/b2f9e193450e9b970404bb14fb20b97b93d684f7))
* **YouTube - Navigation bar:** Added a Glass navigation bar lit rim ([afc5afe](https://github.com/MorpheApp/morphe-patches/commit/afc5afea438ecc3e2b65dadab8a0a5f56bf6d275))
* **YouTube Music - Third-party lyrics:** Add reactive dynamic background layout refinements, and automatic ruby generation ([#4208](https://github.com/MorpheApp/morphe-patches/issues/4208)) ([2d9e39f](https://github.com/MorpheApp/morphe-patches/commit/2d9e39fe1dedb1462a95f9e6e7f920bf6e9b693c))

### 🐛 Bug Fixes

* **YouTube  - Save to Watch later:** Implement the refinements for Watch Later screen ([#4324](https://github.com/MorpheApp/morphe-patches/issues/4324)) ([ee68a99](https://github.com/MorpheApp/morphe-patches/commit/ee68a993a266ee03566c3cf097bca8f0af3354f7))
* **YouTube - Feed card layout:** Comment button of the cards opens the video instead of only the comments panel ([9adfb63](https://github.com/MorpheApp/morphe-patches/commit/9adfb637d3e7e5d1cd4cf26cda07d04a31094258))
* **YouTube - Feed card layout:** Feed videos disappear and come back on scroll when the app drops the cached template version ([be4a66a](https://github.com/MorpheApp/morphe-patches/commit/be4a66a0d6031df4562a214ebfb05cb4122b2d6d))
* **YouTube - Feed card layout:** Feed videos have no save items in the menu when the cards with a save button are converted to the classic layout ([1d34aae](https://github.com/MorpheApp/morphe-patches/commit/1d34aaed6681270670bf8a618b89a3bd1f3dae14))
* **YouTube - Feed card layout:** Playlists converted to cards have no background below the thumbnail ([3a07c14](https://github.com/MorpheApp/morphe-patches/commit/3a07c14994018225fdc9add3494c8e6f2f3b6d8f))
* **YouTube - Hide layout components:** "Hide Explore button" not working in incognito mode ([61e1e9f](https://github.com/MorpheApp/morphe-patches/commit/61e1e9f16adb4c3bce954526441257095814d7df))
* **YouTube - Hide layout components:** Prevent shelves from hiding on Charts, Memberships, and Playables pages ([a61f9b4](https://github.com/MorpheApp/morphe-patches/commit/a61f9b455e4846bfc4de63fc25f4326466bbdec2))
* **YouTube - Navigation bar:** Glass navigation bar is wider than its buttons, so the first and the last button are not aligned with the ends of the bar ([93f9010](https://github.com/MorpheApp/morphe-patches/commit/93f90107ebd5c328865b9e9bf1e048b581c576f6))
* **YouTube - Niconico comments:** Keep a high refresh rate while comments move ([#4377](https://github.com/MorpheApp/morphe-patches/issues/4377)) ([5046880](https://github.com/MorpheApp/morphe-patches/commit/50468807ab6de322bf16a425519c14b7021960df))
* **YouTube - Niconico comments:** Move comments smoothly before the first video state is reported ([#4378](https://github.com/MorpheApp/morphe-patches/issues/4378)) ([76ec46d](https://github.com/MorpheApp/morphe-patches/commit/76ec46dfb32b29204f13d672d56b41b75254a8e7))
* **YouTube - Restore original titles:** Update titles during background playback ([#4347](https://github.com/MorpheApp/morphe-patches/issues/4347)) ([ed67be3](https://github.com/MorpheApp/morphe-patches/commit/ed67be3d6dbb988702c23733a54342dd22fef169))

## [2.1.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.6...v2.1.0-dev.7) (2026-11-03)

### ✨ New Features

* **YouTube - Copy text:** Add option to select text of descriptions and posts ([#4317](https://github.com/MorpheApp/morphe-patches/issues/4317)) ([37f6321](https://github.com/MorpheApp/morphe-patches/commit/37f632113ea6e7740a9b11c3d3e715335498fd30))
* **YouTube - Navigation bar:** Add "Show Watch later button" setting ([#4320](https://github.com/MorpheApp/morphe-patches/issues/4320)) ([338a4dc](https://github.com/MorpheApp/morphe-patches/commit/338a4dc8101f45ca36619a1aa48da7baf90f8ea5))
* **YouTube - Niconico comments:** Add reset button to quick settings ([#4339](https://github.com/MorpheApp/morphe-patches/issues/4339)) ([030d3fc](https://github.com/MorpheApp/morphe-patches/commit/030d3fc75315fb353d47cfb42fa2867c8b757813))
* **YouTube - Niconico comments:** Add video type selection ([#4327](https://github.com/MorpheApp/morphe-patches/issues/4327)) ([e6dbce0](https://github.com/MorpheApp/morphe-patches/commit/e6dbce04f115d7ddd65393b55f0aa9177a6e5591))
* **YouTube - Translate live chat:** Add DeepL provider and fix Google rate limiting issue ([#4313](https://github.com/MorpheApp/morphe-patches/issues/4313)) ([aa84d03](https://github.com/MorpheApp/morphe-patches/commit/aa84d037b9547a6bd7848ceabc65293a2811c8dd))
* **YouTube:** Remove the new setting dot once the setting is opened or changed ([7e8766c](https://github.com/MorpheApp/morphe-patches/commit/7e8766c5fb46fdeab4807bff1786b510f29e8f32))

### 🐛 Bug Fixes

* **Spoof video streams:** Video opened from the search results can load forever when another video is fetched at the same time ([#4334](https://github.com/MorpheApp/morphe-patches/issues/4334)) ([25cde38](https://github.com/MorpheApp/morphe-patches/commit/25cde38f3cf00c015b4bc4d6cd0d56daf7a2914b))
* **YouTube - Feed view count:** Badge of a card that enters from the bottom is hidden between the loading spinner and the view count, when the view count is on a row below the channel ([c9a1a63](https://github.com/MorpheApp/morphe-patches/commit/c9a1a635a3e44b5ecb8562b66fb9dece755c57ab))
* **YouTube - Force fullscreen landscape:** Setting is shown on large screens with Android 16 and later, which ignore the orientation it requests ([79e201f](https://github.com/MorpheApp/morphe-patches/commit/79e201f81c3c158aedc5b613caaee6c363b50d78))
* **YouTube - Hide ads:** Ads are shown in the Shorts feed when a channel is in the ad whitelist ([067aee9](https://github.com/MorpheApp/morphe-patches/commit/067aee9be70f204fd2c5b85ccaef1471c9127280))
* **YouTube - Hide layout components:** Comment box, composer and reply buttons open the channel guidelines sheet with "Hide Community Guidelines" ([7e9903d](https://github.com/MorpheApp/morphe-patches/commit/7e9903d19cb96334285d8035a31e167990f49936))
* **YouTube - Hide layout components:** Pages of the Explore menu, such as Movies and Memberships, are empty or miss their shelves with "Hide horizontal shelves" ([a8acc59](https://github.com/MorpheApp/morphe-patches/commit/a8acc59cfca6b0a5c42edd2d33fd2bcd01f6283f))
* **YouTube - Minimal miniplayer:** Bar keeps a larger gap above the snackbar than the snackbar keeps above the navigation bar ([49dbd6a](https://github.com/MorpheApp/morphe-patches/commit/49dbd6a6222e0f6c768626b2c2f7d1f9b4a6b5dd))
* **YouTube - Minimal miniplayer:** Snackbar covers the bar instead of moving it up like the default miniplayer ([94775a9](https://github.com/MorpheApp/morphe-patches/commit/94775a9336ce259873720c2fe7ba2acb79556826))
* **YouTube - Morphe snackbar:** Increased snackbar queue timeout to 5 seconds ([67b7f76](https://github.com/MorpheApp/morphe-patches/commit/67b7f7693bbc0b7addccc2621a0d078bb52f99f0))
* **YouTube - Niconico comments:** Make quick settings scrollable in landscape ([#4325](https://github.com/MorpheApp/morphe-patches/issues/4325)) ([5d10b9d](https://github.com/MorpheApp/morphe-patches/commit/5d10b9de895cb6a24090133aa8e264151f569126))
* **YouTube - Playback speed:** Holding a Short does not play it at 2.0x when a default Shorts speed is set ([8e32e0f](https://github.com/MorpheApp/morphe-patches/commit/8e32e0f4bb1964811cdbdff1579dbbfce9d22a65))
* **YouTube - Playback speed:** Holding a Short does not play it at the custom tap and hold speed when a default Shorts speed is set ([ad00990](https://github.com/MorpheApp/morphe-patches/commit/ad0099088f806428f1bf890297bd005c6e6c1484))
* **YouTube - Premium-style queue:** Fix dragging videos to the end ([#4315](https://github.com/MorpheApp/morphe-patches/issues/4315)) ([010d9e6](https://github.com/MorpheApp/morphe-patches/commit/010d9e6d0960a643685ae79bc09978739ece14cc))
* **YouTube - Remove background playback restrictions:** Video does not resume when a Short opened over it is closed ([f8c8139](https://github.com/MorpheApp/morphe-patches/commit/f8c813916c48d0428c8a3e4def40aca58060db81))
* **YouTube - Theme:** App crashes on launch with Android 8.0 when the device uses a night configuration and the app uses the light theme ([a290229](https://github.com/MorpheApp/morphe-patches/commit/a290229ef9ffea037a2997fc46962ab12957634c))
* **YouTube - Theme:** Status bar shows white icons on the light theme colors other than white ([d81b7c1](https://github.com/MorpheApp/morphe-patches/commit/d81b7c1eb4e8ff26ed00816a72fc63b5f20b7578))
* **YouTube Music - Downloads:** Offline playback audio focus handling ([#4314](https://github.com/MorpheApp/morphe-patches/issues/4314)) ([509306c](https://github.com/MorpheApp/morphe-patches/commit/509306cdcd85be088e6a97b2b56e4d34cbb400e3))
* **YouTube Music - Hide flyout menu components:** Fix patching 9.44.52 ([8fdd7fe](https://github.com/MorpheApp/morphe-patches/commit/8fdd7fe91d3b19b03d9ec99dc8f5ecf5ed1534b1))
* **YouTube Music - Settings:** App crashes when opening settings with 9.44.52 ([4647eea](https://github.com/MorpheApp/morphe-patches/commit/4647eea4233d4f10d5c832adca797a3e67dbb677))
* **YouTube Music - Third-party lyrics:** Various minor bug fixes ([#4323](https://github.com/MorpheApp/morphe-patches/issues/4323)) ([f3a64b6](https://github.com/MorpheApp/morphe-patches/commit/f3a64b6c6833667a734512de5b904ed3597c324b))
* **YouTube:** Snackbars are shown with an empty space above the navigation bar, as high as the system navigation buttons ([0eb5a08](https://github.com/MorpheApp/morphe-patches/commit/0eb5a08d127dabbc4375ed0f97c22296824f9b57))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.44.52` ([cfd507d](https://github.com/MorpheApp/morphe-patches/commit/cfd507d0329987016aa61b6bc6952b2bbc8a3237))

## [2.1.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.5...v2.1.0-dev.6) (2026-11-02)

### ✨ New Features

* **YouTube - Restore old video action bar:** Add the "Classic Two-Rows" layout to "Video action bar layout", and remove "Enable tablet layout in player" ([73eeadb](https://github.com/MorpheApp/morphe-patches/commit/73eeadb72c35913399e4fc9f5e1abb2ebecf22b4))
* **YouTube / YouTube Music - Hide layout components:** Add "Hide GIF button" and "Hide GIFs and images" comment settings ([#4289](https://github.com/MorpheApp/morphe-patches/issues/4289)) ([7044284](https://github.com/MorpheApp/morphe-patches/commit/7044284d0b0dd9ea1334652f91923a3f1721e18e))
* **YouTube Music:** Add playlist creation from downloaded music tracks ([#4232](https://github.com/MorpheApp/morphe-patches/issues/4232)) ([931f427](https://github.com/MorpheApp/morphe-patches/commit/931f4273fa89c6e47a3e6d9850184f8401ce2141))
* **YouTube:** Show at most one Morphe snackbar message each second ([3569fbc](https://github.com/MorpheApp/morphe-patches/commit/3569fbc184b58d4da4ac19d404da928ec4ba9d1f))

### 🐛 Bug Fixes

* **YouTube - Change start page:** Top bar and navigation bar show the default buttons for 20 seconds without a cached guide ([2e18f68](https://github.com/MorpheApp/morphe-patches/commit/2e18f6885a4cec85da277f219c61fe69e9585ff8))
* **YouTube - Downloads:** Use default export folder if the picked folder is missing ([e34115d](https://github.com/MorpheApp/morphe-patches/commit/e34115deb3ef00634a387e58c092744e5a7b6952))
* **YouTube - Feed view count:** Badge of a vertical thumbnail is in the middle of the thumbnail until the title row is drawn ([5d01f60](https://github.com/MorpheApp/morphe-patches/commit/5d01f6024e78c66ca64d2c19cdb1b3d2c987daac))
* **YouTube - Feed view count:** Loading spinner is shown on cards whose title row is not drawn yet, such as long thumbnails ([0b58b9d](https://github.com/MorpheApp/morphe-patches/commit/0b58b9db57f3c6140e237a59f097ba1434d93335))
* **YouTube - Feed view count:** View count of the previous video is shown for a moment when a list reuses a card, such as in the notifications ([86cd350](https://github.com/MorpheApp/morphe-patches/commit/86cd3501924a494b128b41f56b4c849b54d27fcc))
* **YouTube - Search comments:** Improved the check of the comments panels ([ec1c31d](https://github.com/MorpheApp/morphe-patches/commit/ec1c31d1c7e7a85d714ddc2a9ae62b0aad49e1a1))
* **YouTube Music - Third-party lyrics:** Support tabbed lyrics panels ([#4267](https://github.com/MorpheApp/morphe-patches/issues/4267)) ([a56766b](https://github.com/MorpheApp/morphe-patches/commit/a56766b47feedad72cac55e1d28a507d2f8edbf4))
* **YouTube:** Consolidate "Hide cast button" into a single setting ([5daa6d6](https://github.com/MorpheApp/morphe-patches/commit/5daa6d6e372d0b72d31f5fa4faea6a74049a92a8))
* **YouTube:** Crash on Android 12 when closing a settings screen with a new setting ([77911d1](https://github.com/MorpheApp/morphe-patches/commit/77911d167ceeaa6da1501c64072e189a642a846c))

## [2.1.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.4...v2.1.0-dev.5) (2026-11-01)

### ✨ New Features

* **YouTube - Captions:** Add bilingual captions with synchronized blocks ([#4213](https://github.com/MorpheApp/morphe-patches/issues/4213)) ([0dd8f39](https://github.com/MorpheApp/morphe-patches/commit/0dd8f39adf7bd2960bec992fa661c9a700051a0a))
* **YouTube - Feed video actions:** Watch later button shows a check mark if the video is saved, and removes the video when tapped ([a976db8](https://github.com/MorpheApp/morphe-patches/commit/a976db85f337ce742fbd9a154b26d9745930738c))
* **YouTube - Restore old video action bar:** Replace the setting with "Video action bar layout", with the Default, Classic and Minimal layouts ([545cd37](https://github.com/MorpheApp/morphe-patches/commit/545cd37cc0716ff447508ffa2e31ad599800b012))
* **YouTube:** Add `Translate live chat` patch ([#4222](https://github.com/MorpheApp/morphe-patches/issues/4222)) ([9b598a2](https://github.com/MorpheApp/morphe-patches/commit/9b598a2ce7ff17b2f453fc56f730a734bba1a4e7))

### 🐛 Bug Fixes

* **YouTube - Feed card layout:** Classic layout does not apply to mixes, playlists and posts ([fac7d56](https://github.com/MorpheApp/morphe-patches/commit/fac7d5658a63381fc3f072c7e684b026930109e6))
* **YouTube - Feed view count:** Badge is shown when the text below the title already shows the view count ([f5faf04](https://github.com/MorpheApp/morphe-patches/commit/f5faf04e505baa84ea57b0de1a77b8dbed5ad891))
* **YouTube - GmsCore Support:** Allow casting to audio only devices ([#4268](https://github.com/MorpheApp/morphe-patches/issues/4268)) ([ec04b15](https://github.com/MorpheApp/morphe-patches/commit/ec04b153109ec227d52a75f471b3c886606f4f5e))
* **YouTube - Hide layout components:** Filtered download item of the feed flyout menu appears until its download state is loaded ([be60b7c](https://github.com/MorpheApp/morphe-patches/commit/be60b7c67fd17d9554cca2d1001f2255ba95c903))
* **YouTube - Hide player flyout menu components:** Fix player flyout menu items not hiding ([#4260](https://github.com/MorpheApp/morphe-patches/issues/4260)) ([74dc44b](https://github.com/MorpheApp/morphe-patches/commit/74dc44b5924c0baa7937cdef000f529e5418b09e))
* **YouTube - Seekbar:** Videos with their own seekbar style show an image as the seekbar handle and ignore the seekbar color ([e0dcffb](https://github.com/MorpheApp/morphe-patches/commit/e0dcffbb32401e5929ccdbc3d2a2c55506a4e2a8))
* **YouTube:** Channel whitelist and AiSList report items are missing from the Shorts player flyout menu ([acda216](https://github.com/MorpheApp/morphe-patches/commit/acda21652dbbd533d3395c4ebbe33601d361cbd2))
* **YouTube:** Fix delayed Subscriptions header on 21.28 & 21.30 ([#4278](https://github.com/MorpheApp/morphe-patches/issues/4278)) ([35c1189](https://github.com/MorpheApp/morphe-patches/commit/35c1189c40298860d830e8a9167523ec1f7e0ca6))

## [2.1.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.3...v2.1.0-dev.4) (2026-10-31)

### 🐛 Bug Fixes

* **Spoof video streams:** Do not fetch streams again if a fetch for the same video is in progress ([14cfd47](https://github.com/MorpheApp/morphe-patches/commit/14cfd47d0a5bd0ccf7d388506678fa5e68dd8361))
* **YouTube - Translate posts:** Patch may crash on devices older than Android 10 ([589c3ab](https://github.com/MorpheApp/morphe-patches/commit/589c3abbe540026426f3336b04c2f13cd692b127))

## [2.1.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.2...v2.1.0-dev.3) (2026-10-31)

### ✨ New Features

* **YouTube - Minimal miniplayer:** Add "Docked miniplayer" setting ([f89b66f](https://github.com/MorpheApp/morphe-patches/commit/f89b66f2e5c63637346def8aae49858d76bb14dd))
* **YouTube - Minimal miniplayer:** Add "Expand with swipe up" setting ([e0e36ba](https://github.com/MorpheApp/morphe-patches/commit/e0e36ba3d11e2bd56ba561292887a6c9f626ff72))
* **YouTube:** Add `Change PiP actions` patch ([#4175](https://github.com/MorpheApp/morphe-patches/issues/4175)) ([d9fc859](https://github.com/MorpheApp/morphe-patches/commit/d9fc85939f31340a2678e38375f2290a8d49da7f))

### 🐛 Bug Fixes

* **YouTube - Downloads:** App can crash when downloading Short in-app ([bae1787](https://github.com/MorpheApp/morphe-patches/commit/bae1787e9d2f56e5d5dc845d1916cc46b5c8c288))
* **YouTube - Feed video actions:** Inline watch later button performClick logic superseeded by direct app command ([7f343df](https://github.com/MorpheApp/morphe-patches/commit/7f343df16754bec9a4e102076c450bbf585c94a8))
* **YouTube - Navigation bar:** Swap create with notifications button does not change the toolbar of the You tab ([3c03bbb](https://github.com/MorpheApp/morphe-patches/commit/3c03bbb585c9bcfa05f2cc4d1252e341e0904cb5))
* **YouTube - Navigation bar:** Swiping the miniplayer does not cancel autoplay with Disable auto hide navigation bar ([136d5bc](https://github.com/MorpheApp/morphe-patches/commit/136d5bcbe4672192be5e3486ee100fe8529453a6))
* **YouTube - Swipe controls:** Fix double tap to skip chapters ([#4219](https://github.com/MorpheApp/morphe-patches/issues/4219)) ([602533c](https://github.com/MorpheApp/morphe-patches/commit/602533c6f54e5590cd581e977b185b7feaa26eb6))
* **YouTube Music - Downloads:** Download can fail with "Audio stream unavailable" with TV spoof client ([2406f60](https://github.com/MorpheApp/morphe-patches/commit/2406f60bc256a6dc1848e74b5fd544aec6bb4267))

## [2.1.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v2.1.0-dev.1...v2.1.0-dev.2) (2026-10-31)

### 🐛 Bug Fixes

* **YouTube:** Update experimental target version name ([0f25ad3](https://github.com/MorpheApp/morphe-patches/commit/0f25ad37c62124744f9dce20f1700678cbc45f38))

## [2.1.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v2.0.0...v2.1.0-dev.1) (2026-10-31)

### ✨ New Features

* **GmsCore support:** Support video/audio casting to other devices (Requires latest MicroG-RE) ([#3899](https://github.com/MorpheApp/morphe-patches/issues/3899)) ([87f41aa](https://github.com/MorpheApp/morphe-patches/commit/87f41aae43c3c957c64ac570731343040975c584))
* **YouTube - Downloads:** Export in-app videos to device storage ([#4211](https://github.com/MorpheApp/morphe-patches/issues/4211)) ([9130f66](https://github.com/MorpheApp/morphe-patches/commit/9130f6626f2468d8b75a8befd5856002686279f3))
* **YouTube - Theme:** Add setting to configure 'Glow' splash screen duration, and allow tapping to skip animation ([05a808a](https://github.com/MorpheApp/morphe-patches/commit/05a808a64c02d283f84654a9507874a3db0f0122))

### 🐛 Bug Fixes

* **YouTube - Feed video actions:** Tap and hold on the Watch later button can show the video menu instead of the Save to playlist panel ([810fcdb](https://github.com/MorpheApp/morphe-patches/commit/810fcdbab73e3afaf449cf7934fd1312d9338091))
* **YouTube - Hide layout components:** Downloads item of the You tab cannot be hidden ([e3b17aa](https://github.com/MorpheApp/morphe-patches/commit/e3b17aab860c6220368fbb9c74f7e5b2be0b591d))
* **YouTube - Minimal miniplayer:** Bar is black beside the video while the player collapses in the light theme ([e47fc6f](https://github.com/MorpheApp/morphe-patches/commit/e47fc6f9353699849990878413763d1af3be70f9))
* **YouTube - Save to Watch later:** Item is missing from the flyout menus without a save item, such as the main feed ([0afe955](https://github.com/MorpheApp/morphe-patches/commit/0afe9559915f6f6baa559d9b7ae13a612ae87525))
* **YouTube - Search comments:** Search button wasn't shown in the post comments panel ([a54518a](https://github.com/MorpheApp/morphe-patches/commit/a54518adbb5f1a861b2b0cffda3add454f7dd3dc))
* **YouTube - Video quality:** Quality selected for a regular video in the miniplayer is lost after opening Shorts ([624bb5d](https://github.com/MorpheApp/morphe-patches/commit/624bb5d66ce8d6d531f4430cbd67a682c87e7f48))
* **YouTube:** Flyout menu items can run the action of another item, such as Save to playlist adding the video to the queue ([44badd3](https://github.com/MorpheApp/morphe-patches/commit/44badd3d71c535436590b39fa56262d336369499))
* **YouTube:** Flyout menus are polled every 10 ms on the main thread, even if a menu is never shown ([3afaf21](https://github.com/MorpheApp/morphe-patches/commit/3afaf21be27495d8fcdeddb90aded1549f8352b9))
* **YouTube:** Player flyout menu components do not hide ([#4203](https://github.com/MorpheApp/morphe-patches/issues/4203)) ([4c69ca3](https://github.com/MorpheApp/morphe-patches/commit/4c69ca3f52a1c1143fd82c0b00a610aba8b933ea))
* **YouTube:** Small comments card is shown below the player time bar ([3c58196](https://github.com/MorpheApp/morphe-patches/commit/3c581960c07724d73e4b3a0b3821108dd2939a9d))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.44.523` ([#4185](https://github.com/MorpheApp/morphe-patches/issues/4185)) ([9fbc6a3](https://github.com/MorpheApp/morphe-patches/commit/9fbc6a3d664a080d3ba759cd9f3d9f45eb18ab60))

## [2.0.0](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0...v2.0.0) (2026-10-30)

### ⚠ BREAKING CHANGES

* Patches now use Morphe Patcher 2.0.0

### 🐛 Bug Fixes

* **Reddit - Redgifs audio:** Error toast is shown when network request fails ([6707f0e](https://github.com/MorpheApp/morphe-patches/commit/6707f0e1215ba3620586b95e5c0f8b8576339a86))
* Temporarily change expired PoToken check to log only instead of a user dialog ([1669acd](https://github.com/MorpheApp/morphe-patches/commit/1669acdea4e56f6d1e812d3c0f74ee691bc2e4cd))
* **YouTube - Add to queue:** Feed below the player stutters while scrolling ([5545e3c](https://github.com/MorpheApp/morphe-patches/commit/5545e3c87458e60c5e6ef5653053c02d343dd3f8))
* **YouTube - Add to queue:** Fix native queue on experimental versions ([#4076](https://github.com/MorpheApp/morphe-patches/issues/4076)) ([e009d8b](https://github.com/MorpheApp/morphe-patches/commit/e009d8bddb1bb94525060efc3d9b38ad97ba7d72))
* **YouTube - Add to queue:** Native queue index errors crash before Android 13 ([c5f9f94](https://github.com/MorpheApp/morphe-patches/commit/c5f9f94ee71a480be00a432ee364f4e7099b9537))
* **YouTube - Ambient mode:** Ambient mode is not disabled with 21.43 ([aeb3012](https://github.com/MorpheApp/morphe-patches/commit/aeb3012a1d4fc42e9cb0e80e1cc139f24d445fb7))
* **YouTube - Ambient mode:** Ambient mode is replaced by a black background with the new watch page experiment ([43a9e4c](https://github.com/MorpheApp/morphe-patches/commit/43a9e4c8935627af8f1748071438c25b653deefb))
* **YouTube - Ambient mode:** Bypass Ambient mode restrictions does not work with 21.43 ([aeac8c9](https://github.com/MorpheApp/morphe-patches/commit/aeac8c9c15f93127a41326a3e5ae913a7c75dbae))
* **YouTube - Ask flyout menu:** Ask chat window can be hidden by onscreen keyboard ([7532430](https://github.com/MorpheApp/morphe-patches/commit/7532430e096f5730ba9321b32d8b4bd2c54c77f6))
* **YouTube - Captions:** Captions not shown in picture-in-picture on 21.16 - 21.28 ([#4024](https://github.com/MorpheApp/morphe-patches/issues/4024)) ([b2688c5](https://github.com/MorpheApp/morphe-patches/commit/b2688c5eb957f3ffd142595ff4ee7b491e3b86ae))
* **YouTube - Captions:** Old caption stays on screen after SponsorBlock skips ([#3986](https://github.com/MorpheApp/morphe-patches/issues/3986)) ([e200765](https://github.com/MorpheApp/morphe-patches/commit/e20076530e0af6061da9029bfaa4ad985fdd2f50))
* **YouTube - Captions:** Stabilize automatic captions and restore translation languages ([#4149](https://github.com/MorpheApp/morphe-patches/issues/4149)) ([ba1ac73](https://github.com/MorpheApp/morphe-patches/commit/ba1ac73757dc8935c60434de8d0362b311d73442))
* **YouTube - Channel whitelists:** Flyout menu opens with a delay while the channel is fetched ([5fed7fc](https://github.com/MorpheApp/morphe-patches/commit/5fed7fc701421b701263f742a6ba38fd4cc89dd5))
* **YouTube - Disable continue watching prompt:** Prompt can still appear during playback ([#3996](https://github.com/MorpheApp/morphe-patches/issues/3996)) ([64e3e0e](https://github.com/MorpheApp/morphe-patches/commit/64e3e0ec5eb8f98e8f8f7e11ba754fc52c3af47f))
* **YouTube - Disable playlist autoplay:** fix looping the current video ([#4064](https://github.com/MorpheApp/morphe-patches/issues/4064)) ([f4c1f84](https://github.com/MorpheApp/morphe-patches/commit/f4c1f84e13f0ed9b5982adfccbdbec1529ce0091))
* **YouTube - Download post images:** Match posts with texts of many lines or a single emoji ([#4167](https://github.com/MorpheApp/morphe-patches/issues/4167)) ([0c5dc17](https://github.com/MorpheApp/morphe-patches/commit/0c5dc17e215ad63b748570adea5894553d489dd6))
* **YouTube - Downloads:** Downloaded videos that work at first may not work later ([90d011d](https://github.com/MorpheApp/morphe-patches/commit/90d011dc007cf7e433196fd27f392c87d32363f6))
* **YouTube - Feed card layout:** Horizontal shelves lose the card background when their header is scrolled out of the list ([60489d8](https://github.com/MorpheApp/morphe-patches/commit/60489d84d49c85c44b8007af2de39ee6b82147cb))
* **YouTube - Feed card layout:** Movies converted to cards are not hidden when "Hide movies section" is enabled ([5c6357f](https://github.com/MorpheApp/morphe-patches/commit/5c6357fed1f52c5ed5d0236a393392b860e8d5ae))
* **YouTube - Feed card layout:** Shorts shelves change width and corners when only a last row with one Short is in the list ([97f1f2d](https://github.com/MorpheApp/morphe-patches/commit/97f1f2df9a2ce61384df4327f6743953c1ae598e))
* **YouTube - Feed card layout:** Videos of the horizontal shelves are cut by the left edge of the card ([c0ec5ae](https://github.com/MorpheApp/morphe-patches/commit/c0ec5ae17781305f490e589d2d53a6bc01cead46))
* **YouTube - Feed video actions:** Watch later button is missing after scrolling up ([51dfd75](https://github.com/MorpheApp/morphe-patches/commit/51dfd7565426be389f61dc5f34196cc762a103fe))
* **YouTube - Feed video actions:** Watch later button is shown above the video of posts, and is missing after the app language is changed ([#4172](https://github.com/MorpheApp/morphe-patches/issues/4172)) ([54b7371](https://github.com/MorpheApp/morphe-patches/commit/54b7371f5252dfcd287d2360e37cdacefb5ad3c2))
* **YouTube - Feed video actions:** Watch later button opens the channel in right to left languages ([0e058e8](https://github.com/MorpheApp/morphe-patches/commit/0e058e8d184650326d81a243d083ae9bd6f3f942))
* **YouTube - Feed view count:** View count badge covers the duration in right to left languages ([b012535](https://github.com/MorpheApp/morphe-patches/commit/b01253535eb65761f896042d46ba1fed002232c2))
* **YouTube - Feed view count:** View count badge of a card that enters from the bottom loads only when its title row is shown ([26715b1](https://github.com/MorpheApp/morphe-patches/commit/26715b1723f5755dc13a64c8b41be4a499f4f2cb))
* **YouTube - Force fullscreen landscape:** Screen rotates before the fullscreen gesture completes ([#4050](https://github.com/MorpheApp/morphe-patches/issues/4050)) ([83c0cf0](https://github.com/MorpheApp/morphe-patches/commit/83c0cf004e8cafa142cb862e3d78fd7e98c9f3c3))
* **YouTube - Hide layout components:** "Visit the community" entry point is not hidden in the comments of a video opened from a playlist ([e11da94](https://github.com/MorpheApp/morphe-patches/commit/e11da94ca64632956222074390f67f7f13bd82f9))
* **YouTube - Hide layout components:** Community posts are shown below a video opened from the search results, a channel or a playlist ([b373534](https://github.com/MorpheApp/morphe-patches/commit/b3735342ce3c686f25c76d5e664703f39767fc76))
* **YouTube - Hide layout components:** Fix actions blocked by Hide Snackbar ([#4038](https://github.com/MorpheApp/morphe-patches/issues/4038)) ([9a0fee9](https://github.com/MorpheApp/morphe-patches/commit/9a0fee9ec2846ba2db31cbfc2e4c2ac9b14895b7))
* **YouTube - Hide status bar:** Status bar covers the top bar or leaves an empty bar above it ([#3997](https://github.com/MorpheApp/morphe-patches/issues/3997)) ([bf6fbe0](https://github.com/MorpheApp/morphe-patches/commit/bf6fbe0c75728741f7d51a11a20e3bf2312faba9))
* **YouTube - Hide status bar:** Status bar scroll color and translucent navigation bar do not follow the hidden status bar before the edge to edge flag is read ([a9e6562](https://github.com/MorpheApp/morphe-patches/commit/a9e6562b2a4dbc5d57f8cf65a205206a800d192a))
* **YouTube - Hide status bar:** Top bars are covered by a second status bar when the app is kept out of the camera cutout ([#4112](https://github.com/MorpheApp/morphe-patches/issues/4112)) ([9d3b53c](https://github.com/MorpheApp/morphe-patches/commit/9d3b53c92cb877f309b4463b7d5067aaa1a996a3))
* **YouTube - Hide status bar:** Video player is moved below the display cutout in portrait ([f80398e](https://github.com/MorpheApp/morphe-patches/commit/f80398e107587c7fb9f995f508a65ad1953b2734))
* **YouTube - Litho filter:** Crash when scrolling a list after a filtered element is removed ([6d43157](https://github.com/MorpheApp/morphe-patches/commit/6d4315757768d792614915d0867079437505fab9))
* **YouTube - Litho filter:** Filtered elements leave empty cells in the related videos grid of the tablet layout ([e32b05c](https://github.com/MorpheApp/morphe-patches/commit/e32b05c663e30c23cb998e73fa23d78a58998962))
* **YouTube - Litho filter:** Filtered elements leave empty cells in the tablet layout grids ([#4035](https://github.com/MorpheApp/morphe-patches/issues/4035)) ([4764483](https://github.com/MorpheApp/morphe-patches/commit/4764483db626de5974ef2d3d3cf19d84ef4cfde1))
* **YouTube - Minimal miniplayer:** Bar is partly covered by the keyboard with the default navigation bar style ([bb6e0e3](https://github.com/MorpheApp/morphe-patches/commit/bb6e0e38bf4216395abacf8f4afbd45418b25ed7))
* **YouTube - Minimal miniplayer:** Video title and channel are missing after going back from the Shorts player ([7e665c6](https://github.com/MorpheApp/morphe-patches/commit/7e665c62dc3f88a6f9888b8bc48d1aea885761a1))
* **YouTube - Miniplayer:** "Disable resuming miniplayer" may not work with latest experimental app target ([8554412](https://github.com/MorpheApp/morphe-patches/commit/85544128284a29522310d43ed6bfb3e99706e9d4))
* **YouTube - Miniplayer:** Minimal miniplayer is covered by the keyboard before 21.29 ([5cd2eb2](https://github.com/MorpheApp/morphe-patches/commit/5cd2eb2f8d710e3a724d309dbf98fc845e78cb94))
* **YouTube - Miniplayer:** Related videos lists show a black frame after exiting fullscreen and scroll down ([efbc9b1](https://github.com/MorpheApp/morphe-patches/commit/efbc9b1ea1739b617306f19900fa398251131494))
* **YouTube - Navigation bar:** Black band below pages and the Shorts player when the window is not drawn behind the system navigation buttons ([60daa80](https://github.com/MorpheApp/morphe-patches/commit/60daa80ebabc420946991af736cc74ab8247fee7))
* **YouTube - Navigation bar:** Empty band below the reply bar of the comment replies ([bac5823](https://github.com/MorpheApp/morphe-patches/commit/bac5823bdd42beba2dd79f94010e2001b33017f7))
* **YouTube - Navigation bar:** Navigation bar transluency not working ([#4156](https://github.com/MorpheApp/morphe-patches/issues/4156)) ([82103d3](https://github.com/MorpheApp/morphe-patches/commit/82103d36cacc93eeaed307f75975c492fb610b24))
* **YouTube - Navigation bar:** No connection and back online bars are covered by the system navigation buttons ([2576962](https://github.com/MorpheApp/morphe-patches/commit/2576962149ab22aadc16a26853c9b7154b0d9322))
* **YouTube - Navigation bar:** System navigation buttons cannot be seen in the Shorts player with the light theme ([0115896](https://github.com/MorpheApp/morphe-patches/commit/011589657684ba34a7523f3b17af152c5962ae6e))
* **YouTube - Navigation bar:** Translucent navigation bar is not shown without the edge to edge layout ([b8e1fdd](https://github.com/MorpheApp/morphe-patches/commit/b8e1fddd8a9d7146f2ccc4d1522a86b134cfe7a6))
* **YouTube - Navigation buttons:** Create button is not hidden with the new navigation bar layout ([47f511c](https://github.com/MorpheApp/morphe-patches/commit/47f511c7ae41de2b2ac83257d5a93c4df1216526))
* **YouTube - Playback speed:** Channel speed whitelist does not work for Shorts ([be733a6](https://github.com/MorpheApp/morphe-patches/commit/be733a6883cdf4c5fc8176668afb1e7f5c22cb9f))
* **YouTube - Playback speed:** Channel speed whitelist is not applied to preloaded Shorts ([4f108b5](https://github.com/MorpheApp/morphe-patches/commit/4f108b596a71adbbf223b59faaabcfbe2469d95a))
* **YouTube - Playback speed:** Use the bold icon for the Shorts player menu item ([c710042](https://github.com/MorpheApp/morphe-patches/commit/c710042f6cf3f068141e89cd833dd580d7b64b8c))
* **YouTube - Player icon style:** Add Ionicons picture in picture button icon ([68b8628](https://github.com/MorpheApp/morphe-patches/commit/68b86282725f73c3a92602c792457371ddb88c8e))
* **YouTube - Premium-style queue:** Fix missing titles and stale now playing row ([#3795](https://github.com/MorpheApp/morphe-patches/issues/3795)) ([ef28427](https://github.com/MorpheApp/morphe-patches/commit/ef28427f63c30329b33b8d83c439c95b731a4fb6))
* **YouTube - Premium-style queue:** Play the queue when the player Next button is pressed ([#3796](https://github.com/MorpheApp/morphe-patches/issues/3796)) ([ef8dcef](https://github.com/MorpheApp/morphe-patches/commit/ef8dcef6a9ef888a075fb97d963719ddf82d6b42))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count blinks, moves, and is missing after returning to the feed ([#4176](https://github.com/MorpheApp/morphe-patches/issues/4176)) ([4dc345b](https://github.com/MorpheApp/morphe-patches/commit/4dc345b93f4007d42c124dfb021fb9cbeb221575))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is not shown with the Classic feed card layout ([15a1700](https://github.com/MorpheApp/morphe-patches/commit/15a170042639ca8bc0b4d871b781c29d00926fb2))
* **YouTube - Search comments:** Search button is not shown in the Shorts comments and is shown in other panels ([3b3308b](https://github.com/MorpheApp/morphe-patches/commit/3b3308b61740ab01e35aaa0e97166eeab80164e6))
* **YouTube - Shorts autoplay:** Overlay is out of place when going back to a Short that advanced with the comments open ([60efeb5](https://github.com/MorpheApp/morphe-patches/commit/60efeb58d08ba0e347928c7f4f903a689b474bfd))
* **YouTube - Spoof video streams:** Patch can be included for root installs ([3edf03b](https://github.com/MorpheApp/morphe-patches/commit/3edf03b8efc2f5ea0458456002938c7dbd4bf8d8))
* **YouTube - Theme:** Custom background colors are not applied with 21.43 ([#4019](https://github.com/MorpheApp/morphe-patches/issues/4019)) ([9cc833f](https://github.com/MorpheApp/morphe-patches/commit/9cc833f626bc456d142a6eafe2a613a3f2cc3784))
* **YouTube - Theme:** Glow startup animation does not extend to fullscreen ([7f1a6b3](https://github.com/MorpheApp/morphe-patches/commit/7f1a6b35c8a3989cd2b06a1e81d817015f2ca433))
* **YouTube - Video quality:** Buffered video is cleared with the placeholder playback times of live streams after selecting a quality ([36e3612](https://github.com/MorpheApp/morphe-patches/commit/36e3612c0bfa7435e47fa9529b12a819b11ac843))
* **YouTube - Video quality:** Extend the background resume fix of regular videos to Shorts ([958aa55](https://github.com/MorpheApp/morphe-patches/commit/958aa55c56ccef1e36ea1003f0f869203cc828b7))
* **YouTube - Video quality:** Quality selected for a regular video is lost when the video reloads ([16d4e60](https://github.com/MorpheApp/morphe-patches/commit/16d4e602c7c8961b35bd737b5e5770312ef1781c))
* **YouTube - Video quality:** Regular video returns to the default quality when it resumes from the background ([e5cd752](https://github.com/MorpheApp/morphe-patches/commit/e5cd7523ba2963b29fff6c3169cc71e1a58f405d))
* **YouTube - Video quality:** Selected quality is not applied to the already buffered video ([#4117](https://github.com/MorpheApp/morphe-patches/issues/4117)) ([7faa488](https://github.com/MorpheApp/morphe-patches/commit/7faa48834b1f78f8ca572c773392ed9513de8ea3))
* **YouTube - Video quality:** Short loop restarts with the previous quality when the quality is selected in its first segment ([a325744](https://github.com/MorpheApp/morphe-patches/commit/a325744ef3434bf0fe40525d4e2da9b696a2f2cb))
* **YouTube - Video quality:** Short plays the previous quality segments again when it loops ([328b85a](https://github.com/MorpheApp/morphe-patches/commit/328b85acb6fe32b7722dda7fd41ff2a8988e9c7d))
* **YouTube - Video quality:** Shorts quality menu sets another quality than the one selected ([3e15dcd](https://github.com/MorpheApp/morphe-patches/commit/3e15dcd12190c4b435287080916170e82d0b4ac5))
* **YouTube - Video quality:** Shorts quality selected in the menu is not kept and is used for the next Shorts ([82efbab](https://github.com/MorpheApp/morphe-patches/commit/82efbab5e735cfa3db7a6cc5b05a5ad00b1b0b96))
* **YouTube - Video quality:** Video restarts or plays faster after selecting a quality ([c000b53](https://github.com/MorpheApp/morphe-patches/commit/c000b53eeae02941f82a37e1c66c12a06c3d1059))
* **YouTube Music - Change miniplayer color:** Miniplayer color does not update after track changes ([e1410e3](https://github.com/MorpheApp/morphe-patches/commit/e1410e3189531c1fb4ab41c576c4fdd20aa89e36))
* **YouTube Music - Downloads:** Fix missing metadata in downloaded songs ([#3984](https://github.com/MorpheApp/morphe-patches/issues/3984)) ([7988621](https://github.com/MorpheApp/morphe-patches/commit/7988621db650eb2c32e7cab53731508ad733d5b9))
* **YouTube Music - Downloads:** Fix song menu downloads for accounts without Premium ([#4086](https://github.com/MorpheApp/morphe-patches/issues/4086)) ([93c6893](https://github.com/MorpheApp/morphe-patches/commit/93c689374b0ef72cb97d6c73881ecdb132ce7e91))
* **YouTube Music - Downloads:** Fix wrong song downloads ([#3978](https://github.com/MorpheApp/morphe-patches/issues/3978)) ([7259e27](https://github.com/MorpheApp/morphe-patches/commit/7259e27ade3bd1f76cd89f2ecad07d86f39d0335))
* **YouTube:** 21.43 navigation tabs cannot be hidden ([68b01ca](https://github.com/MorpheApp/morphe-patches/commit/68b01cad1f9419b4dc0e9141659b4def6c3660a4))
* **YouTube:** Channel page community posts do not load when feed "Hide community posts" is enabled ([#4110](https://github.com/MorpheApp/morphe-patches/issues/4110)) ([b54aaec](https://github.com/MorpheApp/morphe-patches/commit/b54aaecaa26e8e6e4491b0c54193cd2b2b6e0f2c))
* **YouTube:** Feed thumbnail badges are missing after scrolling up, show a loading spinner until they are loaded ([03ef708](https://github.com/MorpheApp/morphe-patches/commit/03ef708f724c9af7f784b75ead9da58b8cede5f4))
* **YouTube:** Feed thumbnail badges are shown on the page header of a channel that is live ([394ab97](https://github.com/MorpheApp/morphe-patches/commit/394ab97af76d788d6b13fc4c47f8e2ba4d892cfc))
* **YouTube:** Feed thumbnail badges disappear while scrolling, are missing on cards with replaced titles and are shown on live videos ([4344fab](https://github.com/MorpheApp/morphe-patches/commit/4344fab6ef2e8aa6694072f38478238b84e0f42a))
* **YouTube:** Fingerprints are not found on some targets between 21.04 and 21.35 ([52fa134](https://github.com/MorpheApp/morphe-patches/commit/52fa13489d6a97172d29cf5ff639d958506251ca))
* **YouTube:** Fix TalkBack not reading captions ([#4136](https://github.com/MorpheApp/morphe-patches/issues/4136)) ([b22841c](https://github.com/MorpheApp/morphe-patches/commit/b22841c5a6ddf6ff38b49f262ca5aa893348a600))
* **YouTube:** Miniplayer covered by the keyboard and empty band above the navigation bar ([0345136](https://github.com/MorpheApp/morphe-patches/commit/0345136b552c49b70c01fcc19a18762f57d3b7ad))
* **YouTube:** Morphe flyout menu items are missing in the new popup menu ([d2accff](https://github.com/MorpheApp/morphe-patches/commit/d2accff5135170a4288f326d89b25a81f688f063))
* **YouTube:** Morphe flyout menu items are missing on tablets ([7127541](https://github.com/MorpheApp/morphe-patches/commit/71275419c5e6b8bd6a0a108e3d7815c8ef11a88e))
* **YouTube:** Prevent TalkBack crashes caused by Litho hover recursion ([#4129](https://github.com/MorpheApp/morphe-patches/issues/4129)) ([4c00210](https://github.com/MorpheApp/morphe-patches/commit/4c002101e3472e9700acb8f92a63291f69b61116))
* **YouTube:** Remove legacy litho buffer filtering code required for app versions less than 20.22, change legacy support to `20.26.46` ([0ce43f7](https://github.com/MorpheApp/morphe-patches/commit/0ce43f7b8bf0119f295f269b939186ff264b5d48))
* **YouTube:** Restore TalkBack access to Shorts comments and descriptions ([#4128](https://github.com/MorpheApp/morphe-patches/issues/4128)) ([9542d24](https://github.com/MorpheApp/morphe-patches/commit/9542d24adf3b5ec2c25fce931418160dadbde93c))
* **YouTube:** Watch history search bar from getting hidden when selected ([#4130](https://github.com/MorpheApp/morphe-patches/issues/4130)) ([a4ecfcf](https://github.com/MorpheApp/morphe-patches/commit/a4ecfcfc3ebe99ba452e5e87c9767a83c4760c25))
* **YouTube:** Watch page feed lags when scrolling ([35e4123](https://github.com/MorpheApp/morphe-patches/commit/35e412375a1de62b500e2c9ca70c0ca5a18fb793))

### ✨ New Features

* Validate custom header and icon folders when the option is set ([fbb095d](https://github.com/MorpheApp/morphe-patches/commit/fbb095dbd6b9bf7410e4cff38b664d2fb3048aeb))
* **YouTube - Add to queue:** Add "Native queue" setting ([#3953](https://github.com/MorpheApp/morphe-patches/issues/3953)) ([372eea2](https://github.com/MorpheApp/morphe-patches/commit/372eea295ec4521b9ccdb93a3f188f81a6ad1a6c))
* **YouTube - Channel search:** Search the posts of the channel ([#4078](https://github.com/MorpheApp/morphe-patches/issues/4078)) ([93bd035](https://github.com/MorpheApp/morphe-patches/commit/93bd0351362da6c75eb40f47d0ea0e37c632eb1c))
* **YouTube - Custom branding:** Add experimental YouTube launcher icons ([#4114](https://github.com/MorpheApp/morphe-patches/issues/4114)) ([de9e6e4](https://github.com/MorpheApp/morphe-patches/commit/de9e6e4e7953f6192991e35025ed644806948ecd))
* **YouTube - Downloads:** Add "Quick download on tap" setting ([#3883](https://github.com/MorpheApp/morphe-patches/issues/3883)) ([dd97d93](https://github.com/MorpheApp/morphe-patches/commit/dd97d93628a3feb7bc8758139b01fbe42a532778))
* **YouTube - Downloads:** Add download item to the Shorts menu ([#4099](https://github.com/MorpheApp/morphe-patches/issues/4099)) ([7159826](https://github.com/MorpheApp/morphe-patches/commit/715982644742ca770a1c61fe292a77bb1ce11296))
* **YouTube - Downloads:** Add playlist downloads for accounts without Premium ([456e0db](https://github.com/MorpheApp/morphe-patches/commit/456e0db9603f0930a4893e3f24ee3eee8bd4e5f9))
* **YouTube - Hide layout components:** Add "Hide 'Unavailable videos are hidden' banner" setting ([#4134](https://github.com/MorpheApp/morphe-patches/issues/4134)) ([a7ce357](https://github.com/MorpheApp/morphe-patches/commit/a7ce357d2b654aed2a241c901bf2bc3df2ce7274))
* **YouTube - Media notification controls:** Add options to seek with Previous & Next buttons ([#3955](https://github.com/MorpheApp/morphe-patches/issues/3955)) ([2b07abb](https://github.com/MorpheApp/morphe-patches/commit/2b07abb628fec3bf625a09ab7d019f915c4dfa23))
* **YouTube - Minimal miniplayer:** Swipe the bar up to move it to the top of the screen instead of expanding the player ([f8180da](https://github.com/MorpheApp/morphe-patches/commit/f8180da70c848560c4fe17106afb49ff6852e564))
* **YouTube - Navigation bar:** Add "Disable toolbar navigation tabs" setting ([01e767c](https://github.com/MorpheApp/morphe-patches/commit/01e767c4c3a386e4b7881ce7fc867a516082db23))
* **YouTube - Navigation bar:** Add "Navigation bar style" setting ([db9af37](https://github.com/MorpheApp/morphe-patches/commit/db9af377093121e575fec80ba40e0025dfd66f81))
* **YouTube - Playback speed:** Add playback speed to the Shorts player menu ([#3982](https://github.com/MorpheApp/morphe-patches/issues/3982)) ([b717a69](https://github.com/MorpheApp/morphe-patches/commit/b717a692dfc3c99bee830af548bd13f98a3a4eaa))
* **YouTube - Theme:** Add "Glow Morphe" experimental splash screen type ([#4135](https://github.com/MorpheApp/morphe-patches/issues/4135)) ([6dbdf82](https://github.com/MorpheApp/morphe-patches/commit/6dbdf82457c5f8c7906b56f04640baf7e908060a))
* **YouTube - Theme:** Add experimental YT splash screen animation ([#4109](https://github.com/MorpheApp/morphe-patches/issues/4109)) ([1f24e84](https://github.com/MorpheApp/morphe-patches/commit/1f24e8433b26aed7a0e8cd21bf6c719526e7ecc4))
* **YouTube Music - Third-party lyrics:** enhance sync engine, providers, AI translation, and RTL word sync ([#3877](https://github.com/MorpheApp/morphe-patches/issues/3877)) ([e092212](https://github.com/MorpheApp/morphe-patches/commit/e0922124073fe53b6ff335893b8208af512f34e7))
* **YouTube Music - Third-party lyrics:** Per-syllable romanization layout, dynamic secondary vocals, and typography refinements ([#4090](https://github.com/MorpheApp/morphe-patches/issues/4090)) ([a5d943b](https://github.com/MorpheApp/morphe-patches/commit/a5d943b40369e1a6050db6b5a51a5104a2190ab9))
* **YouTube Music - Third-party lyrics:** Streamline lyrics viewing experience  ([#4002](https://github.com/MorpheApp/morphe-patches/issues/4002)) ([00a4bf4](https://github.com/MorpheApp/morphe-patches/commit/00a4bf457e8df233b21e6f73b244b0c12e91e53e))
* **YouTube Music - Third-party lyrics:** UI changes, partial feature regression ([#4182](https://github.com/MorpheApp/morphe-patches/issues/4182)) ([b6e0a64](https://github.com/MorpheApp/morphe-patches/commit/b6e0a643677d7a975413ab8d1566745cac15127c))
* **YouTube:** Add `Download post images` patch ([#3966](https://github.com/MorpheApp/morphe-patches/issues/3966)) ([5f96fbe](https://github.com/MorpheApp/morphe-patches/commit/5f96fbe0a90efd54b3e1233c9690aa18f4d38dda))
* **YouTube:** Add `Search comments` patch ([#3942](https://github.com/MorpheApp/morphe-patches/issues/3942)) ([fbb628b](https://github.com/MorpheApp/morphe-patches/commit/fbb628ba23ecdcabd00b3bdfbf94aff60f58ac68))
* **YouTube:** Add `Translate posts` patch ([#4163](https://github.com/MorpheApp/morphe-patches/issues/4163)) ([5d571a0](https://github.com/MorpheApp/morphe-patches/commit/5d571a07c37c0231b46651dd46fb2cbeef24713a))
* **YouTube:** Add Niconico-style live/replay comments ([#4080](https://github.com/MorpheApp/morphe-patches/issues/4080)) ([e9f77d7](https://github.com/MorpheApp/morphe-patches/commit/e9f77d7c5932499ababf91481b883c30e96ccd1c))
* **YouTube:** Add offline sponsorblock segment support for in-app downloads ([#4140](https://github.com/MorpheApp/morphe-patches/issues/4140)) ([136851e](https://github.com/MorpheApp/morphe-patches/commit/136851e5a5690fd9e2488eb3f0e57537bdfffc2a))
* **YouTube:** Apply offline SponsorBlock segments to playlist downloads ([#4180](https://github.com/MorpheApp/morphe-patches/issues/4180)) ([d6983da](https://github.com/MorpheApp/morphe-patches/commit/d6983da6ed69327d68ce3b188a8626ef99255d06))
* **YouTube:** Hidden a new type of community post ([fb51b72](https://github.com/MorpheApp/morphe-patches/commit/fb51b722e05df50e98302f87996525b349d0474b))
* **YouTube:** Highlight new in-app settings ([#4162](https://github.com/MorpheApp/morphe-patches/issues/4162)) ([a3b34d7](https://github.com/MorpheApp/morphe-patches/commit/a3b34d75d399fcc7dd3f9cb2c68f32fc112d979b))
* **YouTube:** Redirect Watch later saves to a chosen playlist ([#4016](https://github.com/MorpheApp/morphe-patches/issues/4016)) ([04e791d](https://github.com/MorpheApp/morphe-patches/commit/04e791d3d1c9fa8c8c352c61b18a6348311a8a27))
* **YouTube:** Show a warning when changing 'Navigation bar style' or turning on 'Enable tablet layout in player' ([445194d](https://github.com/MorpheApp/morphe-patches/commit/445194d74ab5373334e14d31e1ceb29926ac267b))
* **YouTube:** Show Morphe messages in snackbar instead of a toast ([#4148](https://github.com/MorpheApp/morphe-patches/issues/4148)) ([035718b](https://github.com/MorpheApp/morphe-patches/commit/035718bf911540f36ba768e5db78cae4ac4caf23))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.43.0` ([6407d5e](https://github.com/MorpheApp/morphe-patches/commit/6407d5efa0f7d99fb54909bc39e2074e8f60ac42))
* **Reddit:** Add experimental support for `2026.44.0` ([793f044](https://github.com/MorpheApp/morphe-patches/commit/793f0447ce2ec70d7c02c8ca005b09000a0f70b0))
* **Reddit:** Add support for `2026.40.0` ([fcc02f7](https://github.com/MorpheApp/morphe-patches/commit/fcc02f77d5a9d7a13b74d14c12b302f9d9902c61))
* **YouTube Music:** Add experimental support for `9.43.51` ([141aa8f](https://github.com/MorpheApp/morphe-patches/commit/141aa8fedea935664df73154cdc1823e893c5b88))
* **YouTube Music:** Add support for `9.30.53` ([f049c91](https://github.com/MorpheApp/morphe-patches/commit/f049c91c540f74da8dffe462a8fa5b10cb073305))
* **YouTube:** Add experimental support for `21.43.523` ([6c413e5](https://github.com/MorpheApp/morphe-patches/commit/6c413e5b7bab279add97ac084b39b0d44c8ca059))
* **YouTube:** Add support for `21.23.492` ([4599204](https://github.com/MorpheApp/morphe-patches/commit/45992041db85e4fb51900cc5a773380732dc1fda))
* **YouTube:** Add support for `21.30.216` ([89defd5](https://github.com/MorpheApp/morphe-patches/commit/89defd5d039e9dbcc139866cb5941cb3b592559d))

## [2.0.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v2.0.0-dev.3...v2.0.0-dev.4) (2026-10-30)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Community posts are shown below a video opened from the search results, a channel or a playlist ([b373534](https://github.com/MorpheApp/morphe-patches/commit/b3735342ce3c686f25c76d5e664703f39767fc76))
* **YouTube - Navigation bar:** Black band below pages and the Shorts player when the window is not drawn behind the system navigation buttons ([60daa80](https://github.com/MorpheApp/morphe-patches/commit/60daa80ebabc420946991af736cc74ab8247fee7))

## [2.0.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v2.0.0-dev.2...v2.0.0-dev.3) (2026-10-30)

### ✨ New Features

* **YouTube Music - Third-party lyrics:** UI changes, partial feature regression ([#4182](https://github.com/MorpheApp/morphe-patches/issues/4182)) ([b6e0a64](https://github.com/MorpheApp/morphe-patches/commit/b6e0a643677d7a975413ab8d1566745cac15127c))

## [2.0.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v2.0.0-dev.1...v2.0.0-dev.2) (2026-10-30)

### 🐛 Bug Fixes

* **YouTube - Captions:** Stabilize automatic captions and restore translation languages ([#4149](https://github.com/MorpheApp/morphe-patches/issues/4149)) ([ba1ac73](https://github.com/MorpheApp/morphe-patches/commit/ba1ac73757dc8935c60434de8d0362b311d73442))
* **YouTube - Feed video actions:** Watch later button is shown above the video of posts, and is missing after the app language is changed ([#4172](https://github.com/MorpheApp/morphe-patches/issues/4172)) ([54b7371](https://github.com/MorpheApp/morphe-patches/commit/54b7371f5252dfcd287d2360e37cdacefb5ad3c2))
* **YouTube - Navigation bar:** Navigation bar transluency not working ([#4156](https://github.com/MorpheApp/morphe-patches/issues/4156)) ([82103d3](https://github.com/MorpheApp/morphe-patches/commit/82103d36cacc93eeaed307f75975c492fb610b24))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count blinks, moves, and is missing after returning to the feed ([#4176](https://github.com/MorpheApp/morphe-patches/issues/4176)) ([4dc345b](https://github.com/MorpheApp/morphe-patches/commit/4dc345b93f4007d42c124dfb021fb9cbeb221575))

### ✨ New Features

* **YouTube:** Add `Translate posts` patch ([#4163](https://github.com/MorpheApp/morphe-patches/issues/4163)) ([5d571a0](https://github.com/MorpheApp/morphe-patches/commit/5d571a07c37c0231b46651dd46fb2cbeef24713a))
* **YouTube:** Apply offline SponsorBlock segments to playlist downloads ([#4180](https://github.com/MorpheApp/morphe-patches/issues/4180)) ([d6983da](https://github.com/MorpheApp/morphe-patches/commit/d6983da6ed69327d68ce3b188a8626ef99255d06))
* **YouTube:** Show Morphe messages in snackbar instead of a toast ([#4148](https://github.com/MorpheApp/morphe-patches/issues/4148)) ([035718b](https://github.com/MorpheApp/morphe-patches/commit/035718bf911540f36ba768e5db78cae4ac4caf23))

## [2.0.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.11...v2.0.0-dev.1) (2026-10-29)

### ⚠ BREAKING CHANGES

* Patches now use Morphe Patcher 2.0.0

* Treat breaking changes as major releases ([c596d42](https://github.com/MorpheApp/morphe-patches/commit/c596d42afb48dd79be022f81f3b731eda8870941))

### 🐛 Bug Fixes

* **YouTube - Download post images:** Match posts with texts of many lines or a single emoji ([#4167](https://github.com/MorpheApp/morphe-patches/issues/4167)) ([0c5dc17](https://github.com/MorpheApp/morphe-patches/commit/0c5dc17e215ad63b748570adea5894553d489dd6))

### ✨ New Features

* **YouTube:** Add offline sponsorblock segment support for in-app downloads ([#4140](https://github.com/MorpheApp/morphe-patches/issues/4140)) ([136851e](https://github.com/MorpheApp/morphe-patches/commit/136851e5a5690fd9e2488eb3f0e57537bdfffc2a))
* **YouTube:** Highlight new in-app settings ([#4162](https://github.com/MorpheApp/morphe-patches/issues/4162)) ([a3b34d7](https://github.com/MorpheApp/morphe-patches/commit/a3b34d75d399fcc7dd3f9cb2c68f32fc112d979b))

### 🚀 Updated App Support

* **YouTube Music:** Add support for `9.30.53` ([f049c91](https://github.com/MorpheApp/morphe-patches/commit/f049c91c540f74da8dffe462a8fa5b10cb073305))

## [1.49.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.10...v1.49.0-dev.11) (2026-10-29)

### ⚠ BREAKING CHANGES

* **YouTube - Theme:** Patches now use Morphe Patcher 2.0.0

Co-authored-by: MarcaDian <152095496+MarcaDian@users.noreply.github.com>

### 🐛 Bug Fixes

* **YouTube - Ambient mode:** Ambient mode is replaced by a black background with the new watch page experiment ([43a9e4c](https://github.com/MorpheApp/morphe-patches/commit/43a9e4c8935627af8f1748071438c25b653deefb))
* **YouTube - Ambient mode:** Bypass Ambient mode restrictions does not work with 21.43 ([aeac8c9](https://github.com/MorpheApp/morphe-patches/commit/aeac8c9c15f93127a41326a3e5ae913a7c75dbae))
* **YouTube - Feed card layout:** Movies converted to cards are not hidden when "Hide movies section" is enabled ([5c6357f](https://github.com/MorpheApp/morphe-patches/commit/5c6357fed1f52c5ed5d0236a393392b860e8d5ae))
* **YouTube - Feed view count:** View count badge of a card that enters from the bottom loads only when its title row is shown ([26715b1](https://github.com/MorpheApp/morphe-patches/commit/26715b1723f5755dc13a64c8b41be4a499f4f2cb))
* **YouTube - Hide layout components:** "Visit the community" entry point is not hidden in the comments of a video opened from a playlist ([e11da94](https://github.com/MorpheApp/morphe-patches/commit/e11da94ca64632956222074390f67f7f13bd82f9))
* **YouTube - Video quality:** Buffered video is cleared with the placeholder playback times of live streams after selecting a quality ([36e3612](https://github.com/MorpheApp/morphe-patches/commit/36e3612c0bfa7435e47fa9529b12a819b11ac843))
* **YouTube - Video quality:** Extend the background resume fix of regular videos to Shorts ([958aa55](https://github.com/MorpheApp/morphe-patches/commit/958aa55c56ccef1e36ea1003f0f869203cc828b7))
* **YouTube - Video quality:** Quality selected for a regular video is lost when the video reloads ([16d4e60](https://github.com/MorpheApp/morphe-patches/commit/16d4e602c7c8961b35bd737b5e5770312ef1781c))
* **YouTube - Video quality:** Regular video returns to the default quality when it resumes from the background ([e5cd752](https://github.com/MorpheApp/morphe-patches/commit/e5cd7523ba2963b29fff6c3169cc71e1a58f405d))
* **YouTube - Video quality:** Short loop restarts with the previous quality when the quality is selected in its first segment ([a325744](https://github.com/MorpheApp/morphe-patches/commit/a325744ef3434bf0fe40525d4e2da9b696a2f2cb))
* **YouTube - Video quality:** Short plays the previous quality segments again when it loops ([328b85a](https://github.com/MorpheApp/morphe-patches/commit/328b85acb6fe32b7722dda7fd41ff2a8988e9c7d))
* **YouTube - Video quality:** Video restarts or plays faster after selecting a quality ([c000b53](https://github.com/MorpheApp/morphe-patches/commit/c000b53eeae02941f82a37e1c66c12a06c3d1059))
* **YouTube Music - Change miniplayer color:** Miniplayer color does not update after track changes ([e1410e3](https://github.com/MorpheApp/morphe-patches/commit/e1410e3189531c1fb4ab41c576c4fdd20aa89e36))
* **YouTube:** Feed thumbnail badges are shown on the page header of a channel that is live ([394ab97](https://github.com/MorpheApp/morphe-patches/commit/394ab97af76d788d6b13fc4c47f8e2ba4d892cfc))
* **YouTube:** Feed thumbnail badges disappear while scrolling, are missing on cards with replaced titles and are shown on live videos ([4344fab](https://github.com/MorpheApp/morphe-patches/commit/4344fab6ef2e8aa6694072f38478238b84e0f42a))
* **YouTube:** Fix TalkBack not reading captions ([#4136](https://github.com/MorpheApp/morphe-patches/issues/4136)) ([b22841c](https://github.com/MorpheApp/morphe-patches/commit/b22841c5a6ddf6ff38b49f262ca5aa893348a600))
* **YouTube:** Prevent TalkBack crashes caused by Litho hover recursion ([#4129](https://github.com/MorpheApp/morphe-patches/issues/4129)) ([4c00210](https://github.com/MorpheApp/morphe-patches/commit/4c002101e3472e9700acb8f92a63291f69b61116))
* **YouTube:** Watch history search bar from getting hidden when selected ([#4130](https://github.com/MorpheApp/morphe-patches/issues/4130)) ([a4ecfcf](https://github.com/MorpheApp/morphe-patches/commit/a4ecfcfc3ebe99ba452e5e87c9767a83c4760c25))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Unavailable videos are hidden' banner" setting ([#4134](https://github.com/MorpheApp/morphe-patches/issues/4134)) ([a7ce357](https://github.com/MorpheApp/morphe-patches/commit/a7ce357d2b654aed2a241c901bf2bc3df2ce7274))
* **YouTube - Minimal miniplayer:** Swipe the bar up to move it to the top of the screen instead of expanding the player ([f8180da](https://github.com/MorpheApp/morphe-patches/commit/f8180da70c848560c4fe17106afb49ff6852e564))
* **YouTube - Theme:** Add "Glow Morphe" experimental splash screen type ([#4135](https://github.com/MorpheApp/morphe-patches/issues/4135)) ([6dbdf82](https://github.com/MorpheApp/morphe-patches/commit/6dbdf82457c5f8c7906b56f04640baf7e908060a))
* **YouTube Music - Third-party lyrics:** Per-syllable romanization layout, dynamic secondary vocals, and typography refinements ([#4090](https://github.com/MorpheApp/morphe-patches/issues/4090)) ([a5d943b](https://github.com/MorpheApp/morphe-patches/commit/a5d943b40369e1a6050db6b5a51a5104a2190ab9))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.44.0` ([793f044](https://github.com/MorpheApp/morphe-patches/commit/793f0447ce2ec70d7c02c8ca005b09000a0f70b0))
* **YouTube:** Add support for `21.30.216` ([89defd5](https://github.com/MorpheApp/morphe-patches/commit/89defd5d039e9dbcc139866cb5941cb3b592559d))

## [1.49.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.9...v1.49.0-dev.10) (2026-10-28)

### 🐛 Bug Fixes

* **YouTube - Ask flyout menu:** Ask chat window can be hidden by onscreen keyboard ([7532430](https://github.com/MorpheApp/morphe-patches/commit/7532430e096f5730ba9321b32d8b4bd2c54c77f6))
* **YouTube - Hide status bar:** Top bars are covered by a second status bar when the app is kept out of the camera cutout ([#4112](https://github.com/MorpheApp/morphe-patches/issues/4112)) ([9d3b53c](https://github.com/MorpheApp/morphe-patches/commit/9d3b53c92cb877f309b4463b7d5067aaa1a996a3))
* **YouTube - Spoof video streams:** Patch can be included for root installs ([3edf03b](https://github.com/MorpheApp/morphe-patches/commit/3edf03b8efc2f5ea0458456002938c7dbd4bf8d8))
* **YouTube - Theme:** Glow startup animation does not extend to fullscreen ([7f1a6b3](https://github.com/MorpheApp/morphe-patches/commit/7f1a6b35c8a3989cd2b06a1e81d817015f2ca433))
* **YouTube - Video quality:** Selected quality is not applied to the already buffered video ([#4117](https://github.com/MorpheApp/morphe-patches/issues/4117)) ([7faa488](https://github.com/MorpheApp/morphe-patches/commit/7faa48834b1f78f8ca572c773392ed9513de8ea3))
* **YouTube:** Restore TalkBack access to Shorts comments and descriptions ([#4128](https://github.com/MorpheApp/morphe-patches/issues/4128)) ([9542d24](https://github.com/MorpheApp/morphe-patches/commit/9542d24adf3b5ec2c25fce931418160dadbde93c))

## [1.49.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.8...v1.49.0-dev.9) (2026-10-27)

### 🐛 Bug Fixes

* **YouTube - Downloads:** Downloaded videos that work at first may not work later ([90d011d](https://github.com/MorpheApp/morphe-patches/commit/90d011dc007cf7e433196fd27f392c87d32363f6))
* **YouTube - Feed video actions:** Watch later button is missing after scrolling up ([51dfd75](https://github.com/MorpheApp/morphe-patches/commit/51dfd7565426be389f61dc5f34196cc762a103fe))
* **YouTube - Feed video actions:** Watch later button opens the channel in right to left languages ([0e058e8](https://github.com/MorpheApp/morphe-patches/commit/0e058e8d184650326d81a243d083ae9bd6f3f942))
* **YouTube - Feed view count:** View count badge covers the duration in right to left languages ([b012535](https://github.com/MorpheApp/morphe-patches/commit/b01253535eb65761f896042d46ba1fed002232c2))
* **YouTube:** Channel page community posts do not load when feed "Hide community posts" is enabled ([#4110](https://github.com/MorpheApp/morphe-patches/issues/4110)) ([b54aaec](https://github.com/MorpheApp/morphe-patches/commit/b54aaecaa26e8e6e4491b0c54193cd2b2b6e0f2c))
* **YouTube:** Feed thumbnail badges are missing after scrolling up, show a loading spinner until they are loaded ([03ef708](https://github.com/MorpheApp/morphe-patches/commit/03ef708f724c9af7f784b75ead9da58b8cede5f4))
* **YouTube:** Remove legacy litho buffer filtering code required for app versions less than 20.22, change legacy support to `20.26.46` ([0ce43f7](https://github.com/MorpheApp/morphe-patches/commit/0ce43f7b8bf0119f295f269b939186ff264b5d48))
* **YouTube:** Watch page feed lags when scrolling ([35e4123](https://github.com/MorpheApp/morphe-patches/commit/35e412375a1de62b500e2c9ca70c0ca5a18fb793))

### ✨ New Features

* Validate custom header and icon folders when the option is set ([fbb095d](https://github.com/MorpheApp/morphe-patches/commit/fbb095dbd6b9bf7410e4cff38b664d2fb3048aeb))
* **YouTube - Custom branding:** Add experimental YouTube launcher icons ([#4114](https://github.com/MorpheApp/morphe-patches/issues/4114)) ([de9e6e4](https://github.com/MorpheApp/morphe-patches/commit/de9e6e4e7953f6192991e35025ed644806948ecd))
* **YouTube - Theme:** Add experimental YT splash screen animation ([#4109](https://github.com/MorpheApp/morphe-patches/issues/4109)) ([1f24e84](https://github.com/MorpheApp/morphe-patches/commit/1f24e8433b26aed7a0e8cd21bf6c719526e7ecc4))
* **YouTube:** Hidden a new type of community post ([fb51b72](https://github.com/MorpheApp/morphe-patches/commit/fb51b722e05df50e98302f87996525b349d0474b))
* **YouTube:** Redirect Watch later saves to a chosen playlist ([#4016](https://github.com/MorpheApp/morphe-patches/issues/4016)) ([04e791d](https://github.com/MorpheApp/morphe-patches/commit/04e791d3d1c9fa8c8c352c61b18a6348311a8a27))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.43.51` ([141aa8f](https://github.com/MorpheApp/morphe-patches/commit/141aa8fedea935664df73154cdc1823e893c5b88))

## [1.49.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.7...v1.49.0-dev.8) (2026-10-27)

### 🐛 Bug Fixes

* **YouTube - Channel whitelists:** Flyout menu opens with a delay while the channel is fetched ([5fed7fc](https://github.com/MorpheApp/morphe-patches/commit/5fed7fc701421b701263f742a6ba38fd4cc89dd5))
* **YouTube - Litho filter:** Crash when scrolling a list after a filtered element is removed ([6d43157](https://github.com/MorpheApp/morphe-patches/commit/6d4315757768d792614915d0867079437505fab9))
* **YouTube - Playback speed:** Use the bold icon for the Shorts player menu item ([c710042](https://github.com/MorpheApp/morphe-patches/commit/c710042f6cf3f068141e89cd833dd580d7b64b8c))
* **YouTube - Player icon style:** Add Ionicons picture in picture button icon ([68b8628](https://github.com/MorpheApp/morphe-patches/commit/68b86282725f73c3a92602c792457371ddb88c8e))
* **YouTube - Premium-style queue:** Fix missing titles and stale now playing row ([#3795](https://github.com/MorpheApp/morphe-patches/issues/3795)) ([ef28427](https://github.com/MorpheApp/morphe-patches/commit/ef28427f63c30329b33b8d83c439c95b731a4fb6))
* **YouTube - Premium-style queue:** Play the queue when the player Next button is pressed ([#3796](https://github.com/MorpheApp/morphe-patches/issues/3796)) ([ef8dcef](https://github.com/MorpheApp/morphe-patches/commit/ef8dcef6a9ef888a075fb97d963719ddf82d6b42))
* **YouTube - Return YouTube Dislike:** Feed thumbnail like count is not shown with the Classic feed card layout ([15a1700](https://github.com/MorpheApp/morphe-patches/commit/15a170042639ca8bc0b4d871b781c29d00926fb2))
* **YouTube Music - Downloads:** Fix song menu downloads for accounts without Premium ([#4086](https://github.com/MorpheApp/morphe-patches/issues/4086)) ([93c6893](https://github.com/MorpheApp/morphe-patches/commit/93c689374b0ef72cb97d6c73881ecdb132ce7e91))

### ✨ New Features

* **YouTube - Channel search:** Search the posts of the channel ([#4078](https://github.com/MorpheApp/morphe-patches/issues/4078)) ([93bd035](https://github.com/MorpheApp/morphe-patches/commit/93bd0351362da6c75eb40f47d0ea0e37c632eb1c))
* **YouTube - Downloads:** Add download item to the Shorts menu ([#4099](https://github.com/MorpheApp/morphe-patches/issues/4099)) ([7159826](https://github.com/MorpheApp/morphe-patches/commit/715982644742ca770a1c61fe292a77bb1ce11296))
* **YouTube - Downloads:** Add playlist downloads for accounts without Premium ([456e0db](https://github.com/MorpheApp/morphe-patches/commit/456e0db9603f0930a4893e3f24ee3eee8bd4e5f9))
* **YouTube Music - Third-party lyrics:** Streamline lyrics viewing experience  ([#4002](https://github.com/MorpheApp/morphe-patches/issues/4002)) ([00a4bf4](https://github.com/MorpheApp/morphe-patches/commit/00a4bf457e8df233b21e6f73b244b0c12e91e53e))
* **YouTube:** Add Niconico-style live/replay comments ([#4080](https://github.com/MorpheApp/morphe-patches/issues/4080)) ([e9f77d7](https://github.com/MorpheApp/morphe-patches/commit/e9f77d7c5932499ababf91481b883c30e96ccd1c))

## [1.49.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.6...v1.49.0-dev.7) (2026-10-26)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Feed below the player stutters while scrolling ([5545e3c](https://github.com/MorpheApp/morphe-patches/commit/5545e3c87458e60c5e6ef5653053c02d343dd3f8))
* **YouTube - Add to queue:** Fix native queue on experimental versions ([#4076](https://github.com/MorpheApp/morphe-patches/issues/4076)) ([e009d8b](https://github.com/MorpheApp/morphe-patches/commit/e009d8bddb1bb94525060efc3d9b38ad97ba7d72))
* **YouTube - Add to queue:** Native queue index errors crash before Android 13 ([c5f9f94](https://github.com/MorpheApp/morphe-patches/commit/c5f9f94ee71a480be00a432ee364f4e7099b9537))
* **YouTube - Captions:** Old caption stays on screen after SponsorBlock skips ([#3986](https://github.com/MorpheApp/morphe-patches/issues/3986)) ([e200765](https://github.com/MorpheApp/morphe-patches/commit/e20076530e0af6061da9029bfaa4ad985fdd2f50))
* **YouTube - Disable playlist autoplay:** fix looping the current video ([#4064](https://github.com/MorpheApp/morphe-patches/issues/4064)) ([f4c1f84](https://github.com/MorpheApp/morphe-patches/commit/f4c1f84e13f0ed9b5982adfccbdbec1529ce0091))
* **YouTube - Force fullscreen landscape:** Screen rotates before the fullscreen gesture completes ([#4050](https://github.com/MorpheApp/morphe-patches/issues/4050)) ([83c0cf0](https://github.com/MorpheApp/morphe-patches/commit/83c0cf004e8cafa142cb862e3d78fd7e98c9f3c3))
* **YouTube - Litho filter:** Filtered elements leave empty cells in the related videos grid of the tablet layout ([e32b05c](https://github.com/MorpheApp/morphe-patches/commit/e32b05c663e30c23cb998e73fa23d78a58998962))
* **YouTube - Litho filter:** Filtered elements leave empty cells in the tablet layout grids ([#4035](https://github.com/MorpheApp/morphe-patches/issues/4035)) ([4764483](https://github.com/MorpheApp/morphe-patches/commit/4764483db626de5974ef2d3d3cf19d84ef4cfde1))
* **YouTube - Minimal miniplayer:** Bar is partly covered by the keyboard with the default navigation bar style ([bb6e0e3](https://github.com/MorpheApp/morphe-patches/commit/bb6e0e38bf4216395abacf8f4afbd45418b25ed7))
* **YouTube - Minimal miniplayer:** Video title and channel are missing after going back from the Shorts player ([7e665c6](https://github.com/MorpheApp/morphe-patches/commit/7e665c62dc3f88a6f9888b8bc48d1aea885761a1))
* **YouTube - Miniplayer:** Related videos lists show a black frame after exiting fullscreen and scroll down ([efbc9b1](https://github.com/MorpheApp/morphe-patches/commit/efbc9b1ea1739b617306f19900fa398251131494))
* **YouTube - Search comments:** Search button is not shown in the Shorts comments and is shown in other panels ([3b3308b](https://github.com/MorpheApp/morphe-patches/commit/3b3308b61740ab01e35aaa0e97166eeab80164e6))
* **YouTube - Video quality:** Shorts quality menu sets another quality than the one selected ([3e15dcd](https://github.com/MorpheApp/morphe-patches/commit/3e15dcd12190c4b435287080916170e82d0b4ac5))
* **YouTube - Video quality:** Shorts quality selected in the menu is not kept and is used for the next Shorts ([82efbab](https://github.com/MorpheApp/morphe-patches/commit/82efbab5e735cfa3db7a6cc5b05a5ad00b1b0b96))

### ✨ New Features

* **YouTube - Playback speed:** Add playback speed to the Shorts player menu ([#3982](https://github.com/MorpheApp/morphe-patches/issues/3982)) ([b717a69](https://github.com/MorpheApp/morphe-patches/commit/b717a692dfc3c99bee830af548bd13f98a3a4eaa))
* **YouTube:** Add `Download post images` patch ([#3966](https://github.com/MorpheApp/morphe-patches/issues/3966)) ([5f96fbe](https://github.com/MorpheApp/morphe-patches/commit/5f96fbe0a90efd54b3e1233c9690aa18f4d38dda))
* **YouTube:** Show a warning when changing 'Navigation bar style' or turning on 'Enable tablet layout in player' ([445194d](https://github.com/MorpheApp/morphe-patches/commit/445194d74ab5373334e14d31e1ceb29926ac267b))

## [1.49.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.5...v1.49.0-dev.6) (2026-10-25)

### 🐛 Bug Fixes

* **YouTube - Captions:** Captions not shown in picture-in-picture on 21.16 - 21.28 ([#4024](https://github.com/MorpheApp/morphe-patches/issues/4024)) ([b2688c5](https://github.com/MorpheApp/morphe-patches/commit/b2688c5eb957f3ffd142595ff4ee7b491e3b86ae))
* **YouTube - Hide layout components:** Fix actions blocked by Hide Snackbar ([#4038](https://github.com/MorpheApp/morphe-patches/issues/4038)) ([9a0fee9](https://github.com/MorpheApp/morphe-patches/commit/9a0fee9ec2846ba2db31cbfc2e4c2ac9b14895b7))
* **YouTube - Playback speed:** Channel speed whitelist is not applied to preloaded Shorts ([4f108b5](https://github.com/MorpheApp/morphe-patches/commit/4f108b596a71adbbf223b59faaabcfbe2469d95a))

### ✨ New Features

* **YouTube - Add to queue:** Add "Native queue" setting ([#3953](https://github.com/MorpheApp/morphe-patches/issues/3953)) ([372eea2](https://github.com/MorpheApp/morphe-patches/commit/372eea295ec4521b9ccdb93a3f188f81a6ad1a6c))
* **YouTube - Downloads:** Add "Quick download on tap" setting ([#3883](https://github.com/MorpheApp/morphe-patches/issues/3883)) ([dd97d93](https://github.com/MorpheApp/morphe-patches/commit/dd97d93628a3feb7bc8758139b01fbe42a532778))
* **YouTube - Media notification controls:** Add options to seek with Previous & Next buttons ([#3955](https://github.com/MorpheApp/morphe-patches/issues/3955)) ([2b07abb](https://github.com/MorpheApp/morphe-patches/commit/2b07abb628fec3bf625a09ab7d019f915c4dfa23))
* **YouTube - Navigation bar:** Add "Navigation bar style" setting ([db9af37](https://github.com/MorpheApp/morphe-patches/commit/db9af377093121e575fec80ba40e0025dfd66f81))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.43.0` ([6407d5e](https://github.com/MorpheApp/morphe-patches/commit/6407d5efa0f7d99fb54909bc39e2074e8f60ac42))
* **Reddit:** Add support for `2026.40.0` ([fcc02f7](https://github.com/MorpheApp/morphe-patches/commit/fcc02f77d5a9d7a13b74d14c12b302f9d9902c61))

## [1.49.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.4...v1.49.0-dev.5) (2026-10-24)

### 🐛 Bug Fixes

* Temporarily change expired PoToken check to log only instead of a user dialog ([1669acd](https://github.com/MorpheApp/morphe-patches/commit/1669acdea4e56f6d1e812d3c0f74ee691bc2e4cd))
* **YouTube - Miniplayer:** Minimal miniplayer is covered by the keyboard before 21.29 ([5cd2eb2](https://github.com/MorpheApp/morphe-patches/commit/5cd2eb2f8d710e3a724d309dbf98fc845e78cb94))
* **YouTube - Theme:** Custom background colors are not applied with 21.43 ([#4019](https://github.com/MorpheApp/morphe-patches/issues/4019)) ([9cc833f](https://github.com/MorpheApp/morphe-patches/commit/9cc833f626bc456d142a6eafe2a613a3f2cc3784))

## [1.49.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.3...v1.49.0-dev.4) (2026-10-24)

### 🐛 Bug Fixes

* **YouTube - Ambient mode:** Ambient mode is not disabled with 21.43 ([aeb3012](https://github.com/MorpheApp/morphe-patches/commit/aeb3012a1d4fc42e9cb0e80e1cc139f24d445fb7))
* **YouTube - Feed card layout:** Shorts shelves change width and corners when only a last row with one Short is in the list ([97f1f2d](https://github.com/MorpheApp/morphe-patches/commit/97f1f2df9a2ce61384df4327f6743953c1ae598e))
* **YouTube - Hide status bar:** Status bar scroll color and translucent navigation bar do not follow the hidden status bar before the edge to edge flag is read ([a9e6562](https://github.com/MorpheApp/morphe-patches/commit/a9e6562b2a4dbc5d57f8cf65a205206a800d192a))
* **YouTube - Miniplayer:** "Disable resuming miniplayer" may not work with latest experimental app target ([8554412](https://github.com/MorpheApp/morphe-patches/commit/85544128284a29522310d43ed6bfb3e99706e9d4))
* **YouTube:** Fingerprints are not found on some targets between 21.04 and 21.35 ([52fa134](https://github.com/MorpheApp/morphe-patches/commit/52fa13489d6a97172d29cf5ff639d958506251ca))

## [1.49.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.2...v1.49.0-dev.3) (2026-10-24)

### 🐛 Bug Fixes

* **Reddit - Redgifs audio:** Error toast is shown when network request fails ([6707f0e](https://github.com/MorpheApp/morphe-patches/commit/6707f0e1215ba3620586b95e5c0f8b8576339a86))
* **YouTube:** 21.43 navigation tabs cannot be hidden ([68b01ca](https://github.com/MorpheApp/morphe-patches/commit/68b01cad1f9419b4dc0e9141659b4def6c3660a4))

## [1.49.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.49.0-dev.1...v1.49.0-dev.2) (2026-10-24)

### 🐛 Bug Fixes

* **YouTube - Disable continue watching prompt:** Prompt can still appear during playback ([#3996](https://github.com/MorpheApp/morphe-patches/issues/3996)) ([64e3e0e](https://github.com/MorpheApp/morphe-patches/commit/64e3e0ec5eb8f98e8f8f7e11ba754fc52c3af47f))
* **YouTube - Feed card layout:** Horizontal shelves lose the card background when their header is scrolled out of the list ([60489d8](https://github.com/MorpheApp/morphe-patches/commit/60489d84d49c85c44b8007af2de39ee6b82147cb))
* **YouTube - Feed card layout:** Videos of the horizontal shelves are cut by the left edge of the card ([c0ec5ae](https://github.com/MorpheApp/morphe-patches/commit/c0ec5ae17781305f490e589d2d53a6bc01cead46))
* **YouTube - Hide status bar:** Status bar covers the top bar or leaves an empty bar above it ([#3997](https://github.com/MorpheApp/morphe-patches/issues/3997)) ([bf6fbe0](https://github.com/MorpheApp/morphe-patches/commit/bf6fbe0c75728741f7d51a11a20e3bf2312faba9))
* **YouTube - Navigation bar:** Empty band below the reply bar of the comment replies ([bac5823](https://github.com/MorpheApp/morphe-patches/commit/bac5823bdd42beba2dd79f94010e2001b33017f7))
* **YouTube - Navigation bar:** No connection and back online bars are covered by the system navigation buttons ([2576962](https://github.com/MorpheApp/morphe-patches/commit/2576962149ab22aadc16a26853c9b7154b0d9322))
* **YouTube - Navigation bar:** System navigation buttons cannot be seen in the Shorts player with the light theme ([0115896](https://github.com/MorpheApp/morphe-patches/commit/011589657684ba34a7523f3b17af152c5962ae6e))
* **YouTube - Navigation buttons:** Create button is not hidden with the new navigation bar layout ([47f511c](https://github.com/MorpheApp/morphe-patches/commit/47f511c7ae41de2b2ac83257d5a93c4df1216526))
* **YouTube - Playback speed:** Channel speed whitelist does not work for Shorts ([be733a6](https://github.com/MorpheApp/morphe-patches/commit/be733a6883cdf4c5fc8176668afb1e7f5c22cb9f))
* **YouTube - Shorts autoplay:** Overlay is out of place when going back to a Short that advanced with the comments open ([60efeb5](https://github.com/MorpheApp/morphe-patches/commit/60efeb58d08ba0e347928c7f4f903a689b474bfd))
* **YouTube Music - Downloads:** Fix missing metadata in downloaded songs ([#3984](https://github.com/MorpheApp/morphe-patches/issues/3984)) ([7988621](https://github.com/MorpheApp/morphe-patches/commit/7988621db650eb2c32e7cab53731508ad733d5b9))
* **YouTube Music - Downloads:** Fix wrong song downloads ([#3978](https://github.com/MorpheApp/morphe-patches/issues/3978)) ([7259e27](https://github.com/MorpheApp/morphe-patches/commit/7259e27ade3bd1f76cd89f2ecad07d86f39d0335))
* **YouTube:** Morphe flyout menu items are missing in the new popup menu ([d2accff](https://github.com/MorpheApp/morphe-patches/commit/d2accff5135170a4288f326d89b25a81f688f063))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** enhance sync engine, providers, AI translation, and RTL word sync ([#3877](https://github.com/MorpheApp/morphe-patches/issues/3877)) ([e092212](https://github.com/MorpheApp/morphe-patches/commit/e0922124073fe53b6ff335893b8208af512f34e7))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.43.523` ([6c413e5](https://github.com/MorpheApp/morphe-patches/commit/6c413e5b7bab279add97ac084b39b0d44c8ca059))

## [1.49.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0...v1.49.0-dev.1) (2026-10-23)

### 🐛 Bug Fixes

* **YouTube - Hide status bar:** Video player is moved below the display cutout in portrait ([f80398e](https://github.com/MorpheApp/morphe-patches/commit/f80398e107587c7fb9f995f508a65ad1953b2734))
* **YouTube - Navigation bar:** Translucent navigation bar is not shown without the edge to edge layout ([b8e1fdd](https://github.com/MorpheApp/morphe-patches/commit/b8e1fddd8a9d7146f2ccc4d1522a86b134cfe7a6))
* **YouTube:** Miniplayer covered by the keyboard and empty band above the navigation bar ([0345136](https://github.com/MorpheApp/morphe-patches/commit/0345136b552c49b70c01fcc19a18762f57d3b7ad))
* **YouTube:** Morphe flyout menu items are missing on tablets ([7127541](https://github.com/MorpheApp/morphe-patches/commit/71275419c5e6b8bd6a0a108e3d7815c8ef11a88e))

### ✨ New Features

* **YouTube - Navigation bar:** Add "Disable toolbar navigation tabs" setting ([01e767c](https://github.com/MorpheApp/morphe-patches/commit/01e767c4c3a386e4b7881ce7fc867a516082db23))
* **YouTube:** Add `Search comments` patch ([#3942](https://github.com/MorpheApp/morphe-patches/issues/3942)) ([fbb628b](https://github.com/MorpheApp/morphe-patches/commit/fbb628ba23ecdcabd00b3bdfbf94aff60f58ac68))

### 🚀 Updated App Support

* **YouTube:** Add support for `21.23.492` ([4599204](https://github.com/MorpheApp/morphe-patches/commit/45992041db85e4fb51900cc5a773380732dc1fda))

## [1.48.0](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0...v1.48.0) (2026-10-22)

### 🐛 Bug Fixes

* **Downloads:** Allow using in-app downloads with player overlay external download button ([3df6c0a](https://github.com/MorpheApp/morphe-patches/commit/3df6c0a3d9ad097db63709cf5b559223d4575dd6))
* Export only filtered logs and stream file exports efficiently ([#3746](https://github.com/MorpheApp/morphe-patches/issues/3746)) ([e04c72d](https://github.com/MorpheApp/morphe-patches/commit/e04c72d8e068204c3a2178b75451fb8bfbb4d755))
* Temporarily revert patches-library update to fix app startup crash ([fd8cc0f](https://github.com/MorpheApp/morphe-patches/commit/fd8cc0fb14540b1e0d6adec903a7c2720a80b2f7))
* **YouTube - Add to queue:** Fix Premium-style queue bugs ([#3752](https://github.com/MorpheApp/morphe-patches/issues/3752)) ([b07a6ac](https://github.com/MorpheApp/morphe-patches/commit/b07a6ac48bae7e6cd0336d4afdc12e368d5442d4))
* **YouTube - Ambient mode:** Force Ambient mode when the server turns it off ([0eda16c](https://github.com/MorpheApp/morphe-patches/commit/0eda16c28e7ca4842a9087bba0fb47d146feddfa))
* **YouTube - Captions:** Restore all translation menu getter routes ([#3818](https://github.com/MorpheApp/morphe-patches/issues/3818)) ([3a6a5b3](https://github.com/MorpheApp/morphe-patches/commit/3a6a5b3ae1d934114668a68ebe56bd512baae18e))
* **YouTube - Captions:** Restore translations from original caption sources ([#3794](https://github.com/MorpheApp/morphe-patches/issues/3794)) ([46ab900](https://github.com/MorpheApp/morphe-patches/commit/46ab900bd9daa990a4d741a6e7f3dc5611173cdb))
* **YouTube - Captions:** Show auto-translated captions of styled caption tracks ([#3837](https://github.com/MorpheApp/morphe-patches/issues/3837)) ([aedcf19](https://github.com/MorpheApp/morphe-patches/commit/aedcf198849b226d3b23638e5e810d9ea39999ba))
* **YouTube - Custom font:** Show custom font picker if no font is selected yet ([8347b98](https://github.com/MorpheApp/morphe-patches/commit/8347b98e007c98065bbe2d546a89bf4f1daa1dce))
* **YouTube - Default video quality:** Forcely disabled automatic stock quality selection and deprecated the code to handle both Stock/Morphe quality selections ([93e0c2b](https://github.com/MorpheApp/morphe-patches/commit/93e0c2b4db27760a22b1e48aef8b87dc330a92bf))
* **YouTube - Default video quality:** SABR video quality drops while the video plays ([#3853](https://github.com/MorpheApp/morphe-patches/issues/3853)) ([0488bda](https://github.com/MorpheApp/morphe-patches/commit/0488bda28d4d5844a2a739d3eefd00c28afd43fa))
* **YouTube - Default video quality:** Video quality drops while the video plays ([9f7b7eb](https://github.com/MorpheApp/morphe-patches/commit/9f7b7ebb10c909f7d2bc480de9fdbd3dd6076e2f))
* **YouTube - Disable translucent bar:** Replace flag override with a proper patch ([88f77a8](https://github.com/MorpheApp/morphe-patches/commit/88f77a86ae737bc5da476011918d480baeff90b3))
* **YouTube - Downloads:** Music videos may not download ([0bac4fa](https://github.com/MorpheApp/morphe-patches/commit/0bac4fa12101e5729e5b4c060d9bac10250281aa))
* **YouTube - Downloads:** Playing video enters picture-in-picture when the external downloader opens ([#3882](https://github.com/MorpheApp/morphe-patches/issues/3882)) ([cf43209](https://github.com/MorpheApp/morphe-patches/commit/cf43209679dbba198e963aa381ce25110a6aa8fb))
* **YouTube - Feed card layout:** Remove the feed vertical spacing override, which can crash the app ([31a85c7](https://github.com/MorpheApp/morphe-patches/commit/31a85c7d1bfb99658c668444c37fd96e16500398))
* **YouTube - Feed card layout:** Round the top outer corners of the Shorts shelves ([8effa2e](https://github.com/MorpheApp/morphe-patches/commit/8effa2e103947e57455e2b93629186a411c86f37))
* **YouTube - Feed card layout:** Shorts shelves of the search results are not cards ([12ed02f](https://github.com/MorpheApp/morphe-patches/commit/12ed02f49d3059875435c6d8cdebe548c7e80dd3))
* **YouTube - Feed card layout:** Show missing watch progress on feed cards ([#3926](https://github.com/MorpheApp/morphe-patches/issues/3926)) ([096798f](https://github.com/MorpheApp/morphe-patches/commit/096798f5877ffce88bac17adef5a9477931071b0))
* **YouTube - Feed card layout:** Sort buttons of the channel tabs have a card background ([328121e](https://github.com/MorpheApp/morphe-patches/commit/328121e9a5b6552075db00327c12ecf39feda762))
* **YouTube - Feed card layout:** Vertical video shelves are not cards ([44564ee](https://github.com/MorpheApp/morphe-patches/commit/44564eeff5d617dab0b0210c149a9c190e9f0021))
* **YouTube - Feed cards layout:** Cards sometimes lose spacing ([0658f00](https://github.com/MorpheApp/morphe-patches/commit/0658f0083bc5d143b379097b706d4114a845a08f))
* **YouTube - Feed cards layout:** Keep horizontal layout for search results on tablets ([0108028](https://github.com/MorpheApp/morphe-patches/commit/0108028df245e0664974d345c58a291f95a1245e))
* **YouTube - Feed cards layout:** Make new style more consistent ([#3801](https://github.com/MorpheApp/morphe-patches/issues/3801)) ([5dc0d0c](https://github.com/MorpheApp/morphe-patches/commit/5dc0d0c71ef9c9c11709e62568eb9c1778e9a4c7))
* **YouTube - Feed video actions:** Show on the grid of landscape ([#3875](https://github.com/MorpheApp/morphe-patches/issues/3875)) ([db5e7d0](https://github.com/MorpheApp/morphe-patches/commit/db5e7d0f97d44032212e7a4451ab38466fd67506))
* **YouTube - Feed video actions:** Watch later button opens the share sheet ([6c94f32](https://github.com/MorpheApp/morphe-patches/commit/6c94f32df957beda5721729f12385eea3537c975))
* **YouTube - Feed view count:** Keep the badge away from the edges of inset thumbnails, show lakh and crore units ([544013a](https://github.com/MorpheApp/morphe-patches/commit/544013adcc8881104c003d8d5e3280f725fc676e))
* **YouTube - Feed view count:** Show on the grid of landscape, same corners and text size as the other badges ([#3874](https://github.com/MorpheApp/morphe-patches/issues/3874)) ([733b6d1](https://github.com/MorpheApp/morphe-patches/commit/733b6d108f09c23892fbe3201dee55e45224b9c3))
* **YouTube - Force animations:** Animate page transitions when the server turns them off ([79979bc](https://github.com/MorpheApp/morphe-patches/commit/79979bcae286d7bbb11b6ccc06558e812b07637f))
* **YouTube - Forced video codec:** Excluded VP9 stream with forced AVC superseeded by Shorts VP9 with SABR restarting fix ([2335a8f](https://github.com/MorpheApp/morphe-patches/commit/2335a8f22eed59d36f1c3c7f0cb8de9fa846207f))
* **YouTube - Hide layout components:** Video titles being hidden on `20.21.37` ([fead993](https://github.com/MorpheApp/morphe-patches/commit/fead993a68706580163825403b3ffd60a6866333))
* **YouTube - Hide preview comment:** Removed the timestamp from the Spanned String instead of disabling its tap logic ([cca6aca](https://github.com/MorpheApp/morphe-patches/commit/cca6aca240ef99e55740af20342a5d28deda6275))
* **YouTube - Jam queue sharing:** Keep the YouTube Music player aligned when Jam queue sharing is off ([#3704](https://github.com/MorpheApp/morphe-patches/issues/3704)) ([fd0db0b](https://github.com/MorpheApp/morphe-patches/commit/fd0db0b04bc12f80acde7fc259d7f72dbf724b13))
* **YouTube - Minimal comments button:** Hide page selector with new layout ([30a9dd1](https://github.com/MorpheApp/morphe-patches/commit/30a9dd17c87658ae405c6223661e478bce2a9629))
* **YouTube - Minimal miniplayer:** Apply minimized position based on commit [#9d8b0df43](https://github.com/MorpheApp/morphe-patches/issues/9d8b0df43) insets ([7f9fb1f](https://github.com/MorpheApp/morphe-patches/commit/7f9fb1f7df988afc7a21ffa4735227a404c06444))
* **YouTube - Minimal miniplayer:** Bar is cut off by the display cutout in landscape ([01267da](https://github.com/MorpheApp/morphe-patches/commit/01267da0f015fb868edb6b59e1086778966c7900))
* **YouTube - Minimal miniplayer:** Show DeArrow title on type 1 style ([72f7b82](https://github.com/MorpheApp/morphe-patches/commit/72f7b82c8ac8d9032d7834abb10ae9f9b86c5ba1))
* **YouTube - Miniplayer:** Match minimal miniplayer icons by content description name instead of resource id ([4502949](https://github.com/MorpheApp/morphe-patches/commit/4502949a61f6d5d39f72e4052f083cbe1460bd09))
* **YouTube - Miniplayer:** Watch transition animation is missing ([779d81c](https://github.com/MorpheApp/morphe-patches/commit/779d81c856133efc0e59a83e81f9628cd05a581f))
* **YouTube - Navigation bar:** App crashes on Android 12-13 when the player is dragged down to the miniplayer ([#3937](https://github.com/MorpheApp/morphe-patches/issues/3937)) ([a6db8d7](https://github.com/MorpheApp/morphe-patches/commit/a6db8d7aba965471d9a51f27ad7324513e2eb40b))
* **YouTube - Navigation bar:** bug: Navigation bar is not disabled in shorts player ([03f3aa2](https://github.com/MorpheApp/morphe-patches/commit/03f3aa27bc48cfb23a54c723065c83283eed6bc2))
* **YouTube - Navigation bar:** Increased the spacing between Shorts player and navigation bar when this latter is hidden ([a6fdc2f](https://github.com/MorpheApp/morphe-patches/commit/a6fdc2f1331f5d2fe14da2abb89dfe4b8799ce7f))
* **YouTube - Navigation bar:** Navigation bar grows and covers the page when the keyboard is open ([7ec9a54](https://github.com/MorpheApp/morphe-patches/commit/7ec9a549a75798c76439a38400dbc325b7cd78df))
* **YouTube - Navigation bar:** Navigation bar is raised and an empty bar is left at the bottom ([eca3334](https://github.com/MorpheApp/morphe-patches/commit/eca3334c07df995dbbb4f58ed425591883086554))
* **YouTube - Navigation bar:** Navigation bar is raised and an empty bar is left at the bottom on Android 11 and lower ([e91d606](https://github.com/MorpheApp/morphe-patches/commit/e91d60686bbc66182eab43e510c04d247e5fb323))
* **YouTube - New feed cards layout:** Rounded edges and padding was wrong ([7d54662](https://github.com/MorpheApp/morphe-patches/commit/7d5466217e5dc7ea1ea323d4f9d7a6baf9f42f8a))
* **YouTube - Open system share sheet:** Build link from share entity ([#3735](https://github.com/MorpheApp/morphe-patches/issues/3735)) ([92e9eb9](https://github.com/MorpheApp/morphe-patches/commit/92e9eb9d0fa941719c6cf7c048dae16ef163812c))
* **YouTube - Reload video:** Videos playing in the feed replace the reloaded video ([92e41c4](https://github.com/MorpheApp/morphe-patches/commit/92e41c43d2a0deb766f081e5b36e1556675e4090))
* **YouTube - Restore original titles:** Do not reload the same video title once the player is opened ([1648848](https://github.com/MorpheApp/morphe-patches/commit/1648848f2b3b2215f0ed3e6a08ddc0877a9365de))
* **YouTube - Return YouTube Dislike:** Place the feed thumbnail like count on inset thumbnails and channel posts ([#3902](https://github.com/MorpheApp/morphe-patches/issues/3902)) ([de420c2](https://github.com/MorpheApp/morphe-patches/commit/de420c275ea33a3664e5ab6424903ff54c2359c4))
* **YouTube - Spoof video streams:** In-app downloads are slow when using spoof streaming ([6a8b5a9](https://github.com/MorpheApp/morphe-patches/commit/6a8b5a976c011ea1d365e90db143c9b4d8745976))
* **YouTube - Video quality:** Fix VP9 Shorts restarting in a loop with spoofed SABR streams ([ef04cc3](https://github.com/MorpheApp/morphe-patches/commit/ef04cc3c12131d0667e598a935425143d1a6dcf1))
* **YouTube - Video quality:** Improved Shorts VP9 SABR loop restarting fix ([aeccfab](https://github.com/MorpheApp/morphe-patches/commit/aeccfabc5c4f256654ab209ff0741a3b5fada31c))
* **YouTube - VideoInformation:** Separated Video and Shorts informations ([e913727](https://github.com/MorpheApp/morphe-patches/commit/e913727f3a115f7be807bc32efbf6c054b8fa35d))
* **YouTube - VideoInformation:** Videos loaded in the background replace the video and playlist IDs of the player ([0ed3595](https://github.com/MorpheApp/morphe-patches/commit/0ed35954b6db94a12956c98b8db620e09dc65dd5))
* **YouTube Music - Android Auto:** Fix large collections not loading on 9.15 ([#3849](https://github.com/MorpheApp/morphe-patches/issues/3849)) ([1c18d6a](https://github.com/MorpheApp/morphe-patches/commit/1c18d6a02a119d0147593d3615c46dce3a65ff19))
* **YouTube Music - Crossfade:** Preserve repeat state on 9.40+ ([#3916](https://github.com/MorpheApp/morphe-patches/issues/3916)) ([ce688de](https://github.com/MorpheApp/morphe-patches/commit/ce688de5f6a0693a0df01e37cf25478eaac2524b))
* **YouTube Music - Enable exclusive audio playback:** Prevent podcasts stopping in Android Auto ([#3850](https://github.com/MorpheApp/morphe-patches/issues/3850)) ([7a2b926](https://github.com/MorpheApp/morphe-patches/commit/7a2b926302f34d1309fb3896ed6720d0db5ab8a5))
* **YouTube Music:** Experimental app version does not patch ([12fad56](https://github.com/MorpheApp/morphe-patches/commit/12fad5684a453f5f8e359e6f66a2ab04e6caede8))
* **YouTube:** "Play next/last in queue" does nothing from feeds when no video is playing ([c770414](https://github.com/MorpheApp/morphe-patches/commit/c770414fb0ed43ac8f2af7519f7f9222cae8f780))
* **YouTube:** Add missing experimental compatibility declaration ([a81a933](https://github.com/MorpheApp/morphe-patches/commit/a81a933274cde895d3b4e026c2d084f35b9b20c5))
* **YouTube:** App can crash when an observer removes itself while it is notified ([5ee5a72](https://github.com/MorpheApp/morphe-patches/commit/5ee5a724433d6b96b7847e98aaf39c096bd81d5f))
* **YouTube:** Channel search not working properly ([ab2ecc7](https://github.com/MorpheApp/morphe-patches/commit/ab2ecc7a31f6678a698893663ee707d49fc51648))
* **YouTube:** Comments button page indicator is invisible with the light theme ([0f7f6d8](https://github.com/MorpheApp/morphe-patches/commit/0f7f6d8f6625d73941e211c51167097288f8682d))
* **YouTube:** Error toasts on app startup with YouTube 21.40+ ([2151a04](https://github.com/MorpheApp/morphe-patches/commit/2151a04d0dfcc7f54e28af645a0e304f9af2d265))
* **YouTube:** Fixed some 21.42+ fingerprints ([7bf6e1f](https://github.com/MorpheApp/morphe-patches/commit/7bf6e1fe85a75f9fcac4869d5ef548b21e2e5534))
* **YouTube:** Flyout menu text is cut when Morphe items are added ([f8b7669](https://github.com/MorpheApp/morphe-patches/commit/f8b7669dfd9b10ed68da3cfae4190cb0f2c7430a))
* **YouTube:** Force show translucent navigation bar ([e5bb8bf](https://github.com/MorpheApp/morphe-patches/commit/e5bb8bfea55258a6926243fbfb7ed19fffea3925))
* **YouTube:** History items are hidden when the keyboard is open ([3f38b2d](https://github.com/MorpheApp/morphe-patches/commit/3f38b2ded7f857a0240126388686234d3c786892))
* **YouTube:** Light/Dark theme colors are wrong ([93cf169](https://github.com/MorpheApp/morphe-patches/commit/93cf169e8fa7f96bef741fe5f02f5654b2ae70f6))
* **YouTube:** Restore Edge TTS and add voice catalog refresh ([#3840](https://github.com/MorpheApp/morphe-patches/issues/3840)) ([4aa4deb](https://github.com/MorpheApp/morphe-patches/commit/4aa4deb6cd6ad4bf01a0f199e984dd3b33449fab))
* **YouTube:** Some external links can not be opened ([128b8d4](https://github.com/MorpheApp/morphe-patches/commit/128b8d4104e17a5b2527c3f951026f9ff79b4ea6))
* **YouTube:** Status bar becomes dark ([9d8b0df](https://github.com/MorpheApp/morphe-patches/commit/9d8b0df43ae3cd4dfc1a537311d4dfc6aa600ac5))
* **YouTube:** Status bar is opaque, black bar above the player and crash on startup ([b5d9498](https://github.com/MorpheApp/morphe-patches/commit/b5d9498577ea285c8dd490bb823bbbd9c6674624))
* **YouTube:** Video metadata panel text can not be read with the light theme ([332e18e](https://github.com/MorpheApp/morphe-patches/commit/332e18e82b73cc737fc6c84d1126e6fa915821fb))
* **YouTube:** Watch page background turns black in light mode ([4667cb0](https://github.com/MorpheApp/morphe-patches/commit/4667cb0ef1d13ee756c87976801f366869d7144d))

### ✨ New Features

* **Reddit - Full width feed media:** Make embedded video players full width ([#3696](https://github.com/MorpheApp/morphe-patches/issues/3696)) ([53b6448](https://github.com/MorpheApp/morphe-patches/commit/53b64487109e05f13d8e0bc581f86e581cd4662b))
* **Reddit - Redgifs audio:** Download Redgifs videos with audio ([#3869](https://github.com/MorpheApp/morphe-patches/issues/3869)) ([f2ed85e](https://github.com/MorpheApp/morphe-patches/commit/f2ed85e67e518ec9115d51d7d6eb0d208232b646))
* **Reddit:** Add `Copy text` patch ([#3665](https://github.com/MorpheApp/morphe-patches/issues/3665)) ([3068f23](https://github.com/MorpheApp/morphe-patches/commit/3068f23e357825a77f6d67760f427634e3baee0c))
* **Reddit:** Add `Customize post layout` patch ([#3541](https://github.com/MorpheApp/morphe-patches/issues/3541)) ([a301bc1](https://github.com/MorpheApp/morphe-patches/commit/a301bc1d07ebd96390566cc2d4503ca48a013775))
* **Reddit:** Add `Download location` patch ([#3870](https://github.com/MorpheApp/morphe-patches/issues/3870)) ([7d0f9b6](https://github.com/MorpheApp/morphe-patches/commit/7d0f9b67193372a92e7065f5fa4f4e366b2ba41c))
* **Reddit:** Add `Redgifs audio` patch ([#3714](https://github.com/MorpheApp/morphe-patches/issues/3714)) ([b664711](https://github.com/MorpheApp/morphe-patches/commit/b66471189b52974ead5666ac033b6b2ec867de2e))
* **Reddit:** Add `Remember collapsed comments` patch ([#3517](https://github.com/MorpheApp/morphe-patches/issues/3517)) ([fbd5a82](https://github.com/MorpheApp/morphe-patches/commit/fbd5a82666abeeabd6c7aeb19b7ca993b1ba85c6))
* **Reddit:** Add `Show flairs in home feed` patch ([#3260](https://github.com/MorpheApp/morphe-patches/issues/3260)) ([93501dd](https://github.com/MorpheApp/morphe-patches/commit/93501dd4b31a103c37509b1c26f7644ca9082aff))
* **Reddit:** Add media viewer and feed media patches ([#3516](https://github.com/MorpheApp/morphe-patches/issues/3516)) ([1e905b5](https://github.com/MorpheApp/morphe-patches/commit/1e905b5449e6a5468a02f017ce4afb336e8f668e))
* **Spoof video streams:** Offer to fix playback when PotHelper no longer works or the default client keeps failing ([#3659](https://github.com/MorpheApp/morphe-patches/issues/3659)) ([f996510](https://github.com/MorpheApp/morphe-patches/commit/f996510cfdc71a78c5c9579efcf7d604e70ae1ea))
* Update to Patcher 2.0 ([#3945](https://github.com/MorpheApp/morphe-patches/issues/3945)) ([d7c25c2](https://github.com/MorpheApp/morphe-patches/commit/d7c25c26031e77c051973fb71b761fa991ee7ddb))
* **YouTube - Add to queue:** Add Premium-style queue setting ([#3582](https://github.com/MorpheApp/morphe-patches/issues/3582)) ([1b1b2bc](https://github.com/MorpheApp/morphe-patches/commit/1b1b2bc74bb49c0553225fc7b691c55fbc961a69))
* **YouTube - Captions:** Add "Show captions in picture-in-picture" setting ([#3907](https://github.com/MorpheApp/morphe-patches/issues/3907)) ([6c817e7](https://github.com/MorpheApp/morphe-patches/commit/6c817e7daa49a1b0bf007f31fc7eece9ff3af566))
* **YouTube - Captions:** Add additional automatic translation languages ([#3754](https://github.com/MorpheApp/morphe-patches/issues/3754)) ([c036e5f](https://github.com/MorpheApp/morphe-patches/commit/c036e5f2e30b467a7c2e3af3ae948c0715efec48))
* **YouTube - Channel search:** Added loading animation during searching ([d3fc642](https://github.com/MorpheApp/morphe-patches/commit/d3fc6421ca3f8e7ac6cc162d1a51b24c4b087e6e))
* **YouTube - Disable video codecs:** Add "Force VP9 codec" setting ([#3578](https://github.com/MorpheApp/morphe-patches/issues/3578)) ([e1398ca](https://github.com/MorpheApp/morphe-patches/commit/e1398ca7da9dc7829aa8e9d2f798206fff26c1f6))
* **YouTube - Downloads:** Add "Download in-app" setting ([#3905](https://github.com/MorpheApp/morphe-patches/issues/3905)) ([ef266aa](https://github.com/MorpheApp/morphe-patches/commit/ef266aa4bf94bf63e5b85a31673c297bf0ef81ef))
* **YouTube - Force animations:** Expand the content below the player with its animation when it loads ([b0020b2](https://github.com/MorpheApp/morphe-patches/commit/b0020b2513fffb6954c5925af3213958b947f94f))
* **YouTube - Hide layout components:** Add "Hide 'No comments yet' message" setting ([#3819](https://github.com/MorpheApp/morphe-patches/issues/3819)) ([32168f9](https://github.com/MorpheApp/morphe-patches/commit/32168f9ebff2269c98ea5d9adedda07394342ab9))
* **YouTube - Hide layout components:** Add "Hide live chat scroll to bottom button" setting ([#3826](https://github.com/MorpheApp/morphe-patches/issues/3826)) ([1956988](https://github.com/MorpheApp/morphe-patches/commit/19569880caabbaed642ce9c48e829d22141405dd))
* **YouTube - Hide status bar:** Add "Fix status bar covering the top bars" setting ([caa1be0](https://github.com/MorpheApp/morphe-patches/commit/caa1be0fe5faf3351fa49a02667f03ef4946b34f))
* **YouTube - Player icon style:** Add Series tracker button icons ([179ff66](https://github.com/MorpheApp/morphe-patches/commit/179ff663d36806e11bd3869df8d1a66287072a7f))
* **YouTube - Restore original titles:** Restore titles of watch history and fullscreen suggested videos ([f55e541](https://github.com/MorpheApp/morphe-patches/commit/f55e54163bd04b7b6fdd3e015951ad6bf4f8d42f))
* **YouTube - Return YouTube Dislike:** Add "Show feed thumbnail like count" setting ([#3786](https://github.com/MorpheApp/morphe-patches/issues/3786)) ([7b2fd85](https://github.com/MorpheApp/morphe-patches/commit/7b2fd85413a12a955dfcd8ff9928790c2ac993e8))
* **YouTube - Series tracking:** Add "Show Series in navigation bar" setting ([#3814](https://github.com/MorpheApp/morphe-patches/issues/3814)) ([abaca95](https://github.com/MorpheApp/morphe-patches/commit/abaca951b67eeae3dd9f1a9bc8f9c09e72b7c20b))
* **YouTube Music - Android Auto:** Add Home, Library, and search features ([#3852](https://github.com/MorpheApp/morphe-patches/issues/3852)) ([65e200f](https://github.com/MorpheApp/morphe-patches/commit/65e200f623efc8b651a338360555884b717e05af))
* **YouTube Music - Third-party lyrics:** Add new providers ([#3717](https://github.com/MorpheApp/morphe-patches/issues/3717)) ([89e31ba](https://github.com/MorpheApp/morphe-patches/commit/89e31ba6d69e26a08b5bdd97b3afb4daa927048f))
* **YouTube Music - Third-party lyrics:** Custom romanization target ([#3750](https://github.com/MorpheApp/morphe-patches/issues/3750)) ([0dfc834](https://github.com/MorpheApp/morphe-patches/commit/0dfc8347118bb9c10e8dd8275996d31afb5f5d37))
* **YouTube Music - Third-party lyrics:** Local romanization and alignment ([#3851](https://github.com/MorpheApp/morphe-patches/issues/3851)) ([9adcefd](https://github.com/MorpheApp/morphe-patches/commit/9adcefda0e18fb08a5e70933f243cdbc1d99e502))
* **YouTube Music:** Add `Custom font` patch ([#3718](https://github.com/MorpheApp/morphe-patches/issues/3718)) ([30a4b85](https://github.com/MorpheApp/morphe-patches/commit/30a4b85885e96aa8216f2b9fb26ed0ba4951e8fe))
* **YouTube:** Add "Force animations" patch, superseding the Miniplayer watch transition fix ([#3872](https://github.com/MorpheApp/morphe-patches/issues/3872)) ([591ad8b](https://github.com/MorpheApp/morphe-patches/commit/591ad8bd917bc168b0144014022438e395624bef))
* **YouTube:** Add `Ask flyout menu` patch ([#3897](https://github.com/MorpheApp/morphe-patches/issues/3897)) ([04c76d0](https://github.com/MorpheApp/morphe-patches/commit/04c76d0ace8e3e5c6d4e4d015e7bc231199b9c02))
* **YouTube:** Add `Custom font` patch ([#3673](https://github.com/MorpheApp/morphe-patches/issues/3673)) ([fc8c837](https://github.com/MorpheApp/morphe-patches/commit/fc8c837390b05edbc5262ea786d1308729e80c24))
* **YouTube:** Add `Feed video actions` patch ([#3758](https://github.com/MorpheApp/morphe-patches/issues/3758)) ([b263c08](https://github.com/MorpheApp/morphe-patches/commit/b263c08af15eb0a72f6ea707bd49597d95209d29))
* **YouTube:** Add `Feed view count` patch ([#3862](https://github.com/MorpheApp/morphe-patches/issues/3862)) ([cf0ce16](https://github.com/MorpheApp/morphe-patches/commit/cf0ce16d8304c31ca7a89e730c09debe07a67390))
* **YouTube:** Add `Series tracking` patch ([#3114](https://github.com/MorpheApp/morphe-patches/issues/3114)) ([d98558f](https://github.com/MorpheApp/morphe-patches/commit/d98558fde76a7d2f49579a9f794423cd765211c9))
* **YouTube:** Add `Video delay` patch ([#3867](https://github.com/MorpheApp/morphe-patches/issues/3867)) ([ec246e2](https://github.com/MorpheApp/morphe-patches/commit/ec246e292e6c7c18373bb486a53c3db205efb83f))
* **YouTube:** Add playback speed for Shorts and skip live Shorts ([#3847](https://github.com/MorpheApp/morphe-patches/issues/3847)) ([3731d97](https://github.com/MorpheApp/morphe-patches/commit/3731d97f6ec4eaedbccaa7b7e8d4775c8cf9d587))
* **YouTube:** Added new feed card layout ([#3768](https://github.com/MorpheApp/morphe-patches/issues/3768)) ([02a4c3d](https://github.com/MorpheApp/morphe-patches/commit/02a4c3d36745f133bfae4983aa615984970631a2))
* **YouTube:** Added new feed cards layout without action buttons ([#3769](https://github.com/MorpheApp/morphe-patches/issues/3769)) ([096b0bb](https://github.com/MorpheApp/morphe-patches/commit/096b0bb3e7a98e00ba56ce3dc4260c0b7106e905))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.42.0` ([1302ae1](https://github.com/MorpheApp/morphe-patches/commit/1302ae1d890588d388b18d0c1cd54313689a2ea7))
* **YouTube Music:** Add experimental support for `9.41.52` ([003a445](https://github.com/MorpheApp/morphe-patches/commit/003a445df12a25f0970a6060853d12ccfbcae7b1))
* **YouTube:** Add experimental support for `21.41.525` ([#3658](https://github.com/MorpheApp/morphe-patches/issues/3658)) ([95eb1fb](https://github.com/MorpheApp/morphe-patches/commit/95eb1fbabe8bdb6251c20b962142cd4daefc1e47))
* **YouTube:** Add experimental support for `21.42.240` ([463a4ba](https://github.com/MorpheApp/morphe-patches/commit/463a4ba0a33cdc72111bf3a5d2d4698d1d3c6bf5))

## [1.48.0-dev.21](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.20...v1.48.0-dev.21) (2026-10-22)

### 🐛 Bug Fixes

* **YouTube Music:** Experimental app version does not patch ([12fad56](https://github.com/MorpheApp/morphe-patches/commit/12fad5684a453f5f8e359e6f66a2ab04e6caede8))

## [1.48.0-dev.20](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.19...v1.48.0-dev.20) (2026-10-22)

### ✨ New Features

* Update to Patcher 2.0 ([#3945](https://github.com/MorpheApp/morphe-patches/issues/3945)) ([d7c25c2](https://github.com/MorpheApp/morphe-patches/commit/d7c25c26031e77c051973fb71b761fa991ee7ddb))

## [1.48.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.18...v1.48.0-dev.19) (2026-10-22)

### 🐛 Bug Fixes

* **YouTube - Default video quality:** SABR video quality drops while the video plays ([#3853](https://github.com/MorpheApp/morphe-patches/issues/3853)) ([0488bda](https://github.com/MorpheApp/morphe-patches/commit/0488bda28d4d5844a2a739d3eefd00c28afd43fa))
* **YouTube - Downloads:** Playing video enters picture-in-picture when the external downloader opens ([#3882](https://github.com/MorpheApp/morphe-patches/issues/3882)) ([cf43209](https://github.com/MorpheApp/morphe-patches/commit/cf43209679dbba198e963aa381ce25110a6aa8fb))
* **YouTube - Feed card layout:** Show missing watch progress on feed cards ([#3926](https://github.com/MorpheApp/morphe-patches/issues/3926)) ([096798f](https://github.com/MorpheApp/morphe-patches/commit/096798f5877ffce88bac17adef5a9477931071b0))
* **YouTube - Feed video actions:** Show on the grid of landscape ([#3875](https://github.com/MorpheApp/morphe-patches/issues/3875)) ([db5e7d0](https://github.com/MorpheApp/morphe-patches/commit/db5e7d0f97d44032212e7a4451ab38466fd67506))
* **YouTube - Navigation bar:** App crashes on Android 12-13 when the player is dragged down to the miniplayer ([#3937](https://github.com/MorpheApp/morphe-patches/issues/3937)) ([a6db8d7](https://github.com/MorpheApp/morphe-patches/commit/a6db8d7aba965471d9a51f27ad7324513e2eb40b))
* **YouTube - Navigation bar:** Increased the spacing between Shorts player and navigation bar when this latter is hidden ([a6fdc2f](https://github.com/MorpheApp/morphe-patches/commit/a6fdc2f1331f5d2fe14da2abb89dfe4b8799ce7f))
* **YouTube:** History items are hidden when the keyboard is open ([3f38b2d](https://github.com/MorpheApp/morphe-patches/commit/3f38b2ded7f857a0240126388686234d3c786892))

### ✨ New Features

* **Reddit - Redgifs audio:** Download Redgifs videos with audio ([#3869](https://github.com/MorpheApp/morphe-patches/issues/3869)) ([f2ed85e](https://github.com/MorpheApp/morphe-patches/commit/f2ed85e67e518ec9115d51d7d6eb0d208232b646))
* **YouTube - Captions:** Add "Show captions in picture-in-picture" setting ([#3907](https://github.com/MorpheApp/morphe-patches/issues/3907)) ([6c817e7](https://github.com/MorpheApp/morphe-patches/commit/6c817e7daa49a1b0bf007f31fc7eece9ff3af566))
* **YouTube - Restore original titles:** Restore titles of watch history and fullscreen suggested videos ([f55e541](https://github.com/MorpheApp/morphe-patches/commit/f55e54163bd04b7b6fdd3e015951ad6bf4f8d42f))
* **YouTube:** Add `Ask flyout menu` patch ([#3897](https://github.com/MorpheApp/morphe-patches/issues/3897)) ([04c76d0](https://github.com/MorpheApp/morphe-patches/commit/04c76d0ace8e3e5c6d4e4d015e7bc231199b9c02))
* **YouTube:** Add `Video delay` patch ([#3867](https://github.com/MorpheApp/morphe-patches/issues/3867)) ([ec246e2](https://github.com/MorpheApp/morphe-patches/commit/ec246e292e6c7c18373bb486a53c3db205efb83f))
* **YouTube:** Add playback speed for Shorts and skip live Shorts ([#3847](https://github.com/MorpheApp/morphe-patches/issues/3847)) ([3731d97](https://github.com/MorpheApp/morphe-patches/commit/3731d97f6ec4eaedbccaa7b7e8d4775c8cf9d587))

## [1.48.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.17...v1.48.0-dev.18) (2026-10-21)

### 🐛 Bug Fixes

* **Downloads:** Allow using in-app downloads with player overlay external download button ([3df6c0a](https://github.com/MorpheApp/morphe-patches/commit/3df6c0a3d9ad097db63709cf5b559223d4575dd6))
* **YouTube - Downloads:** Music videos may not download ([0bac4fa](https://github.com/MorpheApp/morphe-patches/commit/0bac4fa12101e5729e5b4c060d9bac10250281aa))
* **YouTube Music - Crossfade:** Preserve repeat state on 9.40+ ([#3916](https://github.com/MorpheApp/morphe-patches/issues/3916)) ([ce688de](https://github.com/MorpheApp/morphe-patches/commit/ce688de5f6a0693a0df01e37cf25478eaac2524b))

## [1.48.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.16...v1.48.0-dev.17) (2026-10-21)

### 🐛 Bug Fixes

* **YouTube - Navigation bar:** bug: Navigation bar is not disabled in shorts player ([03f3aa2](https://github.com/MorpheApp/morphe-patches/commit/03f3aa27bc48cfb23a54c723065c83283eed6bc2))
* **YouTube - Navigation bar:** Navigation bar grows and covers the page when the keyboard is open ([7ec9a54](https://github.com/MorpheApp/morphe-patches/commit/7ec9a549a75798c76439a38400dbc325b7cd78df))
* **YouTube - Spoof video streams:** In-app downloads are slow when using spoof streaming ([6a8b5a9](https://github.com/MorpheApp/morphe-patches/commit/6a8b5a976c011ea1d365e90db143c9b4d8745976))

### ✨ New Features

* **YouTube Music - Android Auto:** Add Home, Library, and search features ([#3852](https://github.com/MorpheApp/morphe-patches/issues/3852)) ([65e200f](https://github.com/MorpheApp/morphe-patches/commit/65e200f623efc8b651a338360555884b717e05af))

## [1.48.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.15...v1.48.0-dev.16) (2026-10-20)

### 🐛 Bug Fixes

* **YouTube - Ambient mode:** Force Ambient mode when the server turns it off ([0eda16c](https://github.com/MorpheApp/morphe-patches/commit/0eda16c28e7ca4842a9087bba0fb47d146feddfa))
* **YouTube - Feed view count:** Keep the badge away from the edges of inset thumbnails, show lakh and crore units ([544013a](https://github.com/MorpheApp/morphe-patches/commit/544013adcc8881104c003d8d5e3280f725fc676e))
* **YouTube - Force animations:** Animate page transitions when the server turns them off ([79979bc](https://github.com/MorpheApp/morphe-patches/commit/79979bcae286d7bbb11b6ccc06558e812b07637f))
* **YouTube - Return YouTube Dislike:** Place the feed thumbnail like count on inset thumbnails and channel posts ([#3902](https://github.com/MorpheApp/morphe-patches/issues/3902)) ([de420c2](https://github.com/MorpheApp/morphe-patches/commit/de420c275ea33a3664e5ab6424903ff54c2359c4))

### ✨ New Features

* **YouTube - Downloads:** Add "Download in-app" setting ([#3905](https://github.com/MorpheApp/morphe-patches/issues/3905)) ([ef266aa](https://github.com/MorpheApp/morphe-patches/commit/ef266aa4bf94bf63e5b85a31673c297bf0ef81ef))

## [1.48.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.14...v1.48.0-dev.15) (2026-10-20)

### 🐛 Bug Fixes

* Temporarily revert patches-library update to fix app startup crash ([fd8cc0f](https://github.com/MorpheApp/morphe-patches/commit/fd8cc0fb14540b1e0d6adec903a7c2720a80b2f7))

## [1.48.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.13...v1.48.0-dev.14) (2026-10-20)

### 🐛 Bug Fixes

* **YouTube - Feed view count:** Show on the grid of landscape, same corners and text size as the other badges ([#3874](https://github.com/MorpheApp/morphe-patches/issues/3874)) ([733b6d1](https://github.com/MorpheApp/morphe-patches/commit/733b6d108f09c23892fbe3201dee55e45224b9c3))
* **YouTube:** Error toasts on app startup with YouTube 21.40+ ([2151a04](https://github.com/MorpheApp/morphe-patches/commit/2151a04d0dfcc7f54e28af645a0e304f9af2d265))

### ✨ New Features

* **YouTube - Force animations:** Expand the content below the player with its animation when it loads ([b0020b2](https://github.com/MorpheApp/morphe-patches/commit/b0020b2513fffb6954c5925af3213958b947f94f))
* **YouTube Music - Third-party lyrics:** Local romanization and alignment ([#3851](https://github.com/MorpheApp/morphe-patches/issues/3851)) ([9adcefd](https://github.com/MorpheApp/morphe-patches/commit/9adcefda0e18fb08a5e70933f243cdbc1d99e502))

## [1.48.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.12...v1.48.0-dev.13) (2026-10-19)

### 🐛 Bug Fixes

* **YouTube - Captions:** Show auto-translated captions of styled caption tracks ([#3837](https://github.com/MorpheApp/morphe-patches/issues/3837)) ([aedcf19](https://github.com/MorpheApp/morphe-patches/commit/aedcf198849b226d3b23638e5e810d9ea39999ba))
* **YouTube - Feed card layout:** Sort buttons of the channel tabs have a card background ([328121e](https://github.com/MorpheApp/morphe-patches/commit/328121e9a5b6552075db00327c12ecf39feda762))
* **YouTube - Miniplayer:** Watch transition animation is missing ([779d81c](https://github.com/MorpheApp/morphe-patches/commit/779d81c856133efc0e59a83e81f9628cd05a581f))
* **YouTube - Navigation bar:** Navigation bar is raised and an empty bar is left at the bottom on Android 11 and lower ([e91d606](https://github.com/MorpheApp/morphe-patches/commit/e91d60686bbc66182eab43e510c04d247e5fb323))
* **YouTube Music - Android Auto:** Fix large collections not loading on 9.15 ([#3849](https://github.com/MorpheApp/morphe-patches/issues/3849)) ([1c18d6a](https://github.com/MorpheApp/morphe-patches/commit/1c18d6a02a119d0147593d3615c46dce3a65ff19))
* **YouTube Music - Enable exclusive audio playback:** Prevent podcasts stopping in Android Auto ([#3850](https://github.com/MorpheApp/morphe-patches/issues/3850)) ([7a2b926](https://github.com/MorpheApp/morphe-patches/commit/7a2b926302f34d1309fb3896ed6720d0db5ab8a5))
* **YouTube:** "Play next/last in queue" does nothing from feeds when no video is playing ([c770414](https://github.com/MorpheApp/morphe-patches/commit/c770414fb0ed43ac8f2af7519f7f9222cae8f780))
* **YouTube:** Comments button page indicator is invisible with the light theme ([0f7f6d8](https://github.com/MorpheApp/morphe-patches/commit/0f7f6d8f6625d73941e211c51167097288f8682d))
* **YouTube:** Restore Edge TTS and add voice catalog refresh ([#3840](https://github.com/MorpheApp/morphe-patches/issues/3840)) ([4aa4deb](https://github.com/MorpheApp/morphe-patches/commit/4aa4deb6cd6ad4bf01a0f199e984dd3b33449fab))

### ✨ New Features

* **Reddit:** Add `Download location` patch ([#3870](https://github.com/MorpheApp/morphe-patches/issues/3870)) ([7d0f9b6](https://github.com/MorpheApp/morphe-patches/commit/7d0f9b67193372a92e7065f5fa4f4e366b2ba41c))
* **YouTube - Hide layout components:** Add "Hide 'No comments yet' message" setting ([#3819](https://github.com/MorpheApp/morphe-patches/issues/3819)) ([32168f9](https://github.com/MorpheApp/morphe-patches/commit/32168f9ebff2269c98ea5d9adedda07394342ab9))
* **YouTube - Hide layout components:** Add "Hide live chat scroll to bottom button" setting ([#3826](https://github.com/MorpheApp/morphe-patches/issues/3826)) ([1956988](https://github.com/MorpheApp/morphe-patches/commit/19569880caabbaed642ce9c48e829d22141405dd))
* **YouTube - Return YouTube Dislike:** Add "Show feed thumbnail like count" setting ([#3786](https://github.com/MorpheApp/morphe-patches/issues/3786)) ([7b2fd85](https://github.com/MorpheApp/morphe-patches/commit/7b2fd85413a12a955dfcd8ff9928790c2ac993e8))
* **YouTube - Series tracking:** Add "Show Series in navigation bar" setting ([#3814](https://github.com/MorpheApp/morphe-patches/issues/3814)) ([abaca95](https://github.com/MorpheApp/morphe-patches/commit/abaca951b67eeae3dd9f1a9bc8f9c09e72b7c20b))
* **YouTube:** Add "Force animations" patch, superseding the Miniplayer watch transition fix ([#3872](https://github.com/MorpheApp/morphe-patches/issues/3872)) ([591ad8b](https://github.com/MorpheApp/morphe-patches/commit/591ad8bd917bc168b0144014022438e395624bef))
* **YouTube:** Add `Feed view count` patch ([#3862](https://github.com/MorpheApp/morphe-patches/issues/3862)) ([cf0ce16](https://github.com/MorpheApp/morphe-patches/commit/cf0ce16d8304c31ca7a89e730c09debe07a67390))

## [1.48.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.11...v1.48.0-dev.12) (2026-10-18)

### 🐛 Bug Fixes

* **YouTube - Captions:** Restore all translation menu getter routes ([#3818](https://github.com/MorpheApp/morphe-patches/issues/3818)) ([3a6a5b3](https://github.com/MorpheApp/morphe-patches/commit/3a6a5b3ae1d934114668a68ebe56bd512baae18e))
* **YouTube - Default video quality:** Video quality drops while the video plays ([9f7b7eb](https://github.com/MorpheApp/morphe-patches/commit/9f7b7ebb10c909f7d2bc480de9fdbd3dd6076e2f))
* **YouTube - Feed card layout:** Remove the feed vertical spacing override, which can crash the app ([31a85c7](https://github.com/MorpheApp/morphe-patches/commit/31a85c7d1bfb99658c668444c37fd96e16500398))
* **YouTube - Feed card layout:** Round the top outer corners of the Shorts shelves ([8effa2e](https://github.com/MorpheApp/morphe-patches/commit/8effa2e103947e57455e2b93629186a411c86f37))
* **YouTube - Feed card layout:** Shorts shelves of the search results are not cards ([12ed02f](https://github.com/MorpheApp/morphe-patches/commit/12ed02f49d3059875435c6d8cdebe548c7e80dd3))
* **YouTube - Feed card layout:** Vertical video shelves are not cards ([44564ee](https://github.com/MorpheApp/morphe-patches/commit/44564eeff5d617dab0b0210c149a9c190e9f0021))
* **YouTube - Feed video actions:** Watch later button opens the share sheet ([6c94f32](https://github.com/MorpheApp/morphe-patches/commit/6c94f32df957beda5721729f12385eea3537c975))
* **YouTube - Minimal miniplayer:** Bar is cut off by the display cutout in landscape ([01267da](https://github.com/MorpheApp/morphe-patches/commit/01267da0f015fb868edb6b59e1086778966c7900))
* **YouTube - Navigation bar:** Navigation bar is raised and an empty bar is left at the bottom ([eca3334](https://github.com/MorpheApp/morphe-patches/commit/eca3334c07df995dbbb4f58ed425591883086554))
* **YouTube:** App can crash when an observer removes itself while it is notified ([5ee5a72](https://github.com/MorpheApp/morphe-patches/commit/5ee5a724433d6b96b7847e98aaf39c096bd81d5f))
* **YouTube:** Flyout menu text is cut when Morphe items are added ([f8b7669](https://github.com/MorpheApp/morphe-patches/commit/f8b7669dfd9b10ed68da3cfae4190cb0f2c7430a))
* **YouTube:** Status bar is opaque, black bar above the player and crash on startup ([b5d9498](https://github.com/MorpheApp/morphe-patches/commit/b5d9498577ea285c8dd490bb823bbbd9c6674624))
* **YouTube:** Video metadata panel text can not be read with the light theme ([332e18e](https://github.com/MorpheApp/morphe-patches/commit/332e18e82b73cc737fc6c84d1126e6fa915821fb))

### ✨ New Features

* **Reddit:** Add `Redgifs audio` patch ([#3714](https://github.com/MorpheApp/morphe-patches/issues/3714)) ([b664711](https://github.com/MorpheApp/morphe-patches/commit/b66471189b52974ead5666ac033b6b2ec867de2e))
* **YouTube - Hide status bar:** Add "Fix status bar covering the top bars" setting ([caa1be0](https://github.com/MorpheApp/morphe-patches/commit/caa1be0fe5faf3351fa49a02667f03ef4946b34f))

## [1.48.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.10...v1.48.0-dev.11) (2026-10-17)

### 🐛 Bug Fixes

* **YouTube - Captions:** Restore translations from original caption sources ([#3794](https://github.com/MorpheApp/morphe-patches/issues/3794)) ([46ab900](https://github.com/MorpheApp/morphe-patches/commit/46ab900bd9daa990a4d741a6e7f3dc5611173cdb))
* **YouTube - Feed cards layout:** Cards sometimes lose spacing ([0658f00](https://github.com/MorpheApp/morphe-patches/commit/0658f0083bc5d143b379097b706d4114a845a08f))

### ✨ New Features

* **YouTube:** Add `Feed video actions` patch ([#3758](https://github.com/MorpheApp/morphe-patches/issues/3758)) ([b263c08](https://github.com/MorpheApp/morphe-patches/commit/b263c08af15eb0a72f6ea707bd49597d95209d29))

## [1.48.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.9...v1.48.0-dev.10) (2026-10-17)

### 🐛 Bug Fixes

* **YouTube - Default video quality:** Forcely disabled automatic stock quality selection and deprecated the code to handle both Stock/Morphe quality selections ([93e0c2b](https://github.com/MorpheApp/morphe-patches/commit/93e0c2b4db27760a22b1e48aef8b87dc330a92bf))
* **YouTube - Feed cards layout:** Keep horizontal layout for search results on tablets ([0108028](https://github.com/MorpheApp/morphe-patches/commit/0108028df245e0664974d345c58a291f95a1245e))
* **YouTube - Feed cards layout:** Make new style more consistent ([#3801](https://github.com/MorpheApp/morphe-patches/issues/3801)) ([5dc0d0c](https://github.com/MorpheApp/morphe-patches/commit/5dc0d0c71ef9c9c11709e62568eb9c1778e9a4c7))
* **YouTube - Minimal miniplayer:** Apply minimized position based on commit [#9d8b0df43](https://github.com/MorpheApp/morphe-patches/issues/9d8b0df43) insets ([7f9fb1f](https://github.com/MorpheApp/morphe-patches/commit/7f9fb1f7df988afc7a21ffa4735227a404c06444))
* **YouTube - Minimal miniplayer:** Show DeArrow title on type 1 style ([72f7b82](https://github.com/MorpheApp/morphe-patches/commit/72f7b82c8ac8d9032d7834abb10ae9f9b86c5ba1))
* **YouTube - New feed cards layout:** Rounded edges and padding was wrong ([7d54662](https://github.com/MorpheApp/morphe-patches/commit/7d5466217e5dc7ea1ea323d4f9d7a6baf9f42f8a))
* **YouTube:** Force show translucent navigation bar ([e5bb8bf](https://github.com/MorpheApp/morphe-patches/commit/e5bb8bfea55258a6926243fbfb7ed19fffea3925))
* **YouTube:** Light/Dark theme colors are wrong ([93cf169](https://github.com/MorpheApp/morphe-patches/commit/93cf169e8fa7f96bef741fe5f02f5654b2ae70f6))
* **YouTube:** Status bar becomes dark ([9d8b0df](https://github.com/MorpheApp/morphe-patches/commit/9d8b0df43ae3cd4dfc1a537311d4dfc6aa600ac5))

### ✨ New Features

* **Reddit:** Add `Show flairs in home feed` patch ([#3260](https://github.com/MorpheApp/morphe-patches/issues/3260)) ([93501dd](https://github.com/MorpheApp/morphe-patches/commit/93501dd4b31a103c37509b1c26f7644ca9082aff))
* **YouTube - Player icon style:** Add Series tracker button icons ([179ff66](https://github.com/MorpheApp/morphe-patches/commit/179ff663d36806e11bd3869df8d1a66287072a7f))

## [1.48.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.8...v1.48.0-dev.9) (2026-10-16)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Fix Premium-style queue bugs ([#3752](https://github.com/MorpheApp/morphe-patches/issues/3752)) ([b07a6ac](https://github.com/MorpheApp/morphe-patches/commit/b07a6ac48bae7e6cd0336d4afdc12e368d5442d4))
* **YouTube - Forced video codec:** Excluded VP9 stream with forced AVC superseeded by Shorts VP9 with SABR restarting fix ([2335a8f](https://github.com/MorpheApp/morphe-patches/commit/2335a8f22eed59d36f1c3c7f0cb8de9fa846207f))
* **YouTube - Minimal comments button:** Hide page selector with new layout ([30a9dd1](https://github.com/MorpheApp/morphe-patches/commit/30a9dd17c87658ae405c6223661e478bce2a9629))
* **YouTube - Reload video:** Videos playing in the feed replace the reloaded video ([92e41c4](https://github.com/MorpheApp/morphe-patches/commit/92e41c43d2a0deb766f081e5b36e1556675e4090))
* **YouTube - Video quality:** Improved Shorts VP9 SABR loop restarting fix ([aeccfab](https://github.com/MorpheApp/morphe-patches/commit/aeccfabc5c4f256654ab209ff0741a3b5fada31c))
* **YouTube:** Fixed some 21.42+ fingerprints ([7bf6e1f](https://github.com/MorpheApp/morphe-patches/commit/7bf6e1fe85a75f9fcac4869d5ef548b21e2e5534))

### ✨ New Features

* **YouTube - Captions:** Add additional automatic translation languages ([#3754](https://github.com/MorpheApp/morphe-patches/issues/3754)) ([c036e5f](https://github.com/MorpheApp/morphe-patches/commit/c036e5f2e30b467a7c2e3af3ae948c0715efec48))
* **YouTube Music - Third-party lyrics:** Custom romanization target ([#3750](https://github.com/MorpheApp/morphe-patches/issues/3750)) ([0dfc834](https://github.com/MorpheApp/morphe-patches/commit/0dfc8347118bb9c10e8dd8275996d31afb5f5d37))
* **YouTube:** Added new feed card layout ([#3768](https://github.com/MorpheApp/morphe-patches/issues/3768)) ([02a4c3d](https://github.com/MorpheApp/morphe-patches/commit/02a4c3d36745f133bfae4983aa615984970631a2))
* **YouTube:** Added new feed cards layout without action buttons ([#3769](https://github.com/MorpheApp/morphe-patches/issues/3769)) ([096b0bb](https://github.com/MorpheApp/morphe-patches/commit/096b0bb3e7a98e00ba56ce3dc4260c0b7106e905))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.42.0` ([1302ae1](https://github.com/MorpheApp/morphe-patches/commit/1302ae1d890588d388b18d0c1cd54313689a2ea7))
* **YouTube:** Add experimental support for `21.42.240` ([463a4ba](https://github.com/MorpheApp/morphe-patches/commit/463a4ba0a33cdc72111bf3a5d2d4698d1d3c6bf5))

## [1.48.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.7...v1.48.0-dev.8) (2026-10-15)

### 🐛 Bug Fixes

* Export only filtered logs and stream file exports efficiently ([#3746](https://github.com/MorpheApp/morphe-patches/issues/3746)) ([e04c72d](https://github.com/MorpheApp/morphe-patches/commit/e04c72d8e068204c3a2178b75451fb8bfbb4d755))
* **YouTube - Hide layout components:** Video titles being hidden on `20.21.37` ([fead993](https://github.com/MorpheApp/morphe-patches/commit/fead993a68706580163825403b3ffd60a6866333))
* **YouTube - Hide preview comment:** Removed the timestamp from the Spanned String instead of disabling its tap logic ([cca6aca](https://github.com/MorpheApp/morphe-patches/commit/cca6aca240ef99e55740af20342a5d28deda6275))
* **YouTube - Miniplayer:** Match minimal miniplayer icons by content description name instead of resource id ([4502949](https://github.com/MorpheApp/morphe-patches/commit/4502949a61f6d5d39f72e4052f083cbe1460bd09))
* **YouTube - Open system share sheet:** Build link from share entity ([#3735](https://github.com/MorpheApp/morphe-patches/issues/3735)) ([92e9eb9](https://github.com/MorpheApp/morphe-patches/commit/92e9eb9d0fa941719c6cf7c048dae16ef163812c))
* **YouTube - Restore original titles:** Do not reload the same video title once the player is opened ([1648848](https://github.com/MorpheApp/morphe-patches/commit/1648848f2b3b2215f0ed3e6a08ddc0877a9365de))
* **YouTube - Video quality:** Fix VP9 Shorts restarting in a loop with spoofed SABR streams ([ef04cc3](https://github.com/MorpheApp/morphe-patches/commit/ef04cc3c12131d0667e598a935425143d1a6dcf1))
* **YouTube - VideoInformation:** Videos loaded in the background replace the video and playlist IDs of the player ([0ed3595](https://github.com/MorpheApp/morphe-patches/commit/0ed35954b6db94a12956c98b8db620e09dc65dd5))
* **YouTube:** Some external links can not be opened ([128b8d4](https://github.com/MorpheApp/morphe-patches/commit/128b8d4104e17a5b2527c3f951026f9ff79b4ea6))
* **YouTube:** Watch page background turns black in light mode ([4667cb0](https://github.com/MorpheApp/morphe-patches/commit/4667cb0ef1d13ee756c87976801f366869d7144d))

### ✨ New Features

* **YouTube - Channel search:** Added loading animation during searching ([d3fc642](https://github.com/MorpheApp/morphe-patches/commit/d3fc6421ca3f8e7ac6cc162d1a51b24c4b087e6e))
* **YouTube:** Add `Series tracking` patch ([#3114](https://github.com/MorpheApp/morphe-patches/issues/3114)) ([d98558f](https://github.com/MorpheApp/morphe-patches/commit/d98558fde76a7d2f49579a9f794423cd765211c9))

## [1.48.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.6...v1.48.0-dev.7) (2026-10-14)

### 🐛 Bug Fixes

* **YouTube - Jam queue sharing:** Keep the YouTube Music player aligned when Jam queue sharing is off ([#3704](https://github.com/MorpheApp/morphe-patches/issues/3704)) ([fd0db0b](https://github.com/MorpheApp/morphe-patches/commit/fd0db0b04bc12f80acde7fc259d7f72dbf724b13))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Add new providers ([#3717](https://github.com/MorpheApp/morphe-patches/issues/3717)) ([89e31ba](https://github.com/MorpheApp/morphe-patches/commit/89e31ba6d69e26a08b5bdd97b3afb4daa927048f))

## [1.48.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.5...v1.48.0-dev.6) (2026-10-13)

### ✨ New Features

* **YouTube - Disable video codecs:** Add "Force VP9 codec" setting ([#3578](https://github.com/MorpheApp/morphe-patches/issues/3578)) ([e1398ca](https://github.com/MorpheApp/morphe-patches/commit/e1398ca7da9dc7829aa8e9d2f798206fff26c1f6))

## [1.48.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.4...v1.48.0-dev.5) (2026-10-13)

### ✨ New Features

* **Reddit - Full width feed media:** Make embedded video players full width ([#3696](https://github.com/MorpheApp/morphe-patches/issues/3696)) ([53b6448](https://github.com/MorpheApp/morphe-patches/commit/53b64487109e05f13d8e0bc581f86e581cd4662b))
* **Reddit:** Add `Copy text` patch ([#3665](https://github.com/MorpheApp/morphe-patches/issues/3665)) ([3068f23](https://github.com/MorpheApp/morphe-patches/commit/3068f23e357825a77f6d67760f427634e3baee0c))
* **YouTube Music:** Add `Custom font` patch ([#3718](https://github.com/MorpheApp/morphe-patches/issues/3718)) ([30a4b85](https://github.com/MorpheApp/morphe-patches/commit/30a4b85885e96aa8216f2b9fb26ed0ba4951e8fe))

## [1.48.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.3...v1.48.0-dev.4) (2026-10-12)

### ✨ New Features

* **Spoof video streams:** Offer to fix playback when PotHelper no longer works or the default client keeps failing ([#3659](https://github.com/MorpheApp/morphe-patches/issues/3659)) ([f996510](https://github.com/MorpheApp/morphe-patches/commit/f996510cfdc71a78c5c9579efcf7d604e70ae1ea))
* **YouTube - Add to queue:** Add Premium-style queue setting ([#3582](https://github.com/MorpheApp/morphe-patches/issues/3582)) ([1b1b2bc](https://github.com/MorpheApp/morphe-patches/commit/1b1b2bc74bb49c0553225fc7b691c55fbc961a69))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.41.52` ([003a445](https://github.com/MorpheApp/morphe-patches/commit/003a445df12a25f0970a6060853d12ccfbcae7b1))

## [1.48.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.2...v1.48.0-dev.3) (2026-10-12)

### 🐛 Bug Fixes

* **YouTube - Custom font:** Show custom font picker if no font is selected yet ([8347b98](https://github.com/MorpheApp/morphe-patches/commit/8347b98e007c98065bbe2d546a89bf4f1daa1dce))

## [1.48.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.48.0-dev.1...v1.48.0-dev.2) (2026-10-12)

### 🐛 Bug Fixes

* **YouTube:** Add missing experimental compatibility declaration ([a81a933](https://github.com/MorpheApp/morphe-patches/commit/a81a933274cde895d3b4e026c2d084f35b9b20c5))

## [1.48.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0...v1.48.0-dev.1) (2026-10-12)

### 🐛 Bug Fixes

* **YouTube - Disable translucent bar:** Replace flag override with a proper patch ([88f77a8](https://github.com/MorpheApp/morphe-patches/commit/88f77a86ae737bc5da476011918d480baeff90b3))
* **YouTube - VideoInformation:** Separated Video and Shorts informations ([e913727](https://github.com/MorpheApp/morphe-patches/commit/e913727f3a115f7be807bc32efbf6c054b8fa35d))
* **YouTube:** Channel search not working properly ([ab2ecc7](https://github.com/MorpheApp/morphe-patches/commit/ab2ecc7a31f6678a698893663ee707d49fc51648))

### ✨ New Features

* **Reddit:** Add `Customize post layout` patch ([#3541](https://github.com/MorpheApp/morphe-patches/issues/3541)) ([a301bc1](https://github.com/MorpheApp/morphe-patches/commit/a301bc1d07ebd96390566cc2d4503ca48a013775))
* **Reddit:** Add `Remember collapsed comments` patch ([#3517](https://github.com/MorpheApp/morphe-patches/issues/3517)) ([fbd5a82](https://github.com/MorpheApp/morphe-patches/commit/fbd5a82666abeeabd6c7aeb19b7ca993b1ba85c6))
* **Reddit:** Add media viewer and feed media patches ([#3516](https://github.com/MorpheApp/morphe-patches/issues/3516)) ([1e905b5](https://github.com/MorpheApp/morphe-patches/commit/1e905b5449e6a5468a02f017ce4afb336e8f668e))
* **YouTube:** Add `Custom font` patch ([#3673](https://github.com/MorpheApp/morphe-patches/issues/3673)) ([fc8c837](https://github.com/MorpheApp/morphe-patches/commit/fc8c837390b05edbc5262ea786d1308729e80c24))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.41.525` ([#3658](https://github.com/MorpheApp/morphe-patches/issues/3658)) ([95eb1fb](https://github.com/MorpheApp/morphe-patches/commit/95eb1fbabe8bdb6251c20b962142cd4daefc1e47))

## [1.47.0](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0...v1.47.0) (2026-10-11)

### 🐛 Bug Fixes

* **Custom branding:** Use the branded notification icon for playback notifications of mounted installs ([90210ad](https://github.com/MorpheApp/morphe-patches/commit/90210ade0028c1c410c021ba350911cbc212efc4))
* **Settings:** Search hint and tips ignore the Morphe language override ([a532649](https://github.com/MorpheApp/morphe-patches/commit/a5326492f7bd7ae8b1228a1f6603716c002b2433))
* **Spoof video streams:** PoToken generation can stall and show "Failed to generate PoToken" ([#3663](https://github.com/MorpheApp/morphe-patches/issues/3663)) ([32fec71](https://github.com/MorpheApp/morphe-patches/commit/32fec713a9e7e555150b75078d476ddb6a6ba238))
* **Spoof video streams:** Widgets may not play correctly ([#3656](https://github.com/MorpheApp/morphe-patches/issues/3656)) ([a60a3b6](https://github.com/MorpheApp/morphe-patches/commit/a60a3b6725ac8c984e2aa68bd50b3c9358df299f))
* **YouTube - Background playback:** Respect server value of automatic pause and resume flags ([2fa79ef](https://github.com/MorpheApp/morphe-patches/commit/2fa79efa841870b13e18c61e0a54fad057e16b9c))
* **YouTube - Channel search:** Searching again from same channel page may not show channel results ([14ec664](https://github.com/MorpheApp/morphe-patches/commit/14ec664125b49e139d553ec1b55384ecc722a468))
* **YouTube - FlyoutUtils:** Correctly resize feed flyout ([c129aa2](https://github.com/MorpheApp/morphe-patches/commit/c129aa293203a676461016a9bd4ad13e237d9add))
* **YouTube - Force AVC:** Removed VP9 formats with enabled setting ([bb3e3ff](https://github.com/MorpheApp/morphe-patches/commit/bb3e3ff01dc2fcdf7debc4969fb6037b18eefc94))
* **YouTube - Hide layout components:** Hide new type of video labels ([#3641](https://github.com/MorpheApp/morphe-patches/issues/3641)) ([4a7efd1](https://github.com/MorpheApp/morphe-patches/commit/4a7efd1c124c86cc169eb38fd50c311cdec923c7))
* **YouTube - Hide layout components:** History shelf hidden after fullscreen on You tab ([91d9b2d](https://github.com/MorpheApp/morphe-patches/commit/91d9b2daccb9242a02f4fbaa7dcd408a09c5a28a))
* **YouTube - Hide layout components:** Horizontal shelves show again after entering fullscreen ([#3618](https://github.com/MorpheApp/morphe-patches/issues/3618)) ([be4fffa](https://github.com/MorpheApp/morphe-patches/commit/be4fffa02de9d1d9258e148aae4617735c0c244e))
* **YouTube - Hide player flyout menu components:** Add separate Shorts settings for the Captions and Audio Track menus ([963982d](https://github.com/MorpheApp/morphe-patches/commit/963982d54af7c0a10d840e7e940dca29438423d3))
* **YouTube - Legacy player controls:** Autoplay end screen is broken in the miniplayer on 21.36+ ([#3649](https://github.com/MorpheApp/morphe-patches/issues/3649)) ([c3431a3](https://github.com/MorpheApp/morphe-patches/commit/c3431a3476c7d2508308c18d4f7ee8cfdde687ca))
* **YouTube - Litho relayout:** Keep tracking texts after the relayout ([0ee99ca](https://github.com/MorpheApp/morphe-patches/commit/0ee99ca69059ce0648aec12c8a72aba8ae482d0f))
* **YouTube - Minimal miniplayer:** Collapse straight into the bar after the keyboard closed under the expanded player ([3e62423](https://github.com/MorpheApp/morphe-patches/commit/3e62423d0c889714cae97da64270b8d7d04586ee))
* **YouTube - Miniplayer:** Fixed incorrect check to prevent title/channel name overwriting ([#3576](https://github.com/MorpheApp/morphe-patches/issues/3576)) ([1671904](https://github.com/MorpheApp/morphe-patches/commit/1671904e728a69c3545c2b6e73ea077b8a67d8d4))
* **YouTube - Miniplayer:** Improved check to prevent title/channel name overwriting ([ce2e1c5](https://github.com/MorpheApp/morphe-patches/commit/ce2e1c5484d96a769684cb6062364619b542ef2a))
* **YouTube - Navigation bar:** Added a setting to disable A/B navigation buttons layout ([2c3f5c8](https://github.com/MorpheApp/morphe-patches/commit/2c3f5c83131eb479c66a28d1a1c0ffbc810f19ac))
* **YouTube - Picture-in-picture button:** Do not load the flyout icon when the patch is not included ([0902326](https://github.com/MorpheApp/morphe-patches/commit/09023263cd73e85a3a0ea975c5ec514e0aa116f9))
* **YouTube - Playback speed:** Audio pitch controls not working on some devices ([44cf78b](https://github.com/MorpheApp/morphe-patches/commit/44cf78bcb556c2567511524e05e88308dc268486))
* **YouTube - Playback speed:** Fix patching old experimental targets ([99a9851](https://github.com/MorpheApp/morphe-patches/commit/99a9851bf853f4d350e5411381c49a7340b42022))
* **YouTube - Restore original titles:** Find the description by its body instead of the longest text ([3f72696](https://github.com/MorpheApp/morphe-patches/commit/3f726964b9896c12711f578469bc6e522d84474e))
* **YouTube - Restore original titles:** Replace the title in the fullscreen swipe-up panel ([9a966a9](https://github.com/MorpheApp/morphe-patches/commit/9a966a9d2c2f5fb0519218fd408d74653f2e89c7))
* **YouTube - Restore original titles:** Titles of videos searched in different languages ​​were not restored ([41eee25](https://github.com/MorpheApp/morphe-patches/commit/41eee25b9ee9863ba0aed5762f802c91aeb0a6c5))
* **YouTube - Restore video titles:** Do not depend on the TextClassifier to restore titles ([1bbfc37](https://github.com/MorpheApp/morphe-patches/commit/1bbfc370cb407e68303c13368217c2f01cf81b95))
* **YouTube - Settings:** Disable player flyout menu toggles when "Hide Settings button" is enabled ([e67af2e](https://github.com/MorpheApp/morphe-patches/commit/e67af2e19555cdc119c2d3ae5692313145b14fed))
* **YouTube - Skip silence:** Adapt the silence threshold to the audio level ([672830e](https://github.com/MorpheApp/morphe-patches/commit/672830e18c8fe47aedd6079bd8eb7b3441e0939d))
* **YouTube - Spoof video streams:** Legacy app targets may not work correctly ([ddfd5e0](https://github.com/MorpheApp/morphe-patches/commit/ddfd5e0921faae04161cfbe8833f60be74f3ac11))
* **YouTube - Spoof video streams:** Stream spoofing can show "Failed to obtain poToken" error ([c04605b](https://github.com/MorpheApp/morphe-patches/commit/c04605b743a1cd5a9de9d17a86abcfdcef359431))
* **YouTube Music - Third-party lyrics:** App may crash when viewing lyrics ([#3569](https://github.com/MorpheApp/morphe-patches/issues/3569)) ([fe546ad](https://github.com/MorpheApp/morphe-patches/commit/fe546ad518d30833af7b7148f8a9b974088174a7))
* **YouTube:** 'Minimal' miniplayer video area is empty in Arabic (RTL) ([c4f7eb9](https://github.com/MorpheApp/morphe-patches/commit/c4f7eb925e51c6cd91337ae9d4f9c23b7c95d4f2))
* **YouTube:** Allow video upload/live with toolbar create button ([a8fb76a](https://github.com/MorpheApp/morphe-patches/commit/a8fb76ae2162bfab09af383013ee4e2717c3ef38))
* **YouTube:** Audio pitch resets after playback speed ([696c2e4](https://github.com/MorpheApp/morphe-patches/commit/696c2e40bce52706cb5e99c9caa2a96f67a60c37))
* **YouTube:** Decouple flyout buttons and shared hooks from unrelated patches ([#3567](https://github.com/MorpheApp/morphe-patches/issues/3567)) ([dad074a](https://github.com/MorpheApp/morphe-patches/commit/dad074a50b01775881b1054571fdf08b11bfa012))
* **YouTube:** Fix crash when exiting fullscreen with the new player UI ([5651020](https://github.com/MorpheApp/morphe-patches/commit/56510203e25b8dc4619670a756e65c9439fdf66b))
* **YouTube:** Hide microphone at lower right corner of search not working ([d18708b](https://github.com/MorpheApp/morphe-patches/commit/d18708b39d693abd765e98c735296fe2404308e1))
* **YouTube:** Live chat input field is obscured by Android navigation bar on live streams ([f9f5d58](https://github.com/MorpheApp/morphe-patches/commit/f9f5d587eb796f3abc0686c753f8f0ef605633ba))

### ✨ New Features

* Automatically save crash reports to user documents folder ([#3570](https://github.com/MorpheApp/morphe-patches/issues/3570)) ([f633697](https://github.com/MorpheApp/morphe-patches/commit/f63369780d8a69cd0fb868711ca97e148a650d56))
* **Settings:** Show screen descriptions in a dialog from the toolbar info button ([a62ecc7](https://github.com/MorpheApp/morphe-patches/commit/a62ecc7dd3551a0b0954256a0797723d661bc32a))
* **Spoof video streams:** Add Wii U TV client as a fallback for TV ([#3655](https://github.com/MorpheApp/morphe-patches/issues/3655)) ([28ea7f9](https://github.com/MorpheApp/morphe-patches/commit/28ea7f9fe44d45a1869603086ce6e6adb89e4f48))
* **YouTube - Captions:** Add an option to select preferred caption language ([#3566](https://github.com/MorpheApp/morphe-patches/issues/3566)) ([435aa17](https://github.com/MorpheApp/morphe-patches/commit/435aa171aa30942530efae48159e9a61a94ccc8f))
* **YouTube - Channel search:** Add a separate channel page button to search within channels ([#3572](https://github.com/MorpheApp/morphe-patches/issues/3572)) ([639908f](https://github.com/MorpheApp/morphe-patches/commit/639908fd12eb8126171b7a275eb63a3f564c8239))
* **YouTube - DeArrow:** Add "Casual mode" setting ([#3668](https://github.com/MorpheApp/morphe-patches/issues/3668)) ([a13c11b](https://github.com/MorpheApp/morphe-patches/commit/a13c11b26b5a2b264d3fe4d0937e5814f18d2488))
* **YouTube - DeArrow:** Add more fine-grained settings for showing DeArrow titles ([#3573](https://github.com/MorpheApp/morphe-patches/issues/3573)) ([4aa01d6](https://github.com/MorpheApp/morphe-patches/commit/4aa01d6068722f343857c16ae9d5b9bc08e57c27))
* **YouTube - Hide layout components:** Add "Hide 'Ask Gemini' button" setting  ([#3662](https://github.com/MorpheApp/morphe-patches/issues/3662)) ([3da93d5](https://github.com/MorpheApp/morphe-patches/commit/3da93d5ac7d4abb22712f4725fe12cb8be5f1454))
* **YouTube - Hide layout components:** Add "Hide tap and hold gradient" setting ([#3586](https://github.com/MorpheApp/morphe-patches/issues/3586)) ([bf43c38](https://github.com/MorpheApp/morphe-patches/commit/bf43c38ab1bcc2c0966f3cbd12411313ce2f2323))
* **YouTube - Restore original titles:** Added original titles fetching retries ([c1543f0](https://github.com/MorpheApp/morphe-patches/commit/c1543f0b9d3b9982d2c132afbf5609ba34699ff2))
* **YouTube - Restore original titles:** Added support for media notification ([#3640](https://github.com/MorpheApp/morphe-patches/issues/3640)) ([a9ebf92](https://github.com/MorpheApp/morphe-patches/commit/a9ebf92c985e09fb551f9921c403478fd712ddf0))
* **YouTube Music - Crossfade:** Support newer versions ([#3635](https://github.com/MorpheApp/morphe-patches/issues/3635)) ([68988d4](https://github.com/MorpheApp/morphe-patches/commit/68988d4ed5af8c079e44da3562de4cb85f3d18a4))
* **YouTube Music - Settings:** Add a shortcut to change the app language on Android 13+ ([b3b5c11](https://github.com/MorpheApp/morphe-patches/commit/b3b5c11b85e2ddc15e18da2b3e27f1e35b70dfd5))
* **YouTube Music - Third-party lyrics:** SponsorBlock segments as lyrics offset ([#3575](https://github.com/MorpheApp/morphe-patches/issues/3575)) ([a900dfa](https://github.com/MorpheApp/morphe-patches/commit/a900dfa93b330f5a6c4ecc81a47fe2e09fa378fe))
* **YouTube Music:** Add `Enable audio/video switch` patch ([#3471](https://github.com/MorpheApp/morphe-patches/issues/3471)) ([87942b7](https://github.com/MorpheApp/morphe-patches/commit/87942b73da43a5fb1f8bf1bc46aea092badc12cb))
* **YouTube Music:** Add `Playlist track tap action` patch ([#3446](https://github.com/MorpheApp/morphe-patches/issues/3446)) ([66b7e78](https://github.com/MorpheApp/morphe-patches/commit/66b7e7817fb56938a2b6e7bd5a06a4cb2e52e409))
* **YouTube:** Add `Copy text` patch ([#3592](https://github.com/MorpheApp/morphe-patches/issues/3592)) ([f5312eb](https://github.com/MorpheApp/morphe-patches/commit/f5312eb35e275bddddd49696ae277f09d11efbeb))
* **YouTube:** Add `Disable continue watching prompt` patch ([#3580](https://github.com/MorpheApp/morphe-patches/issues/3580)) ([255d917](https://github.com/MorpheApp/morphe-patches/commit/255d917abc874f12382943edff0340425053ef83))
* **YouTube:** Add `Force system font` patch ([#3579](https://github.com/MorpheApp/morphe-patches/issues/3579)) ([3968284](https://github.com/MorpheApp/morphe-patches/commit/3968284900ab15a9d04575b359272759891d19c8))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.41.0` ([4e56069](https://github.com/MorpheApp/morphe-patches/commit/4e56069f64125347959f7a8b1efeffa3e8fac1d6))
* **YouTube:** Add support for `21.20.405` ([4cb3bd8](https://github.com/MorpheApp/morphe-patches/commit/4cb3bd872d57f036dce22692dcfb76f80df5ec20))

## [1.47.0-dev.25](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.24...v1.47.0-dev.25) (2026-10-11)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Audio pitch controls not working on some devices ([44cf78b](https://github.com/MorpheApp/morphe-patches/commit/44cf78bcb556c2567511524e05e88308dc268486))

## [1.47.0-dev.24](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.23...v1.47.0-dev.24) (2026-10-11)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** History shelf hidden after fullscreen on You tab ([91d9b2d](https://github.com/MorpheApp/morphe-patches/commit/91d9b2daccb9242a02f4fbaa7dcd408a09c5a28a))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Ask Gemini' button" setting  ([#3662](https://github.com/MorpheApp/morphe-patches/issues/3662)) ([3da93d5](https://github.com/MorpheApp/morphe-patches/commit/3da93d5ac7d4abb22712f4725fe12cb8be5f1454))

## [1.47.0-dev.23](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.22...v1.47.0-dev.23) (2026-10-11)

### 🐛 Bug Fixes

* **YouTube - Navigation bar:** Added a setting to disable A/B navigation buttons layout ([2c3f5c8](https://github.com/MorpheApp/morphe-patches/commit/2c3f5c83131eb479c66a28d1a1c0ffbc810f19ac))
* **YouTube:** Audio pitch resets after playback speed ([696c2e4](https://github.com/MorpheApp/morphe-patches/commit/696c2e40bce52706cb5e99c9caa2a96f67a60c37))
* **YouTube:** Hide microphone at lower right corner of search not working ([d18708b](https://github.com/MorpheApp/morphe-patches/commit/d18708b39d693abd765e98c735296fe2404308e1))

## [1.47.0-dev.22](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.21...v1.47.0-dev.22) (2026-10-10)

### ✨ New Features

* **YouTube:** Add `Force system font` patch ([#3579](https://github.com/MorpheApp/morphe-patches/issues/3579)) ([3968284](https://github.com/MorpheApp/morphe-patches/commit/3968284900ab15a9d04575b359272759891d19c8))

## [1.47.0-dev.21](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.20...v1.47.0-dev.21) (2026-10-10)

### 🐛 Bug Fixes

* **Spoof video streams:** PoToken generation can stall and show "Failed to generate PoToken" ([#3663](https://github.com/MorpheApp/morphe-patches/issues/3663)) ([32fec71](https://github.com/MorpheApp/morphe-patches/commit/32fec713a9e7e555150b75078d476ddb6a6ba238))

### ✨ New Features

* **YouTube - DeArrow:** Add "Casual mode" setting ([#3668](https://github.com/MorpheApp/morphe-patches/issues/3668)) ([a13c11b](https://github.com/MorpheApp/morphe-patches/commit/a13c11b26b5a2b264d3fe4d0937e5814f18d2488))

## [1.47.0-dev.20](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.19...v1.47.0-dev.20) (2026-10-10)

### 🐛 Bug Fixes

* **YouTube - Skip silence:** Adapt the silence threshold to the audio level ([672830e](https://github.com/MorpheApp/morphe-patches/commit/672830e18c8fe47aedd6079bd8eb7b3441e0939d))

## [1.47.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.18...v1.47.0-dev.19) (2026-10-10)

### 🐛 Bug Fixes

* **YouTube:** Live chat input field is obscured by Android navigation bar on live streams ([f9f5d58](https://github.com/MorpheApp/morphe-patches/commit/f9f5d587eb796f3abc0686c753f8f0ef605633ba))

## [1.47.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.17...v1.47.0-dev.18) (2026-10-10)

### 🐛 Bug Fixes

* **Spoof video streams:** Widgets may not play correctly ([#3656](https://github.com/MorpheApp/morphe-patches/issues/3656)) ([a60a3b6](https://github.com/MorpheApp/morphe-patches/commit/a60a3b6725ac8c984e2aa68bd50b3c9358df299f))

### ✨ New Features

* **Spoof video streams:** Add Wii U TV client as a fallback for TV ([#3655](https://github.com/MorpheApp/morphe-patches/issues/3655)) ([28ea7f9](https://github.com/MorpheApp/morphe-patches/commit/28ea7f9fe44d45a1869603086ce6e6adb89e4f48))

## [1.47.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.16...v1.47.0-dev.17) (2026-10-10)

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.41.0` ([4e56069](https://github.com/MorpheApp/morphe-patches/commit/4e56069f64125347959f7a8b1efeffa3e8fac1d6))

## [1.47.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.15...v1.47.0-dev.16) (2026-10-10)

### 🐛 Bug Fixes

* **YouTube - Legacy player controls:** Autoplay end screen is broken in the miniplayer on 21.36+ ([#3649](https://github.com/MorpheApp/morphe-patches/issues/3649)) ([c3431a3](https://github.com/MorpheApp/morphe-patches/commit/c3431a3476c7d2508308c18d4f7ee8cfdde687ca))

## [1.47.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.14...v1.47.0-dev.15) (2026-10-10)

### 🐛 Bug Fixes

* **YouTube - Restore original titles:** Replace the title in the fullscreen swipe-up panel ([9a966a9](https://github.com/MorpheApp/morphe-patches/commit/9a966a9d2c2f5fb0519218fd408d74653f2e89c7))

## [1.47.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.13...v1.47.0-dev.14) (2026-10-09)

### 🐛 Bug Fixes

* **Settings:** Search hint and tips ignore the Morphe language override ([a532649](https://github.com/MorpheApp/morphe-patches/commit/a5326492f7bd7ae8b1228a1f6603716c002b2433))
* **YouTube - Force AVC:** Removed VP9 formats with enabled setting ([bb3e3ff](https://github.com/MorpheApp/morphe-patches/commit/bb3e3ff01dc2fcdf7debc4969fb6037b18eefc94))

### ✨ New Features

* **YouTube - Restore original titles:** Added support for media notification ([#3640](https://github.com/MorpheApp/morphe-patches/issues/3640)) ([a9ebf92](https://github.com/MorpheApp/morphe-patches/commit/a9ebf92c985e09fb551f9921c403478fd712ddf0))
* **YouTube Music - Settings:** Add a shortcut to change the app language on Android 13+ ([b3b5c11](https://github.com/MorpheApp/morphe-patches/commit/b3b5c11b85e2ddc15e18da2b3e27f1e35b70dfd5))

## [1.47.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.12...v1.47.0-dev.13) (2026-10-09)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide new type of video labels ([#3641](https://github.com/MorpheApp/morphe-patches/issues/3641)) ([4a7efd1](https://github.com/MorpheApp/morphe-patches/commit/4a7efd1c124c86cc169eb38fd50c311cdec923c7))
* **YouTube - Settings:** Disable player flyout menu toggles when "Hide Settings button" is enabled ([e67af2e](https://github.com/MorpheApp/morphe-patches/commit/e67af2e19555cdc119c2d3ae5692313145b14fed))
* **YouTube:** 'Minimal' miniplayer video area is empty in Arabic (RTL) ([c4f7eb9](https://github.com/MorpheApp/morphe-patches/commit/c4f7eb925e51c6cd91337ae9d4f9c23b7c95d4f2))

### ✨ New Features

* **Settings:** Show screen descriptions in a dialog from the toolbar info button ([a62ecc7](https://github.com/MorpheApp/morphe-patches/commit/a62ecc7dd3551a0b0954256a0797723d661bc32a))

## [1.47.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.11...v1.47.0-dev.12) (2026-10-09)

### 🐛 Bug Fixes

* **YouTube - Channel search:** Searching again from same channel page may not show channel results ([14ec664](https://github.com/MorpheApp/morphe-patches/commit/14ec664125b49e139d553ec1b55384ecc722a468))

## [1.47.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.10...v1.47.0-dev.11) (2026-10-09)

### ✨ New Features

* **YouTube Music - Crossfade:** Support newer versions ([#3635](https://github.com/MorpheApp/morphe-patches/issues/3635)) ([68988d4](https://github.com/MorpheApp/morphe-patches/commit/68988d4ed5af8c079e44da3562de4cb85f3d18a4))

## [1.47.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.9...v1.47.0-dev.10) (2026-10-09)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Horizontal shelves show again after entering fullscreen ([#3618](https://github.com/MorpheApp/morphe-patches/issues/3618)) ([be4fffa](https://github.com/MorpheApp/morphe-patches/commit/be4fffa02de9d1d9258e148aae4617735c0c244e))

## [1.47.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.8...v1.47.0-dev.9) (2026-10-09)

### 🚀 Updated App Support

* **YouTube:** Add support for `21.20.405` ([4cb3bd8](https://github.com/MorpheApp/morphe-patches/commit/4cb3bd872d57f036dce22692dcfb76f80df5ec20))

## [1.47.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.7...v1.47.0-dev.8) (2026-10-09)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Fix patching old experimental targets ([99a9851](https://github.com/MorpheApp/morphe-patches/commit/99a9851bf853f4d350e5411381c49a7340b42022))

## [1.47.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.6...v1.47.0-dev.7) (2026-10-09)

### 🐛 Bug Fixes

* **YouTube:** Fix crash when exiting fullscreen with the new player UI ([5651020](https://github.com/MorpheApp/morphe-patches/commit/56510203e25b8dc4619670a756e65c9439fdf66b))

## [1.47.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.5...v1.47.0-dev.6) (2026-10-09)

### 🐛 Bug Fixes

* **Custom branding:** Use the branded notification icon for playback notifications of mounted installs ([90210ad](https://github.com/MorpheApp/morphe-patches/commit/90210ade0028c1c410c021ba350911cbc212efc4))
* **YouTube - Minimal miniplayer:** Collapse straight into the bar after the keyboard closed under the expanded player ([3e62423](https://github.com/MorpheApp/morphe-patches/commit/3e62423d0c889714cae97da64270b8d7d04586ee))
* **YouTube - Miniplayer:** Improved check to prevent title/channel name overwriting ([ce2e1c5](https://github.com/MorpheApp/morphe-patches/commit/ce2e1c5484d96a769684cb6062364619b542ef2a))
* **YouTube - Restore original titles:** Find the description by its body instead of the longest text ([3f72696](https://github.com/MorpheApp/morphe-patches/commit/3f726964b9896c12711f578469bc6e522d84474e))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide tap and hold gradient" setting ([#3586](https://github.com/MorpheApp/morphe-patches/issues/3586)) ([bf43c38](https://github.com/MorpheApp/morphe-patches/commit/bf43c38ab1bcc2c0966f3cbd12411313ce2f2323))
* **YouTube - Restore original titles:** Added original titles fetching retries ([c1543f0](https://github.com/MorpheApp/morphe-patches/commit/c1543f0b9d3b9982d2c132afbf5609ba34699ff2))

## [1.47.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.4...v1.47.0-dev.5) (2026-10-08)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Correctly resize feed flyout ([c129aa2](https://github.com/MorpheApp/morphe-patches/commit/c129aa293203a676461016a9bd4ad13e237d9add))
* **YouTube - Litho relayout:** Keep tracking texts after the relayout ([0ee99ca](https://github.com/MorpheApp/morphe-patches/commit/0ee99ca69059ce0648aec12c8a72aba8ae482d0f))
* **YouTube - Restore video titles:** Do not depend on the TextClassifier to restore titles ([1bbfc37](https://github.com/MorpheApp/morphe-patches/commit/1bbfc370cb407e68303c13368217c2f01cf81b95))

### ✨ New Features

* **YouTube - Captions:** Add an option to select preferred caption language ([#3566](https://github.com/MorpheApp/morphe-patches/issues/3566)) ([435aa17](https://github.com/MorpheApp/morphe-patches/commit/435aa171aa30942530efae48159e9a61a94ccc8f))
* **YouTube:** Add `Disable continue watching prompt` patch ([#3580](https://github.com/MorpheApp/morphe-patches/issues/3580)) ([255d917](https://github.com/MorpheApp/morphe-patches/commit/255d917abc874f12382943edff0340425053ef83))

## [1.47.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.3...v1.47.0-dev.4) (2026-10-08)

### 🐛 Bug Fixes

* **YouTube - Spoof video streams:** Stream spoofing can show "Failed to obtain poToken" error ([c04605b](https://github.com/MorpheApp/morphe-patches/commit/c04605b743a1cd5a9de9d17a86abcfdcef359431))

## [1.47.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.2...v1.47.0-dev.3) (2026-10-08)

### 🐛 Bug Fixes

* **YouTube - Spoof video streams:** Legacy app targets may not work correctly ([ddfd5e0](https://github.com/MorpheApp/morphe-patches/commit/ddfd5e0921faae04161cfbe8833f60be74f3ac11))

## [1.47.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.47.0-dev.1...v1.47.0-dev.2) (2026-10-08)

### 🐛 Bug Fixes

* **YouTube - Background playback:** Respect server value of automatic pause and resume flags ([2fa79ef](https://github.com/MorpheApp/morphe-patches/commit/2fa79efa841870b13e18c61e0a54fad057e16b9c))
* **YouTube - Hide player flyout menu components:** Add separate Shorts settings for the Captions and Audio Track menus ([963982d](https://github.com/MorpheApp/morphe-patches/commit/963982d54af7c0a10d840e7e940dca29438423d3))
* **YouTube - Miniplayer:** Fixed incorrect check to prevent title/channel name overwriting ([#3576](https://github.com/MorpheApp/morphe-patches/issues/3576)) ([1671904](https://github.com/MorpheApp/morphe-patches/commit/1671904e728a69c3545c2b6e73ea077b8a67d8d4))
* **YouTube - Restore original titles:** Titles of videos searched in different languages ​​were not restored ([41eee25](https://github.com/MorpheApp/morphe-patches/commit/41eee25b9ee9863ba0aed5762f802c91aeb0a6c5))
* **YouTube:** Allow video upload/live with toolbar create button ([a8fb76a](https://github.com/MorpheApp/morphe-patches/commit/a8fb76ae2162bfab09af383013ee4e2717c3ef38))

### ✨ New Features

* **YouTube - Channel search:** Add a separate channel page button to search within channels ([#3572](https://github.com/MorpheApp/morphe-patches/issues/3572)) ([639908f](https://github.com/MorpheApp/morphe-patches/commit/639908fd12eb8126171b7a275eb63a3f564c8239))
* **YouTube Music - Third-party lyrics:** SponsorBlock segments as lyrics offset ([#3575](https://github.com/MorpheApp/morphe-patches/issues/3575)) ([a900dfa](https://github.com/MorpheApp/morphe-patches/commit/a900dfa93b330f5a6c4ecc81a47fe2e09fa378fe))
* **YouTube:** Add `Copy text` patch ([#3592](https://github.com/MorpheApp/morphe-patches/issues/3592)) ([f5312eb](https://github.com/MorpheApp/morphe-patches/commit/f5312eb35e275bddddd49696ae277f09d11efbeb))

## [1.47.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0...v1.47.0-dev.1) (2026-10-06)

### 🐛 Bug Fixes

* **YouTube - Picture-in-picture button:** Do not load the flyout icon when the patch is not included ([0902326](https://github.com/MorpheApp/morphe-patches/commit/09023263cd73e85a3a0ea975c5ec514e0aa116f9))
* **YouTube Music - Third-party lyrics:** App may crash when viewing lyrics ([#3569](https://github.com/MorpheApp/morphe-patches/issues/3569)) ([fe546ad](https://github.com/MorpheApp/morphe-patches/commit/fe546ad518d30833af7b7148f8a9b974088174a7))
* **YouTube:** Decouple flyout buttons and shared hooks from unrelated patches ([#3567](https://github.com/MorpheApp/morphe-patches/issues/3567)) ([dad074a](https://github.com/MorpheApp/morphe-patches/commit/dad074a50b01775881b1054571fdf08b11bfa012))

### ✨ New Features

* Automatically save crash reports to user documents folder ([#3570](https://github.com/MorpheApp/morphe-patches/issues/3570)) ([f633697](https://github.com/MorpheApp/morphe-patches/commit/f63369780d8a69cd0fb868711ca97e148a650d56))
* **YouTube - DeArrow:** Add more fine-grained settings for showing DeArrow titles ([#3573](https://github.com/MorpheApp/morphe-patches/issues/3573)) ([4aa01d6](https://github.com/MorpheApp/morphe-patches/commit/4aa01d6068722f343857c16ae9d5b9bc08e57c27))
* **YouTube Music:** Add `Enable audio/video switch` patch ([#3471](https://github.com/MorpheApp/morphe-patches/issues/3471)) ([87942b7](https://github.com/MorpheApp/morphe-patches/commit/87942b73da43a5fb1f8bf1bc46aea092badc12cb))
* **YouTube Music:** Add `Playlist track tap action` patch ([#3446](https://github.com/MorpheApp/morphe-patches/issues/3446)) ([66b7e78](https://github.com/MorpheApp/morphe-patches/commit/66b7e7817fb56938a2b6e7bd5a06a4cb2e52e409))

## [1.46.0](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0...v1.46.0) (2026-10-06)

### 🐛 Bug Fixes

* **Clone app:** Change update permission and update provider to default on ([296aadc](https://github.com/MorpheApp/morphe-patches/commit/296aadc68a930e8e67cb6a382c83b45b417d8ef1))
* **DeArrow:** Always use high quality still images without checking if still exists ([632f5a6](https://github.com/MorpheApp/morphe-patches/commit/632f5a64ba493fd2883729c8bce15dc1773ac91e))
* **DeArrow:** Fix patching `21.16.256` ([035ebd2](https://github.com/MorpheApp/morphe-patches/commit/035ebd217c515685714ee805b2d78967ac37874c))
* **YouTube - DeArrow:** "DeArrow & original thumbnails" sometimes shows still images when no crowdsourced thumbnails exist ([#3531](https://github.com/MorpheApp/morphe-patches/issues/3531)) ([fdfc35d](https://github.com/MorpheApp/morphe-patches/commit/fdfc35d6e2e3c41454421ac7a2c7f7d767a1765f))
* **YouTube - FlyoutUtils:** Separated the fetching of the playlist ID in the header from that of the feed page ([a18724b](https://github.com/MorpheApp/morphe-patches/commit/a18724b2625d28f786dcc4ce07a93f08378723fc))
* **YouTube - FlyoutUtils:** Sets the height of the injected buttons container based on the available display free space ([3da0837](https://github.com/MorpheApp/morphe-patches/commit/3da0837b0360011f5f18c810c91653082dedbc6d))
* **YouTube - Hide Layout components:** Add more navigation tabs to back button or gesture filtering rule ([#3546](https://github.com/MorpheApp/morphe-patches/issues/3546)) ([4420d96](https://github.com/MorpheApp/morphe-patches/commit/4420d96a28e7b258e62e882b474bd77ca0e5f4a4))
* **YouTube - Hide layout components:** Allow filtering in miniplayer mode ([13df501](https://github.com/MorpheApp/morphe-patches/commit/13df5012977a0436fc86f15de9b478c05a25935c))
* **YouTube - Hide layout components:** Hide new type of attributes section in video description ([#3532](https://github.com/MorpheApp/morphe-patches/issues/3532)) ([b051959](https://github.com/MorpheApp/morphe-patches/commit/b05195975b54ad5e981bb0d099fbe6e9f750c7fa))
* **YouTube - Hide layout components:** Hide the chapter title next to the timestamp ([#3475](https://github.com/MorpheApp/morphe-patches/issues/3475)) ([a940c2a](https://github.com/MorpheApp/morphe-patches/commit/a940c2a714acb847494ea8f1b3f2ddf050b24f4e))
* **YouTube - Hide layout components:** Some filters don't work after switching to the "You" tab and using the Back button or gesture ([#3542](https://github.com/MorpheApp/morphe-patches/issues/3542)) ([332c6b2](https://github.com/MorpheApp/morphe-patches/commit/332c6b2a96dc441d160dd746c512f013e766e9ba))
* **YouTube - Hide status bar:** Added top margin and extended the patch to the app settings ([4a0a726](https://github.com/MorpheApp/morphe-patches/commit/4a0a7263b0dbdcd30f98a18a6199d662f1933fdc))
* **YouTube - Minimal miniplayer:** Both video and channel titles are overwritten by those of the short video currently playing ([0da4d71](https://github.com/MorpheApp/morphe-patches/commit/0da4d71a7e5e7d5945fe6c082f3c829eae034ffa))
* **YouTube - Navigation bar:** Disable new toolbar navigation tabs layout ([#3433](https://github.com/MorpheApp/morphe-patches/issues/3433)) ([165dbea](https://github.com/MorpheApp/morphe-patches/commit/165dbea673aae9bc6e11a1fa0e11230bcacd5988))
* **YouTube - Navigation bar:** Experimental targets shows startup error ([3465138](https://github.com/MorpheApp/morphe-patches/commit/3465138af7b0032dac11f9b97a1e6eba2083fb9f))
* **YouTube - PiP button:** Wrong flyout drawable ([#3448](https://github.com/MorpheApp/morphe-patches/issues/3448)) ([88e23e1](https://github.com/MorpheApp/morphe-patches/commit/88e23e11a5fbb7aa860a7341267641951d2dc94f))
* **YouTube - Restore original titles:** Handle titles of videos with disabled embedding ([#3539](https://github.com/MorpheApp/morphe-patches/issues/3539)) ([8612dd1](https://github.com/MorpheApp/morphe-patches/commit/8612dd107f9e723d48327c929558f10afb01faab))
* **YouTube - Save to Watch later:** Flyout menu icons are thin with old player button style ([4e9d7e7](https://github.com/MorpheApp/morphe-patches/commit/4e9d7e79c1dae18552762bf6e99d629b3d55ed9a))
* **YouTube - SponsorBlock:** Keep the segment opacity when importing settings and simplify the SponsorBlock code ([9e6e464](https://github.com/MorpheApp/morphe-patches/commit/9e6e464682f03347467e31e3acee2b41de214b04))
* **YouTube - SponsorBlock:** Undo skip toast blocks touches on some devices ([503606a](https://github.com/MorpheApp/morphe-patches/commit/503606ac9a6ff404984a313034922e6ac543c174))
* **YouTube - SponsorBlock:** Video length without segments is sometimes not shown ([fb7a029](https://github.com/MorpheApp/morphe-patches/commit/fb7a0297049b3397b6b89be919ab0d2cf005b89b))
* **YouTube - System share sheet:** Community posts or in-playlists links cannot be shared ([cca505f](https://github.com/MorpheApp/morphe-patches/commit/cca505f2f45d6466e5a24713a5d13ca3762730cb))
* **YouTube - System share sheet:** In-playlist id searching interfering with videoId sharing ([85207ea](https://github.com/MorpheApp/morphe-patches/commit/85207eab86b6ec1511ef13b6471367a5fa176d9b))
* **YouTube & YT Music - GmsCore support:** Fix notification registration for patched apps ([#3481](https://github.com/MorpheApp/morphe-patches/issues/3481)) ([db5eb58](https://github.com/MorpheApp/morphe-patches/commit/db5eb58fdca24a701e37811fb7c57fba9cebbebc))
* **YouTube Music - Hide buttons:** Only hide the notification button with Hide Notification button ([#3473](https://github.com/MorpheApp/morphe-patches/issues/3473)) ([d0242f3](https://github.com/MorpheApp/morphe-patches/commit/d0242f39f40d3b57eb28b79f3349368ad1ac25b7))
* **YouTube Music - Third-party lyrics:** Validate lyric candidates and display results promptly ([#3518](https://github.com/MorpheApp/morphe-patches/issues/3518)) ([9fca678](https://github.com/MorpheApp/morphe-patches/commit/9fca678be31f7577990bf667784d7db60269787e))
* **YouTube:** Change `20.31.42` support to `20.51.39` ([1438ba6](https://github.com/MorpheApp/morphe-patches/commit/1438ba62892fa042d8a01745b2b5f252a276dc66))
* **YouTube:** Chapters error when selecting ([501e66e](https://github.com/MorpheApp/morphe-patches/commit/501e66ec5d941f9d688481992621d291f7bf66f0))
* **YouTube:** Player flyout menu not scrollable in landscape mode ([e3bfa8b](https://github.com/MorpheApp/morphe-patches/commit/e3bfa8b70c1176c2932811dbc0b48483403c4aba))

### ✨ New Features

* **DeArrow:** Add setting to show DeArrow icon on crowdsourced video titles ([#3510](https://github.com/MorpheApp/morphe-patches/issues/3510)) ([0db7baa](https://github.com/MorpheApp/morphe-patches/commit/0db7baada9d7748acde8646d39f1b85334e60f77))
* **SponsorBlock:** Show the skip behavior on the category preference ([38925c8](https://github.com/MorpheApp/morphe-patches/commit/38925c8e219daf38e85408beba4a001d74b18c2f))
* **YouTube - Hide layout components:** Add Hide channel handle in You tab ([#3459](https://github.com/MorpheApp/morphe-patches/issues/3459)) ([acd4ab7](https://github.com/MorpheApp/morphe-patches/commit/acd4ab725c4f6dc022587740338d4b36a2aca4a0))
* **YouTube - Hide layout components:** Add Hide Help & feedback in menus ([#3476](https://github.com/MorpheApp/morphe-patches/issues/3476)) ([2311fed](https://github.com/MorpheApp/morphe-patches/commit/2311fed4d4deac9ed0f27093924eb703bec2ec8a))
* **YouTube - Player icon style:** Apply the icon style to the player's own controls ([#3451](https://github.com/MorpheApp/morphe-patches/issues/3451)) ([415bf3c](https://github.com/MorpheApp/morphe-patches/commit/415bf3c5f7c9753eb00a9b4924dcbfe15af427cd))
* **YouTube - Player icon style:** Style the cast button and add the missing Ionicons icons ([f721305](https://github.com/MorpheApp/morphe-patches/commit/f721305ee34225fdacd41ebcfbb17546058b7ec6))
* **YouTube Music:** Add `Android Auto` patch ([#3341](https://github.com/MorpheApp/morphe-patches/issues/3341)) ([a6d2dae](https://github.com/MorpheApp/morphe-patches/commit/a6d2dae48732917e834a800bc83e68afc9c6a09f))
* **YouTube:** Add `Skip silence` patch ([#3467](https://github.com/MorpheApp/morphe-patches/issues/3467)) ([7a702fc](https://github.com/MorpheApp/morphe-patches/commit/7a702fcddad7a1ef48a84672fe2567b71ade14d5))
* **YouTube:** Add DeArrow crowdsourced feed video titles, rename `Alternative thumbnails` patch to `DeArrow` ([#3447](https://github.com/MorpheApp/morphe-patches/issues/3447)) ([e6b598d](https://github.com/MorpheApp/morphe-patches/commit/e6b598d2e7d9055d62c3c651d705ca0c774dd6e6))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.40.0` ([2362e48](https://github.com/MorpheApp/morphe-patches/commit/2362e48e932720a668f2e93ae383a2d607e5682e))
* **YouTube Music:** Add experimental support for `9.39.52` ([cfc0435](https://github.com/MorpheApp/morphe-patches/commit/cfc0435c8f1c4ca09ad76734daae8e4a5acfe4ca))
* **YouTube Music:** Add experimental support for `9.40.51` ([60f840d](https://github.com/MorpheApp/morphe-patches/commit/60f840d6b003ba0f5febc037143fe28748e6e899))
* **YouTube Music:** Add support for `9.20.53` ([edd808c](https://github.com/MorpheApp/morphe-patches/commit/edd808c1e954f6c43e2d4c7226c2689f7ae17da7))
* **YouTube:** Add experimental support for `21.40.161` ([#3457](https://github.com/MorpheApp/morphe-patches/issues/3457)) ([30ab48c](https://github.com/MorpheApp/morphe-patches/commit/30ab48c3537d0b642525ea6b2a6c0bf9aba64e73))

## [1.46.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.9...v1.46.0-dev.10) (2026-10-06)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Sets the height of the injected buttons container based on the available display free space ([3da0837](https://github.com/MorpheApp/morphe-patches/commit/3da0837b0360011f5f18c810c91653082dedbc6d))
* **YouTube:** Change `20.31.42` support to `20.51.39` ([1438ba6](https://github.com/MorpheApp/morphe-patches/commit/1438ba62892fa042d8a01745b2b5f252a276dc66))

## [1.46.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.8...v1.46.0-dev.9) (2026-10-06)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Separated the fetching of the playlist ID in the header from that of the feed page ([a18724b](https://github.com/MorpheApp/morphe-patches/commit/a18724b2625d28f786dcc4ce07a93f08378723fc))
* **YouTube - Hide Layout components:** Add more navigation tabs to back button or gesture filtering rule ([#3546](https://github.com/MorpheApp/morphe-patches/issues/3546)) ([4420d96](https://github.com/MorpheApp/morphe-patches/commit/4420d96a28e7b258e62e882b474bd77ca0e5f4a4))
* **YouTube - Hide layout components:** Allow filtering in miniplayer mode ([13df501](https://github.com/MorpheApp/morphe-patches/commit/13df5012977a0436fc86f15de9b478c05a25935c))
* **YouTube Music - Third-party lyrics:** Validate lyric candidates and display results promptly ([#3518](https://github.com/MorpheApp/morphe-patches/issues/3518)) ([9fca678](https://github.com/MorpheApp/morphe-patches/commit/9fca678be31f7577990bf667784d7db60269787e))

## [1.46.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.7...v1.46.0-dev.8) (2026-10-05)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide new type of attributes section in video description ([#3532](https://github.com/MorpheApp/morphe-patches/issues/3532)) ([b051959](https://github.com/MorpheApp/morphe-patches/commit/b05195975b54ad5e981bb0d099fbe6e9f750c7fa))
* **YouTube - Hide layout components:** Some filters don't work after switching to the "You" tab and using the Back button or gesture ([#3542](https://github.com/MorpheApp/morphe-patches/issues/3542)) ([332c6b2](https://github.com/MorpheApp/morphe-patches/commit/332c6b2a96dc441d160dd746c512f013e766e9ba))
* **YouTube - Restore original titles:** Handle titles of videos with disabled embedding ([#3539](https://github.com/MorpheApp/morphe-patches/issues/3539)) ([8612dd1](https://github.com/MorpheApp/morphe-patches/commit/8612dd107f9e723d48327c929558f10afb01faab))

## [1.46.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.6...v1.46.0-dev.7) (2026-10-05)

### 🐛 Bug Fixes

* **YouTube - DeArrow:** "DeArrow & original thumbnails" sometimes shows still images when no crowdsourced thumbnails exist ([#3531](https://github.com/MorpheApp/morphe-patches/issues/3531)) ([fdfc35d](https://github.com/MorpheApp/morphe-patches/commit/fdfc35d6e2e3c41454421ac7a2c7f7d767a1765f))
* **YouTube - System share sheet:** In-playlist id searching interfering with videoId sharing ([85207ea](https://github.com/MorpheApp/morphe-patches/commit/85207eab86b6ec1511ef13b6471367a5fa176d9b))

## [1.46.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.5...v1.46.0-dev.6) (2026-10-05)

### 🐛 Bug Fixes

* **YouTube - Navigation bar:** Experimental targets shows startup error ([3465138](https://github.com/MorpheApp/morphe-patches/commit/3465138af7b0032dac11f9b97a1e6eba2083fb9f))

## [1.46.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.4...v1.46.0-dev.5) (2026-10-05)

### 🐛 Bug Fixes

* **DeArrow:** Fix patching `21.16.256` ([035ebd2](https://github.com/MorpheApp/morphe-patches/commit/035ebd217c515685714ee805b2d78967ac37874c))
* **YouTube - Navigation bar:** Disable new toolbar navigation tabs layout ([#3433](https://github.com/MorpheApp/morphe-patches/issues/3433)) ([165dbea](https://github.com/MorpheApp/morphe-patches/commit/165dbea673aae9bc6e11a1fa0e11230bcacd5988))

## [1.46.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.3...v1.46.0-dev.4) (2026-10-05)

### 🐛 Bug Fixes

* **DeArrow:** Always use high quality still images without checking if still exists ([632f5a6](https://github.com/MorpheApp/morphe-patches/commit/632f5a64ba493fd2883729c8bce15dc1773ac91e))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.40.51` ([60f840d](https://github.com/MorpheApp/morphe-patches/commit/60f840d6b003ba0f5febc037143fe28748e6e899))

## [1.46.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.2...v1.46.0-dev.3) (2026-10-04)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Both video and channel titles are overwritten by those of the short video currently playing ([0da4d71](https://github.com/MorpheApp/morphe-patches/commit/0da4d71a7e5e7d5945fe6c082f3c829eae034ffa))

### ✨ New Features

* **DeArrow:** Add setting to show DeArrow icon on crowdsourced video titles ([#3510](https://github.com/MorpheApp/morphe-patches/issues/3510)) ([0db7baa](https://github.com/MorpheApp/morphe-patches/commit/0db7baada9d7748acde8646d39f1b85334e60f77))
* **YouTube:** Add DeArrow crowdsourced feed video titles, rename `Alternative thumbnails` patch to `DeArrow` ([#3447](https://github.com/MorpheApp/morphe-patches/issues/3447)) ([e6b598d](https://github.com/MorpheApp/morphe-patches/commit/e6b598d2e7d9055d62c3c651d705ca0c774dd6e6))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.40.161` ([#3457](https://github.com/MorpheApp/morphe-patches/issues/3457)) ([30ab48c](https://github.com/MorpheApp/morphe-patches/commit/30ab48c3537d0b642525ea6b2a6c0bf9aba64e73))

## [1.46.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.46.0-dev.1...v1.46.0-dev.2) (2026-10-04)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide the chapter title next to the timestamp ([#3475](https://github.com/MorpheApp/morphe-patches/issues/3475)) ([a940c2a](https://github.com/MorpheApp/morphe-patches/commit/a940c2a714acb847494ea8f1b3f2ddf050b24f4e))
* **YouTube - Hide status bar:** Added top margin and extended the patch to the app settings ([4a0a726](https://github.com/MorpheApp/morphe-patches/commit/4a0a7263b0dbdcd30f98a18a6199d662f1933fdc))
* **YouTube - Save to Watch later:** Flyout menu icons are thin with old player button style ([4e9d7e7](https://github.com/MorpheApp/morphe-patches/commit/4e9d7e79c1dae18552762bf6e99d629b3d55ed9a))
* **YouTube - System share sheet:** Community posts or in-playlists links cannot be shared ([cca505f](https://github.com/MorpheApp/morphe-patches/commit/cca505f2f45d6466e5a24713a5d13ca3762730cb))
* **YouTube & YT Music - GmsCore support:** Fix notification registration for patched apps ([#3481](https://github.com/MorpheApp/morphe-patches/issues/3481)) ([db5eb58](https://github.com/MorpheApp/morphe-patches/commit/db5eb58fdca24a701e37811fb7c57fba9cebbebc))
* **YouTube Music - Hide buttons:** Only hide the notification button with Hide Notification button ([#3473](https://github.com/MorpheApp/morphe-patches/issues/3473)) ([d0242f3](https://github.com/MorpheApp/morphe-patches/commit/d0242f39f40d3b57eb28b79f3349368ad1ac25b7))

### ✨ New Features

* **YouTube - Hide layout components:** Add Hide Help & feedback in menus ([#3476](https://github.com/MorpheApp/morphe-patches/issues/3476)) ([2311fed](https://github.com/MorpheApp/morphe-patches/commit/2311fed4d4deac9ed0f27093924eb703bec2ec8a))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.40.0` ([2362e48](https://github.com/MorpheApp/morphe-patches/commit/2362e48e932720a668f2e93ae383a2d607e5682e))

## [1.46.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0...v1.46.0-dev.1) (2026-10-03)

### 🐛 Bug Fixes

* **Clone app:** Change update permission and update provider to default on ([296aadc](https://github.com/MorpheApp/morphe-patches/commit/296aadc68a930e8e67cb6a382c83b45b417d8ef1))
* **YouTube - PiP button:** Wrong flyout drawable ([#3448](https://github.com/MorpheApp/morphe-patches/issues/3448)) ([88e23e1](https://github.com/MorpheApp/morphe-patches/commit/88e23e11a5fbb7aa860a7341267641951d2dc94f))
* **YouTube - SponsorBlock:** Keep the segment opacity when importing settings and simplify the SponsorBlock code ([9e6e464](https://github.com/MorpheApp/morphe-patches/commit/9e6e464682f03347467e31e3acee2b41de214b04))
* **YouTube - SponsorBlock:** Undo skip toast blocks touches on some devices ([503606a](https://github.com/MorpheApp/morphe-patches/commit/503606ac9a6ff404984a313034922e6ac543c174))
* **YouTube - SponsorBlock:** Video length without segments is sometimes not shown ([fb7a029](https://github.com/MorpheApp/morphe-patches/commit/fb7a0297049b3397b6b89be919ab0d2cf005b89b))
* **YouTube:** Chapters error when selecting ([501e66e](https://github.com/MorpheApp/morphe-patches/commit/501e66ec5d941f9d688481992621d291f7bf66f0))
* **YouTube:** Player flyout menu not scrollable in landscape mode ([e3bfa8b](https://github.com/MorpheApp/morphe-patches/commit/e3bfa8b70c1176c2932811dbc0b48483403c4aba))

### ✨ New Features

* **SponsorBlock:** Show the skip behavior on the category preference ([38925c8](https://github.com/MorpheApp/morphe-patches/commit/38925c8e219daf38e85408beba4a001d74b18c2f))
* **YouTube - Hide layout components:** Add Hide channel handle in You tab ([#3459](https://github.com/MorpheApp/morphe-patches/issues/3459)) ([acd4ab7](https://github.com/MorpheApp/morphe-patches/commit/acd4ab725c4f6dc022587740338d4b36a2aca4a0))
* **YouTube - Player icon style:** Apply the icon style to the player's own controls ([#3451](https://github.com/MorpheApp/morphe-patches/issues/3451)) ([415bf3c](https://github.com/MorpheApp/morphe-patches/commit/415bf3c5f7c9753eb00a9b4924dcbfe15af427cd))
* **YouTube - Player icon style:** Style the cast button and add the missing Ionicons icons ([f721305](https://github.com/MorpheApp/morphe-patches/commit/f721305ee34225fdacd41ebcfbb17546058b7ec6))
* **YouTube Music:** Add `Android Auto` patch ([#3341](https://github.com/MorpheApp/morphe-patches/issues/3341)) ([a6d2dae](https://github.com/MorpheApp/morphe-patches/commit/a6d2dae48732917e834a800bc83e68afc9c6a09f))
* **YouTube:** Add `Skip silence` patch ([#3467](https://github.com/MorpheApp/morphe-patches/issues/3467)) ([7a702fc](https://github.com/MorpheApp/morphe-patches/commit/7a702fcddad7a1ef48a84672fe2567b71ade14d5))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.39.52` ([cfc0435](https://github.com/MorpheApp/morphe-patches/commit/cfc0435c8f1c4ca09ad76734daae8e4a5acfe4ca))
* **YouTube Music:** Add support for `9.20.53` ([edd808c](https://github.com/MorpheApp/morphe-patches/commit/edd808c1e954f6c43e2d4c7226c2689f7ae17da7))

## [1.45.0](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0...v1.45.0) (2026-10-02)

### 🐛 Bug Fixes

* **GmsCore support:** Omit empty intent data ([#3170](https://github.com/MorpheApp/morphe-patches/issues/3170)) ([f03894a](https://github.com/MorpheApp/morphe-patches/commit/f03894a8663fdb19a3ff48765d0cb928bcbc36a3))
* Reduce heap use from ConversionContext dumps and JS player cache ([#3120](https://github.com/MorpheApp/morphe-patches/issues/3120)) ([317fd56](https://github.com/MorpheApp/morphe-patches/commit/317fd56c1ecba41a7b928011a39e6a943ca9b07f))
* Resolve startup crash for older Android devices ([b3391b4](https://github.com/MorpheApp/morphe-patches/commit/b3391b423dba14ceedccf5b6ae5e1abebcc80c5d))
* **YouTube  - Voice over translation:** Add missing accessibility labels and Voice over translation button state ([#3203](https://github.com/MorpheApp/morphe-patches/issues/3203)) ([d99679b](https://github.com/MorpheApp/morphe-patches/commit/d99679b50dc6f19a2feffaa7f5a8940a9d83da94))
* **YouTube - Captions:** Make "Always show" override a manual caption-off ([#3421](https://github.com/MorpheApp/morphe-patches/issues/3421)) ([a92b8ed](https://github.com/MorpheApp/morphe-patches/commit/a92b8edc30e31e16ca61e072540ac722a2616ff9))
* **YouTube - Channel Id Routes:** Straight requests videoDetails field ([60f640e](https://github.com/MorpheApp/morphe-patches/commit/60f640e2a7bd793623ed127b7c3900459ba73bf7))
* **YouTube - Channel search:** Show a channel search hint in the search box ([#3262](https://github.com/MorpheApp/morphe-patches/issues/3262)) ([c5cce56](https://github.com/MorpheApp/morphe-patches/commit/c5cce56d16581024c2ee7dafdd4232e8383c922d))
* **YouTube - Comments filter:** Restored chat button page indicator ([5644496](https://github.com/MorpheApp/morphe-patches/commit/5644496b457b29cad2799c3c2cbc19cb422f0cab))
* **YouTube - Custom branding:** Do not ask which app to use for app shortcut actions ([#3204](https://github.com/MorpheApp/morphe-patches/issues/3204)) ([0a2f0e0](https://github.com/MorpheApp/morphe-patches/commit/0a2f0e0f487512d6fd5f0c97ca83ad061859988c))
* **YouTube - Hide layout components:** Open the correct channel tab when channel tabs are hidden ([#3200](https://github.com/MorpheApp/morphe-patches/issues/3200)) ([53cc35b](https://github.com/MorpheApp/morphe-patches/commit/53cc35b0552b59d0ff34ed057e4c167cb8881322))
* **YouTube - Hide layout components:** Restore preview comment simplebox matcher ([#3130](https://github.com/MorpheApp/morphe-patches/issues/3130)) ([6e55325](https://github.com/MorpheApp/morphe-patches/commit/6e55325ddbbff9323206bda909b4a50b6d2ab178))
* **YouTube - Hide player flyout menu components:** Hide the Audio Track item in the Shorts flyout menu ([#3297](https://github.com/MorpheApp/morphe-patches/issues/3297)) ([09de4d2](https://github.com/MorpheApp/morphe-patches/commit/09de4d2332b4e499435bf7a3032381faf51893c3))
* **YouTube - Layout components filter:** Filtered header buttons left empty spaces ([#3402](https://github.com/MorpheApp/morphe-patches/issues/3402)) ([b719412](https://github.com/MorpheApp/morphe-patches/commit/b719412520f3ed7828b7424a9f4814eec3b4ae50))
* **YouTube - Legacy player controls:** Preserve end screen on 21.36+ ([#3121](https://github.com/MorpheApp/morphe-patches/issues/3121)) ([b895285](https://github.com/MorpheApp/morphe-patches/commit/b895285b2aa0e4cab6bb23226e129c62d517c670))
* **YouTube - Litho filtering:** Shorts were not hidden on home feed after pressing the back button ([#3416](https://github.com/MorpheApp/morphe-patches/issues/3416)) ([5c21cf7](https://github.com/MorpheApp/morphe-patches/commit/5c21cf78bd7cc8fa9d67491cf46c07ae622f02a5))
* **YouTube - Media notification controls:** Remove Previous & Next buttons on Android 12 and lower ([#3332](https://github.com/MorpheApp/morphe-patches/issues/3332)) ([df6c914](https://github.com/MorpheApp/morphe-patches/commit/df6c91407abdb93ea81e9c8a57ddf9ba865f626c))
* **YouTube - Minimal miniplayer:** Fixed Type 2 aspect ratio by hooking video format size ([551490f](https://github.com/MorpheApp/morphe-patches/commit/551490f50127c8ea02725848eab7a16ffec9d487))
* **YouTube - Minimal miniplayer:** Restored interpolate minimizing transitions ([#3280](https://github.com/MorpheApp/morphe-patches/issues/3280)) ([dff3749](https://github.com/MorpheApp/morphe-patches/commit/dff3749d6b665b2669a4ccc9b1b8f70985b1c358))
* **YouTube - Playback speed:** Music videos do not play at 1x speed ([#3210](https://github.com/MorpheApp/morphe-patches/issues/3210)) ([1c7086d](https://github.com/MorpheApp/morphe-patches/commit/1c7086da6270a723da370f89440d70475f96c888))
* **YouTube - Playback speed:** Prevent speed leak into Shorts ([#3169](https://github.com/MorpheApp/morphe-patches/issues/3169)) ([ff35586](https://github.com/MorpheApp/morphe-patches/commit/ff35586e14b339e24a06d32cb77b57234c942fe2))
* **YouTube - Player controls:** Decouple legacy buttons from settings UI ([#3171](https://github.com/MorpheApp/morphe-patches/issues/3171)) ([dfeeb64](https://github.com/MorpheApp/morphe-patches/commit/dfeeb64c54bd2aa49fdbc3653f5ba2f81558d558))
* **YouTube - Player overlay buttons:** Fix startup crash with a partial patch selection ([#3228](https://github.com/MorpheApp/morphe-patches/issues/3228)) ([aee4774](https://github.com/MorpheApp/morphe-patches/commit/aee47746643c948191b25435a8f1b4e96ffb6df7))
* **YouTube - Restore old video action bar:** Do not hide newly posted comments ([#3324](https://github.com/MorpheApp/morphe-patches/issues/3324)) ([37b43f7](https://github.com/MorpheApp/morphe-patches/commit/37b43f7dd36133b6b3a7e76b8489f788e5b46727))
* **YouTube - Return YouTube Dislike:** Do not show dislikes on the share and comment buttons of community posts ([31b657c](https://github.com/MorpheApp/morphe-patches/commit/31b657c5482def040a368b1d4661db704249db50))
* **YouTube - Return YouTube Dislike:** Show dislikes on tablet layout ([#3153](https://github.com/MorpheApp/morphe-patches/issues/3153)) ([7835519](https://github.com/MorpheApp/morphe-patches/commit/7835519c42a656c2d30122dcd97fb27dd12b0b87))
* **YouTube - SponsorBlock:** Preserve exact video end for segment markers ([#3157](https://github.com/MorpheApp/morphe-patches/issues/3157)) ([a860f5b](https://github.com/MorpheApp/morphe-patches/commit/a860f5bdbce792254617fb31d424c02521c62c6f))
* **YouTube - SponsorBlock:** Segments may not load for some versions of YouTube ([#3328](https://github.com/MorpheApp/morphe-patches/issues/3328)) ([3d8c748](https://github.com/MorpheApp/morphe-patches/commit/3d8c748ae7f9ce9b9f21f97a041e60923673e728))
* **YouTube - Video quality:** Do not give a regular video the Shorts quality after leaving Shorts ([#3322](https://github.com/MorpheApp/morphe-patches/issues/3322)) ([aaa2bc1](https://github.com/MorpheApp/morphe-patches/commit/aaa2bc1f6d22db827b73ea064ce1c1c3cf89061e))
* **YouTube - Video quality:** Keep Shorts quality after closing a live stream opened from Shorts ([#3333](https://github.com/MorpheApp/morphe-patches/issues/3333)) ([0a94e0e](https://github.com/MorpheApp/morphe-patches/commit/0a94e0e5714af91c7250a2be66bee3ba6fe7cb17))
* **YouTube Music - Custom branding:** Keep the startup animation on screen until it ends ([6043416](https://github.com/MorpheApp/morphe-patches/commit/6043416854f9d0c3dc2201229fae62a4828a52f7))
* **YouTube Music - Disable dislike redirection:** Fix patch on 9.35+ ([#3226](https://github.com/MorpheApp/morphe-patches/issues/3226)) ([703ddde](https://github.com/MorpheApp/morphe-patches/commit/703ddde1733d3514993ae689dedd1795bf696d82))
* **YouTube Music - Download in app:** Expose offline audio session ([#3167](https://github.com/MorpheApp/morphe-patches/issues/3167)) ([b4fb0e9](https://github.com/MorpheApp/morphe-patches/commit/b4fb0e9d00a2e876b30ce64da66ee459ad974abc))
* **YouTube Music - Downloads:** Fix patching failure "Could not find conversion context field" ([#3231](https://github.com/MorpheApp/morphe-patches/issues/3231)) ([b4f2d7d](https://github.com/MorpheApp/morphe-patches/commit/b4f2d7d83c234b1f71ff4a6c8298a59ffe6ad240))
* **YouTube Music - Hide flyout menu components:** Hide nested download items ([#3165](https://github.com/MorpheApp/morphe-patches/issues/3165)) ([fd2b325](https://github.com/MorpheApp/morphe-patches/commit/fd2b325a655819233d6bdb0ded83ba08b0cb5295))
* **YouTube Music - Play albums songs:** Do not play the first track's song for every track of a queued album ([#3319](https://github.com/MorpheApp/morphe-patches/issues/3319)) ([cd82092](https://github.com/MorpheApp/morphe-patches/commit/cd820925387333b3b45516479c4c4880a450452b))
* **YouTube Music - Return YouTube Dislike:** Dislike count is black when the device uses the light theme ([7e7e15d](https://github.com/MorpheApp/morphe-patches/commit/7e7e15d8e0796a96d615e26ea66ac771fa068321))
* **YouTube Music - Return YouTube Dislike:** Fix dislike counter color ([#3161](https://github.com/MorpheApp/morphe-patches/issues/3161)) ([1404b8b](https://github.com/MorpheApp/morphe-patches/commit/1404b8bc7a09216b468e112c40b3298bf9cb2136))
* **YouTube Music - Third-party lyrics:** Crash while trimming the lyrics cache ([#3272](https://github.com/MorpheApp/morphe-patches/issues/3272)) ([e450b7a](https://github.com/MorpheApp/morphe-patches/commit/e450b7a073b3d0b2c83d37509a7443f40a7b6369))
* **YouTube Music - Third-party lyrics:** Do not cover comments panel ([#3155](https://github.com/MorpheApp/morphe-patches/issues/3155)) ([50e4e65](https://github.com/MorpheApp/morphe-patches/commit/50e4e65ef15e28586ec55fae51da0bb03ae392d9))
* **YouTube Music - Third-party lyrics:** Keep the screen on after the track changes ([#3246](https://github.com/MorpheApp/morphe-patches/issues/3246)) ([e730ebf](https://github.com/MorpheApp/morphe-patches/commit/e730ebfa8be5b689e484eefa33b380554884a862))
* **YouTube Music - Third-party lyrics:** Keep the token dialog buttons on screen with long cookies ([#3245](https://github.com/MorpheApp/morphe-patches/issues/3245)) ([1cf6be0](https://github.com/MorpheApp/morphe-patches/commit/1cf6be0051247409030199b54d864540f9e3f55a))
* **YouTube Music - Third-party lyrics:** minor bug fixes ([#3323](https://github.com/MorpheApp/morphe-patches/issues/3323)) ([292d78b](https://github.com/MorpheApp/morphe-patches/commit/292d78bb3c9b52796a54c68b4797c8db77496b28))
* **YouTube Music - Third-party lyrics:** Reload lyrics when video changes ([#3148](https://github.com/MorpheApp/morphe-patches/issues/3148)) ([2920175](https://github.com/MorpheApp/morphe-patches/commit/29201754faeec713fa2fc43725527062160f8c0c))
* **YouTube:** "Hide preview comment" breaks comment section text box ([#3187](https://github.com/MorpheApp/morphe-patches/issues/3187)) ([d592804](https://github.com/MorpheApp/morphe-patches/commit/d5928043b7982326a102aafa2993e3cb8872eaf7))
* **YouTube:** "Restore old video action bar" hides newly posted comments ([#3216](https://github.com/MorpheApp/morphe-patches/issues/3216)) ([24d5823](https://github.com/MorpheApp/morphe-patches/commit/24d582398b812f96e23bc374c3c77c4dd5506eb4))
* **YouTube:** Always use Litho instead RenderNext as rendering library ([#3347](https://github.com/MorpheApp/morphe-patches/issues/3347)) ([52e0138](https://github.com/MorpheApp/morphe-patches/commit/52e01385e857b5a9858bef107dbaded6a89078df))
* **YouTube:** Do not include hide layout settings indirectly ([d3b678a](https://github.com/MorpheApp/morphe-patches/commit/d3b678a8aff9d10a4f748d81d390c95de00d37f9))
* **YouTube:** Fix patching non-experimental targets ([4625872](https://github.com/MorpheApp/morphe-patches/commit/46258727492fb31cd60db65e9322602408dd32a8))
* **YouTube:** Hidden preview comment still has clickable timestamps ([#3268](https://github.com/MorpheApp/morphe-patches/issues/3268)) ([1dfd537](https://github.com/MorpheApp/morphe-patches/commit/1dfd537aa48d56f050556e262c8547de619f88ea))
* **YouTube:** Hide new community/subscribe buttons on channel page ([#3315](https://github.com/MorpheApp/morphe-patches/issues/3315)) ([5fb37df](https://github.com/MorpheApp/morphe-patches/commit/5fb37dfbc5df6a18914302d4e4a5a5c0b2d8f0b9))
* **YouTube:** Search bar becomes invisible with Hide Status Bar enabled ([b0492b5](https://github.com/MorpheApp/morphe-patches/commit/b0492b552c0fe9b760bd6e00c56f6ec3bbd005c0))

### ✨ New Features

* Add universal `Spoof signature` patch ([#3330](https://github.com/MorpheApp/morphe-patches/issues/3330)) ([77117f6](https://github.com/MorpheApp/morphe-patches/commit/77117f61d312b23f42b74e838c3a2e902be90029))
* **Custom branding:** Animate the Morphe logo at startup ([#3178](https://github.com/MorpheApp/morphe-patches/issues/3178)) ([70e8a9d](https://github.com/MorpheApp/morphe-patches/commit/70e8a9de9fc16efb830e2594dc6ba37ef49653c8))
* **YouTube - Channel search:** Add channel search result sorting ([#3298](https://github.com/MorpheApp/morphe-patches/issues/3298)) ([baadcf7](https://github.com/MorpheApp/morphe-patches/commit/baadcf7ef177c8dc07cbc61670d8d475869f934c))
* **YouTube - Hide layout components:** Add "Hide channel names in subscribed channels bar" ([#3274](https://github.com/MorpheApp/morphe-patches/issues/3274)) ([f8b330f](https://github.com/MorpheApp/morphe-patches/commit/f8b330f7d317632766cb0eeb8b98f64f0c974b0a))
* **YouTube - Hide layout components:** Add "Hide Dislike button" to comments ([#3293](https://github.com/MorpheApp/morphe-patches/issues/3293)) ([bd43ccf](https://github.com/MorpheApp/morphe-patches/commit/bd43ccf58d622b0ed66d3cd739351644de9c8295))
* **YouTube - Hide layout components:** Add "Hide History shelf" ([#3277](https://github.com/MorpheApp/morphe-patches/issues/3277)) ([50c4f34](https://github.com/MorpheApp/morphe-patches/commit/50c4f34ae3728e318d2e61512674167616fedc0c))
* **YouTube - Hide layout components:** Add "Hide live streams" setting  ([#3331](https://github.com/MorpheApp/morphe-patches/issues/3331)) ([53d5680](https://github.com/MorpheApp/morphe-patches/commit/53d5680ee84f8be2e1767f7c1832e081c165a15a))
* **YouTube - Hide layout components:** Add "Hide Menu button" for comments ([#3253](https://github.com/MorpheApp/morphe-patches/issues/3253)) ([9b30447](https://github.com/MorpheApp/morphe-patches/commit/9b30447302de598bd51e612610a858c7a6de9dfb))
* **YouTube - Hide layout components:** Add "Hide Translate button" setting  ([#3265](https://github.com/MorpheApp/morphe-patches/issues/3265)) ([16894f1](https://github.com/MorpheApp/morphe-patches/commit/16894f1ecb93ffdbe8269b0b04aced6a6805da55))
* **YouTube - Hide video action buttons:** Add "Hide channel and Subscribe button" ([#3289](https://github.com/MorpheApp/morphe-patches/issues/3289)) ([0c7cd56](https://github.com/MorpheApp/morphe-patches/commit/0c7cd56bd24c693b59aa3efd472730cee5df72c2))
* **YouTube - Hide video action buttons:** Add Hide Subscribe button option ([#3326](https://github.com/MorpheApp/morphe-patches/issues/3326)) ([a94ccdb](https://github.com/MorpheApp/morphe-patches/commit/a94ccdb354d4aad25c60c25dffea130681924d35))
* **YouTube - Navigation bar:** Add "Hide new content dot" setting  ([#3269](https://github.com/MorpheApp/morphe-patches/issues/3269)) ([c8d440d](https://github.com/MorpheApp/morphe-patches/commit/c8d440d309550c8d41e31238b61ecdc99e993b42))
* **YouTube - Navigation bar:** Add patch options to hide the Search and Subscriptions app shortcuts ([#3270](https://github.com/MorpheApp/morphe-patches/issues/3270)) ([37585d1](https://github.com/MorpheApp/morphe-patches/commit/37585d17d1afdc9cd6c0d371664e5cf585c88043))
* **YouTube - Playback buffer:** Add playback buffer size option ([#3386](https://github.com/MorpheApp/morphe-patches/issues/3386)) ([dfff1f5](https://github.com/MorpheApp/morphe-patches/commit/dfff1f5b170058fe14a59abb6da8214e3022842f))
* **YouTube - Player icon style:** Add custom icons from a zip file ([#3374](https://github.com/MorpheApp/morphe-patches/issues/3374)) ([224b731](https://github.com/MorpheApp/morphe-patches/commit/224b731509a1133a770d1c2f9938178d6a81a920))
* **YouTube - Player icons:** Add icon styles for overlay player buttons, swipe controls and Shorts ([#3287](https://github.com/MorpheApp/morphe-patches/issues/3287)) ([cca4ce0](https://github.com/MorpheApp/morphe-patches/commit/cca4ce0d186d415a651a8c1744afb9cb37a6dc3b))
* **YouTube - Restore original titles:** Restore original channel descriptions ([#3418](https://github.com/MorpheApp/morphe-patches/issues/3418)) ([3467b84](https://github.com/MorpheApp/morphe-patches/commit/3467b84d92a19443cc7cd13167a89e56100b338b))
* **YouTube - Swipe controls:** Add "Volume boost" setting ([#3412](https://github.com/MorpheApp/morphe-patches/issues/3412)) ([9e393e5](https://github.com/MorpheApp/morphe-patches/commit/9e393e542cb8de29edacba412acf127dfc0e775c))
* **YouTube Music - Hide buttons:** Add "Hide New button" setting  ([#3264](https://github.com/MorpheApp/morphe-patches/issues/3264)) ([d535e8d](https://github.com/MorpheApp/morphe-patches/commit/d535e8daa7119f86f1a7bd92f16c8ed1aba23d2a))
* **YouTube Music - Hide buttons:** Add "Hide Voice search button" and "Hide Sound search button" ([#3250](https://github.com/MorpheApp/morphe-patches/issues/3250)) ([cfc880b](https://github.com/MorpheApp/morphe-patches/commit/cfc880bbba4b2ef9451c537fcdb4751e2ce09caa))
* **YouTube Music - Hide layout components:** Add "Hide podcast episode Download button" ([#3251](https://github.com/MorpheApp/morphe-patches/issues/3251)) ([d94ca13](https://github.com/MorpheApp/morphe-patches/commit/d94ca13031d57b80edce4a872d633ffcffdae002))
* **YouTube Music - Third-party lyrics:** Add new provider ([#3174](https://github.com/MorpheApp/morphe-patches/issues/3174)) ([1bc710e](https://github.com/MorpheApp/morphe-patches/commit/1bc710e371eb89e663acaadb415c497b7829fe1e))
* **YouTube Music - Third-party lyrics:** Add Translation / Romanization only modes ([#3252](https://github.com/MorpheApp/morphe-patches/issues/3252)) ([1c6e6cd](https://github.com/MorpheApp/morphe-patches/commit/1c6e6cdbdacdd33088293c27e56c4fa6cc4f4049))
* **YouTube Music - Third-party lyrics:** Add translation language ([#3128](https://github.com/MorpheApp/morphe-patches/issues/3128)) ([7349cb6](https://github.com/MorpheApp/morphe-patches/commit/7349cb691635e2a506163aa9fd5813f0b73c4e3f))
* **YouTube Music - Third-party lyrics:** Keep screen on while viewing lyrics ([#3127](https://github.com/MorpheApp/morphe-patches/issues/3127)) ([cb4df9a](https://github.com/MorpheApp/morphe-patches/commit/cb4df9acf11249de66477ce9764ff29fbe41f9ca))
* **YouTube Music - Third-party lyrics:** Search and prompt ([#3372](https://github.com/MorpheApp/morphe-patches/issues/3372)) ([f2b3201](https://github.com/MorpheApp/morphe-patches/commit/f2b32016108b112458aaf09384423faa37910983))
* **YouTube Music:** Add `Force portrait orientation` patch ([#3291](https://github.com/MorpheApp/morphe-patches/issues/3291)) ([143726e](https://github.com/MorpheApp/morphe-patches/commit/143726ed161e493e5a827654f7f5a1465e2ff53f))
* **YouTube Music:** Add `Jam queue sharing` patch ([#3014](https://github.com/MorpheApp/morphe-patches/issues/3014)) ([cd6d03b](https://github.com/MorpheApp/morphe-patches/commit/cd6d03b71a2ef3bbfb6b53af8f07ada24c7cd36c))
* **YouTube Music:** Add `Media notification controls` patch ([#3288](https://github.com/MorpheApp/morphe-patches/issues/3288)) ([7c4431b](https://github.com/MorpheApp/morphe-patches/commit/7c4431b3b854cb145c540459fbde314b1a4d035a))
* **YouTube Music:** Add `Playback speed` patch ([#3295](https://github.com/MorpheApp/morphe-patches/issues/3295)) ([96eae8f](https://github.com/MorpheApp/morphe-patches/commit/96eae8f66b243646de2e767b37a9d9fb20b81dc4))
* **YouTube:** Add `Disable auto feed refresh` patch  ([#3387](https://github.com/MorpheApp/morphe-patches/issues/3387)) ([444bb0d](https://github.com/MorpheApp/morphe-patches/commit/444bb0dc18f33f56083ab9274a1d86b574fba1b4))
* **YouTube:** Add `Hide status bar` patch ([#3337](https://github.com/MorpheApp/morphe-patches/issues/3337)) ([05c1597](https://github.com/MorpheApp/morphe-patches/commit/05c1597e97ebd428a0d9b0e0a7ae2cbd05442735))
* **YouTube:** Add `Picture-in-picture button` patch ([#3397](https://github.com/MorpheApp/morphe-patches/issues/3397)) ([6c94728](https://github.com/MorpheApp/morphe-patches/commit/6c947288a3fc75105ef7e1c02d37a324dc20dc76))
* **YouTube:** Added "Minimal comments button" setting ([916f228](https://github.com/MorpheApp/morphe-patches/commit/916f228495509ac2af2780a93502e0b872f61aa8))
* **YouTube:** Added "Restore original videos title and description" ([#3384](https://github.com/MorpheApp/morphe-patches/issues/3384)) ([67e650c](https://github.com/MorpheApp/morphe-patches/commit/67e650c1a263a1c26de354527fc00c7dae828db9))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.39.0` ([755bf21](https://github.com/MorpheApp/morphe-patches/commit/755bf216267521a3d206d19be0cb230d8034ebb8))
* **Reddit:** Add support for `2026.24.0` ([707ba5e](https://github.com/MorpheApp/morphe-patches/commit/707ba5ed71d4713d213126db9477e8dde9fd2493))
* **YouTube Music:** Add experimental support for `9.38.51` ([314116f](https://github.com/MorpheApp/morphe-patches/commit/314116f3bad8eb4b42773651da7b663a2fcf759c))
* **YouTube:** Add experimental support for `21.39.522` ([#3290](https://github.com/MorpheApp/morphe-patches/issues/3290)) ([5687e86](https://github.com/MorpheApp/morphe-patches/commit/5687e86075418094937fbb7449e79406f7400ca9))

## [1.45.0-dev.23](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.22...v1.45.0-dev.23) (2026-10-01)

### 🐛 Bug Fixes

* **YouTube - Captions:** Make "Always show" override a manual caption-off ([#3421](https://github.com/MorpheApp/morphe-patches/issues/3421)) ([a92b8ed](https://github.com/MorpheApp/morphe-patches/commit/a92b8edc30e31e16ca61e072540ac722a2616ff9))
* **YouTube:** Search bar becomes invisible with Hide Status Bar enabled ([b0492b5](https://github.com/MorpheApp/morphe-patches/commit/b0492b552c0fe9b760bd6e00c56f6ec3bbd005c0))

### ✨ New Features

* **YouTube - Swipe controls:** Add "Volume boost" setting ([#3412](https://github.com/MorpheApp/morphe-patches/issues/3412)) ([9e393e5](https://github.com/MorpheApp/morphe-patches/commit/9e393e542cb8de29edacba412acf127dfc0e775c))
* **YouTube:** Add `Picture-in-picture button` patch ([#3397](https://github.com/MorpheApp/morphe-patches/issues/3397)) ([6c94728](https://github.com/MorpheApp/morphe-patches/commit/6c947288a3fc75105ef7e1c02d37a324dc20dc76))

## [1.45.0-dev.22](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.21...v1.45.0-dev.22) (2026-10-01)

### 🐛 Bug Fixes

* **YouTube - Litho filtering:** Shorts were not hidden on home feed after pressing the back button ([#3416](https://github.com/MorpheApp/morphe-patches/issues/3416)) ([5c21cf7](https://github.com/MorpheApp/morphe-patches/commit/5c21cf78bd7cc8fa9d67491cf46c07ae622f02a5))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide live streams" setting  ([#3331](https://github.com/MorpheApp/morphe-patches/issues/3331)) ([53d5680](https://github.com/MorpheApp/morphe-patches/commit/53d5680ee84f8be2e1767f7c1832e081c165a15a))
* **YouTube - Restore original titles:** Restore original channel descriptions ([#3418](https://github.com/MorpheApp/morphe-patches/issues/3418)) ([3467b84](https://github.com/MorpheApp/morphe-patches/commit/3467b84d92a19443cc7cd13167a89e56100b338b))
* **YouTube Music:** Add `Jam queue sharing` patch ([#3014](https://github.com/MorpheApp/morphe-patches/issues/3014)) ([cd6d03b](https://github.com/MorpheApp/morphe-patches/commit/cd6d03b71a2ef3bbfb6b53af8f07ada24c7cd36c))
* **YouTube:** Add `Disable auto feed refresh` patch  ([#3387](https://github.com/MorpheApp/morphe-patches/issues/3387)) ([444bb0d](https://github.com/MorpheApp/morphe-patches/commit/444bb0dc18f33f56083ab9274a1d86b574fba1b4))

## [1.45.0-dev.21](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.20...v1.45.0-dev.21) (2026-09-30)

### 🐛 Bug Fixes

* **YouTube - Layout components filter:** Filtered header buttons left empty spaces ([#3402](https://github.com/MorpheApp/morphe-patches/issues/3402)) ([b719412](https://github.com/MorpheApp/morphe-patches/commit/b719412520f3ed7828b7424a9f4814eec3b4ae50))

### ✨ New Features

* **YouTube - Playback buffer:** Add playback buffer size option ([#3386](https://github.com/MorpheApp/morphe-patches/issues/3386)) ([dfff1f5](https://github.com/MorpheApp/morphe-patches/commit/dfff1f5b170058fe14a59abb6da8214e3022842f))
* **YouTube:** Added "Restore original videos title and description" ([#3384](https://github.com/MorpheApp/morphe-patches/issues/3384)) ([67e650c](https://github.com/MorpheApp/morphe-patches/commit/67e650c1a263a1c26de354527fc00c7dae828db9))

## [1.45.0-dev.20](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.19...v1.45.0-dev.20) (2026-09-29)

### 🐛 Bug Fixes

* **YouTube:** Always use Litho instead RenderNext as rendering library ([#3347](https://github.com/MorpheApp/morphe-patches/issues/3347)) ([52e0138](https://github.com/MorpheApp/morphe-patches/commit/52e01385e857b5a9858bef107dbaded6a89078df))

### ✨ New Features

* **YouTube - Player icon style:** Add custom icons from a zip file ([#3374](https://github.com/MorpheApp/morphe-patches/issues/3374)) ([224b731](https://github.com/MorpheApp/morphe-patches/commit/224b731509a1133a770d1c2f9938178d6a81a920))

## [1.45.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.18...v1.45.0-dev.19) (2026-09-28)

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Search and prompt ([#3372](https://github.com/MorpheApp/morphe-patches/issues/3372)) ([f2b3201](https://github.com/MorpheApp/morphe-patches/commit/f2b32016108b112458aaf09384423faa37910983))
* **YouTube Music:** Add `Playback speed` patch ([#3295](https://github.com/MorpheApp/morphe-patches/issues/3295)) ([96eae8f](https://github.com/MorpheApp/morphe-patches/commit/96eae8f66b243646de2e767b37a9d9fb20b81dc4))

## [1.45.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.17...v1.45.0-dev.18) (2026-09-27)

### 🐛 Bug Fixes

* **YouTube - Media notification controls:** Remove Previous & Next buttons on Android 12 and lower ([#3332](https://github.com/MorpheApp/morphe-patches/issues/3332)) ([df6c914](https://github.com/MorpheApp/morphe-patches/commit/df6c91407abdb93ea81e9c8a57ddf9ba865f626c))
* **YouTube - Restore old video action bar:** Do not hide newly posted comments ([#3324](https://github.com/MorpheApp/morphe-patches/issues/3324)) ([37b43f7](https://github.com/MorpheApp/morphe-patches/commit/37b43f7dd36133b6b3a7e76b8489f788e5b46727))
* **YouTube - SponsorBlock:** Segments may not load for some versions of YouTube ([#3328](https://github.com/MorpheApp/morphe-patches/issues/3328)) ([3d8c748](https://github.com/MorpheApp/morphe-patches/commit/3d8c748ae7f9ce9b9f21f97a041e60923673e728))
* **YouTube - Video quality:** Do not give a regular video the Shorts quality after leaving Shorts ([#3322](https://github.com/MorpheApp/morphe-patches/issues/3322)) ([aaa2bc1](https://github.com/MorpheApp/morphe-patches/commit/aaa2bc1f6d22db827b73ea064ce1c1c3cf89061e))
* **YouTube - Video quality:** Keep Shorts quality after closing a live stream opened from Shorts ([#3333](https://github.com/MorpheApp/morphe-patches/issues/3333)) ([0a94e0e](https://github.com/MorpheApp/morphe-patches/commit/0a94e0e5714af91c7250a2be66bee3ba6fe7cb17))
* **YouTube Music - Play albums songs:** Do not play the first track's song for every track of a queued album ([#3319](https://github.com/MorpheApp/morphe-patches/issues/3319)) ([cd82092](https://github.com/MorpheApp/morphe-patches/commit/cd820925387333b3b45516479c4c4880a450452b))
* **YouTube Music - Third-party lyrics:** minor bug fixes ([#3323](https://github.com/MorpheApp/morphe-patches/issues/3323)) ([292d78b](https://github.com/MorpheApp/morphe-patches/commit/292d78bb3c9b52796a54c68b4797c8db77496b28))
* **YouTube:** Hide new community/subscribe buttons on channel page ([#3315](https://github.com/MorpheApp/morphe-patches/issues/3315)) ([5fb37df](https://github.com/MorpheApp/morphe-patches/commit/5fb37dfbc5df6a18914302d4e4a5a5c0b2d8f0b9))

### ✨ New Features

* Add universal `Spoof signature` patch ([#3330](https://github.com/MorpheApp/morphe-patches/issues/3330)) ([77117f6](https://github.com/MorpheApp/morphe-patches/commit/77117f61d312b23f42b74e838c3a2e902be90029))
* **YouTube - Hide video action buttons:** Add Hide Subscribe button option ([#3326](https://github.com/MorpheApp/morphe-patches/issues/3326)) ([a94ccdb](https://github.com/MorpheApp/morphe-patches/commit/a94ccdb354d4aad25c60c25dffea130681924d35))
* **YouTube Music:** Add `Force portrait orientation` patch ([#3291](https://github.com/MorpheApp/morphe-patches/issues/3291)) ([143726e](https://github.com/MorpheApp/morphe-patches/commit/143726ed161e493e5a827654f7f5a1465e2ff53f))
* **YouTube:** Add `Hide status bar` patch ([#3337](https://github.com/MorpheApp/morphe-patches/issues/3337)) ([05c1597](https://github.com/MorpheApp/morphe-patches/commit/05c1597e97ebd428a0d9b0e0a7ae2cbd05442735))

## [1.45.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.16...v1.45.0-dev.17) (2026-09-26)

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.39.522` ([#3290](https://github.com/MorpheApp/morphe-patches/issues/3290)) ([5687e86](https://github.com/MorpheApp/morphe-patches/commit/5687e86075418094937fbb7449e79406f7400ca9))

## [1.45.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.15...v1.45.0-dev.16) (2026-09-25)

### 🐛 Bug Fixes

* **YouTube - Hide player flyout menu components:** Hide the Audio Track item in the Shorts flyout menu ([#3297](https://github.com/MorpheApp/morphe-patches/issues/3297)) ([09de4d2](https://github.com/MorpheApp/morphe-patches/commit/09de4d2332b4e499435bf7a3032381faf51893c3))
* **YouTube - Minimal miniplayer:** Fixed Type 2 aspect ratio by hooking video format size ([551490f](https://github.com/MorpheApp/morphe-patches/commit/551490f50127c8ea02725848eab7a16ffec9d487))

### ✨ New Features

* **YouTube - Channel search:** Add channel search result sorting ([#3298](https://github.com/MorpheApp/morphe-patches/issues/3298)) ([baadcf7](https://github.com/MorpheApp/morphe-patches/commit/baadcf7ef177c8dc07cbc61670d8d475869f934c))
* **YouTube - Hide layout components:** Add "Hide Dislike button" to comments ([#3293](https://github.com/MorpheApp/morphe-patches/issues/3293)) ([bd43ccf](https://github.com/MorpheApp/morphe-patches/commit/bd43ccf58d622b0ed66d3cd739351644de9c8295))
* **YouTube - Player icons:** Add icon styles for overlay player buttons, swipe controls and Shorts ([#3287](https://github.com/MorpheApp/morphe-patches/issues/3287)) ([cca4ce0](https://github.com/MorpheApp/morphe-patches/commit/cca4ce0d186d415a651a8c1744afb9cb37a6dc3b))
* **YouTube Music - Third-party lyrics:** Add Translation / Romanization only modes ([#3252](https://github.com/MorpheApp/morphe-patches/issues/3252)) ([1c6e6cd](https://github.com/MorpheApp/morphe-patches/commit/1c6e6cdbdacdd33088293c27e56c4fa6cc4f4049))

## [1.45.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.14...v1.45.0-dev.15) (2026-09-25)

### 🐛 Bug Fixes

* **YouTube - Channel Id Routes:** Straight requests videoDetails field ([60f640e](https://github.com/MorpheApp/morphe-patches/commit/60f640e2a7bd793623ed127b7c3900459ba73bf7))

### ✨ New Features

* **YouTube - Hide video action buttons:** Add "Hide channel and Subscribe button" ([#3289](https://github.com/MorpheApp/morphe-patches/issues/3289)) ([0c7cd56](https://github.com/MorpheApp/morphe-patches/commit/0c7cd56bd24c693b59aa3efd472730cee5df72c2))
* **YouTube - Navigation bar:** Add patch options to hide the Search and Subscriptions app shortcuts ([#3270](https://github.com/MorpheApp/morphe-patches/issues/3270)) ([37585d1](https://github.com/MorpheApp/morphe-patches/commit/37585d17d1afdc9cd6c0d371664e5cf585c88043))
* **YouTube Music:** Add `Media notification controls` patch ([#3288](https://github.com/MorpheApp/morphe-patches/issues/3288)) ([7c4431b](https://github.com/MorpheApp/morphe-patches/commit/7c4431b3b854cb145c540459fbde314b1a4d035a))

## [1.45.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.13...v1.45.0-dev.14) (2026-09-25)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Restored interpolate minimizing transitions ([#3280](https://github.com/MorpheApp/morphe-patches/issues/3280)) ([dff3749](https://github.com/MorpheApp/morphe-patches/commit/dff3749d6b665b2669a4ccc9b1b8f70985b1c358))
* **YouTube:** Hidden preview comment still has clickable timestamps ([#3268](https://github.com/MorpheApp/morphe-patches/issues/3268)) ([1dfd537](https://github.com/MorpheApp/morphe-patches/commit/1dfd537aa48d56f050556e262c8547de619f88ea))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide channel names in subscribed channels bar" ([#3274](https://github.com/MorpheApp/morphe-patches/issues/3274)) ([f8b330f](https://github.com/MorpheApp/morphe-patches/commit/f8b330f7d317632766cb0eeb8b98f64f0c974b0a))
* **YouTube - Hide layout components:** Add "Hide History shelf" ([#3277](https://github.com/MorpheApp/morphe-patches/issues/3277)) ([50c4f34](https://github.com/MorpheApp/morphe-patches/commit/50c4f34ae3728e318d2e61512674167616fedc0c))
* **YouTube - Hide layout components:** Add "Hide Translate button" setting  ([#3265](https://github.com/MorpheApp/morphe-patches/issues/3265)) ([16894f1](https://github.com/MorpheApp/morphe-patches/commit/16894f1ecb93ffdbe8269b0b04aced6a6805da55))
* **YouTube - Navigation bar:** Add "Hide new content dot" setting  ([#3269](https://github.com/MorpheApp/morphe-patches/issues/3269)) ([c8d440d](https://github.com/MorpheApp/morphe-patches/commit/c8d440d309550c8d41e31238b61ecdc99e993b42))
* **YouTube Music - Hide buttons:** Add "Hide New button" setting  ([#3264](https://github.com/MorpheApp/morphe-patches/issues/3264)) ([d535e8d](https://github.com/MorpheApp/morphe-patches/commit/d535e8daa7119f86f1a7bd92f16c8ed1aba23d2a))
* **YouTube:** Added "Minimal comments button" setting ([916f228](https://github.com/MorpheApp/morphe-patches/commit/916f228495509ac2af2780a93502e0b872f61aa8))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.39.0` ([755bf21](https://github.com/MorpheApp/morphe-patches/commit/755bf216267521a3d206d19be0cb230d8034ebb8))
* **Reddit:** Add support for `2026.24.0` ([707ba5e](https://github.com/MorpheApp/morphe-patches/commit/707ba5ed71d4713d213126db9477e8dde9fd2493))

## [1.45.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.12...v1.45.0-dev.13) (2026-09-24)

### 🐛 Bug Fixes

* **YouTube - Channel search:** Show a channel search hint in the search box ([#3262](https://github.com/MorpheApp/morphe-patches/issues/3262)) ([c5cce56](https://github.com/MorpheApp/morphe-patches/commit/c5cce56d16581024c2ee7dafdd4232e8383c922d))
* **YouTube Music - Custom branding:** Keep the startup animation on screen until it ends ([6043416](https://github.com/MorpheApp/morphe-patches/commit/6043416854f9d0c3dc2201229fae62a4828a52f7))
* **YouTube Music - Third-party lyrics:** Crash while trimming the lyrics cache ([#3272](https://github.com/MorpheApp/morphe-patches/issues/3272)) ([e450b7a](https://github.com/MorpheApp/morphe-patches/commit/e450b7a073b3d0b2c83d37509a7443f40a7b6369))

## [1.45.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.11...v1.45.0-dev.12) (2026-09-24)

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide Menu button" for comments ([#3253](https://github.com/MorpheApp/morphe-patches/issues/3253)) ([9b30447](https://github.com/MorpheApp/morphe-patches/commit/9b30447302de598bd51e612610a858c7a6de9dfb))
* **YouTube Music - Hide buttons:** Add "Hide Voice search button" and "Hide Sound search button" ([#3250](https://github.com/MorpheApp/morphe-patches/issues/3250)) ([cfc880b](https://github.com/MorpheApp/morphe-patches/commit/cfc880bbba4b2ef9451c537fcdb4751e2ce09caa))
* **YouTube Music - Hide layout components:** Add "Hide podcast episode Download button" ([#3251](https://github.com/MorpheApp/morphe-patches/issues/3251)) ([d94ca13](https://github.com/MorpheApp/morphe-patches/commit/d94ca13031d57b80edce4a872d633ffcffdae002))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.38.51` ([314116f](https://github.com/MorpheApp/morphe-patches/commit/314116f3bad8eb4b42773651da7b663a2fcf759c))

## [1.45.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.10...v1.45.0-dev.11) (2026-09-24)

### 🐛 Bug Fixes

* **YouTube:** Fix patching non-experimental targets ([4625872](https://github.com/MorpheApp/morphe-patches/commit/46258727492fb31cd60db65e9322602408dd32a8))

## [1.45.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.9...v1.45.0-dev.10) (2026-09-24)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Open the correct channel tab when channel tabs are hidden ([#3200](https://github.com/MorpheApp/morphe-patches/issues/3200)) ([53cc35b](https://github.com/MorpheApp/morphe-patches/commit/53cc35b0552b59d0ff34ed057e4c167cb8881322))
* **YouTube Music - Third-party lyrics:** Keep the token dialog buttons on screen with long cookies ([#3245](https://github.com/MorpheApp/morphe-patches/issues/3245)) ([1cf6be0](https://github.com/MorpheApp/morphe-patches/commit/1cf6be0051247409030199b54d864540f9e3f55a))

## [1.45.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.8...v1.45.0-dev.9) (2026-09-24)

### 🐛 Bug Fixes

* **YouTube - Player overlay buttons:** Fix startup crash with a partial patch selection ([#3228](https://github.com/MorpheApp/morphe-patches/issues/3228)) ([aee4774](https://github.com/MorpheApp/morphe-patches/commit/aee47746643c948191b25435a8f1b4e96ffb6df7))
* **YouTube Music - Third-party lyrics:** Keep the screen on after the track changes ([#3246](https://github.com/MorpheApp/morphe-patches/issues/3246)) ([e730ebf](https://github.com/MorpheApp/morphe-patches/commit/e730ebfa8be5b689e484eefa33b380554884a862))

## [1.45.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.7...v1.45.0-dev.8) (2026-09-24)

### 🐛 Bug Fixes

* **YouTube Music - Disable dislike redirection:** Fix patch on 9.35+ ([#3226](https://github.com/MorpheApp/morphe-patches/issues/3226)) ([703ddde](https://github.com/MorpheApp/morphe-patches/commit/703ddde1733d3514993ae689dedd1795bf696d82))
* **YouTube Music - Downloads:** Fix patching failure "Could not find conversion context field" ([#3231](https://github.com/MorpheApp/morphe-patches/issues/3231)) ([b4f2d7d](https://github.com/MorpheApp/morphe-patches/commit/b4f2d7d83c234b1f71ff4a6c8298a59ffe6ad240))

## [1.45.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.6...v1.45.0-dev.7) (2026-09-23)

### 🐛 Bug Fixes

* Resolve startup crash for older Android devices ([b3391b4](https://github.com/MorpheApp/morphe-patches/commit/b3391b423dba14ceedccf5b6ae5e1abebcc80c5d))
* **YouTube:** "Hide preview comment" breaks comment section text box ([#3187](https://github.com/MorpheApp/morphe-patches/issues/3187)) ([d592804](https://github.com/MorpheApp/morphe-patches/commit/d5928043b7982326a102aafa2993e3cb8872eaf7))

## [1.45.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.5...v1.45.0-dev.6) (2026-09-23)

### 🐛 Bug Fixes

* **YouTube:** "Restore old video action bar" hides newly posted comments ([#3216](https://github.com/MorpheApp/morphe-patches/issues/3216)) ([24d5823](https://github.com/MorpheApp/morphe-patches/commit/24d582398b812f96e23bc374c3c77c4dd5506eb4))

### ✨ New Features

* **Custom branding:** Animate the Morphe logo at startup ([#3178](https://github.com/MorpheApp/morphe-patches/issues/3178)) ([70e8a9d](https://github.com/MorpheApp/morphe-patches/commit/70e8a9de9fc16efb830e2594dc6ba37ef49653c8))

## [1.45.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.4...v1.45.0-dev.5) (2026-09-23)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Music videos do not play at 1x speed ([#3210](https://github.com/MorpheApp/morphe-patches/issues/3210)) ([1c7086d](https://github.com/MorpheApp/morphe-patches/commit/1c7086da6270a723da370f89440d70475f96c888))

## [1.45.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.3...v1.45.0-dev.4) (2026-09-23)

### 🐛 Bug Fixes

* **YouTube  - Voice over translation:** Add missing accessibility labels and Voice over translation button state ([#3203](https://github.com/MorpheApp/morphe-patches/issues/3203)) ([d99679b](https://github.com/MorpheApp/morphe-patches/commit/d99679b50dc6f19a2feffaa7f5a8940a9d83da94))
* **YouTube - Custom branding:** Do not ask which app to use for app shortcut actions ([#3204](https://github.com/MorpheApp/morphe-patches/issues/3204)) ([0a2f0e0](https://github.com/MorpheApp/morphe-patches/commit/0a2f0e0f487512d6fd5f0c97ca83ad061859988c))
* **YouTube - Return YouTube Dislike:** Do not show dislikes on the share and comment buttons of community posts ([31b657c](https://github.com/MorpheApp/morphe-patches/commit/31b657c5482def040a368b1d4661db704249db50))
* **YouTube Music - Return YouTube Dislike:** Dislike count is black when the device uses the light theme ([7e7e15d](https://github.com/MorpheApp/morphe-patches/commit/7e7e15d8e0796a96d615e26ea66ac771fa068321))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Add new provider ([#3174](https://github.com/MorpheApp/morphe-patches/issues/3174)) ([1bc710e](https://github.com/MorpheApp/morphe-patches/commit/1bc710e371eb89e663acaadb415c497b7829fe1e))

## [1.45.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.2...v1.45.0-dev.3) (2026-09-22)

### 🐛 Bug Fixes

* Reduce heap use from ConversionContext dumps and JS player cache ([#3120](https://github.com/MorpheApp/morphe-patches/issues/3120)) ([317fd56](https://github.com/MorpheApp/morphe-patches/commit/317fd56c1ecba41a7b928011a39e6a943ca9b07f))
* **YouTube - Hide layout components:** Restore preview comment simplebox matcher ([#3130](https://github.com/MorpheApp/morphe-patches/issues/3130)) ([6e55325](https://github.com/MorpheApp/morphe-patches/commit/6e55325ddbbff9323206bda909b4a50b6d2ab178))

## [1.45.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.45.0-dev.1...v1.45.0-dev.2) (2026-09-22)

### 🐛 Bug Fixes

* **GmsCore support:** Omit empty intent data ([#3170](https://github.com/MorpheApp/morphe-patches/issues/3170)) ([f03894a](https://github.com/MorpheApp/morphe-patches/commit/f03894a8663fdb19a3ff48765d0cb928bcbc36a3))
* **YouTube - Playback speed:** Prevent speed leak into Shorts ([#3169](https://github.com/MorpheApp/morphe-patches/issues/3169)) ([ff35586](https://github.com/MorpheApp/morphe-patches/commit/ff35586e14b339e24a06d32cb77b57234c942fe2))
* **YouTube - Player controls:** Decouple legacy buttons from settings UI ([#3171](https://github.com/MorpheApp/morphe-patches/issues/3171)) ([dfeeb64](https://github.com/MorpheApp/morphe-patches/commit/dfeeb64c54bd2aa49fdbc3653f5ba2f81558d558))
* **YouTube Music - Download in app:** Expose offline audio session ([#3167](https://github.com/MorpheApp/morphe-patches/issues/3167)) ([b4fb0e9](https://github.com/MorpheApp/morphe-patches/commit/b4fb0e9d00a2e876b30ce64da66ee459ad974abc))
* **YouTube Music - Hide flyout menu components:** Hide nested download items ([#3165](https://github.com/MorpheApp/morphe-patches/issues/3165)) ([fd2b325](https://github.com/MorpheApp/morphe-patches/commit/fd2b325a655819233d6bdb0ded83ba08b0cb5295))
* **YouTube Music - Return YouTube Dislike:** Fix dislike counter color ([#3161](https://github.com/MorpheApp/morphe-patches/issues/3161)) ([1404b8b](https://github.com/MorpheApp/morphe-patches/commit/1404b8bc7a09216b468e112c40b3298bf9cb2136))
* **YouTube:** Do not include hide layout settings indirectly ([d3b678a](https://github.com/MorpheApp/morphe-patches/commit/d3b678a8aff9d10a4f748d81d390c95de00d37f9))

## [1.45.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0...v1.45.0-dev.1) (2026-09-22)

### 🐛 Bug Fixes

* **YouTube - Comments filter:** Restored chat button page indicator ([5644496](https://github.com/MorpheApp/morphe-patches/commit/5644496b457b29cad2799c3c2cbc19cb422f0cab))
* **YouTube - Legacy player controls:** Preserve end screen on 21.36+ ([#3121](https://github.com/MorpheApp/morphe-patches/issues/3121)) ([b895285](https://github.com/MorpheApp/morphe-patches/commit/b895285b2aa0e4cab6bb23226e129c62d517c670))
* **YouTube - Return YouTube Dislike:** Show dislikes on tablet layout ([#3153](https://github.com/MorpheApp/morphe-patches/issues/3153)) ([7835519](https://github.com/MorpheApp/morphe-patches/commit/7835519c42a656c2d30122dcd97fb27dd12b0b87))
* **YouTube - SponsorBlock:** Preserve exact video end for segment markers ([#3157](https://github.com/MorpheApp/morphe-patches/issues/3157)) ([a860f5b](https://github.com/MorpheApp/morphe-patches/commit/a860f5bdbce792254617fb31d424c02521c62c6f))
* **YouTube Music - Third-party lyrics:** Do not cover comments panel ([#3155](https://github.com/MorpheApp/morphe-patches/issues/3155)) ([50e4e65](https://github.com/MorpheApp/morphe-patches/commit/50e4e65ef15e28586ec55fae51da0bb03ae392d9))
* **YouTube Music - Third-party lyrics:** Reload lyrics when video changes ([#3148](https://github.com/MorpheApp/morphe-patches/issues/3148)) ([2920175](https://github.com/MorpheApp/morphe-patches/commit/29201754faeec713fa2fc43725527062160f8c0c))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Add translation language ([#3128](https://github.com/MorpheApp/morphe-patches/issues/3128)) ([7349cb6](https://github.com/MorpheApp/morphe-patches/commit/7349cb691635e2a506163aa9fd5813f0b73c4e3f))
* **YouTube Music - Third-party lyrics:** Keep screen on while viewing lyrics ([#3127](https://github.com/MorpheApp/morphe-patches/issues/3127)) ([cb4df9a](https://github.com/MorpheApp/morphe-patches/commit/cb4df9acf11249de66477ce9764ff29fbe41f9ca))

## [1.44.0](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0...v1.44.0) (2026-09-21)

### 🐛 Bug Fixes

* **Reddit - App icon:** Support changing icon on cloned installs ([22c4443](https://github.com/MorpheApp/morphe-patches/commit/22c4443912d60641e710a7a12c4dfc0c88ab8100))
* **YouTube - Channel search:** Search is scoped to a channel after leaving its page ([#2997](https://github.com/MorpheApp/morphe-patches/issues/2997)) ([3cc051b](https://github.com/MorpheApp/morphe-patches/commit/3cc051bfffaaee21a579a059a9be198b6d887f74))
* **YouTube - Comments:** Hide new comments carousel ([#3110](https://github.com/MorpheApp/morphe-patches/issues/3110)) ([b733f2e](https://github.com/MorpheApp/morphe-patches/commit/b733f2ef05ff798d4b9caba0e6f6c90e67bbc6f3))
* **YouTube - GmsCore support:** "Play Protect certification" screen is shown on startup ([#2977](https://github.com/MorpheApp/morphe-patches/issues/2977)) ([e250326](https://github.com/MorpheApp/morphe-patches/commit/e25032649908890ae848ee012befbb266deb08e8))
* **YouTube - Hide ads:** Hide new product cards ([#3103](https://github.com/MorpheApp/morphe-patches/issues/3103)) ([ea4a310](https://github.com/MorpheApp/morphe-patches/commit/ea4a310f1a06bf60804d774fcd40219a2a93aaca))
* **YouTube - Hide layout components:** Hide Auto-dubbed label in feed ([#3101](https://github.com/MorpheApp/morphe-patches/issues/3101)) ([5e2af7f](https://github.com/MorpheApp/morphe-patches/commit/5e2af7fbed2e35123c4a4a82c47b0dbb4bd46bbb))
* **YouTube - Hide layout components:** Hide Community button in search ([#3112](https://github.com/MorpheApp/morphe-patches/issues/3112)) ([9b3d122](https://github.com/MorpheApp/morphe-patches/commit/9b3d1222cd9199532835dfe9224c738a96fd0a84))
* **YouTube - Hide layout components:** Hide movie shelf in search results ([#2933](https://github.com/MorpheApp/morphe-patches/issues/2933)) ([032e0f5](https://github.com/MorpheApp/morphe-patches/commit/032e0f51f6ccf2ebbaff0c4d57f2f12b32bd8be8))
* **YouTube - Hide layout components:** Hide new expandable cards ([#3102](https://github.com/MorpheApp/morphe-patches/issues/3102)) ([1f79c62](https://github.com/MorpheApp/morphe-patches/commit/1f79c62e2dc3f0210cf73f29b65e1c94b3c105ec))
* **YouTube - Hide layout components:** Hide Shorts surveys ([#3113](https://github.com/MorpheApp/morphe-patches/issues/3113)) ([18e54f6](https://github.com/MorpheApp/morphe-patches/commit/18e54f6adafeaaad62b970ef9d02186c52ecec33))
* **YouTube - Hide layout components:** Preserve live chat replay ([#3115](https://github.com/MorpheApp/morphe-patches/issues/3115)) ([dff81a7](https://github.com/MorpheApp/morphe-patches/commit/dff81a79b0fc1a7f193cfb59c2903467dd4ecdc2))
* **YouTube - Minimal miniplayer:** Controls fade-in animation doesn't work ([396a0bc](https://github.com/MorpheApp/morphe-patches/commit/396a0bcd333423bb17cbe501599e70d80591f8d0))
* **YouTube - Minimal miniplayer:** Dim the Minimal 2 video less and hide the channel together with the title ([5f8f5e1](https://github.com/MorpheApp/morphe-patches/commit/5f8f5e1894e64de6a7ff605e88e24b3e8fd12b68))
* **YouTube - Minimal miniplayer:** Fully expand the player width during the minimization animation. ([aaa1211](https://github.com/MorpheApp/morphe-patches/commit/aaa1211855d245b44940575dc8f9e3428593bde5))
* **YouTube - Minimal miniplayer:** Improved type 2 bar UI ([299af68](https://github.com/MorpheApp/morphe-patches/commit/299af68d5e90326a76febbaa0a28bbe7b7600986))
* **YouTube - Minimal miniplayer:** Interpolate minimizing transitions. ([13e653a](https://github.com/MorpheApp/morphe-patches/commit/13e653a68943b548728d85042e6785058b3cedb2))
* **YouTube - Minimal miniplayer:** Keep the gap above an opaque navigation bar after a system theme change ([05eff03](https://github.com/MorpheApp/morphe-patches/commit/05eff034bd03d6279b0928da7e56a6b0661b89f0))
* **YouTube - Minimal miniplayer:** Remove one frame flicker when minimizing and missing play/pause icon with an app language set ([10e9c9f](https://github.com/MorpheApp/morphe-patches/commit/10e9c9f9084ea8c7e0f04e77f995a4c28ab98411))
* **YouTube - Minimal miniplayer:** Restored commit [#6e1ca28](https://github.com/MorpheApp/morphe-patches/issues/6e1ca28) ([33595a2](https://github.com/MorpheApp/morphe-patches/commit/33595a279bd0ee2870d390152f86a9615a99153c))
* **YouTube - Minimal miniplayer:** Restored commit [#6e1ca28](https://github.com/MorpheApp/morphe-patches/issues/6e1ca28) ([1101cad](https://github.com/MorpheApp/morphe-patches/commit/1101cad85f4213eec2cfb6c420e018854fa208b0))
* **YouTube - Minimal miniplayer:** Reverted last changes to commit [#aaa1211](https://github.com/MorpheApp/morphe-patches/issues/aaa1211) ([64caec5](https://github.com/MorpheApp/morphe-patches/commit/64caec55020841014dea23c5a773b4372e6883e6))
* **YouTube - Minimal miniplayer:** Slide the bar clear of the screen when closing it ([680ef54](https://github.com/MorpheApp/morphe-patches/commit/680ef54c555b829ddf0bf8cb17637734478563ac))
* **YouTube - Minimal miniplayer:** Span the type 2 bar with the video at any aspect ratio ([4ed999f](https://github.com/MorpheApp/morphe-patches/commit/4ed999f243a18ee859279fddf40c80a9a2b1123b))
* **YouTube - Miniplayer:** Default size setting is not grayed out with modern minimal ([aa9bc8e](https://github.com/MorpheApp/morphe-patches/commit/aa9bc8e6b51f81b9dc497f006372efb0a13f798b))
* **YouTube - Navigation bar:** Use black system bars in Shorts ([#3088](https://github.com/MorpheApp/morphe-patches/issues/3088)) ([e88ec7d](https://github.com/MorpheApp/morphe-patches/commit/e88ec7db71993dd412f656a2c5d988edc07e00a1))
* **YouTube - Override YouTube Music buttons:** App can crash on devices with an OEM media route provider ([#3025](https://github.com/MorpheApp/morphe-patches/issues/3025)) ([ef5652d](https://github.com/MorpheApp/morphe-patches/commit/ef5652d610fa4613b2dee327ca562ab89c25d78d))
* **YouTube - Remove background playback restrictions:** Auto pause when video is loading ([#3060](https://github.com/MorpheApp/morphe-patches/issues/3060)) ([cbffcf3](https://github.com/MorpheApp/morphe-patches/commit/cbffcf3c09bde19ac1e16921cd5f359d1b9430be))
* **YouTube - Return YouTube Dislike:** Dislike vertical text alignment may not be correct ([320aca2](https://github.com/MorpheApp/morphe-patches/commit/320aca2d9785305e81fea17967a3eb5ed39bff9a))
* **YouTube - Return YouTube Dislike:** Dislikes are not shown on the old action bar of some devices ([258cbe6](https://github.com/MorpheApp/morphe-patches/commit/258cbe6fe66f432156aa7ef6bcb73f5932a9d672))
* **YouTube - Return YouTube Dislike:** Estimated likes are not shown on the segmented like button ([bf58420](https://github.com/MorpheApp/morphe-patches/commit/bf5842044a46a53263f178624c5fa1a59f18eecc))
* **YouTube - Return YouTube Dislike:** Show dislikes of the old action bar at every screen density and match the like count spacing ([0ce1259](https://github.com/MorpheApp/morphe-patches/commit/0ce1259bd1d455932c4f9bf0d2dba37d6e5de21b))
* **YouTube - Return YouTube Dislike:** Show dislikes on the segmented like button of tablets and do not widen matching nodes in the feed ([d8717cd](https://github.com/MorpheApp/morphe-patches/commit/d8717cd9a5c67668c928e410d70b28b974ee08e5))
* **YouTube - Return YouTube Dislike:** Show estimated likes on the compact action bar when the like count is hidden ([a6efacf](https://github.com/MorpheApp/morphe-patches/commit/a6efacfd0cdb0c8aa11312c33900a4ab70689ae1))
* **YouTube - Settings:** Fix crash opening settings after the app process is restarted ([#2958](https://github.com/MorpheApp/morphe-patches/issues/2958)) ([89b7bb0](https://github.com/MorpheApp/morphe-patches/commit/89b7bb0cf8bc0553afa56c982bdf234f8ac68298))
* **YouTube - SponsorBlock:** Auto-hide skip button is sometimes shown when not inside a skippable segment ([2655af1](https://github.com/MorpheApp/morphe-patches/commit/2655af1d4240f5cd35844676fad82b489e7597c5))
* **YouTube - Theme:** Experimental app targets can show white Shorts seekbar ([aaeca6a](https://github.com/MorpheApp/morphe-patches/commit/aaeca6a75bf7d1e14e6c31fbbeffa50bda55ac0f))
* **YouTube - Voice over translation:** Add button accessibility label ([#3099](https://github.com/MorpheApp/morphe-patches/issues/3099)) ([1c6f2dd](https://github.com/MorpheApp/morphe-patches/commit/1c6f2ddd178212cca2cbc33ff5cc495822da0607))
* **YouTube Music - Download in app:** Downloads fail when 'Spoof video streams' is turned off ([#3034](https://github.com/MorpheApp/morphe-patches/issues/3034)) ([64249b8](https://github.com/MorpheApp/morphe-patches/commit/64249b8471dd508351b9e7cfb13586812525993e))
* **YouTube Music - Hide ads:** Premium promotion banners are not hidden ([5529b68](https://github.com/MorpheApp/morphe-patches/commit/5529b6887aac2728fafef8fe39c1b011742e03d7))
* **YouTube Music - Return YouTube Dislike:** Show dislikes beside the dislike icon like YouTube does ([#3107](https://github.com/MorpheApp/morphe-patches/issues/3107)) ([ca839ce](https://github.com/MorpheApp/morphe-patches/commit/ca839ce4c46c20e0ae3ca0977511993b87031d5f))
* **YouTube Music - Third-party lyrics:** Lyrics are not shown in a panel that has no heading ([#3033](https://github.com/MorpheApp/morphe-patches/issues/3033)) ([4d5988b](https://github.com/MorpheApp/morphe-patches/commit/4d5988b0eff3bce79b2ab3301d203f27e1318b43))
* **YouTube Music - Third-party lyrics:** Musixmatch cannot be turned on and Deezer returns no lyrics ([f6c0213](https://github.com/MorpheApp/morphe-patches/commit/f6c021343a3aa9ddf62c1cc0ec168765cfc57882))
* **YouTube Music - Third-party lyrics:** Right to left lyrics are garbled while being highlighted ([72798cb](https://github.com/MorpheApp/morphe-patches/commit/72798cb704b886cdd5606e6a29298e8338f5f312))
* **YouTube:** Deprecated componentHost extension ([c42f07d](https://github.com/MorpheApp/morphe-patches/commit/c42f07df385805aa22744fd2bc169f77b24a77c0))
* **YouTube:** Hide player time bar backgrounds ([#3030](https://github.com/MorpheApp/morphe-patches/issues/3030)) ([a11b9b1](https://github.com/MorpheApp/morphe-patches/commit/a11b9b1248b0f4232b7892ad4dbe4de19caa4d2b))
* **YouTube:** Hide Shorts captions flyout item ([#3082](https://github.com/MorpheApp/morphe-patches/issues/3082)) ([a0d8171](https://github.com/MorpheApp/morphe-patches/commit/a0d8171790c2f6f50dfb8588d973697f731785c8))
* **YouTube:** Player seekbar is not shown for some users ([bb2b91e](https://github.com/MorpheApp/morphe-patches/commit/bb2b91e118f1d3e6766340226e4697c758e8efe3))
* **YouTube:** Preserve fullscreen button when scale button is hidden ([#3027](https://github.com/MorpheApp/morphe-patches/issues/3027)) ([7d4ab61](https://github.com/MorpheApp/morphe-patches/commit/7d4ab619163fba7c20dd4666ca0fe2240eb16380))
* **YouTube:** Support Unicode AISList channel handles ([#3028](https://github.com/MorpheApp/morphe-patches/issues/3028)) ([fcf415f](https://github.com/MorpheApp/morphe-patches/commit/fcf415f43d78cb6833e2ae14db245989240f7f5e))

### ✨ New Features

* **Custom branding:** Warn that the app icon setting only changes the launcher icon ([8607c76](https://github.com/MorpheApp/morphe-patches/commit/8607c76d33e931fc0931de8e2a52d5ac9b4d3dc6))
* **Reddit:** Add `Start as guest` patch ([#3109](https://github.com/MorpheApp/morphe-patches/issues/3109)) ([c720c2a](https://github.com/MorpheApp/morphe-patches/commit/c720c2af26ea30423fcd0a96341fe916fdef1477))
* **YouTube - Channel search:** Show the searched channel in the results header ([c0e49d4](https://github.com/MorpheApp/morphe-patches/commit/c0e49d4ba97a5ca79033e379f3f581a395cda7a4))
* **YouTube - Miniplayer:** Add option to hide Minimal 2 miniplayer title ([#3087](https://github.com/MorpheApp/morphe-patches/issues/3087)) ([6e1ca28](https://github.com/MorpheApp/morphe-patches/commit/6e1ca285e43094004fa6b828d4482ddab6949ff6))
* **YouTube - Return YouTube Dislike:** Show like and dislike counts on the icon only video action bar ([#3075](https://github.com/MorpheApp/morphe-patches/issues/3075)) ([6934e0c](https://github.com/MorpheApp/morphe-patches/commit/6934e0c06dc8e6797f3217e8d609f7a6823b12c9))
* **YouTube - Save to Watch later:** Add support for Shorts ([#2934](https://github.com/MorpheApp/morphe-patches/issues/2934)) ([b4540c9](https://github.com/MorpheApp/morphe-patches/commit/b4540c91b1ae361f5184b96438d8f3a627a8367a))
* **YouTube Music - Third-party lyrics:** Add new lyric providers ([#3041](https://github.com/MorpheApp/morphe-patches/issues/3041)) ([d5b00ae](https://github.com/MorpheApp/morphe-patches/commit/d5b00aed59fe2f333e2e155637a50ffae208f6de))
* **YouTube Music - Third-party lyrics:** Add syllable lyrics, new providers, romanized lyrics, mediasession lyrics, miniplayer lyrics ([#2625](https://github.com/MorpheApp/morphe-patches/issues/2625)) ([ea883b3](https://github.com/MorpheApp/morphe-patches/commit/ea883b34f6a750eb3f6b954742d41088b6b99879))
* **YouTube Music - Third-party lyrics:** Animate the panel buttons between their states ([abec544](https://github.com/MorpheApp/morphe-patches/commit/abec5445a13bb366a63109a003d8a9444f96cdf7))
* **YouTube Music:** Add offline audio downloads ([#2528](https://github.com/MorpheApp/morphe-patches/issues/2528)) ([d9999ca](https://github.com/MorpheApp/morphe-patches/commit/d9999ca6695be270461b46bf41ee6e5e6ca3d0e6))
* **YouTube:** Add `Channel search` patch ([#2964](https://github.com/MorpheApp/morphe-patches/issues/2964)) ([acd856c](https://github.com/MorpheApp/morphe-patches/commit/acd856cc27dde7f33042ddced67c8ee6a8c31e30))
* **YouTube:** Add `Force fullscreen landscape mode` patch ([#2431](https://github.com/MorpheApp/morphe-patches/issues/2431)) ([a037335](https://github.com/MorpheApp/morphe-patches/commit/a03733538e5a56957b525a17668253eb5da404da))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.38.0` ([404fc59](https://github.com/MorpheApp/morphe-patches/commit/404fc599fa082fd958780450a1ec57476295c712))
* **YouTube Music:** Add experimental support for `9.37.54` ([04f67ae](https://github.com/MorpheApp/morphe-patches/commit/04f67ae150d23b1c888061e9d723459736f8f52c))
* **YouTube:** Add experimental support for `21.38.123` ([#3053](https://github.com/MorpheApp/morphe-patches/issues/3053)) ([fd4a726](https://github.com/MorpheApp/morphe-patches/commit/fd4a72611ea561f605085fc1512a91b8084410fe))
* **YouTube:** Add experimental support for `21.47.42` ([#2962](https://github.com/MorpheApp/morphe-patches/issues/2962)) ([9418faa](https://github.com/MorpheApp/morphe-patches/commit/9418faaf46610875781a4952a379523c09a462db))
* **YouTube:** Add support for `21.16.256` ([900575c](https://github.com/MorpheApp/morphe-patches/commit/900575ccc97cb8faf831786afd693c30d28e4f9f))

## [1.44.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.18...v1.44.0-dev.19) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide Shorts surveys ([#3113](https://github.com/MorpheApp/morphe-patches/issues/3113)) ([18e54f6](https://github.com/MorpheApp/morphe-patches/commit/18e54f6adafeaaad62b970ef9d02186c52ecec33))

### ✨ New Features

* **Reddit:** Add `Start as guest` patch ([#3109](https://github.com/MorpheApp/morphe-patches/issues/3109)) ([c720c2a](https://github.com/MorpheApp/morphe-patches/commit/c720c2af26ea30423fcd0a96341fe916fdef1477))

## [1.44.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.17...v1.44.0-dev.18) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Comments:** Hide new comments carousel ([#3110](https://github.com/MorpheApp/morphe-patches/issues/3110)) ([b733f2e](https://github.com/MorpheApp/morphe-patches/commit/b733f2ef05ff798d4b9caba0e6f6c90e67bbc6f3))
* **YouTube - Hide layout components:** Hide Community button in search ([#3112](https://github.com/MorpheApp/morphe-patches/issues/3112)) ([9b3d122](https://github.com/MorpheApp/morphe-patches/commit/9b3d1222cd9199532835dfe9224c738a96fd0a84))
* **YouTube - Hide layout components:** Preserve live chat replay ([#3115](https://github.com/MorpheApp/morphe-patches/issues/3115)) ([dff81a7](https://github.com/MorpheApp/morphe-patches/commit/dff81a79b0fc1a7f193cfb59c2903467dd4ecdc2))
* **YouTube - Minimal miniplayer:** Dim the Minimal 2 video less and hide the channel together with the title ([5f8f5e1](https://github.com/MorpheApp/morphe-patches/commit/5f8f5e1894e64de6a7ff605e88e24b3e8fd12b68))
* **YouTube - Minimal miniplayer:** Keep the gap above an opaque navigation bar after a system theme change ([05eff03](https://github.com/MorpheApp/morphe-patches/commit/05eff034bd03d6279b0928da7e56a6b0661b89f0))
* **YouTube Music - Return YouTube Dislike:** Show dislikes beside the dislike icon like YouTube does ([#3107](https://github.com/MorpheApp/morphe-patches/issues/3107)) ([ca839ce](https://github.com/MorpheApp/morphe-patches/commit/ca839ce4c46c20e0ae3ca0977511993b87031d5f))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Add new lyric providers ([#3041](https://github.com/MorpheApp/morphe-patches/issues/3041)) ([d5b00ae](https://github.com/MorpheApp/morphe-patches/commit/d5b00aed59fe2f333e2e155637a50ffae208f6de))

## [1.44.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.16...v1.44.0-dev.17) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Remove one frame flicker when minimizing and missing play/pause icon with an app language set ([10e9c9f](https://github.com/MorpheApp/morphe-patches/commit/10e9c9f9084ea8c7e0f04e77f995a4c28ab98411))

## [1.44.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.15...v1.44.0-dev.16) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Hide ads:** Hide new product cards ([#3103](https://github.com/MorpheApp/morphe-patches/issues/3103)) ([ea4a310](https://github.com/MorpheApp/morphe-patches/commit/ea4a310f1a06bf60804d774fcd40219a2a93aaca))
* **YouTube - Hide layout components:** Hide new expandable cards ([#3102](https://github.com/MorpheApp/morphe-patches/issues/3102)) ([1f79c62](https://github.com/MorpheApp/morphe-patches/commit/1f79c62e2dc3f0210cf73f29b65e1c94b3c105ec))
* **YouTube - Return YouTube Dislike:** Dislikes are not shown on the old action bar of some devices ([258cbe6](https://github.com/MorpheApp/morphe-patches/commit/258cbe6fe66f432156aa7ef6bcb73f5932a9d672))
* **YouTube - Return YouTube Dislike:** Estimated likes are not shown on the segmented like button ([bf58420](https://github.com/MorpheApp/morphe-patches/commit/bf5842044a46a53263f178624c5fa1a59f18eecc))
* **YouTube - Return YouTube Dislike:** Show dislikes on the segmented like button of tablets and do not widen matching nodes in the feed ([d8717cd](https://github.com/MorpheApp/morphe-patches/commit/d8717cd9a5c67668c928e410d70b28b974ee08e5))
* **YouTube - Return YouTube Dislike:** Show estimated likes on the compact action bar when the like count is hidden ([a6efacf](https://github.com/MorpheApp/morphe-patches/commit/a6efacfd0cdb0c8aa11312c33900a4ab70689ae1))

## [1.44.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.14...v1.44.0-dev.15) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide Auto-dubbed label in feed ([#3101](https://github.com/MorpheApp/morphe-patches/issues/3101)) ([5e2af7f](https://github.com/MorpheApp/morphe-patches/commit/5e2af7fbed2e35123c4a4a82c47b0dbb4bd46bbb))
* **YouTube - Return YouTube Dislike:** Show dislikes of the old action bar at every screen density and match the like count spacing ([0ce1259](https://github.com/MorpheApp/morphe-patches/commit/0ce1259bd1d455932c4f9bf0d2dba37d6e5de21b))
* **YouTube - Voice over translation:** Add button accessibility label ([#3099](https://github.com/MorpheApp/morphe-patches/issues/3099)) ([1c6f2dd](https://github.com/MorpheApp/morphe-patches/commit/1c6f2ddd178212cca2cbc33ff5cc495822da0607))

## [1.44.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.13...v1.44.0-dev.14) (2026-09-21)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Restored commit [#6e1ca28](https://github.com/MorpheApp/morphe-patches/issues/6e1ca28) ([33595a2](https://github.com/MorpheApp/morphe-patches/commit/33595a279bd0ee2870d390152f86a9615a99153c))
* **YouTube - Minimal miniplayer:** Restored commit [#6e1ca28](https://github.com/MorpheApp/morphe-patches/issues/6e1ca28) ([1101cad](https://github.com/MorpheApp/morphe-patches/commit/1101cad85f4213eec2cfb6c420e018854fa208b0))
* **YouTube - Minimal miniplayer:** Reverted last changes to commit [#aaa1211](https://github.com/MorpheApp/morphe-patches/issues/aaa1211) ([64caec5](https://github.com/MorpheApp/morphe-patches/commit/64caec55020841014dea23c5a773b4372e6883e6))
* **YouTube - Return YouTube Dislike:** Dislike vertical text alignment may not be correct ([320aca2](https://github.com/MorpheApp/morphe-patches/commit/320aca2d9785305e81fea17967a3eb5ed39bff9a))

## [1.44.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.12...v1.44.0-dev.13) (2026-09-20)

### ✨ New Features

* **YouTube - Return YouTube Dislike:** Show like and dislike counts on the icon only video action bar ([#3075](https://github.com/MorpheApp/morphe-patches/issues/3075)) ([6934e0c](https://github.com/MorpheApp/morphe-patches/commit/6934e0c06dc8e6797f3217e8d609f7a6823b12c9))

## [1.44.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.11...v1.44.0-dev.12) (2026-09-20)

### 🐛 Bug Fixes

* **YouTube - Navigation bar:** Use black system bars in Shorts ([#3088](https://github.com/MorpheApp/morphe-patches/issues/3088)) ([e88ec7d](https://github.com/MorpheApp/morphe-patches/commit/e88ec7db71993dd412f656a2c5d988edc07e00a1))
* **YouTube:** Hide Shorts captions flyout item ([#3082](https://github.com/MorpheApp/morphe-patches/issues/3082)) ([a0d8171](https://github.com/MorpheApp/morphe-patches/commit/a0d8171790c2f6f50dfb8588d973697f731785c8))

### ✨ New Features

* **YouTube - Miniplayer:** Add option to hide Minimal 2 miniplayer title ([#3087](https://github.com/MorpheApp/morphe-patches/issues/3087)) ([6e1ca28](https://github.com/MorpheApp/morphe-patches/commit/6e1ca285e43094004fa6b828d4482ddab6949ff6))

## [1.44.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.10...v1.44.0-dev.11) (2026-09-19)

### ✨ New Features

* **YouTube - Channel search:** Show the searched channel in the results header ([c0e49d4](https://github.com/MorpheApp/morphe-patches/commit/c0e49d4ba97a5ca79033e379f3f581a395cda7a4))

## [1.44.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.9...v1.44.0-dev.10) (2026-09-19)

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.37.54` ([04f67ae](https://github.com/MorpheApp/morphe-patches/commit/04f67ae150d23b1c888061e9d723459736f8f52c))

## [1.44.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.8...v1.44.0-dev.9) (2026-09-19)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Controls fade-in animation doesn't work ([396a0bc](https://github.com/MorpheApp/morphe-patches/commit/396a0bcd333423bb17cbe501599e70d80591f8d0))
* **YouTube - Minimal miniplayer:** Interpolate minimizing transitions. ([13e653a](https://github.com/MorpheApp/morphe-patches/commit/13e653a68943b548728d85042e6785058b3cedb2))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.38.0` ([404fc59](https://github.com/MorpheApp/morphe-patches/commit/404fc599fa082fd958780450a1ec57476295c712))

## [1.44.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.7...v1.44.0-dev.8) (2026-09-19)

### 🐛 Bug Fixes

* **YouTube - Theme:** Experimental app targets can show white Shorts seekbar ([aaeca6a](https://github.com/MorpheApp/morphe-patches/commit/aaeca6a75bf7d1e14e6c31fbbeffa50bda55ac0f))

## [1.44.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.6...v1.44.0-dev.7) (2026-09-19)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Fully expand the player width during the minimization animation. ([aaa1211](https://github.com/MorpheApp/morphe-patches/commit/aaa1211855d245b44940575dc8f9e3428593bde5))
* **YouTube - Remove background playback restrictions:** Auto pause when video is loading ([#3060](https://github.com/MorpheApp/morphe-patches/issues/3060)) ([cbffcf3](https://github.com/MorpheApp/morphe-patches/commit/cbffcf3c09bde19ac1e16921cd5f359d1b9430be))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.38.123` ([#3053](https://github.com/MorpheApp/morphe-patches/issues/3053)) ([fd4a726](https://github.com/MorpheApp/morphe-patches/commit/fd4a72611ea561f605085fc1512a91b8084410fe))

## [1.44.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.5...v1.44.0-dev.6) (2026-09-18)

### 🚀 Updated App Support

* **YouTube:** Add support for `21.16.256` ([900575c](https://github.com/MorpheApp/morphe-patches/commit/900575ccc97cb8faf831786afd693c30d28e4f9f))

## [1.44.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.4...v1.44.0-dev.5) (2026-09-18)

### 🐛 Bug Fixes

* **YouTube Music - Download in app:** Downloads fail when 'Spoof video streams' is turned off ([#3034](https://github.com/MorpheApp/morphe-patches/issues/3034)) ([64249b8](https://github.com/MorpheApp/morphe-patches/commit/64249b8471dd508351b9e7cfb13586812525993e))
* **YouTube Music - Third-party lyrics:** Lyrics are not shown in a panel that has no heading ([#3033](https://github.com/MorpheApp/morphe-patches/issues/3033)) ([4d5988b](https://github.com/MorpheApp/morphe-patches/commit/4d5988b0eff3bce79b2ab3301d203f27e1318b43))
* **YouTube Music - Third-party lyrics:** Musixmatch cannot be turned on and Deezer returns no lyrics ([f6c0213](https://github.com/MorpheApp/morphe-patches/commit/f6c021343a3aa9ddf62c1cc0ec168765cfc57882))
* **YouTube Music - Third-party lyrics:** Right to left lyrics are garbled while being highlighted ([72798cb](https://github.com/MorpheApp/morphe-patches/commit/72798cb704b886cdd5606e6a29298e8338f5f312))
* **YouTube:** Hide player time bar backgrounds ([#3030](https://github.com/MorpheApp/morphe-patches/issues/3030)) ([a11b9b1](https://github.com/MorpheApp/morphe-patches/commit/a11b9b1248b0f4232b7892ad4dbe4de19caa4d2b))
* **YouTube:** Preserve fullscreen button when scale button is hidden ([#3027](https://github.com/MorpheApp/morphe-patches/issues/3027)) ([7d4ab61](https://github.com/MorpheApp/morphe-patches/commit/7d4ab619163fba7c20dd4666ca0fe2240eb16380))
* **YouTube:** Support Unicode AISList channel handles ([#3028](https://github.com/MorpheApp/morphe-patches/issues/3028)) ([fcf415f](https://github.com/MorpheApp/morphe-patches/commit/fcf415f43d78cb6833e2ae14db245989240f7f5e))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Animate the panel buttons between their states ([abec544](https://github.com/MorpheApp/morphe-patches/commit/abec5445a13bb366a63109a003d8a9444f96cdf7))
* **YouTube:** Add `Force fullscreen landscape mode` patch ([#2431](https://github.com/MorpheApp/morphe-patches/issues/2431)) ([a037335](https://github.com/MorpheApp/morphe-patches/commit/a03733538e5a56957b525a17668253eb5da404da))

## [1.44.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.3...v1.44.0-dev.4) (2026-09-17)

### 🐛 Bug Fixes

* **YouTube - Override YouTube Music buttons:** App can crash on devices with an OEM media route provider ([#3025](https://github.com/MorpheApp/morphe-patches/issues/3025)) ([ef5652d](https://github.com/MorpheApp/morphe-patches/commit/ef5652d610fa4613b2dee327ca562ab89c25d78d))

## [1.44.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.2...v1.44.0-dev.3) (2026-09-17)

### 🐛 Bug Fixes

* **YouTube - SponsorBlock:** Auto-hide skip button is sometimes shown when not inside a skippable segment ([2655af1](https://github.com/MorpheApp/morphe-patches/commit/2655af1d4240f5cd35844676fad82b489e7597c5))
* **YouTube Music - Hide ads:** Premium promotion banners are not hidden ([5529b68](https://github.com/MorpheApp/morphe-patches/commit/5529b6887aac2728fafef8fe39c1b011742e03d7))

### ✨ New Features

* **YouTube - Save to Watch later:** Add support for Shorts ([#2934](https://github.com/MorpheApp/morphe-patches/issues/2934)) ([b4540c9](https://github.com/MorpheApp/morphe-patches/commit/b4540c91b1ae361f5184b96438d8f3a627a8367a))
* **YouTube Music:** Add offline audio downloads ([#2528](https://github.com/MorpheApp/morphe-patches/issues/2528)) ([d9999ca](https://github.com/MorpheApp/morphe-patches/commit/d9999ca6695be270461b46bf41ee6e5e6ca3d0e6))

## [1.44.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.44.0-dev.1...v1.44.0-dev.2) (2026-09-16)

### 🐛 Bug Fixes

* **YouTube - Channel search:** Search is scoped to a channel after leaving its page ([#2997](https://github.com/MorpheApp/morphe-patches/issues/2997)) ([3cc051b](https://github.com/MorpheApp/morphe-patches/commit/3cc051bfffaaee21a579a059a9be198b6d887f74))
* **YouTube - Hide layout components:** Hide movie shelf in search results ([#2933](https://github.com/MorpheApp/morphe-patches/issues/2933)) ([032e0f5](https://github.com/MorpheApp/morphe-patches/commit/032e0f51f6ccf2ebbaff0c4d57f2f12b32bd8be8))
* **YouTube:** Player seekbar is not shown for some users ([bb2b91e](https://github.com/MorpheApp/morphe-patches/commit/bb2b91e118f1d3e6766340226e4697c758e8efe3))

### ✨ New Features

* **YouTube Music - Third-party lyrics:** Add syllable lyrics, new providers, romanized lyrics, mediasession lyrics, miniplayer lyrics ([#2625](https://github.com/MorpheApp/morphe-patches/issues/2625)) ([ea883b3](https://github.com/MorpheApp/morphe-patches/commit/ea883b34f6a750eb3f6b954742d41088b6b99879))

## [1.44.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.43.1-dev.2...v1.44.0-dev.1) (2026-09-15)

### 🐛 Bug Fixes

* **YouTube - GmsCore support:** "Play Protect certification" screen is shown on startup ([#2977](https://github.com/MorpheApp/morphe-patches/issues/2977)) ([e250326](https://github.com/MorpheApp/morphe-patches/commit/e25032649908890ae848ee012befbb266deb08e8))

### ✨ New Features

* **Custom branding:** Warn that the app icon setting only changes the launcher icon ([8607c76](https://github.com/MorpheApp/morphe-patches/commit/8607c76d33e931fc0931de8e2a52d5ac9b4d3dc6))
* **YouTube:** Add `Channel search` patch ([#2964](https://github.com/MorpheApp/morphe-patches/issues/2964)) ([acd856c](https://github.com/MorpheApp/morphe-patches/commit/acd856cc27dde7f33042ddced67c8ee6a8c31e30))

## [1.43.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.43.1-dev.1...v1.43.1-dev.2) (2026-09-15)

### 🐛 Bug Fixes

* **YouTube - Minimal miniplayer:** Improved type 2 bar UI ([299af68](https://github.com/MorpheApp/morphe-patches/commit/299af68d5e90326a76febbaa0a28bbe7b7600986))
* **YouTube - Miniplayer:** Default size setting is not grayed out with modern minimal ([aa9bc8e](https://github.com/MorpheApp/morphe-patches/commit/aa9bc8e6b51f81b9dc497f006372efb0a13f798b))
* **YouTube:** Deprecated componentHost extension ([c42f07d](https://github.com/MorpheApp/morphe-patches/commit/c42f07df385805aa22744fd2bc169f77b24a77c0))

## [1.43.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0...v1.43.1-dev.1) (2026-09-15)

### 🐛 Bug Fixes

* **Reddit - App icon:** Support changing icon on cloned installs ([22c4443](https://github.com/MorpheApp/morphe-patches/commit/22c4443912d60641e710a7a12c4dfc0c88ab8100))
* **YouTube - Minimal miniplayer:** Slide the bar clear of the screen when closing it ([680ef54](https://github.com/MorpheApp/morphe-patches/commit/680ef54c555b829ddf0bf8cb17637734478563ac))
* **YouTube - Minimal miniplayer:** Span the type 2 bar with the video at any aspect ratio ([4ed999f](https://github.com/MorpheApp/morphe-patches/commit/4ed999f243a18ee859279fddf40c80a9a2b1123b))
* **YouTube - Settings:** Fix crash opening settings after the app process is restarted ([#2958](https://github.com/MorpheApp/morphe-patches/issues/2958)) ([89b7bb0](https://github.com/MorpheApp/morphe-patches/commit/89b7bb0cf8bc0553afa56c982bdf234f8ac68298))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.37.42` ([#2962](https://github.com/MorpheApp/morphe-patches/issues/2962)) ([9418faa](https://github.com/MorpheApp/morphe-patches/commit/9418faaf46610875781a4952a379523c09a462db))

## [1.43.0](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0...v1.43.0) (2026-09-14)

### 🐛 Bug Fixes

* **Theme:** Show the color the app draws when a color the user picked needs an overlay the app cannot register ([a4c1539](https://github.com/MorpheApp/morphe-patches/commit/a4c1539ac45233862f2b7594f322328a33b5d218))
* **Theme:** Use the nearest palette color when the app is not given an overlay manager ([#2926](https://github.com/MorpheApp/morphe-patches/issues/2926)) ([86e146c](https://github.com/MorpheApp/morphe-patches/commit/86e146c54bad8450265f2ac2d734722fd682794c))
* **YouTube - Change header:** Apply custom header logo to explore menu ([#2910](https://github.com/MorpheApp/morphe-patches/issues/2910)) ([e549894](https://github.com/MorpheApp/morphe-patches/commit/e549894d1c8dd2e9909a5c773c3c9c81a4df64a5))
* **YouTube - Disable fullscreen gestures:** Restore pinch-to-zoom past fill on `21.36`+ ([#2876](https://github.com/MorpheApp/morphe-patches/issues/2876)) ([dd76cc1](https://github.com/MorpheApp/morphe-patches/commit/dd76cc1198fffb42d99f993ae03bd6e6cdcb4cf7))
* **YouTube - FlyoutUtils:** Check typo ([66be4ae](https://github.com/MorpheApp/morphe-patches/commit/66be4aeb48d1bf81e82ef0b3dfb7992d572299f5))
* **YouTube - FlyoutUtils:** Fetch element description straight from ViewGroup instead componentHost ([7565b9d](https://github.com/MorpheApp/morphe-patches/commit/7565b9d4409d20cf58075fb7d53eca081d2ac282))
* **YouTube - FlyoutUtils:** Injected buttons are shown in collaborators panel ([#2867](https://github.com/MorpheApp/morphe-patches/issues/2867)) ([b595f8d](https://github.com/MorpheApp/morphe-patches/commit/b595f8d60023b127a67c4238bf285e12ebeee427))
* **YouTube - Fullscreen video scale:** Restore UI after leaving fullscreen on tablet/foldable landscape ([#2874](https://github.com/MorpheApp/morphe-patches/issues/2874)) ([75f477f](https://github.com/MorpheApp/morphe-patches/commit/75f477f5c8834bd30cb27f66cc13b7f9c1f4c981))
* **YouTube - Hide layout components:** Fix UI padding in comment replies and incognito search ([#2891](https://github.com/MorpheApp/morphe-patches/issues/2891)) ([59485db](https://github.com/MorpheApp/morphe-patches/commit/59485db96f29c9fa458ceca5f29e1754197220f4))
* **YouTube - Hide layout components:** Patch failing on `20.21.37` ([41d89ef](https://github.com/MorpheApp/morphe-patches/commit/41d89ef38ae4feb744054656a6b6a8a653f14eaa))
* **YouTube - Loop video:** Respect sleep timer end of video state ([#2890](https://github.com/MorpheApp/morphe-patches/issues/2890)) ([9f4f2a8](https://github.com/MorpheApp/morphe-patches/commit/9f4f2a8a6a8bef2627f8809cdec5b9b40773855a))
* **YouTube - Navigation bar:** Keep the app edge to edge when the translucent navigation bar is disabled ([7f2153d](https://github.com/MorpheApp/morphe-patches/commit/7f2153d58830debfe44b9feb94d4a064dd6f56d5))
* **YouTube - Spoof video streams:** Show AV1 toggle when 'Android VR' client is selected ([19f2325](https://github.com/MorpheApp/morphe-patches/commit/19f232578d8f65c77a90de6da021c5bea59f31d9))
* **YouTube - Video quality:** Prevent infinite loading when opening videos from Shorts ([#2871](https://github.com/MorpheApp/morphe-patches/issues/2871)) ([8fb3e31](https://github.com/MorpheApp/morphe-patches/commit/8fb3e318dc19fa25f96c85b1759c1d534a7a931f))
* **YouTube Music - Remember shuffle state:** Prevent continuous queue shuffling ([#2870](https://github.com/MorpheApp/morphe-patches/issues/2870)) ([b58019c](https://github.com/MorpheApp/morphe-patches/commit/b58019c16a54b315533cc5f61f6f8718c6d66651))
* **YouTube:** Remove "Restore old player button style" from `21.36` and later experimental targets ([8cc2f54](https://github.com/MorpheApp/morphe-patches/commit/8cc2f549833219384320bf5d43128702bbc1b2bb))

### ✨ New Features

* **Custom branding:** Add an app icon patch option and support mounted installations ([#2518](https://github.com/MorpheApp/morphe-patches/issues/2518)) ([e7a508f](https://github.com/MorpheApp/morphe-patches/commit/e7a508f2b1b629066e49776254e5c2e2f625976a))
* **GmsCore support:** Handle conflicting MicroG installs ([#2907](https://github.com/MorpheApp/morphe-patches/issues/2907)) ([31a66d9](https://github.com/MorpheApp/morphe-patches/commit/31a66d95932f6ccf4e39a5804c750af72a606d15))
* **Reddit:** Add `Custom app icon` patch ([#2937](https://github.com/MorpheApp/morphe-patches/issues/2937)) ([c17f699](https://github.com/MorpheApp/morphe-patches/commit/c17f6990a6d3ed5f8041f07eb3cb129a939e529e))
* **YouTube - Fullscreen video scale:** Add option to show scale button only in fullscreen ([#2878](https://github.com/MorpheApp/morphe-patches/issues/2878)) ([f4bb073](https://github.com/MorpheApp/morphe-patches/commit/f4bb07318ee181502b00eb8e009aed7df42b78bc))
* **YouTube - Miniplayer:** Add "Minimal 2" miniplayer type ([#2928](https://github.com/MorpheApp/morphe-patches/issues/2928)) ([3ae8dd1](https://github.com/MorpheApp/morphe-patches/commit/3ae8dd17d0b1ad543a994dbb3bf1b076e1eb7301))
* **YouTube - Miniplayer:** Restore the minimal miniplayer on 21.29+ ([#2911](https://github.com/MorpheApp/morphe-patches/issues/2911)) ([af1a457](https://github.com/MorpheApp/morphe-patches/commit/af1a457e6c62888c1d5de81a54ceefe8edff9abc))
* **YouTube - Spoof app version:** Add "Restore old captions behavior" spoof target ([eea2f2a](https://github.com/MorpheApp/morphe-patches/commit/eea2f2a052bb64bbf763a0eaa8323f95506c9faa))
* **YouTube - Swipe controls:** Add a volume steps option and set the swipe distance per step ([#2938](https://github.com/MorpheApp/morphe-patches/issues/2938)) ([f06d565](https://github.com/MorpheApp/morphe-patches/commit/f06d565ad899c022370237d9694aa29fbe22e95b))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.36.0` & `2026.37.0` ([596c812](https://github.com/MorpheApp/morphe-patches/commit/596c81283a2666cbb3568786fdb40d587a0bb986))
* **YouTube Music:** Add experimental support for `9.36.50` ([da8c85d](https://github.com/MorpheApp/morphe-patches/commit/da8c85d88a3c34597426525f5a81f69a4efdcd75))

## [1.43.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.6...v1.43.0-dev.7) (2026-09-14)

### ✨ New Features

* **YouTube - Miniplayer:** Add "Minimal 2" miniplayer type ([#2928](https://github.com/MorpheApp/morphe-patches/issues/2928)) ([3ae8dd1](https://github.com/MorpheApp/morphe-patches/commit/3ae8dd17d0b1ad543a994dbb3bf1b076e1eb7301))

## [1.43.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.5...v1.43.0-dev.6) (2026-09-14)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Fetch element description straight from ViewGroup instead componentHost ([7565b9d](https://github.com/MorpheApp/morphe-patches/commit/7565b9d4409d20cf58075fb7d53eca081d2ac282))

## [1.43.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.4...v1.43.0-dev.5) (2026-09-13)

### ✨ New Features

* **YouTube - Swipe controls:** Add a volume steps option and set the swipe distance per step ([#2938](https://github.com/MorpheApp/morphe-patches/issues/2938)) ([f06d565](https://github.com/MorpheApp/morphe-patches/commit/f06d565ad899c022370237d9694aa29fbe22e95b))

## [1.43.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.3...v1.43.0-dev.4) (2026-09-13)

### ✨ New Features

* **Custom branding:** Add an app icon patch option and support mounted installations ([#2518](https://github.com/MorpheApp/morphe-patches/issues/2518)) ([e7a508f](https://github.com/MorpheApp/morphe-patches/commit/e7a508f2b1b629066e49776254e5c2e2f625976a))
* **Reddit:** Add `App icon` patch ([#2937](https://github.com/MorpheApp/morphe-patches/issues/2937)) ([c17f699](https://github.com/MorpheApp/morphe-patches/commit/c17f6990a6d3ed5f8041f07eb3cb129a939e529e))

## [1.43.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.2...v1.43.0-dev.3) (2026-09-13)

### 🐛 Bug Fixes

* **Theme:** Show the color the app draws when a color the user picked needs an overlay the app cannot register ([a4c1539](https://github.com/MorpheApp/morphe-patches/commit/a4c1539ac45233862f2b7594f322328a33b5d218))
* **Theme:** Use the nearest palette color when the app is not given an overlay manager ([#2926](https://github.com/MorpheApp/morphe-patches/issues/2926)) ([86e146c](https://github.com/MorpheApp/morphe-patches/commit/86e146c54bad8450265f2ac2d734722fd682794c))
* **YouTube - Disable fullscreen gestures:** Restore pinch-to-zoom past fill on `21.36`+ ([#2876](https://github.com/MorpheApp/morphe-patches/issues/2876)) ([dd76cc1](https://github.com/MorpheApp/morphe-patches/commit/dd76cc1198fffb42d99f993ae03bd6e6cdcb4cf7))

### ✨ New Features

* **YouTube - Fullscreen video scale:** Add option to show scale button only in fullscreen ([#2878](https://github.com/MorpheApp/morphe-patches/issues/2878)) ([f4bb073](https://github.com/MorpheApp/morphe-patches/commit/f4bb07318ee181502b00eb8e009aed7df42b78bc))
* **YouTube - Spoof app version:** Add "Restore old captions behavior" spoof target ([eea2f2a](https://github.com/MorpheApp/morphe-patches/commit/eea2f2a052bb64bbf763a0eaa8323f95506c9faa))

## [1.43.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.43.0-dev.1...v1.43.0-dev.2) (2026-09-12)

### 🐛 Bug Fixes

* **YouTube - Change header:** Apply custom header logo to explore menu ([#2910](https://github.com/MorpheApp/morphe-patches/issues/2910)) ([e549894](https://github.com/MorpheApp/morphe-patches/commit/e549894d1c8dd2e9909a5c773c3c9c81a4df64a5))
* **YouTube - Navigation bar:** Keep the app edge to edge when the translucent navigation bar is disabled ([7f2153d](https://github.com/MorpheApp/morphe-patches/commit/7f2153d58830debfe44b9feb94d4a064dd6f56d5))
* **YouTube - Spoof video streams:** Show AV1 toggle when 'Android VR' client is selected ([19f2325](https://github.com/MorpheApp/morphe-patches/commit/19f232578d8f65c77a90de6da021c5bea59f31d9))

### ✨ New Features

* **YouTube - Miniplayer:** Restore the minimal miniplayer on 21.29+ ([#2911](https://github.com/MorpheApp/morphe-patches/issues/2911)) ([af1a457](https://github.com/MorpheApp/morphe-patches/commit/af1a457e6c62888c1d5de81a54ceefe8edff9abc))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.36.0` & `2026.37.0` ([596c812](https://github.com/MorpheApp/morphe-patches/commit/596c81283a2666cbb3568786fdb40d587a0bb986))

## [1.43.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.42.1-dev.3...v1.43.0-dev.1) (2026-09-12)

### ✨ New Features

* **GmsCore support:** Handle conflicting MicroG installs ([#2907](https://github.com/MorpheApp/morphe-patches/issues/2907)) ([31a66d9](https://github.com/MorpheApp/morphe-patches/commit/31a66d95932f6ccf4e39a5804c750af72a606d15))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.36.50` ([da8c85d](https://github.com/MorpheApp/morphe-patches/commit/da8c85d88a3c34597426525f5a81f69a4efdcd75))

## [1.42.1-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.42.1-dev.2...v1.42.1-dev.3) (2026-09-11)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Patch failing on `20.21.37` ([41d89ef](https://github.com/MorpheApp/morphe-patches/commit/41d89ef38ae4feb744054656a6b6a8a653f14eaa))

## [1.42.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.42.1-dev.1...v1.42.1-dev.2) (2026-09-11)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Injected buttons are shown in collaborators panel ([#2867](https://github.com/MorpheApp/morphe-patches/issues/2867)) ([b595f8d](https://github.com/MorpheApp/morphe-patches/commit/b595f8d60023b127a67c4238bf285e12ebeee427))
* **YouTube - Hide layout components:** Fix UI padding in comment replies and incognito search ([#2891](https://github.com/MorpheApp/morphe-patches/issues/2891)) ([59485db](https://github.com/MorpheApp/morphe-patches/commit/59485db96f29c9fa458ceca5f29e1754197220f4))
* **YouTube - Loop video:** Respect sleep timer end of video state ([#2890](https://github.com/MorpheApp/morphe-patches/issues/2890)) ([9f4f2a8](https://github.com/MorpheApp/morphe-patches/commit/9f4f2a8a6a8bef2627f8809cdec5b9b40773855a))

## [1.42.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0...v1.42.1-dev.1) (2026-09-10)

### 🐛 Bug Fixes

* **YouTube - Fullscreen video scale:** Restore UI after leaving fullscreen on tablet/foldable landscape ([#2874](https://github.com/MorpheApp/morphe-patches/issues/2874)) ([75f477f](https://github.com/MorpheApp/morphe-patches/commit/75f477f5c8834bd30cb27f66cc13b7f9c1f4c981))
* **YouTube - Video quality:** Prevent infinite loading when opening videos from Shorts ([#2871](https://github.com/MorpheApp/morphe-patches/issues/2871)) ([8fb3e31](https://github.com/MorpheApp/morphe-patches/commit/8fb3e318dc19fa25f96c85b1759c1d534a7a931f))
* **YouTube Music - Remember shuffle state:** Prevent continuous queue shuffling ([#2870](https://github.com/MorpheApp/morphe-patches/issues/2870)) ([b58019c](https://github.com/MorpheApp/morphe-patches/commit/b58019c16a54b315533cc5f61f6f8718c6d66651))
* **YouTube:** Remove "Restore old player button style" from `21.36` and later experimental targets ([8cc2f54](https://github.com/MorpheApp/morphe-patches/commit/8cc2f549833219384320bf5d43128702bbc1b2bb))

## [1.42.0](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0...v1.42.0) (2026-09-09)

### 🐛 Bug Fixes

* **GmsCore support:** Prompt to update outdated MicroG ([#2787](https://github.com/MorpheApp/morphe-patches/issues/2787)) ([c30850d](https://github.com/MorpheApp/morphe-patches/commit/c30850dea5d27aae956d0c6e10e6d32fc98c3e5f))
* **YouTube - Channel whitelists:** Hide injected flyout menu buttons from other unrelated menu's  ([#2808](https://github.com/MorpheApp/morphe-patches/issues/2808)) ([5ba4ab4](https://github.com/MorpheApp/morphe-patches/commit/5ba4ab46f1a1ff62a8a733adc1b52a5614208036))
* **YouTube - Channel whitelists:** Whitelists buttons are visible in some flyouts ([#2802](https://github.com/MorpheApp/morphe-patches/issues/2802)) ([2f482ff](https://github.com/MorpheApp/morphe-patches/commit/2f482ff33e5b0fa59d7877b9e34b7a47aa110397))
* **YouTube - Hide layout components:** App may crash when 'You may like' section is hidden ([#2852](https://github.com/MorpheApp/morphe-patches/issues/2852)) ([407411d](https://github.com/MorpheApp/morphe-patches/commit/407411db710c8beb6e94e4e5f29fab3dc9060a30))
* **YouTube - Hide layout components:** Hide guidelines in live chat ([b7528e0](https://github.com/MorpheApp/morphe-patches/commit/b7528e0e3c63f8d50caa3ebefa6dfd4c6a1859b1))
* **YouTube - Hide layout components:** Hide new type of community posts ([17b13ff](https://github.com/MorpheApp/morphe-patches/commit/17b13fff559866ef733e0b738a3ab7f3ba548200))
* **YouTube - Hide layout components:** Resolve empty channel tabs when using "Hide channel tab filter" ([#2747](https://github.com/MorpheApp/morphe-patches/issues/2747)) ([8232fa7](https://github.com/MorpheApp/morphe-patches/commit/8232fa7eeeb8d7c6e458e3ac16503fadccfceec4))
* **YouTube - Hide player overlay buttons:** Apply the control buttons background opacity to the player time bar ([#2805](https://github.com/MorpheApp/morphe-patches/issues/2805)) ([302ab28](https://github.com/MorpheApp/morphe-patches/commit/302ab28ce8c00b2b5a093dcbedeb739706360d67))
* **YouTube - Hide Shorts components:** Hide new type of paused overlay button ([c958fb6](https://github.com/MorpheApp/morphe-patches/commit/c958fb666cac54aaa3c822b736db85479c4dc6db))
* **YouTube - SponsorBlock:** Skip buttons are not show with `21.26.45` ([f667d85](https://github.com/MorpheApp/morphe-patches/commit/f667d85352b8165b1680c54bd22e211e81e7f1ce))
* **YouTube - Theme:** Apply the foreground color to text and icons in more locations ([#2707](https://github.com/MorpheApp/morphe-patches/issues/2707)) ([126a7d7](https://github.com/MorpheApp/morphe-patches/commit/126a7d7baacc3783e88681028612304e54e74608))
* **YouTube - Video quality:** Restore `ShortsPlayerState` check to fix default video quality ([b596375](https://github.com/MorpheApp/morphe-patches/commit/b59637570cc477d09a236cf14582e4b06d1abc37))
* **YouTube Music - Downloads:** Prevent external downloader triggering on non-download actions ([#2858](https://github.com/MorpheApp/morphe-patches/issues/2858)) ([a4cd837](https://github.com/MorpheApp/morphe-patches/commit/a4cd8377166eb308ba6d09ecc0f4be166535e9b4))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide channel links section" setting ([ddcdabe](https://github.com/MorpheApp/morphe-patches/commit/ddcdabe19a50aedb0eb80fa62de68e9d534e3167))
* **YouTube - Hide layout components:** Add "Report AI channel" video menu entry ([#2763](https://github.com/MorpheApp/morphe-patches/issues/2763)) ([17d1135](https://github.com/MorpheApp/morphe-patches/commit/17d1135c33d7af159c48198e30d14623ea738aff))
* **YouTube - Hide player overlay buttons:** Add option to change the player control buttons background opacity ([#2764](https://github.com/MorpheApp/morphe-patches/issues/2764)) ([4a2d3a4](https://github.com/MorpheApp/morphe-patches/commit/4a2d3a4ddd4006c9aa8efa2546f8d734cf85f28f))
* **YouTube - Hide Shorts components:** Add "Hide gesture hints" setting ([#2760](https://github.com/MorpheApp/morphe-patches/issues/2760)) ([73df92a](https://github.com/MorpheApp/morphe-patches/commit/73df92adf973775ac42f8d89f938bf17ec7e03b3))
* **YouTube - Remove background playback restrictions:** Add "Auto pause when device is locked" setting ([#2719](https://github.com/MorpheApp/morphe-patches/issues/2719)) ([f8bc479](https://github.com/MorpheApp/morphe-patches/commit/f8bc479af4e8b53cf1eea71cfaab923ddfb00910))
* **YouTube Music - Scrobbling:** Add "Fill in missing album" setting ([#2666](https://github.com/MorpheApp/morphe-patches/issues/2666)) ([c94ecbd](https://github.com/MorpheApp/morphe-patches/commit/c94ecbddec7454d866c05b85926dc6670d3ef648))
* **YouTube:** Add `Remember livestream playback position` patch ([#2753](https://github.com/MorpheApp/morphe-patches/issues/2753)) ([6252c85](https://github.com/MorpheApp/morphe-patches/commit/6252c85e7ce22ee4030a0a9b9094f467f42fa863))
* **YouTube:** Add channel whitelists for ads and playback speed ([#2334](https://github.com/MorpheApp/morphe-patches/issues/2334)) ([4850003](https://github.com/MorpheApp/morphe-patches/commit/4850003c90948552383f7bead3e185d6085a2b57))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.35.54` ([7e42c2a](https://github.com/MorpheApp/morphe-patches/commit/7e42c2a57aa3838338b02569bce5e69f102457d2))
* **YouTube:** Add support for `21.13.164` ([58b9a75](https://github.com/MorpheApp/morphe-patches/commit/58b9a7540847828dc543e0056821d451acfdbfdf))
* **YouTube:** Add experimental support for `21.36.45` ([#2814](https://github.com/MorpheApp/morphe-patches/issues/2814)) ([07d36c3](https://github.com/MorpheApp/morphe-patches/commit/07d36c334ec9834e671bf1bb97b14f6a20dcdbbe))

## [1.42.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.9...v1.42.0-dev.10) (2026-09-09)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide guidelines in live chat ([b7528e0](https://github.com/MorpheApp/morphe-patches/commit/b7528e0e3c63f8d50caa3ebefa6dfd4c6a1859b1))

## [1.42.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.8...v1.42.0-dev.9) (2026-09-09)

### 🐛 Bug Fixes

* **YouTube Music - Downloads:** Prevent external downloader triggering on non-download actions ([#2858](https://github.com/MorpheApp/morphe-patches/issues/2858)) ([a4cd837](https://github.com/MorpheApp/morphe-patches/commit/a4cd8377166eb308ba6d09ecc0f4be166535e9b4))

### 🚀 Updated App Support

* **YouTube:** Add support for `21.13.164` ([58b9a75](https://github.com/MorpheApp/morphe-patches/commit/58b9a7540847828dc543e0056821d451acfdbfdf))

## [1.42.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.7...v1.42.0-dev.8) (2026-09-08)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** App may crash when 'You may like' section is hidden ([#2852](https://github.com/MorpheApp/morphe-patches/issues/2852)) ([407411d](https://github.com/MorpheApp/morphe-patches/commit/407411db710c8beb6e94e4e5f29fab3dc9060a30))

## [1.42.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.6...v1.42.0-dev.7) (2026-09-07)

### 🐛 Bug Fixes

* **GmsCore support:** Prompt to update outdated MicroG ([#2787](https://github.com/MorpheApp/morphe-patches/issues/2787)) ([c30850d](https://github.com/MorpheApp/morphe-patches/commit/c30850dea5d27aae956d0c6e10e6d32fc98c3e5f))

## [1.42.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.5...v1.42.0-dev.6) (2026-09-06)

### 🐛 Bug Fixes

* **YouTube - Channel whitelists:** Hide injected flyout menu buttons from other unrelated menu's  ([#2808](https://github.com/MorpheApp/morphe-patches/issues/2808)) ([5ba4ab4](https://github.com/MorpheApp/morphe-patches/commit/5ba4ab46f1a1ff62a8a733adc1b52a5614208036))

## [1.42.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.4...v1.42.0-dev.5) (2026-09-06)

### 🐛 Bug Fixes

* **YouTube - SponsorBlock:** Skip buttons not working on `21.36.45` ([f667d85](https://github.com/MorpheApp/morphe-patches/commit/f667d85352b8165b1680c54bd22e211e81e7f1ce))

## [1.42.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.3...v1.42.0-dev.4) (2026-09-06)

### 🐛 Bug Fixes

* **YouTube - Channel whitelists:** Whitelists buttons are visible in some flyouts ([#2802](https://github.com/MorpheApp/morphe-patches/issues/2802)) ([2f482ff](https://github.com/MorpheApp/morphe-patches/commit/2f482ff33e5b0fa59d7877b9e34b7a47aa110397))
* **YouTube - Hide player overlay buttons:** Apply the control buttons background opacity to the player time bar ([#2805](https://github.com/MorpheApp/morphe-patches/issues/2805)) ([302ab28](https://github.com/MorpheApp/morphe-patches/commit/302ab28ce8c00b2b5a093dcbedeb739706360d67))
* **YouTube - Hide Shorts components:** Hide new type of paused overlay button ([c958fb6](https://github.com/MorpheApp/morphe-patches/commit/c958fb666cac54aaa3c822b736db85479c4dc6db))

### ✨ New Features

* **YouTube Music - Scrobbling:** Add "Fill in missing album" setting ([#2666](https://github.com/MorpheApp/morphe-patches/issues/2666)) ([c94ecbd](https://github.com/MorpheApp/morphe-patches/commit/c94ecbddec7454d866c05b85926dc6670d3ef648))
* **YouTube:** Add `Remember livestream playback position` patch ([#2753](https://github.com/MorpheApp/morphe-patches/issues/2753)) ([6252c85](https://github.com/MorpheApp/morphe-patches/commit/6252c85e7ce22ee4030a0a9b9094f467f42fa863))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.36.45` ([#2814](https://github.com/MorpheApp/morphe-patches/issues/2814)) ([07d36c3](https://github.com/MorpheApp/morphe-patches/commit/07d36c334ec9834e671bf1bb97b14f6a20dcdbbe))

## [1.42.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.2...v1.42.0-dev.3) (2026-09-05)

### 🐛 Bug Fixes

* **YouTube - Video quality:** Restore `ShortsPlayerState` check to fix default video quality ([b596375](https://github.com/MorpheApp/morphe-patches/commit/b59637570cc477d09a236cf14582e4b06d1abc37))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Report AI channel" video menu entry ([#2763](https://github.com/MorpheApp/morphe-patches/issues/2763)) ([17d1135](https://github.com/MorpheApp/morphe-patches/commit/17d1135c33d7af159c48198e30d14623ea738aff))
* **YouTube - Hide Shorts components:** Add "Hide gesture hints" setting ([#2760](https://github.com/MorpheApp/morphe-patches/issues/2760)) ([73df92a](https://github.com/MorpheApp/morphe-patches/commit/73df92adf973775ac42f8d89f938bf17ec7e03b3))
* **YouTube:** Add channel whitelists for ads and playback speed ([#2334](https://github.com/MorpheApp/morphe-patches/issues/2334)) ([4850003](https://github.com/MorpheApp/morphe-patches/commit/4850003c90948552383f7bead3e185d6085a2b57))

## [1.42.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.42.0-dev.1...v1.42.0-dev.2) (2026-09-04)

### 🐛 Bug Fixes

* **YouTube - Theme:** Apply the foreground color to text and icons in more locations ([#2707](https://github.com/MorpheApp/morphe-patches/issues/2707)) ([126a7d7](https://github.com/MorpheApp/morphe-patches/commit/126a7d7baacc3783e88681028612304e54e74608))

### ✨ New Features

* **YouTube - Hide player overlay buttons:** Add option to change the player control buttons background opacity ([#2764](https://github.com/MorpheApp/morphe-patches/issues/2764)) ([4a2d3a4](https://github.com/MorpheApp/morphe-patches/commit/4a2d3a4ddd4006c9aa8efa2546f8d734cf85f28f))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.35.54` ([7e42c2a](https://github.com/MorpheApp/morphe-patches/commit/7e42c2a57aa3838338b02569bce5e69f102457d2))

## [1.42.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0...v1.42.0-dev.1) (2026-09-03)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide new type of community posts ([17b13ff](https://github.com/MorpheApp/morphe-patches/commit/17b13fff559866ef733e0b738a3ab7f3ba548200))
* **YouTube - Hide layout components:** Resolve empty channel tabs when using "Hide channel tab filter" ([#2747](https://github.com/MorpheApp/morphe-patches/issues/2747)) ([8232fa7](https://github.com/MorpheApp/morphe-patches/commit/8232fa7eeeb8d7c6e458e3ac16503fadccfceec4))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide channel links section" setting ([ddcdabe](https://github.com/MorpheApp/morphe-patches/commit/ddcdabe19a50aedb0eb80fa62de68e9d534e3167))
* **YouTube - Remove background playback restrictions:** Add "Auto pause when device is locked" setting ([#2719](https://github.com/MorpheApp/morphe-patches/issues/2719)) ([f8bc479](https://github.com/MorpheApp/morphe-patches/commit/f8bc479af4e8b53cf1eea71cfaab923ddfb00910))

## [1.41.0](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0...v1.41.0) (2026-09-01)

### 🐛 Bug Fixes

* **Enable debugging - Feature flags manager:** Only use active flags as binary search candidates ([c6f0e1d](https://github.com/MorpheApp/morphe-patches/commit/c6f0e1d15247c38753853e389e0a6a63ea8b4bf4))
* **Reddit:** Preserve font weights with system and custom fonts ([#2643](https://github.com/MorpheApp/morphe-patches/issues/2643)) ([9cf3838](https://github.com/MorpheApp/morphe-patches/commit/9cf38388b924c8ca5a27db6fb82d6231b16dbc41))
* **Settings:** Keep search results in sync with preferences and highlight every match ([#2712](https://github.com/MorpheApp/morphe-patches/issues/2712)) ([5cae2b5](https://github.com/MorpheApp/morphe-patches/commit/5cae2b57c35afeb2d6d14e4ea52edaf93d138043))
* **Settings:** Resolve OOM crashes and prevent duplicate dialogs ([047121d](https://github.com/MorpheApp/morphe-patches/commit/047121d9d9001ba56439ce20ac7596e48a415a90))
* **Theme:** "App default" color is drawn pure black instead of the colors of the app ([07c6d35](https://github.com/MorpheApp/morphe-patches/commit/07c6d356de44614842038680639777fc0b010d4e))
* **Theme:** Add new color tokens and Litho hooks ([a7d7520](https://github.com/MorpheApp/morphe-patches/commit/a7d7520f824013816d579a716e67ef6a76102936))
* **Theme:** Morphe dialogs and settings are pure black with the "App default" color ([f5ce706](https://github.com/MorpheApp/morphe-patches/commit/f5ce7061d24097312a06fb0227393a59c730c8f0))
* **Theme:** Prevent an endless activity relaunch loop ([212fc09](https://github.com/MorpheApp/morphe-patches/commit/212fc09a1e8b9048e736a57a9ca3e5c1511896bd))
* **Theme:** Splash screen is pure black with the "App default" color ([4a226c7](https://github.com/MorpheApp/morphe-patches/commit/4a226c7d11760c56e10b9ba6ebdf60fdf97c860c))
* **Theme:** Use more compact custom theme palette ([73eab93](https://github.com/MorpheApp/morphe-patches/commit/73eab930902d56ca78ce5b6b40377997fa906140))
* **Translations:** Report the HTTP status of a failed translation instead of a file not found error ([b524f57](https://github.com/MorpheApp/morphe-patches/commit/b524f578ef2e4f31a5a80ebd7eaf0380fa3d335f))
* **YouTube - Add to queue:** Flyout menu is too wide and loses the item changes on rotation ([72dbc80](https://github.com/MorpheApp/morphe-patches/commit/72dbc80f74853e491f377dbb11b111b351880362))
* **YouTube - Advanced quality menu:** The menu is not show in some circumstances ([a867890](https://github.com/MorpheApp/morphe-patches/commit/a8678901703c6b903f4002ab950355ccebcc1d15))
* **YouTube - Change form factor:** Prevent tablet layout causing app to crash ([#2600](https://github.com/MorpheApp/morphe-patches/issues/2600)) ([f54d9cd](https://github.com/MorpheApp/morphe-patches/commit/f54d9cd0c86ec3fa960d2505201f323f4766ebd5))
* **YouTube - Hide ads:** Prevent button swap when Navigation bar patch is excluded ([#2714](https://github.com/MorpheApp/morphe-patches/issues/2714)) ([032cf5a](https://github.com/MorpheApp/morphe-patches/commit/032cf5a74acde337aa3ddf4f42e90f6ac0c5eba2))
* **YouTube - Hide ads:** Prevent unintended navigation button swap ([#2659](https://github.com/MorpheApp/morphe-patches/issues/2659)) ([389d2d3](https://github.com/MorpheApp/morphe-patches/commit/389d2d37ddd14dd102ce98bafa85feedb1df8234))
* **YouTube - Hide layout components:** Exception thrown if there are duplicate keywords in the `Comments carousel filter` ([#2640](https://github.com/MorpheApp/morphe-patches/issues/2640)) ([5c3be65](https://github.com/MorpheApp/morphe-patches/commit/5c3be655f3f92bae646b494bc7a3be57d6fc0cb0))
* **YouTube - Hide layout components:** Prevent Library shelves from being hidden ([#2597](https://github.com/MorpheApp/morphe-patches/issues/2597)) ([2d1e542](https://github.com/MorpheApp/morphe-patches/commit/2d1e5428f23a76b8f3ba6d8c84e1148b459ed112))
* **YouTube - Hide player overlay buttons:** Cast button is not always hidden ([0c9cabf](https://github.com/MorpheApp/morphe-patches/commit/0c9cabfd9c30cc4c80453fc927f6cd0566f1a6b3))
* **YouTube - Hide player overlay buttons:** Hide new type of cast button ([bb36691](https://github.com/MorpheApp/morphe-patches/commit/bb3669139536e0c632fb4991b7e4bcd4ee3cc84e))
* **YouTube - Legacy player controls:** Top bar buttons are hidden in some circumstances ([f429938](https://github.com/MorpheApp/morphe-patches/commit/f429938f5ebde77d811aba4faad37ef01566e954))
* **YouTube - PlayerOverlayButton:** Correct spacing when fullscreen button is hidden ([#2663](https://github.com/MorpheApp/morphe-patches/issues/2663)) ([7ddb7c2](https://github.com/MorpheApp/morphe-patches/commit/7ddb7c2870a0a28f1d1df6c2c621d873782f1775))
* **YouTube - Reload video:** Keep pitch/speed after reload ([#2595](https://github.com/MorpheApp/morphe-patches/issues/2595)) ([959597c](https://github.com/MorpheApp/morphe-patches/commit/959597cef9b5ac7ed5342bf64ff3b31da7f7a842))
* **YouTube - Save to watch later for kids button:** Button was hidden in flyout for some videos ([109f9dc](https://github.com/MorpheApp/morphe-patches/commit/109f9dc64ffffdbde70c51395cfd9fa8a08b999f))
* **YouTube - Seekbar:** Force newer splash screen animation ([91f937a](https://github.com/MorpheApp/morphe-patches/commit/91f937a83346df0e1361fa11f7e5db422c8ff3d2))
* **YouTube - Theme:** Apply custom colors to the menu and dialog backgrounds ([2cca3d9](https://github.com/MorpheApp/morphe-patches/commit/2cca3d9e3d806e87000f900959079bd9e25d81e5))
* **YouTube - Theme:** Apply custom theme to drop-down menus ([#2589](https://github.com/MorpheApp/morphe-patches/issues/2589)) ([66765bd](https://github.com/MorpheApp/morphe-patches/commit/66765bde7b0410c41b1dcfb9b052adbb1cec1f27))
* **YouTube - Theme:** Custom colors are not applied to experimental flyout menus ([6e30492](https://github.com/MorpheApp/morphe-patches/commit/6e304926f7ad112e5566bed4a727851fc0198f5b))
* **YouTube - Theme:** Some elements keeps the stock color after leaving picture in picture ([#2591](https://github.com/MorpheApp/morphe-patches/issues/2591)) ([a897f41](https://github.com/MorpheApp/morphe-patches/commit/a897f416f708fee55ca394b67fcb8db0160aac9c))
* **YouTube - Video quality:** SABR playback breaks due to "Prioritize video quality" ([#2720](https://github.com/MorpheApp/morphe-patches/issues/2720)) ([895a8f1](https://github.com/MorpheApp/morphe-patches/commit/895a8f19e897239a7e3e4978c0524822f1863c78))
* **YouTube Music - Play albums songs:** Restore music videos outside of albums and use the SponsorBlock segments of the song ([55cd280](https://github.com/MorpheApp/morphe-patches/commit/55cd28030ca12efd686735a08885dcf42bd58f77))
* **YouTube Music - Play albums songs:** Use the length of the song instead of the length of the music video ([e38ec78](https://github.com/MorpheApp/morphe-patches/commit/e38ec78c780cc698f227fed577e96ef15114c140))
* **YouTube Music - Scrobbling:** Scrobble the song version of album tracks instead of the music video ([9ceace2](https://github.com/MorpheApp/morphe-patches/commit/9ceace24b220ea711d91fa750665a46d85bce444))
* **YouTube Music - Theme:** Fade the page header into the background color ([#2636](https://github.com/MorpheApp/morphe-patches/issues/2636)) ([5f5a478](https://github.com/MorpheApp/morphe-patches/commit/5f5a478f7c8670958255b06eeabbfff2e9be4ff0))
* **YouTube Music - Third-party lyrics:** Show the lyrics of the song version of album tracks ([e29d3e9](https://github.com/MorpheApp/morphe-patches/commit/e29d3e939dad95fab0981517be47a55529dc30b1))
* **YouTube Music:** Various issues of the `Play albums songs` patch ([#2698](https://github.com/MorpheApp/morphe-patches/issues/2698)) ([b18ca17](https://github.com/MorpheApp/morphe-patches/commit/b18ca17bb50c255fc1328ec291b77298cf687ff2))

### ✨ New Features

* Add `App refresh rate` patch ([#2695](https://github.com/MorpheApp/morphe-patches/issues/2695)) ([e11c5e9](https://github.com/MorpheApp/morphe-patches/commit/e11c5e97cfb63f413cb3e1f695f50610e11016d5))
* Add `PoToken provider` patch ([#2618](https://github.com/MorpheApp/morphe-patches/issues/2618)) ([fb25ff1](https://github.com/MorpheApp/morphe-patches/commit/fb25ff1fe8270a8a8d003361e17c130c5d422237))
* **Enable debugging - Feature flags manager:** Redesign and add flag forcing, import and export, and binary search ([#2638](https://github.com/MorpheApp/morphe-patches/issues/2638)) ([f0fdebe](https://github.com/MorpheApp/morphe-patches/commit/f0fdebeb02e40360c150e093180530a606709660))
* **Enable debugging - Feature flags manager:** Tell apart a behavior with no flag from one caused by more than one flag ([249c6bf](https://github.com/MorpheApp/morphe-patches/commit/249c6bf10571669fb8399e47fbf9a99d96d6e9f0))
* **Settings:** Add an option to change the name of the Morphe settings entry ([#2691](https://github.com/MorpheApp/morphe-patches/issues/2691)) ([942d6fb](https://github.com/MorpheApp/morphe-patches/commit/942d6fb59121fbf5629adbcbcb735db7818cac9e))
* **YouTube - Disable fullscreen gestures:** Add option to disable pinch-to-zoom ([#2633](https://github.com/MorpheApp/morphe-patches/issues/2633)) ([7b05d2d](https://github.com/MorpheApp/morphe-patches/commit/7b05d2db985232b5dc3bd3a3bcde13e9b4875dbc))
* **YouTube - Disable video codecs:** Add "Force HDR video" setting ([#2634](https://github.com/MorpheApp/morphe-patches/issues/2634)) ([04529f3](https://github.com/MorpheApp/morphe-patches/commit/04529f34cc7052b57b1290bf5b1eeeffea3b76b9))
* **YouTube - Hide layout components:** Add "Hide 'Top fans' button" setting ([#2660](https://github.com/MorpheApp/morphe-patches/issues/2660)) ([1e719f6](https://github.com/MorpheApp/morphe-patches/commit/1e719f614c75163bda9b9bac95bbadfb6268ff1c))
* **YouTube - Hide layout components:** Add "Hide filter bar in channel page" and "Hide 'Members only' chip" settings ([#2622](https://github.com/MorpheApp/morphe-patches/issues/2622)) ([5db5a77](https://github.com/MorpheApp/morphe-patches/commit/5db5a7799d3617b4d93d39ecc42c3d0af58308e8))
* **YouTube - Hide player flyout menu components:** Add "Hide 'On-the-go' menu" setting ([#2715](https://github.com/MorpheApp/morphe-patches/issues/2715)) ([8408ec9](https://github.com/MorpheApp/morphe-patches/commit/8408ec93703286988fe1b65024cea272e19aa489))
* **YouTube - Save to Watch later:** Support for related kids videos ([#2572](https://github.com/MorpheApp/morphe-patches/issues/2572)) ([b0ec540](https://github.com/MorpheApp/morphe-patches/commit/b0ec540b8829864e3fdcda5910edff1fddf1a72a))
* **YouTube - Wide search bar:** Replace the toggle with Disabled, Wide and Extra wide options ([#2608](https://github.com/MorpheApp/morphe-patches/issues/2608)) ([ce18f82](https://github.com/MorpheApp/morphe-patches/commit/ce18f821225e7c82da6832828e405d56394026fe))
* **YouTube Music - Hide music action buttons:** Add "Hide 'Live chat replay' button" setting ([#2674](https://github.com/MorpheApp/morphe-patches/issues/2674)) ([d43da80](https://github.com/MorpheApp/morphe-patches/commit/d43da80e8b27a5e767337d3a4c2fec64bb221d59))
* **YouTube Music:** Add `Play song version in albums` patch ([#2556](https://github.com/MorpheApp/morphe-patches/issues/2556)) ([5093f61](https://github.com/MorpheApp/morphe-patches/commit/5093f6120b39dc87a943b0d90bfc720ddb6b9a53))
* **YouTube:** Add `Disable playlist autoplay` patch ([#2628](https://github.com/MorpheApp/morphe-patches/issues/2628)) ([7beae7a](https://github.com/MorpheApp/morphe-patches/commit/7beae7afaaba4a00649874033915bd599877ad94))
* **YouTube:** Add `Disable scrolling speed limit` patch ([#2582](https://github.com/MorpheApp/morphe-patches/issues/2582)) ([162e690](https://github.com/MorpheApp/morphe-patches/commit/162e690df1d4fdf3f0acc2f720586d256c259e22))
* **YouTube:** Add `Fullscreen video scale` patch ([#2616](https://github.com/MorpheApp/morphe-patches/issues/2616)) ([53815a9](https://github.com/MorpheApp/morphe-patches/commit/53815a9ab88c4595e9e070ce56605584cd7a34e7))
* **YouTube:** Add `Mute button` patch ([#2624](https://github.com/MorpheApp/morphe-patches/issues/2624)) ([4c2b3c0](https://github.com/MorpheApp/morphe-patches/commit/4c2b3c040a404bd8661decc31398ca0a343a6768))
* **YouTube:** Disabled automatic playback pause after opening the player's video settings ([829f4c3](https://github.com/MorpheApp/morphe-patches/commit/829f4c3b64dde3cd0069680f9ecf44cccbcf3038))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.35.0` ([71f8a7f](https://github.com/MorpheApp/morphe-patches/commit/71f8a7fca74e3f008a9879a924f45aae7e5e4052))
* **YouTube Music:** Add experimental support for `9.34.52` ([fea25c2](https://github.com/MorpheApp/morphe-patches/commit/fea25c2c2fb7c20122ad5b9ac893a2733047a804))
* **YouTube:** Add experimental support for `21.35.442` ([#2627](https://github.com/MorpheApp/morphe-patches/issues/2627)) ([4535022](https://github.com/MorpheApp/morphe-patches/commit/453502203ca298c837176995c283502cf8f4adb1))
* **YouTube:** Add support for `21.07.247` ([0c61372](https://github.com/MorpheApp/morphe-patches/commit/0c61372bdca637a2bdb6d144627e181348cb372c))

### 🔧 Improvements

* **YouTube:** Fix some issues and improve code ([#2688](https://github.com/MorpheApp/morphe-patches/issues/2688)) ([d8fcd8c](https://github.com/MorpheApp/morphe-patches/commit/d8fcd8c04ad72cc2655237e2c3d61d26bd220099))
* **YouTube:** Fix some issues and improve code ([#2699](https://github.com/MorpheApp/morphe-patches/issues/2699)) ([31beebf](https://github.com/MorpheApp/morphe-patches/commit/31beebfe81eaf08ea008ab321255057393e83482))

## [1.41.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.11...v1.41.0-dev.12) (2026-09-01)

### 🐛 Bug Fixes

* **Settings:** Keep search results in sync with preferences and highlight every match ([#2712](https://github.com/MorpheApp/morphe-patches/issues/2712)) ([5cae2b5](https://github.com/MorpheApp/morphe-patches/commit/5cae2b57c35afeb2d6d14e4ea52edaf93d138043))
* **YouTube - Video quality:** SABR playback breaks due to "Prioritize video quality" ([#2720](https://github.com/MorpheApp/morphe-patches/issues/2720)) ([895a8f1](https://github.com/MorpheApp/morphe-patches/commit/895a8f19e897239a7e3e4978c0524822f1863c78))

### ✨ New Features

* **YouTube - Hide player flyout menu components:** Add "Hide 'On-the-go' menu" setting ([#2715](https://github.com/MorpheApp/morphe-patches/issues/2715)) ([8408ec9](https://github.com/MorpheApp/morphe-patches/commit/8408ec93703286988fe1b65024cea272e19aa489))

## [1.41.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.10...v1.41.0-dev.11) (2026-08-31)

### 🐛 Bug Fixes

* **YouTube - Hide ads:** Prevent button swap when Navigation bar patch is excluded ([#2714](https://github.com/MorpheApp/morphe-patches/issues/2714)) ([032cf5a](https://github.com/MorpheApp/morphe-patches/commit/032cf5a74acde337aa3ddf4f42e90f6ac0c5eba2))

## [1.41.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.9...v1.41.0-dev.10) (2026-08-31)

### 🐛 Bug Fixes

* **YouTube - Save to watch later for kids button:** Button was hidden in flyout for some videos ([109f9dc](https://github.com/MorpheApp/morphe-patches/commit/109f9dc64ffffdbde70c51395cfd9fa8a08b999f))

## [1.41.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.8...v1.41.0-dev.9) (2026-08-31)

### 🐛 Bug Fixes

* **Translations:** Report the HTTP status of a failed translation instead of a file not found error ([b524f57](https://github.com/MorpheApp/morphe-patches/commit/b524f578ef2e4f31a5a80ebd7eaf0380fa3d335f))
* **YouTube Music - Play albums songs:** Restore music videos outside of albums and use the SponsorBlock segments of the song ([55cd280](https://github.com/MorpheApp/morphe-patches/commit/55cd28030ca12efd686735a08885dcf42bd58f77))
* **YouTube Music - Play albums songs:** Use the length of the song instead of the length of the music video ([e38ec78](https://github.com/MorpheApp/morphe-patches/commit/e38ec78c780cc698f227fed577e96ef15114c140))
* **YouTube Music - Scrobbling:** Scrobble the song version of album tracks instead of the music video ([9ceace2](https://github.com/MorpheApp/morphe-patches/commit/9ceace24b220ea711d91fa750665a46d85bce444))
* **YouTube Music - Third-party lyrics:** Show the lyrics of the song version of album tracks ([e29d3e9](https://github.com/MorpheApp/morphe-patches/commit/e29d3e939dad95fab0981517be47a55529dc30b1))
* **YouTube Music:** Various issues of the `Play albums songs` patch ([#2698](https://github.com/MorpheApp/morphe-patches/issues/2698)) ([b18ca17](https://github.com/MorpheApp/morphe-patches/commit/b18ca17bb50c255fc1328ec291b77298cf687ff2))

### 🔧 Improvements

* **YouTube:** Fix some issues and improve code ([#2699](https://github.com/MorpheApp/morphe-patches/issues/2699)) ([31beebf](https://github.com/MorpheApp/morphe-patches/commit/31beebfe81eaf08ea008ab321255057393e83482))

## [1.41.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.7...v1.41.0-dev.8) (2026-08-31)

### ✨ New Features

* Add `App refresh rate` patch ([#2695](https://github.com/MorpheApp/morphe-patches/issues/2695)) ([e11c5e9](https://github.com/MorpheApp/morphe-patches/commit/e11c5e97cfb63f413cb3e1f695f50610e11016d5))
* **Settings:** Add an option to change the name of the Morphe settings entry ([#2691](https://github.com/MorpheApp/morphe-patches/issues/2691)) ([942d6fb](https://github.com/MorpheApp/morphe-patches/commit/942d6fb59121fbf5629adbcbcb735db7818cac9e))

### 🚀 Updated App Support

* **YouTube:** Add support for `21.07.247` ([0c61372](https://github.com/MorpheApp/morphe-patches/commit/0c61372bdca637a2bdb6d144627e181348cb372c))

## [1.41.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.6...v1.41.0-dev.7) (2026-08-30)

### 🐛 Bug Fixes

* **YouTube - Legacy player controls:** Top bar buttons are hidden in some circumstances ([f429938](https://github.com/MorpheApp/morphe-patches/commit/f429938f5ebde77d811aba4faad37ef01566e954))

### ✨ New Features

* **YouTube Music - Hide music action buttons:** Add "Hide 'Live chat replay' button" setting ([#2674](https://github.com/MorpheApp/morphe-patches/issues/2674)) ([d43da80](https://github.com/MorpheApp/morphe-patches/commit/d43da80e8b27a5e767337d3a4c2fec64bb221d59))
* **YouTube Music:** Add `Play song version in albums` patch ([#2556](https://github.com/MorpheApp/morphe-patches/issues/2556)) ([5093f61](https://github.com/MorpheApp/morphe-patches/commit/5093f6120b39dc87a943b0d90bfc720ddb6b9a53))
* **YouTube:** Disabled automatic playback pause after opening the player's video settings ([829f4c3](https://github.com/MorpheApp/morphe-patches/commit/829f4c3b64dde3cd0069680f9ecf44cccbcf3038))

### 🔧 Improvements

* **YouTube:** Fix some issues and improve code ([#2688](https://github.com/MorpheApp/morphe-patches/issues/2688)) ([d8fcd8c](https://github.com/MorpheApp/morphe-patches/commit/d8fcd8c04ad72cc2655237e2c3d61d26bd220099))

## [1.41.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.5...v1.41.0-dev.6) (2026-08-30)

### 🐛 Bug Fixes

* **Enable debugging - Feature flags manager:** Only use active flags as binary search candidates ([c6f0e1d](https://github.com/MorpheApp/morphe-patches/commit/c6f0e1d15247c38753853e389e0a6a63ea8b4bf4))
* **YouTube - Advanced quality menu:** The menu is not show in some circumstances ([a867890](https://github.com/MorpheApp/morphe-patches/commit/a8678901703c6b903f4002ab950355ccebcc1d15))
* **YouTube - Hide player overlay buttons:** Hide new type of cast button ([bb36691](https://github.com/MorpheApp/morphe-patches/commit/bb3669139536e0c632fb4991b7e4bcd4ee3cc84e))
* **YouTube - Theme:** Apply custom colors to the menu and dialog backgrounds ([2cca3d9](https://github.com/MorpheApp/morphe-patches/commit/2cca3d9e3d806e87000f900959079bd9e25d81e5))
* **YouTube - Theme:** Custom colors are not applied to experimental flyout menus ([6e30492](https://github.com/MorpheApp/morphe-patches/commit/6e304926f7ad112e5566bed4a727851fc0198f5b))

### ✨ New Features

* **Enable debugging - Feature flags manager:** Redesign and add flag forcing, import and export, and binary search ([#2638](https://github.com/MorpheApp/morphe-patches/issues/2638)) ([f0fdebe](https://github.com/MorpheApp/morphe-patches/commit/f0fdebeb02e40360c150e093180530a606709660))
* **Enable debugging - Feature flags manager:** Tell apart a behavior with no flag from one caused by more than one flag ([249c6bf](https://github.com/MorpheApp/morphe-patches/commit/249c6bf10571669fb8399e47fbf9a99d96d6e9f0))

## [1.41.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.4...v1.41.0-dev.5) (2026-08-29)

### 🐛 Bug Fixes

* **YouTube - Hide ads:** Prevent unintended navigation button swap ([#2659](https://github.com/MorpheApp/morphe-patches/issues/2659)) ([389d2d3](https://github.com/MorpheApp/morphe-patches/commit/389d2d37ddd14dd102ce98bafa85feedb1df8234))
* **YouTube - Hide player overlay buttons:** Cast button is not always hidden ([0c9cabf](https://github.com/MorpheApp/morphe-patches/commit/0c9cabfd9c30cc4c80453fc927f6cd0566f1a6b3))
* **YouTube - PlayerOverlayButton:** Correct spacing when fullscreen button is hidden ([#2663](https://github.com/MorpheApp/morphe-patches/issues/2663)) ([7ddb7c2](https://github.com/MorpheApp/morphe-patches/commit/7ddb7c2870a0a28f1d1df6c2c621d873782f1775))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Top fans' button" setting ([#2660](https://github.com/MorpheApp/morphe-patches/issues/2660)) ([1e719f6](https://github.com/MorpheApp/morphe-patches/commit/1e719f614c75163bda9b9bac95bbadfb6268ff1c))

## [1.41.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.3...v1.41.0-dev.4) (2026-08-29)

### 🐛 Bug Fixes

* **Reddit:** Preserve font weights with system and custom fonts ([#2643](https://github.com/MorpheApp/morphe-patches/issues/2643)) ([9cf3838](https://github.com/MorpheApp/morphe-patches/commit/9cf38388b924c8ca5a27db6fb82d6231b16dbc41))
* **YouTube - Hide layout components:** Exception thrown if there are duplicate keywords in the `Comments carousel filter` ([#2640](https://github.com/MorpheApp/morphe-patches/issues/2640)) ([5c3be65](https://github.com/MorpheApp/morphe-patches/commit/5c3be655f3f92bae646b494bc7a3be57d6fc0cb0))

### ✨ New Features

* **YouTube - Disable video codecs:** Add "Force HDR video" setting ([#2634](https://github.com/MorpheApp/morphe-patches/issues/2634)) ([04529f3](https://github.com/MorpheApp/morphe-patches/commit/04529f34cc7052b57b1290bf5b1eeeffea3b76b9))
* **YouTube:** Add `Disable playlist autoplay` patch ([#2628](https://github.com/MorpheApp/morphe-patches/issues/2628)) ([7beae7a](https://github.com/MorpheApp/morphe-patches/commit/7beae7afaaba4a00649874033915bd599877ad94))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.35.442` ([#2627](https://github.com/MorpheApp/morphe-patches/issues/2627)) ([4535022](https://github.com/MorpheApp/morphe-patches/commit/453502203ca298c837176995c283502cf8f4adb1))

## [1.41.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.2...v1.41.0-dev.3) (2026-08-28)

### 🐛 Bug Fixes

* **YouTube Music - Theme:** Fade the page header into the background color ([#2636](https://github.com/MorpheApp/morphe-patches/issues/2636)) ([5f5a478](https://github.com/MorpheApp/morphe-patches/commit/5f5a478f7c8670958255b06eeabbfff2e9be4ff0))

### ✨ New Features

* Add `PoToken provider` patch ([#2618](https://github.com/MorpheApp/morphe-patches/issues/2618)) ([fb25ff1](https://github.com/MorpheApp/morphe-patches/commit/fb25ff1fe8270a8a8d003361e17c130c5d422237))
* **YouTube - Disable fullscreen gestures:** Add option to disable pinch-to-zoom ([#2633](https://github.com/MorpheApp/morphe-patches/issues/2633)) ([7b05d2d](https://github.com/MorpheApp/morphe-patches/commit/7b05d2db985232b5dc3bd3a3bcde13e9b4875dbc))
* **YouTube - Hide layout components:** Add "Hide filter bar in channel page" and "Hide 'Members only' chip" settings ([#2622](https://github.com/MorpheApp/morphe-patches/issues/2622)) ([5db5a77](https://github.com/MorpheApp/morphe-patches/commit/5db5a7799d3617b4d93d39ecc42c3d0af58308e8))
* **YouTube:** Add `Mute button` patch ([#2624](https://github.com/MorpheApp/morphe-patches/issues/2624)) ([4c2b3c0](https://github.com/MorpheApp/morphe-patches/commit/4c2b3c040a404bd8661decc31398ca0a343a6768))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.35.0` ([71f8a7f](https://github.com/MorpheApp/morphe-patches/commit/71f8a7fca74e3f008a9879a924f45aae7e5e4052))

## [1.41.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.41.0-dev.1...v1.41.0-dev.2) (2026-08-27)

### 🐛 Bug Fixes

* **Theme:** Prevent an endless activity relaunch loop ([212fc09](https://github.com/MorpheApp/morphe-patches/commit/212fc09a1e8b9048e736a57a9ca3e5c1511896bd))
* **YouTube - Theme:** Some elements keeps the stock color after leaving picture in picture ([#2591](https://github.com/MorpheApp/morphe-patches/issues/2591)) ([a897f41](https://github.com/MorpheApp/morphe-patches/commit/a897f416f708fee55ca394b67fcb8db0160aac9c))

### ✨ New Features

* **YouTube - Wide search bar:** Replace the toggle with Disabled, Wide and Extra wide options ([#2608](https://github.com/MorpheApp/morphe-patches/issues/2608)) ([ce18f82](https://github.com/MorpheApp/morphe-patches/commit/ce18f821225e7c82da6832828e405d56394026fe))
* **YouTube:** Add `Fullscreen video scale` patch ([#2616](https://github.com/MorpheApp/morphe-patches/issues/2616)) ([53815a9](https://github.com/MorpheApp/morphe-patches/commit/53815a9ab88c4595e9e070ce56605584cd7a34e7))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.34.52` ([fea25c2](https://github.com/MorpheApp/morphe-patches/commit/fea25c2c2fb7c20122ad5b9ac893a2733047a804))

## [1.41.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0...v1.41.0-dev.1) (2026-08-26)

### 🐛 Bug Fixes

* **Settings:** Resolve OOM crashes and prevent duplicate dialogs ([047121d](https://github.com/MorpheApp/morphe-patches/commit/047121d9d9001ba56439ce20ac7596e48a415a90))
* **Theme:** "App default" color is drawn pure black instead of the colors of the app ([07c6d35](https://github.com/MorpheApp/morphe-patches/commit/07c6d356de44614842038680639777fc0b010d4e))
* **Theme:** Add new color tokens and Litho hooks ([a7d7520](https://github.com/MorpheApp/morphe-patches/commit/a7d7520f824013816d579a716e67ef6a76102936))
* **Theme:** Morphe dialogs and settings are pure black with the "App default" color ([f5ce706](https://github.com/MorpheApp/morphe-patches/commit/f5ce7061d24097312a06fb0227393a59c730c8f0))
* **Theme:** Splash screen is pure black with the "App default" color ([4a226c7](https://github.com/MorpheApp/morphe-patches/commit/4a226c7d11760c56e10b9ba6ebdf60fdf97c860c))
* **Theme:** Use more compact custom theme palette ([73eab93](https://github.com/MorpheApp/morphe-patches/commit/73eab930902d56ca78ce5b6b40377997fa906140))
* **YouTube - Add to queue:** Flyout menu is too wide and loses the item changes on rotation ([72dbc80](https://github.com/MorpheApp/morphe-patches/commit/72dbc80f74853e491f377dbb11b111b351880362))
* **YouTube - Change form factor:** Prevent tablet layout causing app to crash ([#2600](https://github.com/MorpheApp/morphe-patches/issues/2600)) ([f54d9cd](https://github.com/MorpheApp/morphe-patches/commit/f54d9cd0c86ec3fa960d2505201f323f4766ebd5))
* **YouTube - Hide layout components:** Prevent Library shelves from being hidden ([#2597](https://github.com/MorpheApp/morphe-patches/issues/2597)) ([2d1e542](https://github.com/MorpheApp/morphe-patches/commit/2d1e5428f23a76b8f3ba6d8c84e1148b459ed112))
* **YouTube - Reload video:** Keep pitch/speed after reload ([#2595](https://github.com/MorpheApp/morphe-patches/issues/2595)) ([959597c](https://github.com/MorpheApp/morphe-patches/commit/959597cef9b5ac7ed5342bf64ff3b31da7f7a842))
* **YouTube - Seekbar:** Force newer splash screen animation ([91f937a](https://github.com/MorpheApp/morphe-patches/commit/91f937a83346df0e1361fa11f7e5db422c8ff3d2))
* **YouTube - Theme:** Apply custom theme to drop-down menus ([#2589](https://github.com/MorpheApp/morphe-patches/issues/2589)) ([66765bd](https://github.com/MorpheApp/morphe-patches/commit/66765bde7b0410c41b1dcfb9b052adbb1cec1f27))

### ✨ New Features

* **YouTube - Save to Watch later:** Support for related kids videos ([#2572](https://github.com/MorpheApp/morphe-patches/issues/2572)) ([b0ec540](https://github.com/MorpheApp/morphe-patches/commit/b0ec540b8829864e3fdcda5910edff1fddf1a72a))
* **YouTube:** Add `Disable scrolling speed limit` patch ([#2582](https://github.com/MorpheApp/morphe-patches/issues/2582)) ([162e690](https://github.com/MorpheApp/morphe-patches/commit/162e690df1d4fdf3f0acc2f720586d256c259e22))

## [1.40.0](https://github.com/MorpheApp/morphe-patches/compare/v1.39.1...v1.40.0) (2026-08-24)

### 🐛 Bug Fixes

* **Add to queue:** Error message is shown when adding to queue from certain channels ([e39ff88](https://github.com/MorpheApp/morphe-patches/commit/e39ff884d2f4e81bbda0b99c09b70da2e82de7b3))
* Context is sometimes not set ([e54b364](https://github.com/MorpheApp/morphe-patches/commit/e54b364b8ca1122c77b5d8dc44a04c40d99d1598))
* **Disable Play Store updates:** Change manifest version code but preserve existing internal version code checks ([#2470](https://github.com/MorpheApp/morphe-patches/issues/2470)) ([8fc60e8](https://github.com/MorpheApp/morphe-patches/commit/8fc60e820754cbfa17576623cc7f7a0a9c035fb3))
* **Network proxy:** Avoid platform HTTPS fallback ([#2510](https://github.com/MorpheApp/morphe-patches/issues/2510)) ([bc6c9be](https://github.com/MorpheApp/morphe-patches/commit/bc6c9be001b3ec2aee781fdf8976d27e3cf1851a))
* **Reddit - Hide Trending shelves:** Resolve fingerprint failure ([ea9c443](https://github.com/MorpheApp/morphe-patches/commit/ea9c443b0fd9f34d2a2f0c118564b8042901b9fe))
* **Reddit:** Add legacy app target of `2024.02.0` to allow logging in then upgrading the patched installation ([#2473](https://github.com/MorpheApp/morphe-patches/issues/2473)) ([e7c32bf](https://github.com/MorpheApp/morphe-patches/commit/e7c32bf115d1e3c71a5aed9c370e4bafb282887c))
* **Reddit:** If Google sign-in is attempted then show a popup to instead use email/password to login ([9f0d9f0](https://github.com/MorpheApp/morphe-patches/commit/9f0d9f0e9f4c77accec598db2ed6b405def23f2c))
* **Reddit:** Improve login compatibility ([#2423](https://github.com/MorpheApp/morphe-patches/issues/2423)) ([1344e30](https://github.com/MorpheApp/morphe-patches/commit/1344e30046ef57959bae84a0926a2530686dc8ee))
* **SponsorBlock:** Allow SB user id with curly brackets ([8df4e08](https://github.com/MorpheApp/morphe-patches/commit/8df4e085c0d01ad2d1a16ecedf0e9ff4d5206c3e))
* **Theme:** Apply theme color to foreground text ([#2567](https://github.com/MorpheApp/morphe-patches/issues/2567)) ([64bc593](https://github.com/MorpheApp/morphe-patches/commit/64bc593c5c9659dc2bfb54768a27a7210ef6b30c))
* **Theme:** Change the color of the new content indicator of the top bar ([#2550](https://github.com/MorpheApp/morphe-patches/issues/2550)) ([4f0210b](https://github.com/MorpheApp/morphe-patches/commit/4f0210b0793e37c546ec5a52b59a52f7e98564a9))
* **Theme:** Use only the color resources that the app version declares ([d1e1514](https://github.com/MorpheApp/morphe-patches/commit/d1e1514360649cd56776afb2ab7455d69826a9fd))
* **YouTube - Add to queue:** "Overridde 'Play next in queue' button" not working  ([#2539](https://github.com/MorpheApp/morphe-patches/issues/2539)) ([235d3c6](https://github.com/MorpheApp/morphe-patches/commit/235d3c651fc9b01b80b26269c652b6344b073e8c))
* **YouTube - Add to queue:** Added shorts as flyout video element ([338fc4f](https://github.com/MorpheApp/morphe-patches/commit/338fc4f6697027ada2e5eeced0b38d39c3f0732a))
* **YouTube - Add to queue:** Buttons was shown in wrong panels ([#2396](https://github.com/MorpheApp/morphe-patches/issues/2396)) ([630f31e](https://github.com/MorpheApp/morphe-patches/commit/630f31e319d5e86e1322273d59bf2dcbdf20a7e5))
* **YouTube - Add to queue:** Error toast is shown when using YouTube `20.21.37` ([a1c5aef](https://github.com/MorpheApp/morphe-patches/commit/a1c5aef3bf9f1320f797c74a6caf1e49872a10a4))
* **YouTube - Add to queue:** Fixed some injected buttons related UI issues ([#2387](https://github.com/MorpheApp/morphe-patches/issues/2387)) ([eccae81](https://github.com/MorpheApp/morphe-patches/commit/eccae814937228bda12d46e20005de8533a729bd))
* **YouTube - Add to queue:** Match the flyout menu items to the app's own items ([#2553](https://github.com/MorpheApp/morphe-patches/issues/2553)) ([693a33b](https://github.com/MorpheApp/morphe-patches/commit/693a33b3507d9e0b19c498150884c8cfb0ae524b))
* **YouTube - Captions:** Auto captions do not show when video is unmuted ([#2436](https://github.com/MorpheApp/morphe-patches/issues/2436)) ([e80ce29](https://github.com/MorpheApp/morphe-patches/commit/e80ce29de61169a1ab6b94a6cdec650b35871887))
* **YouTube - FlyoutUtils:** Unified extraction videoId logic and added new litho video element ([a103d4a](https://github.com/MorpheApp/morphe-patches/commit/a103d4af319db5d2eb47f3bb1492154d3afeb495))
* **YouTube - Hide layout components:** Hide hype points in description ([6a398c4](https://github.com/MorpheApp/morphe-patches/commit/6a398c40491bb7f40cb9f5acd5983df371dd051b))
* **YouTube - Hide layout components:** Hide padding when using "Hide horizontal shelves" ([11435a7](https://github.com/MorpheApp/morphe-patches/commit/11435a7e95083aaa36acb63c2e07f3dd8fd446cf))
* **YouTube - Hide layout components:** Hide video recommendation labels only in search results ([a5d7677](https://github.com/MorpheApp/morphe-patches/commit/a5d76773e8d15c7f813380e87e9af8ef8d52be64))
* **YouTube - Hide layout components:** Library filter bar being hidden ([8dd791c](https://github.com/MorpheApp/morphe-patches/commit/8dd791c387f1fa30ce169aa91a08b6aa7a632cda))
* **YouTube - Hide Shorts components:** Shorts filter not working in search results ([2178eb5](https://github.com/MorpheApp/morphe-patches/commit/2178eb5b615996997903c1ba0743d2d03d102f45))
* **YouTube - Miniplayer:** Remove "Default size" setting that YouTube removed in 21.32+ ([30daf1b](https://github.com/MorpheApp/morphe-patches/commit/30daf1bdb9b9e68b7dc59d06a667bd7be0bc7b25))
* **YouTube - Navigation bar:** Merge disable translucent navigation bar/status into a single setting ([#2451](https://github.com/MorpheApp/morphe-patches/issues/2451)) ([652a515](https://github.com/MorpheApp/morphe-patches/commit/652a5153a1f006393a94db95ce5ba873c860bdf9))
* **YouTube - Override YouTube Music buttons:** Resolve intent routing failure ([#2487](https://github.com/MorpheApp/morphe-patches/issues/2487)) ([a8761c2](https://github.com/MorpheApp/morphe-patches/commit/a8761c2efeedb16ecb41dc925f144352c0b5b350))
* **YouTube - Playback speed:** Separate playback speed observations from commands ([#2501](https://github.com/MorpheApp/morphe-patches/issues/2501)) ([a433b29](https://github.com/MorpheApp/morphe-patches/commit/a433b29bf86d6545fc106f4c7d5e8fed7e4e91e9))
* **YouTube - Seekbar thumbnail:** Improved labels visibility ([1e1951f](https://github.com/MorpheApp/morphe-patches/commit/1e1951f530ec8473f9077da13d8b93e8bfc7a864))
* **YouTube - Seekbar thumbnail:** Prevent thumbnail resizing fluctuations ([0ce23bd](https://github.com/MorpheApp/morphe-patches/commit/0ce23bda8c2c0f6d630097e26af000e845e8d40d))
* **YouTube - Seekbar thumbnail:** Reduced heatmap peak point font pad… ([#2564](https://github.com/MorpheApp/morphe-patches/issues/2564)) ([1209b95](https://github.com/MorpheApp/morphe-patches/commit/1209b9544914a84ce621e026aa366de2a6d1dd0b))
* **YouTube - Seekbar thumbnail:** Reduced label font size ([9117e58](https://github.com/MorpheApp/morphe-patches/commit/9117e584ff574932feefd5d1a6c5f85bd58c9607))
* **YouTube - Seekbar thumbnail:** Reduced labels height ([96615e3](https://github.com/MorpheApp/morphe-patches/commit/96615e38c4f67ad369afef56094d02af3efc04c2))
* **YouTube - Seekbar thumbnail:** Removed shadow layer from labels ([737db50](https://github.com/MorpheApp/morphe-patches/commit/737db50a0bb9db5726506b42ad0a36af2d155831))
* **YouTube - Seekbar:** Dynamically set round edges for 'most replayed' label background ([#2462](https://github.com/MorpheApp/morphe-patches/issues/2462)) ([80791b7](https://github.com/MorpheApp/morphe-patches/commit/80791b72d93c4c606a2b87edfc2dc9b7891fd439))
* **YouTube - Swipe controls:** Do not restore the brightness when the player returns from picture in picture ([2deb2a7](https://github.com/MorpheApp/morphe-patches/commit/2deb2a76fdcaa71da1622b7fa18f1f27d78b9a6b))
* **YouTube - Theme:** Add new hex integer to dark values ([ccab8bb](https://github.com/MorpheApp/morphe-patches/commit/ccab8bba1678b29bbab8261bba18a99694e5e9fa))
* **YouTube - Wide search bar:** Use the background color selected in the settings ([abb7441](https://github.com/MorpheApp/morphe-patches/commit/abb7441fcabebc607b98a7fe0116abdc6fdce2b0))
* **YouTube:** Override feature flag that interferes with "Restore old player button style" ([3ff43e5](https://github.com/MorpheApp/morphe-patches/commit/3ff43e54e2aa28311ab575018bafc16997172392))
* **YouTube:** Prevent playback speed/quality UI text from wrapping at large font sizes ([#2403](https://github.com/MorpheApp/morphe-patches/issues/2403)) ([9123870](https://github.com/MorpheApp/morphe-patches/commit/912387021246c9f44312efb4900adfceb8842af4))
* **YouTube:** Shorts are AV1 regardless of HW support ([98e7842](https://github.com/MorpheApp/morphe-patches/commit/98e7842771e2f763f6c38d1b0404142fe6cae334))

### ✨ New Features

* **Reddit:** Disable forced in-app update popup ([#2416](https://github.com/MorpheApp/morphe-patches/issues/2416)) ([e0616a6](https://github.com/MorpheApp/morphe-patches/commit/e0616a69b28a34bc266b338bb2973a7104d280d9))
* **Spoof video streams:** Default client maintenance ([#2479](https://github.com/MorpheApp/morphe-patches/issues/2479)) ([62c6a35](https://github.com/MorpheApp/morphe-patches/commit/62c6a351b5313ba9068c62306129ec0dfef29e5e))
* **Spoof video streams:** Makes `TV Simply` available in signed-out or incognito mode by generating a PoToken ([#2533](https://github.com/MorpheApp/morphe-patches/issues/2533)) ([c9a1622](https://github.com/MorpheApp/morphe-patches/commit/c9a1622f047ea33b7cf18544bb88975d4bf0a796))
* **Theme:** Add a patch option to permanently set the app background color ([#2568](https://github.com/MorpheApp/morphe-patches/issues/2568)) ([7166721](https://github.com/MorpheApp/morphe-patches/commit/71667215acf495be2cfebf1cb11afda6a6a892e9))
* **Theme:** Change the app background color from the app settings ([#2524](https://github.com/MorpheApp/morphe-patches/issues/2524)) ([4d89ab2](https://github.com/MorpheApp/morphe-patches/commit/4d89ab2f7b456f05b79ec79c006da51535a35168))
* **YouTube - Background playback:** Prevent paused videos from auto-resuming after returning to app ([b2799ae](https://github.com/MorpheApp/morphe-patches/commit/b2799ae73d4bba329e87e9db39029ad8b87ca129))
* **YouTube - Hide layout components:** Add "Hide live chat tooltips" setting  ([#2463](https://github.com/MorpheApp/morphe-patches/issues/2463)) ([9f95b8e](https://github.com/MorpheApp/morphe-patches/commit/9f95b8ee3ff8fbec1176f7b82e78db23ae7d5548))
* **YouTube - Hide layout components:** Add "Hide Notifications menu header" setting ([#2445](https://github.com/MorpheApp/morphe-patches/issues/2445)) ([2fd2eb5](https://github.com/MorpheApp/morphe-patches/commit/2fd2eb5ab6ee3577a3e61d144d57827fc84fa51d))
* **YouTube - Playback speed:** Add "Default playback audio pitch" setting ([#2282](https://github.com/MorpheApp/morphe-patches/issues/2282)) ([2f5efc1](https://github.com/MorpheApp/morphe-patches/commit/2f5efc1ae48894fc609b7ea2bdc87074a8e85ba3))
* **YouTube - Seekbar thumbnail:** Added most watched section marker during seeking ([5752c7e](https://github.com/MorpheApp/morphe-patches/commit/5752c7e2ab5971476155da171cea73c269a47cd2))
* **YouTube - Swipe control:** Redesign swipe control action settings ([#2368](https://github.com/MorpheApp/morphe-patches/issues/2368)) ([f7196f7](https://github.com/MorpheApp/morphe-patches/commit/f7196f790c89196154be720ab9620122081a8a6d))
* **YouTube - Swipe controls:** Add "Ignore swipes when locked" setting ([#2469](https://github.com/MorpheApp/morphe-patches/issues/2469)) ([1fce673](https://github.com/MorpheApp/morphe-patches/commit/1fce673271bde7033fef98814f4704e7187e450d))
* **YouTube - Swipe controls:** Support swipe controls in split-screen ([#2503](https://github.com/MorpheApp/morphe-patches/issues/2503)) ([f2b04c2](https://github.com/MorpheApp/morphe-patches/commit/f2b04c22f3e1b7d386704db2089d2af9c3309889))
* **YouTube - Theme:** Draw the splash screen with the selected background color ([#2543](https://github.com/MorpheApp/morphe-patches/issues/2543)) ([fb3302d](https://github.com/MorpheApp/morphe-patches/commit/fb3302d54724ca97e8e753ffdbae111a0c55beb7))
* **YouTube:** Add "Add-on support" patch for third party patch bundles ([#2295](https://github.com/MorpheApp/morphe-patches/issues/2295)) ([ab81287](https://github.com/MorpheApp/morphe-patches/commit/ab81287f7b1cdb7af13036beba28886e4016c78a))
* **YouTube:** Add "Back button exits the feed" setting ([#2488](https://github.com/MorpheApp/morphe-patches/issues/2488)) ([fe8e03c](https://github.com/MorpheApp/morphe-patches/commit/fe8e03cc67266e022a46c281e3962eaf7a253b14))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.32.0` ([#2405](https://github.com/MorpheApp/morphe-patches/issues/2405)) ([7149c54](https://github.com/MorpheApp/morphe-patches/commit/7149c5463e7873c3e421a99b9551ee1b8308684c))
* **Reddit:** Add experimental support for `2026.34.0` ([260f6d3](https://github.com/MorpheApp/morphe-patches/commit/260f6d32b7fae753c93e08e37cd727a33c6c4eac))
* **YouTube Music:** Add experimental support for `9.31.51` ([bbd6f5b](https://github.com/MorpheApp/morphe-patches/commit/bbd6f5bde6af737adf2752b98c7ff9a9e3385bb9))
* **YouTube Music:** Add experimental support for `9.32.51` ([#2458](https://github.com/MorpheApp/morphe-patches/issues/2458)) ([9b280d0](https://github.com/MorpheApp/morphe-patches/commit/9b280d07e344944db4ae03b3a8d84c71b05d17c1))
* **YouTube Music:** Add experimental support for `9.33.52` ([2e7fe4c](https://github.com/MorpheApp/morphe-patches/commit/2e7fe4cbf8ca42a07dce812c181cc8d1a1511014))
* **YouTube:** Add experimental support for `21.33.321` ([2cfc72b](https://github.com/MorpheApp/morphe-patches/commit/2cfc72b77e66a6b3c57d771f547ee87177f80183))
* **YouTube:** Add experimental support for `21.34.243` ([50ba5d6](https://github.com/MorpheApp/morphe-patches/commit/50ba5d6d4f0f1d5f72747d13740319ea5dca8eca))

## [1.40.0-dev.23](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.22...v1.40.0-dev.23) (2026-08-24)

### 🐛 Bug Fixes

* **Add to queue:** Error message is shown when adding to queue from certain channels ([e39ff88](https://github.com/MorpheApp/morphe-patches/commit/e39ff884d2f4e81bbda0b99c09b70da2e82de7b3))
* **YouTube - Theme:** Add new hex integer to dark values ([ccab8bb](https://github.com/MorpheApp/morphe-patches/commit/ccab8bba1678b29bbab8261bba18a99694e5e9fa))

## [1.40.0-dev.22](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.21...v1.40.0-dev.22) (2026-08-24)

### 🐛 Bug Fixes

* **Theme:** Apply theme color to foreground text ([#2567](https://github.com/MorpheApp/morphe-patches/issues/2567)) ([64bc593](https://github.com/MorpheApp/morphe-patches/commit/64bc593c5c9659dc2bfb54768a27a7210ef6b30c))

### ✨ New Features

* **Theme:** Add a patch option to permanently set the app background color ([#2568](https://github.com/MorpheApp/morphe-patches/issues/2568)) ([7166721](https://github.com/MorpheApp/morphe-patches/commit/71667215acf495be2cfebf1cb11afda6a6a892e9))

## [1.40.0-dev.21](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.20...v1.40.0-dev.21) (2026-08-23)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Match the flyout menu items to the app's own items ([#2553](https://github.com/MorpheApp/morphe-patches/issues/2553)) ([693a33b](https://github.com/MorpheApp/morphe-patches/commit/693a33b3507d9e0b19c498150884c8cfb0ae524b))

## [1.40.0-dev.20](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.19...v1.40.0-dev.20) (2026-08-23)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Unified extraction videoId logic and added new litho video element ([a103d4a](https://github.com/MorpheApp/morphe-patches/commit/a103d4af319db5d2eb47f3bb1492154d3afeb495))
* **YouTube - Seekbar thumbnail:** Reduced heatmap peak point font pad… ([#2564](https://github.com/MorpheApp/morphe-patches/issues/2564)) ([1209b95](https://github.com/MorpheApp/morphe-patches/commit/1209b9544914a84ce621e026aa366de2a6d1dd0b))

## [1.40.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.18...v1.40.0-dev.19) (2026-08-22)

### 🐛 Bug Fixes

* Context is sometimes not set ([e54b364](https://github.com/MorpheApp/morphe-patches/commit/e54b364b8ca1122c77b5d8dc44a04c40d99d1598))
* **Theme:** Change the color of the new content indicator of the top bar ([#2550](https://github.com/MorpheApp/morphe-patches/issues/2550)) ([4f0210b](https://github.com/MorpheApp/morphe-patches/commit/4f0210b0793e37c546ec5a52b59a52f7e98564a9))

## [1.40.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.17...v1.40.0-dev.18) (2026-08-22)

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.34.243` ([50ba5d6](https://github.com/MorpheApp/morphe-patches/commit/50ba5d6d4f0f1d5f72747d13740319ea5dca8eca))

## [1.40.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.16...v1.40.0-dev.17) (2026-08-22)

### ✨ New Features

* **YouTube - Theme:** Draw the splash screen with the selected background color ([#2543](https://github.com/MorpheApp/morphe-patches/issues/2543)) ([fb3302d](https://github.com/MorpheApp/morphe-patches/commit/fb3302d54724ca97e8e753ffdbae111a0c55beb7))

## [1.40.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.15...v1.40.0-dev.16) (2026-08-21)

### 🐛 Bug Fixes

* **Theme:** Use only the color resources that the app version declares ([d1e1514](https://github.com/MorpheApp/morphe-patches/commit/d1e1514360649cd56776afb2ab7455d69826a9fd))
* **YouTube - Add to queue:** "Overridde 'Play next in queue' button" not working  ([#2539](https://github.com/MorpheApp/morphe-patches/issues/2539)) ([235d3c6](https://github.com/MorpheApp/morphe-patches/commit/235d3c651fc9b01b80b26269c652b6344b073e8c))
* **YouTube - Swipe controls:** Do not restore the brightness when the player returns from picture in picture ([2deb2a7](https://github.com/MorpheApp/morphe-patches/commit/2deb2a76fdcaa71da1622b7fa18f1f27d78b9a6b))
* **YouTube - Wide search bar:** Use the background color selected in the settings ([abb7441](https://github.com/MorpheApp/morphe-patches/commit/abb7441fcabebc607b98a7fe0116abdc6fdce2b0))

## [1.40.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.14...v1.40.0-dev.15) (2026-08-21)

### ✨ New Features

* **Spoof video streams:** Makes `TV Simply` available in signed-out or incognito mode by generating a PoToken ([#2533](https://github.com/MorpheApp/morphe-patches/issues/2533)) ([c9a1622](https://github.com/MorpheApp/morphe-patches/commit/c9a1622f047ea33b7cf18544bb88975d4bf0a796))
* **Theme:** Change the app background color from the app settings ([#2524](https://github.com/MorpheApp/morphe-patches/issues/2524)) ([4d89ab2](https://github.com/MorpheApp/morphe-patches/commit/4d89ab2f7b456f05b79ec79c006da51535a35168))

## [1.40.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.13...v1.40.0-dev.14) (2026-08-21)

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.34.0` ([260f6d3](https://github.com/MorpheApp/morphe-patches/commit/260f6d32b7fae753c93e08e37cd727a33c6c4eac))

## [1.40.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.12...v1.40.0-dev.13) (2026-08-20)

### 🐛 Bug Fixes

* **Network proxy:** Avoid platform HTTPS fallback ([#2510](https://github.com/MorpheApp/morphe-patches/issues/2510)) ([bc6c9be](https://github.com/MorpheApp/morphe-patches/commit/bc6c9be001b3ec2aee781fdf8976d27e3cf1851a))
* **YouTube - Captions:** Auto captions do not show when video is unmuted ([#2436](https://github.com/MorpheApp/morphe-patches/issues/2436)) ([e80ce29](https://github.com/MorpheApp/morphe-patches/commit/e80ce29de61169a1ab6b94a6cdec650b35871887))
* **YouTube - Seekbar thumbnail:** Reduced label font size ([9117e58](https://github.com/MorpheApp/morphe-patches/commit/9117e584ff574932feefd5d1a6c5f85bd58c9607))
* **YouTube - Seekbar thumbnail:** Reduced labels height ([96615e3](https://github.com/MorpheApp/morphe-patches/commit/96615e38c4f67ad369afef56094d02af3efc04c2))
* **YouTube - Seekbar thumbnail:** Removed shadow layer from labels ([737db50](https://github.com/MorpheApp/morphe-patches/commit/737db50a0bb9db5726506b42ad0a36af2d155831))
* **YouTube:** Override feature flag that interferes with "Restore old player button style" ([3ff43e5](https://github.com/MorpheApp/morphe-patches/commit/3ff43e54e2aa28311ab575018bafc16997172392))

### ✨ New Features

* **YouTube - Swipe controls:** Support swipe controls in split-screen ([#2503](https://github.com/MorpheApp/morphe-patches/issues/2503)) ([f2b04c2](https://github.com/MorpheApp/morphe-patches/commit/f2b04c22f3e1b7d386704db2089d2af9c3309889))

## [1.40.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.11...v1.40.0-dev.12) (2026-08-19)

### 🐛 Bug Fixes

* **Reddit - Hide Trending shelves:** Resolve fingerprint failure ([ea9c443](https://github.com/MorpheApp/morphe-patches/commit/ea9c443b0fd9f34d2a2f0c118564b8042901b9fe))

### ✨ New Features

* **Spoof video streams:** Default client maintenance ([#2479](https://github.com/MorpheApp/morphe-patches/issues/2479)) ([62c6a35](https://github.com/MorpheApp/morphe-patches/commit/62c6a351b5313ba9068c62306129ec0dfef29e5e))

## [1.40.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.10...v1.40.0-dev.11) (2026-08-19)

### 🐛 Bug Fixes

* **SponsorBlock:** Allow SB user id with curly brackets ([8df4e08](https://github.com/MorpheApp/morphe-patches/commit/8df4e085c0d01ad2d1a16ecedf0e9ff4d5206c3e))
* **YouTube - Playback speed:** Separate playback speed observations from commands ([#2501](https://github.com/MorpheApp/morphe-patches/issues/2501)) ([a433b29](https://github.com/MorpheApp/morphe-patches/commit/a433b29bf86d6545fc106f4c7d5e8fed7e4e91e9))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.33.52` ([2e7fe4c](https://github.com/MorpheApp/morphe-patches/commit/2e7fe4cbf8ca42a07dce812c181cc8d1a1511014))

## [1.40.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.9...v1.40.0-dev.10) (2026-08-18)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Error toast is shown when using YouTube `20.21.37` ([a1c5aef](https://github.com/MorpheApp/morphe-patches/commit/a1c5aef3bf9f1320f797c74a6caf1e49872a10a4))
* **YouTube - Override YouTube Music buttons:** Resolve intent routing failure ([#2487](https://github.com/MorpheApp/morphe-patches/issues/2487)) ([a8761c2](https://github.com/MorpheApp/morphe-patches/commit/a8761c2efeedb16ecb41dc925f144352c0b5b350))

### ✨ New Features

* **YouTube:** Add "Back button exits the feed" setting ([#2488](https://github.com/MorpheApp/morphe-patches/issues/2488)) ([fe8e03c](https://github.com/MorpheApp/morphe-patches/commit/fe8e03cc67266e022a46c281e3962eaf7a253b14))

## [1.40.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.8...v1.40.0-dev.9) (2026-08-18)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide hype points in description ([6a398c4](https://github.com/MorpheApp/morphe-patches/commit/6a398c40491bb7f40cb9f5acd5983df371dd051b))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.32.51` ([#2458](https://github.com/MorpheApp/morphe-patches/issues/2458)) ([9b280d0](https://github.com/MorpheApp/morphe-patches/commit/9b280d07e344944db4ae03b3a8d84c71b05d17c1))

## [1.40.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.7...v1.40.0-dev.8) (2026-08-17)

### 🐛 Bug Fixes

* **Disable Play Store updates:** Change manifest version code but preserve existing internal version code checks ([#2470](https://github.com/MorpheApp/morphe-patches/issues/2470)) ([8fc60e8](https://github.com/MorpheApp/morphe-patches/commit/8fc60e820754cbfa17576623cc7f7a0a9c035fb3))
* **Reddit:** Add legacy app target of `2024.02.0` to allow logging in then upgrading the patched installation ([#2473](https://github.com/MorpheApp/morphe-patches/issues/2473)) ([e7c32bf](https://github.com/MorpheApp/morphe-patches/commit/e7c32bf115d1e3c71a5aed9c370e4bafb282887c))
* **YouTube - Seekbar:** Dynamically set round edges for 'most replayed' label background ([#2462](https://github.com/MorpheApp/morphe-patches/issues/2462)) ([80791b7](https://github.com/MorpheApp/morphe-patches/commit/80791b72d93c4c606a2b87edfc2dc9b7891fd439))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide live chat tooltips" setting  ([#2463](https://github.com/MorpheApp/morphe-patches/issues/2463)) ([9f95b8e](https://github.com/MorpheApp/morphe-patches/commit/9f95b8ee3ff8fbec1176f7b82e78db23ae7d5548))
* **YouTube - Hide layout components:** Add "Hide Notifications menu header" setting ([#2445](https://github.com/MorpheApp/morphe-patches/issues/2445)) ([2fd2eb5](https://github.com/MorpheApp/morphe-patches/commit/2fd2eb5ab6ee3577a3e61d144d57827fc84fa51d))
* **YouTube - Swipe controls:** Add "Ignore swipes when locked" setting ([#2469](https://github.com/MorpheApp/morphe-patches/issues/2469)) ([1fce673](https://github.com/MorpheApp/morphe-patches/commit/1fce673271bde7033fef98814f4704e7187e450d))

## [1.40.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.6...v1.40.0-dev.7) (2026-08-15)

### 🐛 Bug Fixes

* **Reddit:** Improve login compatibility ([#2423](https://github.com/MorpheApp/morphe-patches/issues/2423)) ([1344e30](https://github.com/MorpheApp/morphe-patches/commit/1344e30046ef57959bae84a0926a2530686dc8ee))
* **YouTube - Hide layout components:** Hide padding when using "Hide horizontal shelves" ([11435a7](https://github.com/MorpheApp/morphe-patches/commit/11435a7e95083aaa36acb63c2e07f3dd8fd446cf))
* **YouTube - Navigation bar:** Merge disable translucent navigation bar/status into a single setting ([#2451](https://github.com/MorpheApp/morphe-patches/issues/2451)) ([652a515](https://github.com/MorpheApp/morphe-patches/commit/652a5153a1f006393a94db95ce5ba873c860bdf9))
* **YouTube - Seekbar thumbnail:** Improved labels visibility ([1e1951f](https://github.com/MorpheApp/morphe-patches/commit/1e1951f530ec8473f9077da13d8b93e8bfc7a864))
* **YouTube - Seekbar thumbnail:** Prevent thumbnail resizing fluctuations ([0ce23bd](https://github.com/MorpheApp/morphe-patches/commit/0ce23bda8c2c0f6d630097e26af000e845e8d40d))

### ✨ New Features

* **YouTube - Swipe control:** Redesign swipe control action settings ([#2368](https://github.com/MorpheApp/morphe-patches/issues/2368)) ([f7196f7](https://github.com/MorpheApp/morphe-patches/commit/f7196f790c89196154be720ab9620122081a8a6d))

## [1.40.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.5...v1.40.0-dev.6) (2026-08-14)

### 🐛 Bug Fixes

* **Reddit:** If Google sign-in is attempted then show a popup to instead use email/password to login ([9f0d9f0](https://github.com/MorpheApp/morphe-patches/commit/9f0d9f0e9f4c77accec598db2ed6b405def23f2c))
* **YouTube - Hide layout components:** Hide video recommendation labels only in search results ([a5d7677](https://github.com/MorpheApp/morphe-patches/commit/a5d76773e8d15c7f813380e87e9af8ef8d52be64))
* **YouTube - Hide layout components:** Library filter bar being hidden ([8dd791c](https://github.com/MorpheApp/morphe-patches/commit/8dd791c387f1fa30ce169aa91a08b6aa7a632cda))
* **YouTube - Hide Shorts components:** Shorts filter not working in search results ([2178eb5](https://github.com/MorpheApp/morphe-patches/commit/2178eb5b615996997903c1ba0743d2d03d102f45))
* **YouTube:** Shorts are AV1 regardless of HW support ([98e7842](https://github.com/MorpheApp/morphe-patches/commit/98e7842771e2f763f6c38d1b0404142fe6cae334))

### ✨ New Features

* **YouTube - Background playback:** Prevent paused videos from auto-resuming after returning to app ([b2799ae](https://github.com/MorpheApp/morphe-patches/commit/b2799ae73d4bba329e87e9db39029ad8b87ca129))
* **YouTube - Playback speed:** Add "Default playback audio pitch" setting ([#2282](https://github.com/MorpheApp/morphe-patches/issues/2282)) ([2f5efc1](https://github.com/MorpheApp/morphe-patches/commit/2f5efc1ae48894fc609b7ea2bdc87074a8e85ba3))

## [1.40.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.4...v1.40.0-dev.5) (2026-08-13)

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.33.321` ([2cfc72b](https://github.com/MorpheApp/morphe-patches/commit/2cfc72b77e66a6b3c57d771f547ee87177f80183))

## [1.40.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.3...v1.40.0-dev.4) (2026-08-12)

### ✨ New Features

* **Reddit:** Disable forced in-app update popup ([#2416](https://github.com/MorpheApp/morphe-patches/issues/2416)) ([e0616a6](https://github.com/MorpheApp/morphe-patches/commit/e0616a69b28a34bc266b338bb2973a7104d280d9))
* **YouTube - Seekbar thumbnail:** Added most watched section marker during seeking ([5752c7e](https://github.com/MorpheApp/morphe-patches/commit/5752c7e2ab5971476155da171cea73c269a47cd2))

## [1.40.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.2...v1.40.0-dev.3) (2026-08-11)

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.32.0` ([#2405](https://github.com/MorpheApp/morphe-patches/issues/2405)) ([7149c54](https://github.com/MorpheApp/morphe-patches/commit/7149c5463e7873c3e421a99b9551ee1b8308684c))

## [1.40.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.40.0-dev.1...v1.40.0-dev.2) (2026-08-10)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Added shorts as flyout video element ([338fc4f](https://github.com/MorpheApp/morphe-patches/commit/338fc4f6697027ada2e5eeced0b38d39c3f0732a))
* **YouTube:** Prevent playback speed/quality UI text from wrapping at large font sizes ([#2403](https://github.com/MorpheApp/morphe-patches/issues/2403)) ([9123870](https://github.com/MorpheApp/morphe-patches/commit/912387021246c9f44312efb4900adfceb8842af4))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.31.51` ([bbd6f5b](https://github.com/MorpheApp/morphe-patches/commit/bbd6f5bde6af737adf2752b98c7ff9a9e3385bb9))

## [1.40.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.39.1...v1.40.0-dev.1) (2026-08-09)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Buttons was shown in wrong panels ([#2396](https://github.com/MorpheApp/morphe-patches/issues/2396)) ([630f31e](https://github.com/MorpheApp/morphe-patches/commit/630f31e319d5e86e1322273d59bf2dcbdf20a7e5))
* **YouTube - Add to queue:** Fixed some injected buttons related UI issues ([#2387](https://github.com/MorpheApp/morphe-patches/issues/2387)) ([eccae81](https://github.com/MorpheApp/morphe-patches/commit/eccae814937228bda12d46e20005de8533a729bd))
* **YouTube - Miniplayer:** Remove "Default size" setting that YouTube removed in 21.32+ ([30daf1b](https://github.com/MorpheApp/morphe-patches/commit/30daf1bdb9b9e68b7dc59d06a667bd7be0bc7b25))

## [1.39.1](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0...v1.39.1) (2026-08-08)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Flyout menu not available in fullscreen ([b270824](https://github.com/MorpheApp/morphe-patches/commit/b270824072a4fc0f8df758ab48ca8090c3965323))

## [1.39.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0...v1.39.1-dev.1) (2026-08-08)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Flyout menu not available in fullscreen ([b270824](https://github.com/MorpheApp/morphe-patches/commit/b270824072a4fc0f8df758ab48ca8090c3965323))

## [1.39.0](https://github.com/MorpheApp/morphe-patches/compare/v1.38.0...v1.39.0) (2026-08-08)

### 🐛 Bug Fixes

* **Reddit:** Morphe settings menu is not localized for experimental app targets ([fefa59b](https://github.com/MorpheApp/morphe-patches/commit/fefa59b9534c2858b6b90c0a1ba7a69d70848b9a))
* **Reddit:** Show Morphe in-app settings with Reddit 2026.25.0+ ([#2260](https://github.com/MorpheApp/morphe-patches/issues/2260)) ([ec780c5](https://github.com/MorpheApp/morphe-patches/commit/ec780c5975f9ef3c4e578fff90ad09ba293e9b8e))
* Rename `Change package name` to `Clone app` ([#2347](https://github.com/MorpheApp/morphe-patches/issues/2347)) ([efd4d01](https://github.com/MorpheApp/morphe-patches/commit/efd4d01fe822b6b7f8d58147f6363e09bc89d335))
* **Spoof video streams:** Restore missing YT method ([#2362](https://github.com/MorpheApp/morphe-patches/issues/2362)) ([23c1d7c](https://github.com/MorpheApp/morphe-patches/commit/23c1d7c2bc3672dec481aca835aa5c6d4127fc88))
* **YouTube - Add to queue:** Improved "Add feed flyout queue menu item" UI ([69701d7](https://github.com/MorpheApp/morphe-patches/commit/69701d7e3c7652ad483448f95380d2e101192400))
* **YouTube - Disable fullscreen gestures:** Disable feature flag to restore zoom functionality ([#2292](https://github.com/MorpheApp/morphe-patches/issues/2292)) ([4413218](https://github.com/MorpheApp/morphe-patches/commit/44132182e2b148486ea72dd5d849e8dadb1520dd))
* **YouTube - Disable sign in to TV popup:** Add support for newer versions ([#2226](https://github.com/MorpheApp/morphe-patches/issues/2226)) ([96716ef](https://github.com/MorpheApp/morphe-patches/commit/96716efdf6f7ddcf05a6cf642df88804e99af487))
* **YouTube - DRC audio:** Patch doesn't work on last experimental versions. ([65c5816](https://github.com/MorpheApp/morphe-patches/commit/65c581662a72ccba9f28923a9ada8564f238c310))
* **YouTube - Hide layout components:** Hide trending hashtags ([7f375cc](https://github.com/MorpheApp/morphe-patches/commit/7f375ccf058f5782d0533743f5a06c6d649dbf0e))
* **YouTube - Seekbar thumbnail:** Hide thumbnail during precise seeking ([9f5848a](https://github.com/MorpheApp/morphe-patches/commit/9f5848a0120e6b472d59442d1a1e94a762b60d50))
* **YouTube - Seekbar thumbnail:** Show slide-to-seek thumbnail when option is enabled ([174c4e6](https://github.com/MorpheApp/morphe-patches/commit/174c4e62f2c03fa5a673bff095d82b1475f8b82c))
* **YouTube - Seekbar:** Fix patching older app targets ([0b3c42c](https://github.com/MorpheApp/morphe-patches/commit/0b3c42ce100046b0d5b99b9e110dcbeb6ad26aba))
* **YouTube - Seekbar:** Show Shorts seekbar thumbnails ([bd648dc](https://github.com/MorpheApp/morphe-patches/commit/bd648dc703685987d493c54c95524795a9faaa25))
* **YouTube Music - Disable DRC audio:** Fix patching experimental app versions ([04aed07](https://github.com/MorpheApp/morphe-patches/commit/04aed073ee4829fbac26c597a62ebbc1a524f588))
* **YouTube Music - Hide layout components:** Remove "Hide 'Suggested for you' shelf" setting as it hides playlist content ([c279c40](https://github.com/MorpheApp/morphe-patches/commit/c279c4054ffbb004594bc1066bb234aa0f8624b5))
* **YouTube Music - Spoof app version:** Add spoof targets `8.23.51` and `9.13.51`, remove 6.x and 7.x targets that YT is shutting down support for ([74e4b1d](https://github.com/MorpheApp/morphe-patches/commit/74e4b1daae905301fc9ea9590de42637854a324e))
* **YouTube Music - Third-party lyrics:** Do not cover the comments and live chat panels ([5e3eb4c](https://github.com/MorpheApp/morphe-patches/commit/5e3eb4cf492abd7524f787ffce11f02f1803869b))
* **YouTube Music:** Remove `7.29.52` app target that YouTube no longer supports ([8b453db](https://github.com/MorpheApp/morphe-patches/commit/8b453dbfe30d695458d913808c8a4bc2a6813ed4))
* **YouTube:** Prevent chapter titles from being truncated ([#2352](https://github.com/MorpheApp/morphe-patches/issues/2352)) ([1609eb1](https://github.com/MorpheApp/morphe-patches/commit/1609eb113d5ed1081205ce58bf7ae566531dcdfe))
* **YouTube:** Remove "Restore old YouTube settings screen" from 21.30+ targets ([51c0af2](https://github.com/MorpheApp/morphe-patches/commit/51c0af26c9d3e2c7c351a3ce521a0e4a404d60e8))

### ✨ New Features

* **Spoof video streams:** Add 'TVHTML5 DASH' as a temporary workaround for 'TVHTML5 SABR' (playback issues in livestreams) ([173a925](https://github.com/MorpheApp/morphe-patches/commit/173a9253cf3e93d5234682ddb6031092b91b2853))
* **Spoof video streams:** Default client maintenance ([#2309](https://github.com/MorpheApp/morphe-patches/issues/2309)) ([e86d61f](https://github.com/MorpheApp/morphe-patches/commit/e86d61f5d874d57f72fac9b8c0c534a89f264ca4))
* **YouTube - Add to queue:** Add "Add feed flyout queue menu item" setting ([#2333](https://github.com/MorpheApp/morphe-patches/issues/2333)) ([1c54df8](https://github.com/MorpheApp/morphe-patches/commit/1c54df894a7836c5c3764cef5eb5f14e8af5fcd5))
* **YouTube - Disable sign in to TV popup:** Add "Disable 'Connect your devices' popup" setting ([#2325](https://github.com/MorpheApp/morphe-patches/issues/2325)) ([8b8837e](https://github.com/MorpheApp/morphe-patches/commit/8b8837eb3f0450d5c89eb59912fa1a84dd555dbf))
* **YouTube - Hide layout components:** Add "Hide 'Invite others to message' card" setting ([#2304](https://github.com/MorpheApp/morphe-patches/issues/2304)) ([b582e75](https://github.com/MorpheApp/morphe-patches/commit/b582e757c5d93a4d7e68f10688a399963d0360bd))
* **YouTube - Hide layout components:** Add "Hide Chapters and 'In this video' button" setting ([#2354](https://github.com/MorpheApp/morphe-patches/issues/2354)) ([ec15b89](https://github.com/MorpheApp/morphe-patches/commit/ec15b89a9a7e33caf43f7e95a17bc771dc37ba8b))
* **YouTube - Hide layout components:** Add "Hide Learning menu" and "Hide 'How YouTube works' menu" settings ([997f433](https://github.com/MorpheApp/morphe-patches/commit/997f4337cff8e1ba7c6bd4e36f61589e3db0e97e))
* **YouTube - Hide layout components:** Add "Hide player gesture hints" setting ([#2328](https://github.com/MorpheApp/morphe-patches/issues/2328)) ([588b8c0](https://github.com/MorpheApp/morphe-patches/commit/588b8c0f41bac446d1479d60bf632d88762cb057))
* **YouTube - Hide Shorts components:** Add "Hide Save button" setting ([#2363](https://github.com/MorpheApp/morphe-patches/issues/2363)) ([12846cb](https://github.com/MorpheApp/morphe-patches/commit/12846cb75497d52562bed0d4feb163f1c35bbcc0))
* **YouTube Music:** Add `Remove viewer discretion dialog` patch ([#2297](https://github.com/MorpheApp/morphe-patches/issues/2297)) ([f0d3ba1](https://github.com/MorpheApp/morphe-patches/commit/f0d3ba149d81f72680b571ce596eabdd8990c572))
* **YouTube Music:** Add `Third-party lyrics` patch ([#2269](https://github.com/MorpheApp/morphe-patches/issues/2269)) ([fbf2e63](https://github.com/MorpheApp/morphe-patches/commit/fbf2e63d66be9baa4d825d986ab405a679b96df0))
* **YouTube:** Add `Playback in feeds` patch ([#2261](https://github.com/MorpheApp/morphe-patches/issues/2261)) ([fced431](https://github.com/MorpheApp/morphe-patches/commit/fced4313f612031bfea7d15fe341e80a7c3e4567))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.30.0` ([f8dbf83](https://github.com/MorpheApp/morphe-patches/commit/f8dbf83a99508b3e08beb0e6061af7f1fb6880ca))
* **Reddit:** Add experimental support for `2026.31.0` ([2f3df14](https://github.com/MorpheApp/morphe-patches/commit/2f3df146415cc407220499fcc7bea60378940b5d))
* **Reddit:** Add experimental support for `2026.31.1` ([7bf92f4](https://github.com/MorpheApp/morphe-patches/commit/7bf92f4f4ead5f28d95ff06452e1d1af376628d9))
* **YouTube:** Add experimental support for `21.31.523` ([#2207](https://github.com/MorpheApp/morphe-patches/issues/2207)) ([061663b](https://github.com/MorpheApp/morphe-patches/commit/061663b85b76f0aabe9337de8d84970d4ca406b5))
* **YouTube:** Add experimental support for `21.32.2` ([adc044b](https://github.com/MorpheApp/morphe-patches/commit/adc044bcb75ac3270cf04f778e230c2c80b24841))

## [1.39.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.10...v1.39.0-dev.11) (2026-08-08)

### 🐛 Bug Fixes

* Rename `Change package name` to `Clone app` ([#2347](https://github.com/MorpheApp/morphe-patches/issues/2347)) ([efd4d01](https://github.com/MorpheApp/morphe-patches/commit/efd4d01fe822b6b7f8d58147f6363e09bc89d335))
* **Spoof video streams:** Restore missing YT method ([#2362](https://github.com/MorpheApp/morphe-patches/issues/2362)) ([23c1d7c](https://github.com/MorpheApp/morphe-patches/commit/23c1d7c2bc3672dec481aca835aa5c6d4127fc88))
* **YouTube - Add to queue:** Improved "Add feed flyout queue menu item" UI ([69701d7](https://github.com/MorpheApp/morphe-patches/commit/69701d7e3c7652ad483448f95380d2e101192400))

### ✨ New Features

* **Spoof video streams:** Add 'TVHTML5 DASH' as a temporary workaround for 'TVHTML5 SABR' (playback issues in livestreams) ([173a925](https://github.com/MorpheApp/morphe-patches/commit/173a9253cf3e93d5234682ddb6031092b91b2853))
* **YouTube - Hide Shorts components:** Add "Hide Save button" setting ([#2363](https://github.com/MorpheApp/morphe-patches/issues/2363)) ([12846cb](https://github.com/MorpheApp/morphe-patches/commit/12846cb75497d52562bed0d4feb163f1c35bbcc0))

## [1.39.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.9...v1.39.0-dev.10) (2026-08-07)

### 🐛 Bug Fixes

* **YouTube:** Prevent chapter titles from being truncated ([#2352](https://github.com/MorpheApp/morphe-patches/issues/2352)) ([1609eb1](https://github.com/MorpheApp/morphe-patches/commit/1609eb113d5ed1081205ce58bf7ae566531dcdfe))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.32.2` ([adc044b](https://github.com/MorpheApp/morphe-patches/commit/adc044bcb75ac3270cf04f778e230c2c80b24841))

## [1.39.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.8...v1.39.0-dev.9) (2026-08-07)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Hide trending hashtags ([7f375cc](https://github.com/MorpheApp/morphe-patches/commit/7f375ccf058f5782d0533743f5a06c6d649dbf0e))
* **YouTube Music - Spoof app version:** Add spoof targets `8.23.51` and `9.13.51`, remove 6.x and 7.x targets that YT is shutting down support for ([74e4b1d](https://github.com/MorpheApp/morphe-patches/commit/74e4b1daae905301fc9ea9590de42637854a324e))
* **YouTube Music:** Remove `7.29.52` app target that YouTube no longer supports ([8b453db](https://github.com/MorpheApp/morphe-patches/commit/8b453dbfe30d695458d913808c8a4bc2a6813ed4))

### ✨ New Features

* **YouTube - Add to queue:** Add "Add feed flyout queue menu item" setting ([#2333](https://github.com/MorpheApp/morphe-patches/issues/2333)) ([1c54df8](https://github.com/MorpheApp/morphe-patches/commit/1c54df894a7836c5c3764cef5eb5f14e8af5fcd5))
* **YouTube - Hide layout components:** Add "Hide Chapters and 'In this video' button" setting ([#2354](https://github.com/MorpheApp/morphe-patches/issues/2354)) ([ec15b89](https://github.com/MorpheApp/morphe-patches/commit/ec15b89a9a7e33caf43f7e95a17bc771dc37ba8b))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.31.1` ([7bf92f4](https://github.com/MorpheApp/morphe-patches/commit/7bf92f4f4ead5f28d95ff06452e1d1af376628d9))

## [1.39.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.7...v1.39.0-dev.8) (2026-08-06)

### 🐛 Bug Fixes

* **YouTube Music - Disable DRC audio:** Fix patching experimental app versions ([04aed07](https://github.com/MorpheApp/morphe-patches/commit/04aed073ee4829fbac26c597a62ebbc1a524f588))

## [1.39.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.6...v1.39.0-dev.7) (2026-08-06)

### 🐛 Bug Fixes

* **YouTube - Disable DRC audio:** Patch doesn't work on latest experimental versions ([65c5816](https://github.com/MorpheApp/morphe-patches/commit/65c581662a72ccba9f28923a9ada8564f238c310))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide player gesture hints" setting ([#2328](https://github.com/MorpheApp/morphe-patches/issues/2328)) ([588b8c0](https://github.com/MorpheApp/morphe-patches/commit/588b8c0f41bac446d1479d60bf632d88762cb057))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.31.0` ([2f3df14](https://github.com/MorpheApp/morphe-patches/commit/2f3df146415cc407220499fcc7bea60378940b5d))

## [1.39.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.5...v1.39.0-dev.6) (2026-08-05)

### 🐛 Bug Fixes

* **YouTube - Seekbar:** Fix patching older app targets ([0b3c42c](https://github.com/MorpheApp/morphe-patches/commit/0b3c42ce100046b0d5b99b9e110dcbeb6ad26aba))

## [1.39.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.4...v1.39.0-dev.5) (2026-08-05)

### 🐛 Bug Fixes

* **YouTube - Seekbar:** Show Shorts seekbar thumbnails ([bd648dc](https://github.com/MorpheApp/morphe-patches/commit/bd648dc703685987d493c54c95524795a9faaa25))

### ✨ New Features

* **Spoof video streams:** Default client maintenance ([#2309](https://github.com/MorpheApp/morphe-patches/issues/2309)) ([e86d61f](https://github.com/MorpheApp/morphe-patches/commit/e86d61f5d874d57f72fac9b8c0c534a89f264ca4))
* **YouTube - Disable sign in to TV popup:** Add "Disable 'Connect your devices' popup" setting ([#2325](https://github.com/MorpheApp/morphe-patches/issues/2325)) ([8b8837e](https://github.com/MorpheApp/morphe-patches/commit/8b8837eb3f0450d5c89eb59912fa1a84dd555dbf))

## [1.39.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.3...v1.39.0-dev.4) (2026-08-04)

### 🐛 Bug Fixes

* **YouTube - Disable fullscreen gestures:** Disable feature flag to restore zoom functionality ([#2292](https://github.com/MorpheApp/morphe-patches/issues/2292)) ([4413218](https://github.com/MorpheApp/morphe-patches/commit/44132182e2b148486ea72dd5d849e8dadb1520dd))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Invite others to message' card" setting ([#2304](https://github.com/MorpheApp/morphe-patches/issues/2304)) ([b582e75](https://github.com/MorpheApp/morphe-patches/commit/b582e757c5d93a4d7e68f10688a399963d0360bd))

## [1.39.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.2...v1.39.0-dev.3) (2026-08-03)

### 🐛 Bug Fixes

* **YouTube Music - Third-party lyrics:** Do not cover the comments and live chat panels ([5e3eb4c](https://github.com/MorpheApp/morphe-patches/commit/5e3eb4cf492abd7524f787ffce11f02f1803869b))

## [1.39.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.39.0-dev.1...v1.39.0-dev.2) (2026-08-03)

### 🐛 Bug Fixes

* **Reddit:** Morphe settings menu is not localized for experimental app targets ([fefa59b](https://github.com/MorpheApp/morphe-patches/commit/fefa59b9534c2858b6b90c0a1ba7a69d70848b9a))
* **YouTube - Disable sign in to TV popup:** Add support for newer versions ([#2226](https://github.com/MorpheApp/morphe-patches/issues/2226)) ([96716ef](https://github.com/MorpheApp/morphe-patches/commit/96716efdf6f7ddcf05a6cf642df88804e99af487))
* **YouTube:** Remove "Restore old YouTube settings screen" from 21.30+ targets ([51c0af2](https://github.com/MorpheApp/morphe-patches/commit/51c0af26c9d3e2c7c351a3ce521a0e4a404d60e8))

### ✨ New Features

* **YouTube Music:** Add `Remove viewer discretion dialog` patch ([#2297](https://github.com/MorpheApp/morphe-patches/issues/2297)) ([f0d3ba1](https://github.com/MorpheApp/morphe-patches/commit/f0d3ba149d81f72680b571ce596eabdd8990c572))
* **YouTube Music:** Add `Third-party lyrics` patch ([#2269](https://github.com/MorpheApp/morphe-patches/issues/2269)) ([fbf2e63](https://github.com/MorpheApp/morphe-patches/commit/fbf2e63d66be9baa4d825d986ab405a679b96df0))

## [1.39.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.38.1-dev.1...v1.39.0-dev.1) (2026-08-02)

### 🐛 Bug Fixes

* **Reddit:** Show Morphe in-app settings with Reddit `2026.25.0`+ ([#2260](https://github.com/MorpheApp/morphe-patches/issues/2260)) ([ec780c5](https://github.com/MorpheApp/morphe-patches/commit/ec780c5975f9ef3c4e578fff90ad09ba293e9b8e))
* **YouTube - Seekbar thumbnail:** Hide thumbnail during precise seeking ([9f5848a](https://github.com/MorpheApp/morphe-patches/commit/9f5848a0120e6b472d59442d1a1e94a762b60d50))
* **YouTube - Seekbar thumbnail:** Show slide-to-seek thumbnail when option is enabled ([174c4e6](https://github.com/MorpheApp/morphe-patches/commit/174c4e62f2c03fa5a673bff095d82b1475f8b82c))
* **YouTube Music - Hide layout components:** Remove "Hide 'Suggested for you' shelf" setting as it hides playlist content ([c279c40](https://github.com/MorpheApp/morphe-patches/commit/c279c4054ffbb004594bc1066bb234aa0f8624b5))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide Learning menu" and "Hide 'How YouTube works' menu" settings ([997f433](https://github.com/MorpheApp/morphe-patches/commit/997f4337cff8e1ba7c6bd4e36f61589e3db0e97e))
* **YouTube:** Add `Playback in feeds` patch ([#2261](https://github.com/MorpheApp/morphe-patches/issues/2261)) ([fced431](https://github.com/MorpheApp/morphe-patches/commit/fced4313f612031bfea7d15fe341e80a7c3e4567))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.30.0` ([f8dbf83](https://github.com/MorpheApp/morphe-patches/commit/f8dbf83a99508b3e08beb0e6061af7f1fb6880ca))

## [1.38.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.38.0...v1.38.1-dev.1) (2026-08-01)

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.31.523` ([#2207](https://github.com/MorpheApp/morphe-patches/issues/2207)) ([061663b](https://github.com/MorpheApp/morphe-patches/commit/061663b85b76f0aabe9337de8d84970d4ca406b5))

## [1.38.0](https://github.com/MorpheApp/morphe-patches/compare/v1.37.0...v1.38.0) (2026-08-01)

### 🐛 Bug Fixes

* Mirror in RTL locales and restyle to match the manager ([#2273](https://github.com/MorpheApp/morphe-patches/issues/2273)) ([78e4c48](https://github.com/MorpheApp/morphe-patches/commit/78e4c48fde884a922c559c4e0f8662901ed29e8b))
* **Settings:** Hidden category title is included when copying a setting breadcrumb ([f412fc8](https://github.com/MorpheApp/morphe-patches/commit/f412fc81d7bce31de9c511212d9672813ea54620))
* **YouTube - Seekbar thumbnail:** Always show timestamp and chapter name ([9dc0cce](https://github.com/MorpheApp/morphe-patches/commit/9dc0cceb3c09a669f6771e1b7bc5f4497b8e5e26))
* **YouTube - Swipe controls:** Evaluate swipe zone before recycling MotionEvent ([#2238](https://github.com/MorpheApp/morphe-patches/issues/2238)) ([e398514](https://github.com/MorpheApp/morphe-patches/commit/e39851427ca240c6474df275e553bad18ecda8ac))
* **YouTube - Swipe controls:** Resolve memory leaks in swipe controls ([#2268](https://github.com/MorpheApp/morphe-patches/issues/2268)) ([498768f](https://github.com/MorpheApp/morphe-patches/commit/498768f13a0057afdbd065760f50074f4679193e))
* **YouTube Music - Bypass certificate checks:** Resolve Android Auto crash ([#2239](https://github.com/MorpheApp/morphe-patches/issues/2239)) ([0b6a7b0](https://github.com/MorpheApp/morphe-patches/commit/0b6a7b0fd2491a8f33647bfce76ebd0a92e20225))
* **YouTube:** Resolve legacy app target crash ([1df09a5](https://github.com/MorpheApp/morphe-patches/commit/1df09a5ab9c8b95c3080edff61f52f390bfce1d3))

### ✨ New Features

* Add `Change installer source` universal patch ([#2257](https://github.com/MorpheApp/morphe-patches/issues/2257)) ([43b0992](https://github.com/MorpheApp/morphe-patches/commit/43b0992d8a801f34c943514c71aaa5357f05edcf))
* **YouTube - Hide layout components:** Add "Hide 'Get Premium' button" setting ([#2275](https://github.com/MorpheApp/morphe-patches/issues/2275)) ([c46fcca](https://github.com/MorpheApp/morphe-patches/commit/c46fcca74379050b2a3f1df66185b4f2c1d45195))
* **YouTube - Hide layout components:** Add "Hide explore menu components" setting ([#2159](https://github.com/MorpheApp/morphe-patches/issues/2159)) ([7dc29bc](https://github.com/MorpheApp/morphe-patches/commit/7dc29bcbd7d2927ebcc65145fb23d4f9e46581ec))
* **YouTube Music - Hide layout components:** Add "Hide Audio / Video toggle", "Hide comment components", "Hide feed components", "Hide Repeat button", and "Hide Shuffle button" settings ([#2228](https://github.com/MorpheApp/morphe-patches/issues/2228)) ([931bb3a](https://github.com/MorpheApp/morphe-patches/commit/931bb3ac6c042b7113bd31e9fdccef9a8972ce87))
* **YouTube:** Add `Wide search bar` patch ([#2221](https://github.com/MorpheApp/morphe-patches/issues/2221)) ([be8de15](https://github.com/MorpheApp/morphe-patches/commit/be8de1567731623f91a391bc479fab019e7b81a5))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.29.54` ([4945ac4](https://github.com/MorpheApp/morphe-patches/commit/4945ac46c87817f9b1fa1cc99adc24bc966308c1))
* **YouTube Music:** Add experimental support for `9.30.52` ([#2254](https://github.com/MorpheApp/morphe-patches/issues/2254)) ([422fbf4](https://github.com/MorpheApp/morphe-patches/commit/422fbf40304842ca66d835f66889f48eee23702b))

## [1.38.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.38.0-dev.2...v1.38.0-dev.3) (2026-07-30)

### 🐛 Bug Fixes

* **YouTube:** Resolve legacy app target crash ([1df09a5](https://github.com/MorpheApp/morphe-patches/commit/1df09a5ab9c8b95c3080edff61f52f390bfce1d3))

## [1.38.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.38.0-dev.1...v1.38.0-dev.2) (2026-07-30)

### 🐛 Bug Fixes

* **Settings:** Hidden category title is included when copying a setting breadcrumb ([f412fc8](https://github.com/MorpheApp/morphe-patches/commit/f412fc81d7bce31de9c511212d9672813ea54620))
* **YouTube Music - Bypass certificate checks:** Resolve Android Auto crash ([#2239](https://github.com/MorpheApp/morphe-patches/issues/2239)) ([0b6a7b0](https://github.com/MorpheApp/morphe-patches/commit/0b6a7b0fd2491a8f33647bfce76ebd0a92e20225))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.30.52` ([#2254](https://github.com/MorpheApp/morphe-patches/issues/2254)) ([422fbf4](https://github.com/MorpheApp/morphe-patches/commit/422fbf40304842ca66d835f66889f48eee23702b))

## [1.38.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.37.1-dev.1...v1.38.0-dev.1) (2026-07-29)

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide explore menu components" setting ([#2159](https://github.com/MorpheApp/morphe-patches/issues/2159)) ([7dc29bc](https://github.com/MorpheApp/morphe-patches/commit/7dc29bcbd7d2927ebcc65145fb23d4f9e46581ec))
* **YouTube Music - Hide layout components:** Add "Hide Audio / Video toggle", "Hide comment components", "Hide feed components", "Hide Repeat button", and "Hide Shuffle button" settings ([#2228](https://github.com/MorpheApp/morphe-patches/issues/2228)) ([931bb3a](https://github.com/MorpheApp/morphe-patches/commit/931bb3ac6c042b7113bd31e9fdccef9a8972ce87))
* **YouTube:** Add `Wide search bar` patch ([#2221](https://github.com/MorpheApp/morphe-patches/issues/2221)) ([be8de15](https://github.com/MorpheApp/morphe-patches/commit/be8de1567731623f91a391bc479fab019e7b81a5))

## [1.37.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.37.0...v1.37.1-dev.1) (2026-07-28)

### 🐛 Bug Fixes

* **YouTube - Swipe controls:** Evaluate swipe zone before recycling MotionEvent ([#2238](https://github.com/MorpheApp/morphe-patches/issues/2238)) ([e398514](https://github.com/MorpheApp/morphe-patches/commit/e39851427ca240c6474df275e553bad18ecda8ac))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.29.54` ([4945ac4](https://github.com/MorpheApp/morphe-patches/commit/4945ac46c87817f9b1fa1cc99adc24bc966308c1))

## [1.37.0](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0...v1.37.0) (2026-07-26)

### 🐛 Bug Fixes

* **YouTube - Copy video link:** Use correct timestamp query delimiter when link shortener is disabled ([#2172](https://github.com/MorpheApp/morphe-patches/issues/2172)) ([c3affe2](https://github.com/MorpheApp/morphe-patches/commit/c3affe2bfaf208a267b216d2d40a9ba149a4877e))
* **YouTube - Playback speed:** "Use normal speed for music" does not work when default playback speed is "Auto" ([#2171](https://github.com/MorpheApp/morphe-patches/issues/2171)) ([5c1538a](https://github.com/MorpheApp/morphe-patches/commit/5c1538ad2acbd3275da28b255a2aa7c906a96404))
* **YouTube - Playback speed:** Playback speed button sometimes does not update ([#2206](https://github.com/MorpheApp/morphe-patches/issues/2206)) ([e2c08fc](https://github.com/MorpheApp/morphe-patches/commit/e2c08fcfed94454f9b28138ac22627693c389287))
* **YouTube - Remember video quality:** Added new buffering quality flag override ([3585811](https://github.com/MorpheApp/morphe-patches/commit/3585811a3ad2d5448a840d6ca52383c18e5f6800))
* **YouTube - Remember video quality:** Improved platypus quality flag override logic ([2682d43](https://github.com/MorpheApp/morphe-patches/commit/2682d43110a03296d8f7af63dab1f8d9d73a5f11))

### ✨ New Features

* **Spoof video streams:** Default client maintenance ([#2208](https://github.com/MorpheApp/morphe-patches/issues/2208)) ([4e93ec9](https://github.com/MorpheApp/morphe-patches/commit/4e93ec983847ef4ab76fcfd9e52875e418fc205d))
* **YouTube - Seekbar:** Add "Enable seekbar thumbnails" setting ([#2182](https://github.com/MorpheApp/morphe-patches/issues/2182)) ([32575ea](https://github.com/MorpheApp/morphe-patches/commit/32575ea9bcd6ff7b135a598799c969c15b4bfadd))
* **YouTube - Seekbar:** Show video chapter title below seekbar thumbnail ([#2214](https://github.com/MorpheApp/morphe-patches/issues/2214)) ([bf3cde6](https://github.com/MorpheApp/morphe-patches/commit/bf3cde65389060bdf18a65525015fe56776e24cb))

## [1.37.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.37.0-dev.2...v1.37.0-dev.3) (2026-07-26)

### 🐛 Bug Fixes

* **YouTube - Remember video quality:** Added new buffering quality flag override ([3585811](https://github.com/MorpheApp/morphe-patches/commit/3585811a3ad2d5448a840d6ca52383c18e5f6800))

### ✨ New Features

* **YouTube - Seekbar:** Show video chapter title below seekbar thumbnail ([#2214](https://github.com/MorpheApp/morphe-patches/issues/2214)) ([bf3cde6](https://github.com/MorpheApp/morphe-patches/commit/bf3cde65389060bdf18a65525015fe56776e24cb))

## [1.37.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.37.0-dev.1...v1.37.0-dev.2) (2026-07-25)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Playback speed button sometimes does not update ([#2206](https://github.com/MorpheApp/morphe-patches/issues/2206)) ([e2c08fc](https://github.com/MorpheApp/morphe-patches/commit/e2c08fcfed94454f9b28138ac22627693c389287))
* **YouTube - Remember video quality:** Improved platypus quality flag override logic ([2682d43](https://github.com/MorpheApp/morphe-patches/commit/2682d43110a03296d8f7af63dab1f8d9d73a5f11))

### ✨ New Features

* **Spoof video streams:** Default client maintenance ([#2208](https://github.com/MorpheApp/morphe-patches/issues/2208)) ([4e93ec9](https://github.com/MorpheApp/morphe-patches/commit/4e93ec983847ef4ab76fcfd9e52875e418fc205d))

## [1.37.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0...v1.37.0-dev.1) (2026-07-24)

### 🐛 Bug Fixes

* **YouTube - Copy video link:** Use correct timestamp query delimiter when link shortener is disabled ([#2172](https://github.com/MorpheApp/morphe-patches/issues/2172)) ([c3affe2](https://github.com/MorpheApp/morphe-patches/commit/c3affe2bfaf208a267b216d2d40a9ba149a4877e))
* **YouTube - Playback speed:** "Use normal speed for music" does not work when default playback speed is "Auto" ([#2171](https://github.com/MorpheApp/morphe-patches/issues/2171)) ([5c1538a](https://github.com/MorpheApp/morphe-patches/commit/5c1538ad2acbd3275da28b255a2aa7c906a96404))

### ✨ New Features

* **YouTube - Seekbar:** Add "Enable seekbar thumbnails" setting ([#2182](https://github.com/MorpheApp/morphe-patches/issues/2182)) ([32575ea](https://github.com/MorpheApp/morphe-patches/commit/32575ea9bcd6ff7b135a598799c969c15b4bfadd))

## [1.36.0](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0...v1.36.0) (2026-07-23)

### 🐛 Bug Fixes

* **Force original audio:** Not working in SABR playback ([#2117](https://github.com/MorpheApp/morphe-patches/issues/2117)) ([f2f73f3](https://github.com/MorpheApp/morphe-patches/commit/f2f73f358f67c69ab20be6e2b55fb4a35c934a0c))
* **YouTube - Engagement Panel:** Implemented a queue of open panels ([079b23f](https://github.com/MorpheApp/morphe-patches/commit/079b23f343f67554b82a8c64457ac2c19d670749))
* **YouTube - FlyoutUtils:** Added compatibility with other video shelf types ([ce7c0b0](https://github.com/MorpheApp/morphe-patches/commit/ce7c0b070feaa5de1c865642657a5e00922c9281))
* **YouTube - Force original audio track:** Disable setting toggle for Android Creator only ([60ff67b](https://github.com/MorpheApp/morphe-patches/commit/60ff67b57cb83fa91cb91135bb7a30afefe0fc94))
* **YouTube - Hide filter bar:** Related videos filter bar is not correctly hidden ([0245d6b](https://github.com/MorpheApp/morphe-patches/commit/0245d6bd0b4092a2121e397002f99cd21c22e5f4))
* **YouTube - Hide layout components:** Hide all the thumbnails when using "Hide search term thumbnails" ([#2108](https://github.com/MorpheApp/morphe-patches/issues/2108)) ([8abb927](https://github.com/MorpheApp/morphe-patches/commit/8abb927bec2e9f3c1776b4279f5a2a944586e781))
* **YouTube - Hide layout components:** Hide new type of community post ([35ae5e9](https://github.com/MorpheApp/morphe-patches/commit/35ae5e972d353a4119954a7ffcb8fb399980b4fa))
* **YouTube - Hide layout components:** Related videos filter bar not hidden on older versions ([#2086](https://github.com/MorpheApp/morphe-patches/issues/2086)) ([21035f7](https://github.com/MorpheApp/morphe-patches/commit/21035f77e49f5c58b752b32473ba31fb86125ec4))
* **YouTube - Hide layout components:** Skip list fetch and parse while all toggles are off ([a35a429](https://github.com/MorpheApp/morphe-patches/commit/a35a429f971d97c6179af8a76c19c235bf2ca1e8))
* **YouTube - Hide Shorts components:** "Hide video link label" not working on old layouts ([56c8292](https://github.com/MorpheApp/morphe-patches/commit/56c82923db252cf242fa2aea8a4722a64ddabd6f))
* **YouTube - Hide Shorts components:** Hide new type of labels ([#2069](https://github.com/MorpheApp/morphe-patches/issues/2069)) ([befe786](https://github.com/MorpheApp/morphe-patches/commit/befe786470525c7b72a1a357c4539f06496452a8))
* **YouTube - LegacyPlayerControlButton:** Fixed some issues following the add of support for version `21.28.204` ([318d691](https://github.com/MorpheApp/morphe-patches/commit/318d691dc0ce31a92c69ac856cad7e0b1d797255))
* **YouTube - Open system share sheet:** Fetch the commentId only when the share button is pressed ([ee8df69](https://github.com/MorpheApp/morphe-patches/commit/ee8df69c50c5906d635222fc1e188350eda779a5))
* **YouTube - Open system share sheet:** Share sheet doesn't works in Shorts ([a8ff805](https://github.com/MorpheApp/morphe-patches/commit/a8ff80576bd94561b4a2d631e911a684022c807d))
* **YouTube - Playback speed:** Playback speed is remembered even if the user does not change it manually ([#2134](https://github.com/MorpheApp/morphe-patches/issues/2134)) ([b6dbe4f](https://github.com/MorpheApp/morphe-patches/commit/b6dbe4f294f124d7b7d84db3360249deda150bf0))
* **YouTube - Remember video quality:** Default video quality may not be applied ([#2144](https://github.com/MorpheApp/morphe-patches/issues/2144)) ([dcb3cbc](https://github.com/MorpheApp/morphe-patches/commit/dcb3cbc798dbaed0739718c529e675e49cbaa764))
* **YouTube - SponsorBlock:** Show segment when `21.28`+ auto-hide is off ([bbc171c](https://github.com/MorpheApp/morphe-patches/commit/bbc171cc99c2f42390e2fdc1b4cbf1cb1aee5b1e))
* **YouTube - Spoof video streams:** Updated visionOS spoof user agent to support AV1 ([acfafc8](https://github.com/MorpheApp/morphe-patches/commit/acfafc82145804a570cdf6e3f2503731ff58ff06))
* **YouTube Music - Force original audio:** Patch applied to old version where SABR is not enforced ([daa9582](https://github.com/MorpheApp/morphe-patches/commit/daa95828950af97c5b3ec898e72f9c537e06daeb))
* **YouTube Music - Remember shuffle state:** Remove conflicting playback controls fingerprint ([f78e195](https://github.com/MorpheApp/morphe-patches/commit/f78e19576eb2c81fb9c26143d6ae611f68839b27))
* **YouTube Music - Settings menu filter:** Support version `8.51.51` ([bb733ec](https://github.com/MorpheApp/morphe-patches/commit/bb733ec297c5cffb5346cc19100a7accffb1b966))
* **YouTube Music:** Resolve patching experimental app versions ([b6b2b15](https://github.com/MorpheApp/morphe-patches/commit/b6b2b15dc63e6a1e6ace7fbfc07cc366d5b25127))
* **YouTube:** Update compatibility version name ([ca4dd01](https://github.com/MorpheApp/morphe-patches/commit/ca4dd01fa78bdb921e701cf14267a2d787034d25))

### ✨ New Features

* Add `Settings menu filter` patch ([#2029](https://github.com/MorpheApp/morphe-patches/issues/2029)) ([8880421](https://github.com/MorpheApp/morphe-patches/commit/88804215819b3de2bd7736047fa0b65e514c58aa))
* Add typed patch options ([#1971](https://github.com/MorpheApp/morphe-patches/issues/1971)) ([242318c](https://github.com/MorpheApp/morphe-patches/commit/242318c86c842a7bdf2ab364223003637edae20f))
* **Reddit:** Add `Custom font` patch ([#2100](https://github.com/MorpheApp/morphe-patches/issues/2100)) ([b242ad9](https://github.com/MorpheApp/morphe-patches/commit/b242ad94ec560ac030f64ce602f3571d2c93a887))
* **Settings:** Long-press a Morphe setting to copy its breadcrumb ([#2130](https://github.com/MorpheApp/morphe-patches/issues/2130)) ([622ef54](https://github.com/MorpheApp/morphe-patches/commit/622ef54e1dafeb1456ec6fd3616106c2592eca11))
* **Spoof video streams:** Default client maintenance ([#2094](https://github.com/MorpheApp/morphe-patches/issues/2094)) ([f321bda](https://github.com/MorpheApp/morphe-patches/commit/f321bda0455b1b45334679083066474a77d35442))
* **YouTube - Hide layout components:** Add "Hide 'Search inside this video' section" setting ([#2097](https://github.com/MorpheApp/morphe-patches/issues/2097)) ([e4adb52](https://github.com/MorpheApp/morphe-patches/commit/e4adb5278a983248b0da7e1167bc4cc971332cdc))
* **YouTube - Hide layout components:** Add "Hide featured palylists section" setting ([59d7196](https://github.com/MorpheApp/morphe-patches/commit/59d7196fa37cc26205c26405eea119ebb3c66cbb))
* **YouTube - Hide layout components:** Add "Hide hashtag section" setting ([95710b1](https://github.com/MorpheApp/morphe-patches/commit/95710b18e7a92c02e904c1ba4cc6f0c0aef87ff0))
* **YouTube Music - Hide ads:** Add "Hide Music Premium promotions" setting ([#2122](https://github.com/MorpheApp/morphe-patches/issues/2122)) ([671f24c](https://github.com/MorpheApp/morphe-patches/commit/671f24cca071639deb293a740ce3a4bd79e9db3a))
* **YouTube Music:** Add `Return YouTube Dislike` patch ([#1994](https://github.com/MorpheApp/morphe-patches/issues/1994)) ([8f58725](https://github.com/MorpheApp/morphe-patches/commit/8f587259ba8fb4dade3a44eabcdead1948c53945))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.29.0` ([e0629fc](https://github.com/MorpheApp/morphe-patches/commit/e0629fcdc4edce25db8124d279142bcfd14cb8d8))
* **YouTube Music:** Add experimental support for `9.28.51` ([39e85de](https://github.com/MorpheApp/morphe-patches/commit/39e85de5574832e2c282f9dd6e75c1ff3fb5d616))
* **YouTube:** Add experimental support for `21.28.204` ([#2008](https://github.com/MorpheApp/morphe-patches/issues/2008)) ([44a0e67](https://github.com/MorpheApp/morphe-patches/commit/44a0e67c9c22e6251d0786e031fdb5b16a5b9c13))
* **YouTube:** Add experimental support for `21.29.363` ([#2084](https://github.com/MorpheApp/morphe-patches/issues/2084)) ([048880e](https://github.com/MorpheApp/morphe-patches/commit/048880e01b868be9280ed2cc295b4dfd42fbe60f))

## [1.36.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.11...v1.36.0-dev.12) (2026-07-23)

### ✨ New Features

* Add typed patch options ([#1971](https://github.com/MorpheApp/morphe-patches/issues/1971)) ([242318c](https://github.com/MorpheApp/morphe-patches/commit/242318c86c842a7bdf2ab364223003637edae20f))

## [1.36.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.10...v1.36.0-dev.11) (2026-07-23)

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide hashtag section" setting ([95710b1](https://github.com/MorpheApp/morphe-patches/commit/95710b18e7a92c02e904c1ba4cc6f0c0aef87ff0))

## [1.36.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.9...v1.36.0-dev.10) (2026-07-22)

### 🐛 Bug Fixes

* **YouTube - Hide Shorts components:** "Hide video link label" not working on old layouts ([56c8292](https://github.com/MorpheApp/morphe-patches/commit/56c82923db252cf242fa2aea8a4722a64ddabd6f))

## [1.36.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.8...v1.36.0-dev.9) (2026-07-22)

### 🐛 Bug Fixes

* **YouTube - Remember video quality:** Default video quality may not be applied ([#2144](https://github.com/MorpheApp/morphe-patches/issues/2144)) ([dcb3cbc](https://github.com/MorpheApp/morphe-patches/commit/dcb3cbc798dbaed0739718c529e675e49cbaa764))
* **YouTube Music - Settings menu filter:** Support version `8.51.51` ([bb733ec](https://github.com/MorpheApp/morphe-patches/commit/bb733ec297c5cffb5346cc19100a7accffb1b966))

## [1.36.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.7...v1.36.0-dev.8) (2026-07-22)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Playback speed is remembered even if the user does not change it manually ([#2134](https://github.com/MorpheApp/morphe-patches/issues/2134)) ([b6dbe4f](https://github.com/MorpheApp/morphe-patches/commit/b6dbe4f294f124d7b7d84db3360249deda150bf0))

### ✨ New Features

* **Settings:** Long-press a Morphe setting to copy its breadcrumb ([#2130](https://github.com/MorpheApp/morphe-patches/issues/2130)) ([622ef54](https://github.com/MorpheApp/morphe-patches/commit/622ef54e1dafeb1456ec6fd3616106c2592eca11))
* **YouTube - Hide layout components:** Add "Hide featured playlists section" setting ([59d7196](https://github.com/MorpheApp/morphe-patches/commit/59d7196fa37cc26205c26405eea119ebb3c66cbb))

## [1.36.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.6...v1.36.0-dev.7) (2026-07-21)

### 🐛 Bug Fixes

* **YouTube:** Update compatibility version name ([ca4dd01](https://github.com/MorpheApp/morphe-patches/commit/ca4dd01fa78bdb921e701cf14267a2d787034d25))

### ✨ New Features

* **YouTube Music - Hide ads:** Add "Hide Music Premium promotions" setting ([#2122](https://github.com/MorpheApp/morphe-patches/issues/2122)) ([671f24c](https://github.com/MorpheApp/morphe-patches/commit/671f24cca071639deb293a740ce3a4bd79e9db3a))

## [1.36.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.5...v1.36.0-dev.6) (2026-07-21)

### 🐛 Bug Fixes

* **Force original audio:** Not working in SABR playback ([#2117](https://github.com/MorpheApp/morphe-patches/issues/2117)) ([f2f73f3](https://github.com/MorpheApp/morphe-patches/commit/f2f73f358f67c69ab20be6e2b55fb4a35c934a0c))
* **YouTube - Force original audio track:** Disable setting toggle for Android Creator only ([60ff67b](https://github.com/MorpheApp/morphe-patches/commit/60ff67b57cb83fa91cb91135bb7a30afefe0fc94))
* **YouTube - Hide layout components:** Hide all the thumbnails when using "Hide search term thumbnails" ([#2108](https://github.com/MorpheApp/morphe-patches/issues/2108)) ([8abb927](https://github.com/MorpheApp/morphe-patches/commit/8abb927bec2e9f3c1776b4279f5a2a944586e781))
* **YouTube - Hide layout components:** Hide new type of community post ([35ae5e9](https://github.com/MorpheApp/morphe-patches/commit/35ae5e972d353a4119954a7ffcb8fb399980b4fa))
* **YouTube Music - Force original audio:** Patch applied to old version where SABR is not enforced ([daa9582](https://github.com/MorpheApp/morphe-patches/commit/daa95828950af97c5b3ec898e72f9c537e06daeb))

### ✨ New Features

* Add `Settings menu filter` patch ([#2029](https://github.com/MorpheApp/morphe-patches/issues/2029)) ([8880421](https://github.com/MorpheApp/morphe-patches/commit/88804215819b3de2bd7736047fa0b65e514c58aa))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.29.363` ([#2084](https://github.com/MorpheApp/morphe-patches/issues/2084)) ([048880e](https://github.com/MorpheApp/morphe-patches/commit/048880e01b868be9280ed2cc295b4dfd42fbe60f))

## [1.36.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.4...v1.36.0-dev.5) (2026-07-20)

### 🐛 Bug Fixes

* **YouTube Music - Remember shuffle state:** Remove conflicting playback controls fingerprint ([f78e195](https://github.com/MorpheApp/morphe-patches/commit/f78e19576eb2c81fb9c26143d6ae611f68839b27))

### ✨ New Features

* **Reddit:** Add `Custom font` and `Force system font` patches ([#2100](https://github.com/MorpheApp/morphe-patches/issues/2100)) ([b242ad9](https://github.com/MorpheApp/morphe-patches/commit/b242ad94ec560ac030f64ce602f3571d2c93a887))
* **Spoof video streams:** Default client maintenance ([#2094](https://github.com/MorpheApp/morphe-patches/issues/2094)) ([f321bda](https://github.com/MorpheApp/morphe-patches/commit/f321bda0455b1b45334679083066474a77d35442))

## [1.36.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.3...v1.36.0-dev.4) (2026-07-19)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Related videos filter bar not hidden on older versions ([#2086](https://github.com/MorpheApp/morphe-patches/issues/2086)) ([21035f7](https://github.com/MorpheApp/morphe-patches/commit/21035f77e49f5c58b752b32473ba31fb86125ec4))
* **YouTube - SponsorBlock:** Show segment when `21.28`+ auto-hide is off ([bbc171c](https://github.com/MorpheApp/morphe-patches/commit/bbc171cc99c2f42390e2fdc1b4cbf1cb1aee5b1e))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Search inside this video' section" setting ([#2097](https://github.com/MorpheApp/morphe-patches/issues/2097)) ([e4adb52](https://github.com/MorpheApp/morphe-patches/commit/e4adb5278a983248b0da7e1167bc4cc971332cdc))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.28.51` ([39e85de](https://github.com/MorpheApp/morphe-patches/commit/39e85de5574832e2c282f9dd6e75c1ff3fb5d616))

## [1.36.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.2...v1.36.0-dev.3) (2026-07-19)

### 🐛 Bug Fixes

* **YouTube - Spoof video streams:** Updated visionOS spoof user agent to support AV1 ([acfafc8](https://github.com/MorpheApp/morphe-patches/commit/acfafc82145804a570cdf6e3f2503731ff58ff06))
* **YouTube Music:** Resolve patching experimental app versions ([b6b2b15](https://github.com/MorpheApp/morphe-patches/commit/b6b2b15dc63e6a1e6ace7fbfc07cc366d5b25127))

## [1.36.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.36.0-dev.1...v1.36.0-dev.2) (2026-07-19)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Skip list fetch and parse while all toggles are off ([a35a429](https://github.com/MorpheApp/morphe-patches/commit/a35a429f971d97c6179af8a76c19c235bf2ca1e8))
* **YouTube - LegacyPlayerControlButton:** Fixed some issues following the add of support for version 21.28.204 ([318d691](https://github.com/MorpheApp/morphe-patches/commit/318d691dc0ce31a92c69ac856cad7e0b1d797255))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.28.204` ([#2008](https://github.com/MorpheApp/morphe-patches/issues/2008)) ([44a0e67](https://github.com/MorpheApp/morphe-patches/commit/44a0e67c9c22e6251d0786e031fdb5b16a5b9c13))

## [1.36.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0...v1.36.0-dev.1) (2026-07-18)

### 🐛 Bug Fixes

* **YouTube - Engagement Panel:** Implement a queue for open panels ([079b23f](https://github.com/MorpheApp/morphe-patches/commit/079b23f343f67554b82a8c64457ac2c19d670749))
* **YouTube - FlyoutUtils:** Add compatibility with other video shelf types ([ce7c0b0](https://github.com/MorpheApp/morphe-patches/commit/ce7c0b070feaa5de1c865642657a5e00922c9281))
* **YouTube - Hide layout components:** Related videos filter bar is not correctly hidden ([0245d6b](https://github.com/MorpheApp/morphe-patches/commit/0245d6bd0b4092a2121e397002f99cd21c22e5f4))
* **YouTube - Hide Shorts components:** Hide new type of labels ([#2069](https://github.com/MorpheApp/morphe-patches/issues/2069)) ([befe786](https://github.com/MorpheApp/morphe-patches/commit/befe786470525c7b72a1a357c4539f06496452a8))
* **YouTube - Open system share sheet:** Fetch the commentId only when the share button is pressed ([ee8df69](https://github.com/MorpheApp/morphe-patches/commit/ee8df69c50c5906d635222fc1e188350eda779a5))
* **YouTube - Open system share sheet:** Share sheet doesn't works in Shorts ([a8ff805](https://github.com/MorpheApp/morphe-patches/commit/a8ff80576bd94561b4a2d631e911a684022c807d))

### ✨ New Features

* **YouTube Music:** Add `Return YouTube Dislike` patch ([#1994](https://github.com/MorpheApp/morphe-patches/issues/1994)) ([8f58725](https://github.com/MorpheApp/morphe-patches/commit/8f587259ba8fb4dade3a44eabcdead1948c53945))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.29.0` ([e0629fc](https://github.com/MorpheApp/morphe-patches/commit/e0629fcdc4edce25db8124d279142bcfd14cb8d8))

## [1.35.0](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0...v1.35.0) (2026-07-16)

### 🐛 Bug Fixes

* **Network proxy:** Support HTTPS proxies for auxiliary requests ([#2022](https://github.com/MorpheApp/morphe-patches/issues/2022)) ([ee52f90](https://github.com/MorpheApp/morphe-patches/commit/ee52f9033687b6022f494f9afba4e0abb1bccba1))
* **Spoof video streams:** Check setting value instead of availability for JavaScript toggles ([1d92650](https://github.com/MorpheApp/morphe-patches/commit/1d926503bf9ef29d8e135786479ecef1de20adbc))
* **YouTube - Copy video link:** Copied video link is always shortened ([#1993](https://github.com/MorpheApp/morphe-patches/issues/1993)) ([ff0e8cc](https://github.com/MorpheApp/morphe-patches/commit/ff0e8ccb935ca3e267c625778ad93f2db213c367))
* **YouTube - FlyoutUtils:** Error message when opening Shorts flyout menu ([aaf5f55](https://github.com/MorpheApp/morphe-patches/commit/aaf5f55a3a6d769dd850023925725481768e3a15))
* **YouTube - Hide ads:** Hide shopping links in transcripts ([#2025](https://github.com/MorpheApp/morphe-patches/issues/2025)) ([0cf389b](https://github.com/MorpheApp/morphe-patches/commit/0cf389b921c813961f8b4d3bd12636b84e3f61d1))
* **YouTube - Hide layout components:** Comment box being hidden on `20.21.37` ([7f77b20](https://github.com/MorpheApp/morphe-patches/commit/7f77b20404368279eb216e4911cfe27b9047655e))
* **YouTube - Open system share sheet:** Support channelID & commentID fetching ([#1975](https://github.com/MorpheApp/morphe-patches/issues/1975)) ([34c2b58](https://github.com/MorpheApp/morphe-patches/commit/34c2b58eab29967b1fc784ae0c644297b850ca36))
* **YouTube - Playback speed:** Support new native playback speed menu ([#1957](https://github.com/MorpheApp/morphe-patches/issues/1957)) ([a4641d6](https://github.com/MorpheApp/morphe-patches/commit/a4641d6731170e03b26abc4ecb37230193271673))
* **YouTube - Spoof video sttreams:** Sometimes player headers is null ([#2035](https://github.com/MorpheApp/morphe-patches/issues/2035)) ([c9552c0](https://github.com/MorpheApp/morphe-patches/commit/c9552c0eee1415e290218cfe603bb4af98ed0681))
* **YouTube Music - Downloads:** Hide Premium dialog on external download ([#2009](https://github.com/MorpheApp/morphe-patches/issues/2009)) ([4cfe552](https://github.com/MorpheApp/morphe-patches/commit/4cfe552daa946c8d4ca946aeffffb63b62ad8370))
* **YouTube Music:** Fix `9.15.51` startup ([9e2c372](https://github.com/MorpheApp/morphe-patches/commit/9e2c37218aeb601d1d05d66fba4d89255d20c01f))

### ✨ New Features

* **YouTube - Hide layout components:** Add "AI channel filter" settings ([#1972](https://github.com/MorpheApp/morphe-patches/issues/1972)) ([03c0b97](https://github.com/MorpheApp/morphe-patches/commit/03c0b97f983a3bbae22bba3a5f51bd2fc09e9a25))
* **YouTube - Hide layout components:** Add "Hide gift animation and cards" and "Hide gift button" settings ([#1991](https://github.com/MorpheApp/morphe-patches/issues/1991)) ([83451d9](https://github.com/MorpheApp/morphe-patches/commit/83451d95249b4e951b466c3b7ff8a64b3d7f1a4d))
* **YouTube - Hide layout components:** Add "Hide video thumbnail" setting ([#2043](https://github.com/MorpheApp/morphe-patches/issues/2043)) ([360bc41](https://github.com/MorpheApp/morphe-patches/commit/360bc412759a8de12ecd31b30f95d199801eea0f))
* **YouTube - Swipe controls:** Add playback speed step preference ([#1977](https://github.com/MorpheApp/morphe-patches/issues/1977)) ([25927d1](https://github.com/MorpheApp/morphe-patches/commit/25927d12ec5d5a1c0bba570a70ba09fe1e28497c))
* **YouTube Music:** Add `Disable dislike redirection` patch ([#1962](https://github.com/MorpheApp/morphe-patches/issues/1962)) ([e399e05](https://github.com/MorpheApp/morphe-patches/commit/e399e05835f40e00a5efb9f311eadbee9be599a9))
* **YouTube Music:** Add `Remember shuffle state` patch ([#1963](https://github.com/MorpheApp/morphe-patches/issues/1963)) ([7e8a6ba](https://github.com/MorpheApp/morphe-patches/commit/7e8a6babdbafd1dd87ac1397c088f318b89a02da))
* **YouTube Music:** Add `Spoof app version` patch ([#1948](https://github.com/MorpheApp/morphe-patches/issues/1948)) ([46a86d3](https://github.com/MorpheApp/morphe-patches/commit/46a86d3106e9e00d718e5410ef0c03fb6b228f90))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.28.0` ([9f18957](https://github.com/MorpheApp/morphe-patches/commit/9f18957acd350db0180cb2c66521e8b83b598558))
* **YouTube:** Add support for `21.04.223` ([12e19c0](https://github.com/MorpheApp/morphe-patches/commit/12e19c00a143c90b3dd12668a45e07b0cc6dd7a0))

## [1.35.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0-dev.5...v1.35.0-dev.6) (2026-07-16)

### 🐛 Bug Fixes

* **YouTube - FlyoutUtils:** Error message when opening Shorts flyout menu ([aaf5f55](https://github.com/MorpheApp/morphe-patches/commit/aaf5f55a3a6d769dd850023925725481768e3a15))
* **YouTube - Hide layout components:** Comment box being hidden on `20.21.37` ([7f77b20](https://github.com/MorpheApp/morphe-patches/commit/7f77b20404368279eb216e4911cfe27b9047655e))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide video thumbnail" setting ([#2043](https://github.com/MorpheApp/morphe-patches/issues/2043)) ([360bc41](https://github.com/MorpheApp/morphe-patches/commit/360bc412759a8de12ecd31b30f95d199801eea0f))

### 🚀 Updated App Support

* **YouTube:** Add support for `21.04.223` ([12e19c0](https://github.com/MorpheApp/morphe-patches/commit/12e19c00a143c90b3dd12668a45e07b0cc6dd7a0))

## [1.35.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0-dev.4...v1.35.0-dev.5) (2026-07-15)

### 🐛 Bug Fixes

* **YouTube - Spoof video streams:** Sometimes player headers is null ([#2035](https://github.com/MorpheApp/morphe-patches/issues/2035)) ([c9552c0](https://github.com/MorpheApp/morphe-patches/commit/c9552c0eee1415e290218cfe603bb4af98ed0681))

### ✨ New Features

* **YouTube - Hide layout components:** Add "AI channel filter" settings ([#1972](https://github.com/MorpheApp/morphe-patches/issues/1972)) ([03c0b97](https://github.com/MorpheApp/morphe-patches/commit/03c0b97f983a3bbae22bba3a5f51bd2fc09e9a25))

## [1.35.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0-dev.3...v1.35.0-dev.4) (2026-07-14)

### 🐛 Bug Fixes

* **Network proxy:** Support HTTPS proxies for auxiliary requests ([#2022](https://github.com/MorpheApp/morphe-patches/issues/2022)) ([ee52f90](https://github.com/MorpheApp/morphe-patches/commit/ee52f9033687b6022f494f9afba4e0abb1bccba1))
* **YouTube - Hide ads:** Hide shopping links in transcripts ([#2025](https://github.com/MorpheApp/morphe-patches/issues/2025)) ([0cf389b](https://github.com/MorpheApp/morphe-patches/commit/0cf389b921c813961f8b4d3bd12636b84e3f61d1))
* **YouTube - Open system share sheet:** Support channelID & commentID fetching ([#1975](https://github.com/MorpheApp/morphe-patches/issues/1975)) ([34c2b58](https://github.com/MorpheApp/morphe-patches/commit/34c2b58eab29967b1fc784ae0c644297b850ca36))

### ✨ New Features

* **YouTube Music:** Add `Remember shuffle state` patch ([#1963](https://github.com/MorpheApp/morphe-patches/issues/1963)) ([7e8a6ba](https://github.com/MorpheApp/morphe-patches/commit/7e8a6babdbafd1dd87ac1397c088f318b89a02da))

## [1.35.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0-dev.2...v1.35.0-dev.3) (2026-07-13)

### 🐛 Bug Fixes

* **YouTube Music:** Fix `9.15.51` startup ([9e2c372](https://github.com/MorpheApp/morphe-patches/commit/9e2c37218aeb601d1d05d66fba4d89255d20c01f))

## [1.35.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.35.0-dev.1...v1.35.0-dev.2) (2026-07-13)

### 🐛 Bug Fixes

* **YouTube - Playback speed:** Support new native playback speed menu ([#1957](https://github.com/MorpheApp/morphe-patches/issues/1957)) ([a4641d6](https://github.com/MorpheApp/morphe-patches/commit/a4641d6731170e03b26abc4ecb37230193271673))
* **YouTube Music - Downloads:** Hide Premium dialog on external download ([#2009](https://github.com/MorpheApp/morphe-patches/issues/2009)) ([4cfe552](https://github.com/MorpheApp/morphe-patches/commit/4cfe552daa946c8d4ca946aeffffb63b62ad8370))

### ✨ New Features

* **YouTube Music:** Add `Disable dislike redirection` patch ([#1962](https://github.com/MorpheApp/morphe-patches/issues/1962)) ([e399e05](https://github.com/MorpheApp/morphe-patches/commit/e399e05835f40e00a5efb9f311eadbee9be599a9))

## [1.35.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0...v1.35.0-dev.1) (2026-07-12)

### 🐛 Bug Fixes

* **Spoof video streams:** Check setting value instead of availability for JavaScript toggles ([1d92650](https://github.com/MorpheApp/morphe-patches/commit/1d926503bf9ef29d8e135786479ecef1de20adbc))
* **YouTube - Copy video link:** Copied video link is always shortened ([#1993](https://github.com/MorpheApp/morphe-patches/issues/1993)) ([ff0e8cc](https://github.com/MorpheApp/morphe-patches/commit/ff0e8ccb935ca3e267c625778ad93f2db213c367))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide gift animation and cards" and "Hide gift button" settings ([#1991](https://github.com/MorpheApp/morphe-patches/issues/1991)) ([83451d9](https://github.com/MorpheApp/morphe-patches/commit/83451d95249b4e951b466c3b7ff8a64b3d7f1a4d))
* **YouTube - Swipe controls:** Add playback speed step preference ([#1977](https://github.com/MorpheApp/morphe-patches/issues/1977)) ([25927d1](https://github.com/MorpheApp/morphe-patches/commit/25927d12ec5d5a1c0bba570a70ba09fe1e28497c))
* **YouTube Music:** Add `Spoof app version` patch ([#1948](https://github.com/MorpheApp/morphe-patches/issues/1948)) ([46a86d3](https://github.com/MorpheApp/morphe-patches/commit/46a86d3106e9e00d718e5410ef0c03fb6b228f90))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.28.0` ([9f18957](https://github.com/MorpheApp/morphe-patches/commit/9f18957acd350db0180cb2c66521e8b83b598558))

## [1.34.0](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0...v1.34.0) (2026-07-10)

### 🐛 Bug Fixes

* **GmsCore support:** Use custom provider package name when `Change package name` is used ([7d0d56d](https://github.com/MorpheApp/morphe-patches/commit/7d0d56d0652dbfd3bb6cd5b21dc21310e2b73e68))
* **Reddit - Settings:** Morphe language does not change after restarting ([#1950](https://github.com/MorpheApp/morphe-patches/issues/1950)) ([fc41c27](https://github.com/MorpheApp/morphe-patches/commit/fc41c2757c1c6897e314e35de3e227adede03939))
* **Spoof video streams:** Change default client to 'TV' ([ce3f496](https://github.com/MorpheApp/morphe-patches/commit/ce3f496f9013af2d4146dc0d0f86a629d9dd7d9d))
* **YouTube - Add to queue:** Allows tablet patches for versions 21.xx ([6ef2a3f](https://github.com/MorpheApp/morphe-patches/commit/6ef2a3f7aadb845b0e0ec5b839773d8e68504868))
* **YouTube - Add to queue:** Prevents the flyout video id reset blocking ([93d134f](https://github.com/MorpheApp/morphe-patches/commit/93d134f9df792e35f0b1e40ef933262bc40fa517))
* **YouTube - Miniplayer/Disable automatic reposition:** Support vertical position lock ([4adc714](https://github.com/MorpheApp/morphe-patches/commit/4adc71465bbee964112e45ffa93e685901fcaec5))
* **YouTube - Return YouTube Dislike:** Remove RYD Shorts due to YT removing Shorts dislike and RYD API no longer providing reliable Shorts dislikes data ([#1924](https://github.com/MorpheApp/morphe-patches/issues/1924)) ([fcb613a](https://github.com/MorpheApp/morphe-patches/commit/fcb613aacb28ccd319f7211282305d0c6a912874))
* **YouTube - Spoof video streams:** Mention Android Studio 720p limitation in settings UI ([387abbf](https://github.com/MorpheApp/morphe-patches/commit/387abbf4c543a4c5ed9b6574bf792e7ce3b1c949))
* **YouTube - Voice over translation:** Keep the user's original audio volume ratio after rewinding ([#1939](https://github.com/MorpheApp/morphe-patches/issues/1939)) ([d673d91](https://github.com/MorpheApp/morphe-patches/commit/d673d9181d7a203824bab2a83955d965d2423c3b))
* **YouTube Music - Downloads:** Add "Override feed/search flyout button" setting ([#1931](https://github.com/MorpheApp/morphe-patches/issues/1931)) ([af7cf55](https://github.com/MorpheApp/morphe-patches/commit/af7cf55a99c9ebf8e42649af4b931bb74cedf086))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide filter bar in comments" and "Sanitize highlighted search links" settings ([#1935](https://github.com/MorpheApp/morphe-patches/issues/1935)) ([1876708](https://github.com/MorpheApp/morphe-patches/commit/187670860225c5c8272a4f34d131a98448ca311c))
* **YouTube - Miniplayer:** Add "Disable automatic reposition" setting ([#1920](https://github.com/MorpheApp/morphe-patches/issues/1920)) ([e49c0b4](https://github.com/MorpheApp/morphe-patches/commit/e49c0b4053a2bcfd0f9b1140d1e5438e43d215c5))
* **YouTube - Miniplayer:** Add "Disable playback with horizontal drag" setting ([#1916](https://github.com/MorpheApp/morphe-patches/issues/1916)) ([186f060](https://github.com/MorpheApp/morphe-patches/commit/186f0603352f26e30fdfab100fe0b77eb22496d6))
* **YouTube - Theme:** Add "Modern YouTube" dark theme preset ([#1918](https://github.com/MorpheApp/morphe-patches/issues/1918)) ([0a381c8](https://github.com/MorpheApp/morphe-patches/commit/0a381c8c0cd80d1bd3cb1f339587e48798ced00f))
* **YouTube Music - Change miniplayer color:** Add "Change navigation bar color" setting ([#1908](https://github.com/MorpheApp/morphe-patches/issues/1908)) ([9b570cd](https://github.com/MorpheApp/morphe-patches/commit/9b570cd2cfcd0695fa38ea84541133940146e7cf))
* **YouTube Music - Settings:** Add Morphe language selector ([#1937](https://github.com/MorpheApp/morphe-patches/issues/1937)) ([443500c](https://github.com/MorpheApp/morphe-patches/commit/443500c66718d722a393707712c78ac3232e0fbd))
* **YouTube Music:** Add `Downloads` patch ([#1881](https://github.com/MorpheApp/morphe-patches/issues/1881)) ([d078a37](https://github.com/MorpheApp/morphe-patches/commit/d078a37cd1a8ef93f9546efb24e783a7b826a8b8))
* **YouTube Music:** Add `Hide flyout menu components` patch ([#1906](https://github.com/MorpheApp/morphe-patches/issues/1906)) ([dbc4ba0](https://github.com/MorpheApp/morphe-patches/commit/dbc4ba08c0e23838dafa17d7fd0cfc9d33ba6524))
* **YouTube Music:** Add `Hide layout components` patch with `Custom filter` ([#1919](https://github.com/MorpheApp/morphe-patches/issues/1919)) ([f6e9849](https://github.com/MorpheApp/morphe-patches/commit/f6e9849331a16eebf870338e75012a529915d3b8))
* **YouTube Music:** Add `Hide music action buttons` patch ([#1953](https://github.com/MorpheApp/morphe-patches/issues/1953)) ([b142f87](https://github.com/MorpheApp/morphe-patches/commit/b142f87e39cbe30e046d8731fa2997d6a1523bf7))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.27.0` ([4dabc41](https://github.com/MorpheApp/morphe-patches/commit/4dabc4142664669937d47ffad7d6f768aaa48f8e))

## [1.34.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.6...v1.34.0-dev.7) (2026-07-09)

### 🐛 Bug Fixes

* **YouTube - Spoof video streams:** Mention Android Studio 720p limitation in settings UI ([387abbf](https://github.com/MorpheApp/morphe-patches/commit/387abbf4c543a4c5ed9b6574bf792e7ce3b1c949))

## [1.34.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.5...v1.34.0-dev.6) (2026-07-09)

### 🐛 Bug Fixes

* **Spoof video streams:** Change default client to 'TV' ([ce3f496](https://github.com/MorpheApp/morphe-patches/commit/ce3f496f9013af2d4146dc0d0f86a629d9dd7d9d))

### ✨ New Features

* **YouTube Music:** Add `Hide music action buttons` patch ([#1953](https://github.com/MorpheApp/morphe-patches/issues/1953)) ([b142f87](https://github.com/MorpheApp/morphe-patches/commit/b142f87e39cbe30e046d8731fa2997d6a1523bf7))

## [1.34.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.4...v1.34.0-dev.5) (2026-07-09)

### 🐛 Bug Fixes

* **Reddit - Settings:** Morphe language does not change after restarting ([#1950](https://github.com/MorpheApp/morphe-patches/issues/1950)) ([fc41c27](https://github.com/MorpheApp/morphe-patches/commit/fc41c2757c1c6897e314e35de3e227adede03939))

### ✨ New Features

* **YouTube Music - Change miniplayer color:** Add "Change navigation bar color" setting ([#1908](https://github.com/MorpheApp/morphe-patches/issues/1908)) ([9b570cd](https://github.com/MorpheApp/morphe-patches/commit/9b570cd2cfcd0695fa38ea84541133940146e7cf))

## [1.34.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.3...v1.34.0-dev.4) (2026-07-08)

### 🐛 Bug Fixes

* **GmsCore support:** Use custom provider package name when `Change package name` is used ([7d0d56d](https://github.com/MorpheApp/morphe-patches/commit/7d0d56d0652dbfd3bb6cd5b21dc21310e2b73e68))
* **YouTube - Voice over translation:** Keep the user's original audio volume ratio after rewinding ([#1939](https://github.com/MorpheApp/morphe-patches/issues/1939)) ([d673d91](https://github.com/MorpheApp/morphe-patches/commit/d673d9181d7a203824bab2a83955d965d2423c3b))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide filter bar in comments" and "Sanitize highlighted search links" settings ([#1935](https://github.com/MorpheApp/morphe-patches/issues/1935)) ([1876708](https://github.com/MorpheApp/morphe-patches/commit/187670860225c5c8272a4f34d131a98448ca311c))
* **YouTube Music:** Add `Hide flyout menu components` patch ([#1906](https://github.com/MorpheApp/morphe-patches/issues/1906)) ([dbc4ba0](https://github.com/MorpheApp/morphe-patches/commit/dbc4ba08c0e23838dafa17d7fd0cfc9d33ba6524))
* **YouTube Music:** Add `Hide layout components` patch with `Custom filter` ([#1919](https://github.com/MorpheApp/morphe-patches/issues/1919)) ([f6e9849](https://github.com/MorpheApp/morphe-patches/commit/f6e9849331a16eebf870338e75012a529915d3b8))

## [1.34.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.2...v1.34.0-dev.3) (2026-07-07)

### ✨ New Features

* **YouTube - Miniplayer:** Add "Disable automatic reposition" setting ([#1920](https://github.com/MorpheApp/morphe-patches/issues/1920)) ([e49c0b4](https://github.com/MorpheApp/morphe-patches/commit/e49c0b4053a2bcfd0f9b1140d1e5438e43d215c5))
* **YouTube Music - Settings:** Add Morphe language selector ([#1937](https://github.com/MorpheApp/morphe-patches/issues/1937)) ([443500c](https://github.com/MorpheApp/morphe-patches/commit/443500c66718d722a393707712c78ac3232e0fbd))

## [1.34.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.34.0-dev.1...v1.34.0-dev.2) (2026-07-05)

### 🐛 Bug Fixes

* **YouTube - Return YouTube Dislike:** Remove RYD Shorts due to YT removing Shorts dislike and RYD API no longer providing reliable Shorts dislikes data ([#1924](https://github.com/MorpheApp/morphe-patches/issues/1924)) ([fcb613a](https://github.com/MorpheApp/morphe-patches/commit/fcb613aacb28ccd319f7211282305d0c6a912874))
* **YouTube Music - Downloads:** Add "Override feed/search flyout button" setting ([#1931](https://github.com/MorpheApp/morphe-patches/issues/1931)) ([af7cf55](https://github.com/MorpheApp/morphe-patches/commit/af7cf55a99c9ebf8e42649af4b931bb74cedf086))

## [1.34.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0...v1.34.0-dev.1) (2026-07-05)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Patch not working for tablets on `21.xx` ([6ef2a3f](https://github.com/MorpheApp/morphe-patches/commit/6ef2a3f7aadb845b0e0ec5b839773d8e68504868))
* **YouTube - Add to queue:** Prevent the flyout video ID reset blocking ([93d134f](https://github.com/MorpheApp/morphe-patches/commit/93d134f9df792e35f0b1e40ef933262bc40fa517))

### ✨ New Features

* **YouTube - Miniplayer:** Add "Disable playback with horizontal drag" setting ([#1916](https://github.com/MorpheApp/morphe-patches/issues/1916)) ([186f060](https://github.com/MorpheApp/morphe-patches/commit/186f0603352f26e30fdfab100fe0b77eb22496d6))
* **YouTube - Theme:** Add "Modern YouTube" dark theme preset ([#1918](https://github.com/MorpheApp/morphe-patches/issues/1918)) ([0a381c8](https://github.com/MorpheApp/morphe-patches/commit/0a381c8c0cd80d1bd3cb1f339587e48798ced00f))
* **YouTube Music:** Add `Downloads` patch ([#1881](https://github.com/MorpheApp/morphe-patches/issues/1881)) ([d078a37](https://github.com/MorpheApp/morphe-patches/commit/d078a37cd1a8ef93f9546efb24e783a7b826a8b8))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.27.0` ([4dabc41](https://github.com/MorpheApp/morphe-patches/commit/4dabc4142664669937d47ffad7d6f768aaa48f8e))

## [1.33.0](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0...v1.33.0) (2026-07-03)

### 🐛 Bug Fixes

* **Change package name:** Add incompatible apps, update all permissions and providers ([#1847](https://github.com/MorpheApp/morphe-patches/issues/1847)) ([ff5359a](https://github.com/MorpheApp/morphe-patches/commit/ff5359ac6d61b7b7274a7d7ed7c06198c1ed3b7f))
* **Reddit - Hide communities shelf:** Communities shelf not being hidden on experimental versions ([#1828](https://github.com/MorpheApp/morphe-patches/issues/1828)) ([0f05846](https://github.com/MorpheApp/morphe-patches/commit/0f0584668a38f7ba721a2eb9c4daec9c00de8466))
* **Reddit - Hide Trending shelves:** Hide 'Trending communities' shelf in search suggestions ([#1785](https://github.com/MorpheApp/morphe-patches/issues/1785)) ([a9a58fb](https://github.com/MorpheApp/morphe-patches/commit/a9a58fb2069437dbcbe6613f740881ca21cfd45c))
* **Reddit - Hide Trending shelves:** Hide 'Trending on Reddit' shelf ([#1849](https://github.com/MorpheApp/morphe-patches/issues/1849)) ([5dfff49](https://github.com/MorpheApp/morphe-patches/commit/5dfff49c21f0aad61e997ad1ef31c65af58f85ab))
* **YouTube - Add to queue:** Show reload options when player is minimized ([#1879](https://github.com/MorpheApp/morphe-patches/issues/1879)) ([95c4ecf](https://github.com/MorpheApp/morphe-patches/commit/95c4ecfb4525ca0964a223fdf2c0f51a9d8d6da0))
* **YouTube - Add to queue:** Support tablet form factor ([#1891](https://github.com/MorpheApp/morphe-patches/issues/1891)) ([f55b720](https://github.com/MorpheApp/morphe-patches/commit/f55b7206f78e6b5dbe063e6f9e39093929047f34))
* **YouTube - Add to queue:** Use app activity for dialog to open dialog ([f3e2b2b](https://github.com/MorpheApp/morphe-patches/commit/f3e2b2b3f3350ff6bea937f9eb81da10aab14c34))
* **YouTube - Add to queue:** Video from a playlist does not open or reload within the playlist ([fbca3e7](https://github.com/MorpheApp/morphe-patches/commit/fbca3e755a67d89026064a6c04dfbaf1bb676caf))
* **YouTube - Bypass link redirects:** Fix potential crash and cleanup ([6a0b518](https://github.com/MorpheApp/morphe-patches/commit/6a0b518403228c5575f80abf1c3cf48159454563))
* **YouTube - Disable player popup panels:** Patch not working for some users ([#1821](https://github.com/MorpheApp/morphe-patches/issues/1821)) ([2d34625](https://github.com/MorpheApp/morphe-patches/commit/2d34625cb3e6635fa5381ded1e38c464b8d9e269))
* **YouTube - Hide layout components:**  Match `RD` playlist URLs to improve "Hide mix playlists" filter ([#1835](https://github.com/MorpheApp/morphe-patches/issues/1835)) ([1172ce0](https://github.com/MorpheApp/morphe-patches/commit/1172ce044f14cc842eb6390d997d7793f8e2b4c3))
* **YouTube - Open system share sheet:** Add full link format along with shortener setting check ([0259b4c](https://github.com/MorpheApp/morphe-patches/commit/0259b4c50ea5502f8c7f2457a9d8522cbee4915a))
* **YouTube - Open system share sheet:** Increase the opening speed of the system share sheet ([9cacff8](https://github.com/MorpheApp/morphe-patches/commit/9cacff89172fb05760bdae2dbbae275c0db5934c))
* **YouTube - Open system share sheet:** Prevent consecutive attempts to close the panel ([d9c6b1b](https://github.com/MorpheApp/morphe-patches/commit/d9c6b1b08fdc290ed5f59ad80056452ca5f0d52b))
* **YouTube - Open system share sheet:** Support older app versions ([d1ccae8](https://github.com/MorpheApp/morphe-patches/commit/d1ccae8dc396322d406134122e90fb13c6c3ae0c))
* **YouTube - Reload video:** Use the correct URL query parameters ([9b399ec](https://github.com/MorpheApp/morphe-patches/commit/9b399ec5d240f84d7a9f2d2ffc3cb7877df1d0da))
* **YouTube - Return YouTube Dislike:** Unnecessary RYD API requests in playlist ([#1815](https://github.com/MorpheApp/morphe-patches/issues/1815)) ([219114a](https://github.com/MorpheApp/morphe-patches/commit/219114aaa3ae0e67993457a9f706bb5f7c397257))
* **YouTube - SponsorBlock:** Resolve missing resource dependency when patch is excluded ([3721511](https://github.com/MorpheApp/morphe-patches/commit/3721511a7e89124fe92d529399f58f3ec39b26f3))
* **YouTube - SponsorBlock:** Send correct user agent when submitting segments ([#1903](https://github.com/MorpheApp/morphe-patches/issues/1903)) ([37cecf4](https://github.com/MorpheApp/morphe-patches/commit/37cecf4e5e87599a24178aaaa7ebcd6703591c95))
* **YouTube Music - Scrobbling:** Parse artist and track from video title ([#1885](https://github.com/MorpheApp/morphe-patches/issues/1885)) ([29c8d02](https://github.com/MorpheApp/morphe-patches/commit/29c8d021426abc5d04c9cea0ae7aa9139374b38e))
* **YouTube Music - SponsorBlock:** Support older app versions ([bb74726](https://github.com/MorpheApp/morphe-patches/commit/bb7472618b96cf6953292b8466c347a1ddd523df))

### ✨ New Features

* Add `Network proxy` patch ([#1823](https://github.com/MorpheApp/morphe-patches/issues/1823)) ([6bf4d9f](https://github.com/MorpheApp/morphe-patches/commit/6bf4d9f436a9056b4af7df700ef5b91499b2c1eb))
* **YouTube - Hide layout components:** Add "Sanitize video subtitle" setting ([#1277](https://github.com/MorpheApp/morphe-patches/issues/1277)) ([0cb4bc5](https://github.com/MorpheApp/morphe-patches/commit/0cb4bc5d59c18b3df9037914db2002942db127be))
* **YouTube Music:** Add `Scrobbling` patch ([#1856](https://github.com/MorpheApp/morphe-patches/issues/1856)) ([f9ca802](https://github.com/MorpheApp/morphe-patches/commit/f9ca802aa756d7eb78ab86df5f302c3abfe2d15b))
* **YouTube Music:** Add `SponsorBlock` patch ([#1842](https://github.com/MorpheApp/morphe-patches/issues/1842)) ([0e6e8f1](https://github.com/MorpheApp/morphe-patches/commit/0e6e8f1c0d53df205be8cf12f365224293128f1f))
* **YouTube:** Add `Add to queue` patch ([#1837](https://github.com/MorpheApp/morphe-patches/issues/1837)) ([36a1e6e](https://github.com/MorpheApp/morphe-patches/commit/36a1e6e6d6c529aa94fc607970c2cf067b0f6f4c))
* **YouTube:** Add `Voice over translation` patch ([#1685](https://github.com/MorpheApp/morphe-patches/issues/1685)) ([d811a32](https://github.com/MorpheApp/morphe-patches/commit/d811a3264878d01697eb75bd05185d9359603a4a))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.26.0` ([de01fad](https://github.com/MorpheApp/morphe-patches/commit/de01fadca647632390ecf4148986880d924434b5))
* **YouTube Music:** Add experimental support for `9.25.50` ([bc6d8aa](https://github.com/MorpheApp/morphe-patches/commit/bc6d8aa3517cfa7918d0ac5849ccff42c7340ad6))
* **YouTube Music:** Add experimental support for `9.26.51` ([0be25a1](https://github.com/MorpheApp/morphe-patches/commit/0be25a10bfe1afbcb8bbdc5ff25b0272ba468ab4))
* **YouTube:** Add experimental support for `21.26.360` ([197e9ce](https://github.com/MorpheApp/morphe-patches/commit/197e9ce272515002787a41c919ff7ea8ec698f30))

## [1.33.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.9...v1.33.0-dev.10) (2026-07-02)

### 🐛 Bug Fixes

* **YouTube - Open system share sheet:** Add full link format along with shortener setting check ([0259b4c](https://github.com/MorpheApp/morphe-patches/commit/0259b4c50ea5502f8c7f2457a9d8522cbee4915a))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.26.51` ([0be25a1](https://github.com/MorpheApp/morphe-patches/commit/0be25a10bfe1afbcb8bbdc5ff25b0272ba468ab4))

## [1.33.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.8...v1.33.0-dev.9) (2026-07-01)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Support tablet form factor ([#1891](https://github.com/MorpheApp/morphe-patches/issues/1891)) ([f55b720](https://github.com/MorpheApp/morphe-patches/commit/f55b7206f78e6b5dbe063e6f9e39093929047f34))

## [1.33.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.7...v1.33.0-dev.8) (2026-06-30)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Show reload options when player is minimized ([#1879](https://github.com/MorpheApp/morphe-patches/issues/1879)) ([95c4ecf](https://github.com/MorpheApp/morphe-patches/commit/95c4ecfb4525ca0964a223fdf2c0f51a9d8d6da0))
* **YouTube - Bypass link redirects:** Fix potential crash and cleanup ([6a0b518](https://github.com/MorpheApp/morphe-patches/commit/6a0b518403228c5575f80abf1c3cf48159454563))
* **YouTube - Reload video:** Use the correct URL query parameters ([9b399ec](https://github.com/MorpheApp/morphe-patches/commit/9b399ec5d240f84d7a9f2d2ffc3cb7877df1d0da))
* **YouTube - Open system share sheet:** Support older app versions ([d1ccae8](https://github.com/MorpheApp/morphe-patches/commit/d1ccae8dc396322d406134122e90fb13c6c3ae0c))
* **YouTube Music - Scrobbling:** Parse artist and track from video title ([#1885](https://github.com/MorpheApp/morphe-patches/issues/1885)) ([29c8d02](https://github.com/MorpheApp/morphe-patches/commit/29c8d021426abc5d04c9cea0ae7aa9139374b38e))

## [1.33.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.6...v1.33.0-dev.7) (2026-06-29)

### 🐛 Bug Fixes

* **YouTube - Open system share sheet:** Prevent consecutive attempts to close the panel ([d9c6b1b](https://github.com/MorpheApp/morphe-patches/commit/d9c6b1b08fdc290ed5f59ad80056452ca5f0d52b))
* **YouTube Music - SponsorBlock:** Support older app versions ([bb74726](https://github.com/MorpheApp/morphe-patches/commit/bb7472618b96cf6953292b8466c347a1ddd523df))

## [1.33.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.5...v1.33.0-dev.6) (2026-06-29)

### 🐛 Bug Fixes

* **YouTube - SponsorBlock:** Resolve missing resource dependency when patch is excluded ([3721511](https://github.com/MorpheApp/morphe-patches/commit/3721511a7e89124fe92d529399f58f3ec39b26f3))
* **YouTube - Open system share sheet:** Increase the opening speed of the system share sheet ([9cacff8](https://github.com/MorpheApp/morphe-patches/commit/9cacff89172fb05760bdae2dbbae275c0db5934c))
* **YouTube - Add to queue:** Video from a playlist does not open or reload within the playlist ([fbca3e7](https://github.com/MorpheApp/morphe-patches/commit/fbca3e755a67d89026064a6c04dfbaf1bb676caf))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Sanitize video subtitle" setting ([#1277](https://github.com/MorpheApp/morphe-patches/issues/1277)) ([0cb4bc5](https://github.com/MorpheApp/morphe-patches/commit/0cb4bc5d59c18b3df9037914db2002942db127be))
* **YouTube Music:** Add `SponsorBlock` patch ([#1842](https://github.com/MorpheApp/morphe-patches/issues/1842)) ([0e6e8f1](https://github.com/MorpheApp/morphe-patches/commit/0e6e8f1c0d53df205be8cf12f365224293128f1f))

## [1.33.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.4...v1.33.0-dev.5) (2026-06-28)

### 🐛 Bug Fixes

* **YouTube - Add to queue:** Use app activity for dialog to open dialog ([f3e2b2b](https://github.com/MorpheApp/morphe-patches/commit/f3e2b2b3f3350ff6bea937f9eb81da10aab14c34))

## [1.33.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.3...v1.33.0-dev.4) (2026-06-28)

### ✨ New Features

* **YouTube Music:** Add `Scrobbling` patch ([#1856](https://github.com/MorpheApp/morphe-patches/issues/1856)) ([f9ca802](https://github.com/MorpheApp/morphe-patches/commit/f9ca802aa756d7eb78ab86df5f302c3abfe2d15b))
* **YouTube:** Add `Add to queue` patch ([#1837](https://github.com/MorpheApp/morphe-patches/issues/1837)) ([36a1e6e](https://github.com/MorpheApp/morphe-patches/commit/36a1e6e6d6c529aa94fc607970c2cf067b0f6f4c))

## [1.33.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.2...v1.33.0-dev.3) (2026-06-27)

### 🐛 Bug Fixes

* **Change package name:** Add incompatible apps, update all permissions and providers ([#1847](https://github.com/MorpheApp/morphe-patches/issues/1847)) ([ff5359a](https://github.com/MorpheApp/morphe-patches/commit/ff5359ac6d61b7b7274a7d7ed7c06198c1ed3b7f))
* **Reddit - Hide Trending shelves:** Hide 'Trending on Reddit' shelf ([#1849](https://github.com/MorpheApp/morphe-patches/issues/1849)) ([5dfff49](https://github.com/MorpheApp/morphe-patches/commit/5dfff49c21f0aad61e997ad1ef31c65af58f85ab))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.26.0` ([de01fad](https://github.com/MorpheApp/morphe-patches/commit/de01fadca647632390ecf4148986880d924434b5))
* **YouTube:** Add experimental support for `21.26.360` ([197e9ce](https://github.com/MorpheApp/morphe-patches/commit/197e9ce272515002787a41c919ff7ea8ec698f30))

## [1.33.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.33.0-dev.1...v1.33.0-dev.2) (2026-06-26)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:**  Match `RD` playlist URLs to improve "Hide mix playlists" filter ([#1835](https://github.com/MorpheApp/morphe-patches/issues/1835)) ([1172ce0](https://github.com/MorpheApp/morphe-patches/commit/1172ce044f14cc842eb6390d997d7793f8e2b4c3))

### ✨ New Features

* **YouTube:** Add `Voice over translation` patch ([#1685](https://github.com/MorpheApp/morphe-patches/issues/1685)) ([d811a32](https://github.com/MorpheApp/morphe-patches/commit/d811a3264878d01697eb75bd05185d9359603a4a))

## [1.33.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0...v1.33.0-dev.1) (2026-06-25)

### 🐛 Bug Fixes

* **Reddit - Hide communities shelf:** Communities shelf not being hidden on experimental versions ([#1828](https://github.com/MorpheApp/morphe-patches/issues/1828)) ([0f05846](https://github.com/MorpheApp/morphe-patches/commit/0f0584668a38f7ba721a2eb9c4daec9c00de8466))
* **Reddit - Hide Trending shelves:** Hide 'Trending communities' shelf in search suggestions ([#1785](https://github.com/MorpheApp/morphe-patches/issues/1785)) ([a9a58fb](https://github.com/MorpheApp/morphe-patches/commit/a9a58fb2069437dbcbe6613f740881ca21cfd45c))
* **YouTube - Disable player popup panels:** Patch not working for some users ([#1821](https://github.com/MorpheApp/morphe-patches/issues/1821)) ([2d34625](https://github.com/MorpheApp/morphe-patches/commit/2d34625cb3e6635fa5381ded1e38c464b8d9e269))
* **YouTube - Return YouTube Dislike:** Unnecessary RYD API requests in playlist ([#1815](https://github.com/MorpheApp/morphe-patches/issues/1815)) ([219114a](https://github.com/MorpheApp/morphe-patches/commit/219114aaa3ae0e67993457a9f706bb5f7c397257))

### ✨ New Features

* Add `Network proxy` patch ([#1823](https://github.com/MorpheApp/morphe-patches/issues/1823)) ([6bf4d9f](https://github.com/MorpheApp/morphe-patches/commit/6bf4d9f436a9056b4af7df700ef5b91499b2c1eb))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.25.50` ([bc6d8aa](https://github.com/MorpheApp/morphe-patches/commit/bc6d8aa3517cfa7918d0ac5849ccff42c7340ad6))

## [1.32.0](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0...v1.32.0) (2026-06-23)

### 🐛 Bug Fixes

* **YouTube - Bypass link redirects:** Resolve patch not working on community posts and video descriptions ([#1755](https://github.com/MorpheApp/morphe-patches/issues/1755)) ([c5c6376](https://github.com/MorpheApp/morphe-patches/commit/c5c6376546efdc90cbf89f7f5554880432161b22))
* **YouTube - Change form factor:** Prevent app crash when using tablet mode in `onResume` state ([#1803](https://github.com/MorpheApp/morphe-patches/issues/1803)) ([4b0de25](https://github.com/MorpheApp/morphe-patches/commit/4b0de256e74f6eeb279ba164146fb9a01f2f8176))
* **YouTube - Copy video link:** Wrong localization resource name ([dbddc1a](https://github.com/MorpheApp/morphe-patches/commit/dbddc1a55ea37e90bb7bfae221dd86a4a042b5fb))
* **YouTube - Disable player popup panels:** Deprecated the old way to disable popup panels ([709b4fb](https://github.com/MorpheApp/morphe-patches/commit/709b4fb5f5a98713903befbbc3a54e4a11e9a668))
* **YouTube - Disable player popup panels:** Patch doesn't work in some circumstances ([6d6018c](https://github.com/MorpheApp/morphe-patches/commit/6d6018cf4a4ee6f79a283001aebe5b9d21767741))
* **YouTube - Hide layout components:** Resolve "Hide horizontal shelves" hiding other components ([#930](https://github.com/MorpheApp/morphe-patches/issues/930)) ([3c53157](https://github.com/MorpheApp/morphe-patches/commit/3c5315774896dc78ab5ad4d7b44380f9a21d3312))
* **YouTube - Sanitize sharing links:** Live links are not sanitized ([ad91b37](https://github.com/MorpheApp/morphe-patches/commit/ad91b3759c42befbf4c32804cad5de5a48f14255))
* **YouTube - Navigation bar:** Prevent navigation bar animation when swiping to dismiss miniplayer ([#1800](https://github.com/MorpheApp/morphe-patches/issues/1800)) ([dcc4c0c](https://github.com/MorpheApp/morphe-patches/commit/dcc4c0c28ac600ca057c8720f5e71f8c712011ac))
* **YouTube - Override YouTube Music buttons:** Target app opens when clicking on 'YouTube Music' button inside explore menu ([#1707](https://github.com/MorpheApp/morphe-patches/issues/1707)) ([1f08df2](https://github.com/MorpheApp/morphe-patches/commit/1f08df24848bce582919e21b4b3e3f7bb6ebe5ab))
* **YouTube - Reload video:** App exits after pressing back button ([#1740](https://github.com/MorpheApp/morphe-patches/issues/1740)) ([743bc76](https://github.com/MorpheApp/morphe-patches/commit/743bc76743c529aa8f6da4ecffd9643088c7fd97))
* **YouTube - Remove viewer discretion dialog:** In-app video downloader does not work for Premium users ([#1756](https://github.com/MorpheApp/morphe-patches/issues/1756)) ([3353302](https://github.com/MorpheApp/morphe-patches/commit/3353302753352388dbeef9454bb7902cdeb9eae0))
* **YouTube - Spoof video streams:** Always allow details fetching ([6bc0eee](https://github.com/MorpheApp/morphe-patches/commit/6bc0eeefe02fa89a5d0669698ceb2fffc5bc51c7))
* **YouTube Music - Track crossfade:** Dismissing the queue does not stop playback, fix songs incorrectly skipped ([#1773](https://github.com/MorpheApp/morphe-patches/issues/1773)) ([206b84e](https://github.com/MorpheApp/morphe-patches/commit/206b84eb6b20f873edee53253fd8460a993a30ab))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide comments by keywords" setting ([#1759](https://github.com/MorpheApp/morphe-patches/issues/1759)) ([d076c2b](https://github.com/MorpheApp/morphe-patches/commit/d076c2b3b7c561952fa2ae94be5d4de3119439af))
* **YouTube - Hide video action buttons:** Add "Restore old video action bar", "Hide Connect button", and "Hide More button" settings ([#1780](https://github.com/MorpheApp/morphe-patches/issues/1780)) ([0481899](https://github.com/MorpheApp/morphe-patches/commit/0481899aef98c45aa3cc88c9e3ff5cc8387fb4c5))
* **YouTube - Navigation bar:** Restore "Hide Cast button" setting in toolbar ([c27e63e](https://github.com/MorpheApp/morphe-patches/commit/c27e63ecb464b1e85e6ff97f13e21cc641a99fe7))
* **YouTube - Navigation bar:** Add "Hide Chat button" setting in toolbar ([32ee079](https://github.com/MorpheApp/morphe-patches/commit/32ee07910d9d80a8f3eac3b6f0dd0968a6c6c81d))
* **YouTube - Open videos fullscreen:** Add landscape mode option ([#1770](https://github.com/MorpheApp/morphe-patches/issues/1770)) ([c2e78f1](https://github.com/MorpheApp/morphe-patches/commit/c2e78f14c4539479213623cb62587f02051ff421))
* **YouTube:** Add `Disable fullscreen gesture` patch ([#1724](https://github.com/MorpheApp/morphe-patches/issues/1724)) ([00ec593](https://github.com/MorpheApp/morphe-patches/commit/00ec59355d57c66f1189b779ab6806c7dcdd5fd3))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.24.0` ([eb47573](https://github.com/MorpheApp/morphe-patches/commit/eb4757326ef90cf6cf9865b12bd451603cb8a111))
* **Reddit:** Add experimental support for `2026.25.0` ([d1a8fcc](https://github.com/MorpheApp/morphe-patches/commit/d1a8fccf5dfbec51eec36d1f49cdf2a9fe50847d))
* **YouTube:** Add experimental support for `21.25.523` ([773b386](https://github.com/MorpheApp/morphe-patches/commit/773b386ba8d8bb0c831dee82880b0fcdbbd58b75))
* **YouTube Music:** Add support for `9.15.51` ([4ef13c7](https://github.com/MorpheApp/morphe-patches/commit/4ef13c7a0475c1b9f3aeac3613711df81806b461))
* **YouTube Music:** Add experimental support for `9.23.52` ([#1747](https://github.com/MorpheApp/morphe-patches/issues/1747)) ([31f0c4a](https://github.com/MorpheApp/morphe-patches/commit/31f0c4a503226ce7e6ffa58eb8f32af2f1f92f8c))
* **YouTube Music:** Add experimental support for `9.24.51` ([d30738a](https://github.com/MorpheApp/morphe-patches/commit/d30738a771222c8181623371a2f3b27b442dc478))

## [1.32.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.6...v1.32.0-dev.7) (2026-06-22)

### 🐛 Bug Fixes

* **YouTube - Change form factor:** Prevent app crash when using tablet mode in `onResume` state ([#1803](https://github.com/MorpheApp/morphe-patches/issues/1803)) ([4b0de25](https://github.com/MorpheApp/morphe-patches/commit/4b0de256e74f6eeb279ba164146fb9a01f2f8176))
* **YouTube - Hide layout components:** Resolve "Hide horizontal shelves" hiding other components ([#930](https://github.com/MorpheApp/morphe-patches/issues/930)) ([3c53157](https://github.com/MorpheApp/morphe-patches/commit/3c5315774896dc78ab5ad4d7b44380f9a21d3312))

## [1.32.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.5...v1.32.0-dev.6) (2026-06-22)

### 🐛 Bug Fixes

* **YouTube - Disable player popup panels:** Patch doesn't work in some circumstances ([6d6018c](https://github.com/MorpheApp/morphe-patches/commit/6d6018cf4a4ee6f79a283001aebe5b9d21767741))
* **YouTube - Spoof video streams:** Always allow details fetching ([6bc0eee](https://github.com/MorpheApp/morphe-patches/commit/6bc0eeefe02fa89a5d0669698ceb2fffc5bc51c7))

## [1.32.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.4...v1.32.0-dev.5) (2026-06-21)

### 🐛 Bug Fixes

* **YouTube - Navigation bar:** Prevent navigation bar animation when swiping to dismiss miniplayer ([#1800](https://github.com/MorpheApp/morphe-patches/issues/1800)) ([dcc4c0c](https://github.com/MorpheApp/morphe-patches/commit/dcc4c0c28ac600ca057c8720f5e71f8c712011ac))

### ✨ New Features

* **YouTube - Hide video action buttons:** Add "Restore old video action bar", "Hide Connect button", and "Hide More button" settings ([#1780](https://github.com/MorpheApp/morphe-patches/issues/1780)) ([0481899](https://github.com/MorpheApp/morphe-patches/commit/0481899aef98c45aa3cc88c9e3ff5cc8387fb4c5))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.25.0` ([d1a8fcc](https://github.com/MorpheApp/morphe-patches/commit/d1a8fccf5dfbec51eec36d1f49cdf2a9fe50847d))

## [1.32.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.3...v1.32.0-dev.4) (2026-06-20)

### ✨ New Features

* **YouTube - Open videos fullscreen:** Add landscape mode option ([#1770](https://github.com/MorpheApp/morphe-patches/issues/1770)) ([c2e78f1](https://github.com/MorpheApp/morphe-patches/commit/c2e78f14c4539479213623cb62587f02051ff421))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.25.523` ([773b386](https://github.com/MorpheApp/morphe-patches/commit/773b386ba8d8bb0c831dee82880b0fcdbbd58b75))

## [1.32.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.2...v1.32.0-dev.3) (2026-06-18)

### 🐛 Bug Fixes

* **YouTube Music - Track crossfade:** Dismissing the queue does not stop playback, fix songs incorrectly skipped ([#1773](https://github.com/MorpheApp/morphe-patches/issues/1773)) ([206b84e](https://github.com/MorpheApp/morphe-patches/commit/206b84eb6b20f873edee53253fd8460a993a30ab))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.24.51` ([d30738a](https://github.com/MorpheApp/morphe-patches/commit/d30738a771222c8181623371a2f3b27b442dc478))

## [1.32.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.32.0-dev.1...v1.32.0-dev.2) (2026-06-17)

### 🐛 Bug Fixes

* **YouTube - Bypass link redirects:** Resolve patch not working on community posts and video descriptions ([#1755](https://github.com/MorpheApp/morphe-patches/issues/1755)) ([c5c6376](https://github.com/MorpheApp/morphe-patches/commit/c5c6376546efdc90cbf89f7f5554880432161b22))
* **YouTube - Copy video link:** Wrong localization resource name ([dbddc1a](https://github.com/MorpheApp/morphe-patches/commit/dbddc1a55ea37e90bb7bfae221dd86a4a042b5fb))
* **YouTube - Override YouTube Music buttons:** Target app opens when clicking on 'YouTube Music' button inside explore menu ([#1707](https://github.com/MorpheApp/morphe-patches/issues/1707)) ([1f08df2](https://github.com/MorpheApp/morphe-patches/commit/1f08df24848bce582919e21b4b3e3f7bb6ebe5ab))
* **YouTube - Remove viewer discretion dialog:** In-app video downloader does not work for Premium users ([#1756](https://github.com/MorpheApp/morphe-patches/issues/1756)) ([3353302](https://github.com/MorpheApp/morphe-patches/commit/3353302753352388dbeef9454bb7902cdeb9eae0))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide comments by keywords" setting ([#1759](https://github.com/MorpheApp/morphe-patches/issues/1759)) ([d076c2b](https://github.com/MorpheApp/morphe-patches/commit/d076c2b3b7c561952fa2ae94be5d4de3119439af))
* **YouTube - Navigation bar:** Restore "Hide Cast button" setting in toolbar ([c27e63e](https://github.com/MorpheApp/morphe-patches/commit/c27e63ecb464b1e85e6ff97f13e21cc641a99fe7))
* **YouTube - Navigation bar:** Add "Hide Chat button" setting in toolbar ([32ee079](https://github.com/MorpheApp/morphe-patches/commit/32ee07910d9d80a8f3eac3b6f0dd0968a6c6c81d))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.24.0` ([eb47573](https://github.com/MorpheApp/morphe-patches/commit/eb4757326ef90cf6cf9865b12bd451603cb8a111))
* **YouTube Music:** Add support for `9.15.51` ([4ef13c7](https://github.com/MorpheApp/morphe-patches/commit/4ef13c7a0475c1b9f3aeac3613711df81806b461))

## [1.32.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0...v1.32.0-dev.1) (2026-06-15)

### 🐛 Bug Fixes

* **YouTube - Sanitize sharing links:** Live links are not sanitized ([ad91b37](https://github.com/MorpheApp/morphe-patches/commit/ad91b3759c42befbf4c32804cad5de5a48f14255))
* **YouTube - Reload video:** App exits after pressing back button ([#1740](https://github.com/MorpheApp/morphe-patches/issues/1740)) ([743bc76](https://github.com/MorpheApp/morphe-patches/commit/743bc76743c529aa8f6da4ecffd9643088c7fd97))

### ✨ New Features

* **YouTube:** Add `Disable fullscreen gesture` patch ([#1724](https://github.com/MorpheApp/morphe-patches/issues/1724)) ([00ec593](https://github.com/MorpheApp/morphe-patches/commit/00ec59355d57c66f1189b779ab6806c7dcdd5fd3))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.23.52` ([#1747](https://github.com/MorpheApp/morphe-patches/issues/1747)) ([31f0c4a](https://github.com/MorpheApp/morphe-patches/commit/31f0c4a503226ce7e6ffa58eb8f32af2f1f92f8c))

## [1.31.0](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0...v1.31.0) (2026-06-13)

### 🐛 Bug Fixes

* **Reddit - Hide Ask button:** Update patch to support experimental app targets ([#1623](https://github.com/MorpheApp/morphe-patches/issues/1623)) ([7c4a9fb](https://github.com/MorpheApp/morphe-patches/commit/7c4a9fbfccd6c3bd80b06f67d49404cd1ddc7019))
* **Reddit - Hide Trending Today shelf:** Hide "Trending" header ([#1622](https://github.com/MorpheApp/morphe-patches/issues/1622)) ([00e1587](https://github.com/MorpheApp/morphe-patches/commit/00e1587633aea8cf5856dd89a951ced5be75da0a))
* **YouTube - Exit fullscreen mode:** Shorts regular player does not exit fullscreen mode ([2fb96a6](https://github.com/MorpheApp/morphe-patches/commit/2fb96a6918775d344c3208871e98a4c87805493c))
* **YouTube - Hide layout components:** Allow partial matches for "Enable Library / You bottom menu filter" setting ([59ea065](https://github.com/MorpheApp/morphe-patches/commit/59ea06565cfbd55a69be4494f42d6734a7c25668))
* **YouTube - Sanitize sharing links:** Exclude post links from shortening ([ce1dd46](https://github.com/MorpheApp/morphe-patches/commit/ce1dd46276e3cd830d8644774819b3395c355abb))
* **YouTube - Miniplayer:** Restore play/pause icons for minimal miniplayer on 21.17+ ([#1644](https://github.com/MorpheApp/morphe-patches/issues/1644)) ([9f4624f](https://github.com/MorpheApp/morphe-patches/commit/9f4624f64b701d7610c34d78a41f2288cf2fcc74))
* **YouTube - Open system share sheet:** Prevent PiP from being invoked ([#1635](https://github.com/MorpheApp/morphe-patches/issues/1635)) ([195e749](https://github.com/MorpheApp/morphe-patches/commit/195e749f5afd12e5bdb489a1115b2383651a0f51))
* **YouTube - Remove background playback restrictions:** Fix Shorts background playback not working ([#1629](https://github.com/MorpheApp/morphe-patches/issues/1629)) ([250f85e](https://github.com/MorpheApp/morphe-patches/commit/250f85e2a740197e6aaeff2acb24b2aad086cf51))
* **YouTube - Remove viewer discretion dialog:** Dialog cannot be dismissed ([#1710](https://github.com/MorpheApp/morphe-patches/issues/1710)) ([b962bd0](https://github.com/MorpheApp/morphe-patches/commit/b962bd0c485a5bea1b46bd55fee5943aefd797bd))
* **YouTube - Sanitize sharing links:** Resolve "Open system share sheet" not working ([#1599](https://github.com/MorpheApp/morphe-patches/issues/1599)) ([24c319a](https://github.com/MorpheApp/morphe-patches/commit/24c319a78593b8cd2def3cd98146dee1f2c09a0a))
* **YouTube - Theme:** Apply dark text color to "Material You" notification dot count ([#1615](https://github.com/MorpheApp/morphe-patches/issues/1615)) ([5289c6b](https://github.com/MorpheApp/morphe-patches/commit/5289c6b6a64df89fb85c3d6f563a24bd9c7f345e))
* **YouTube Music - Theme:** Apply "Material You" to notification dot ([#1657](https://github.com/MorpheApp/morphe-patches/issues/1657)) ([0355a17](https://github.com/MorpheApp/morphe-patches/commit/0355a17ac8ed19b161572ec2ea2b62d86bdb6803))

### ✨ New Features

* **YouTube - Change form factor:** Add "Enable tablet layout in player" setting ([#1695](https://github.com/MorpheApp/morphe-patches/issues/1695)) ([6376142](https://github.com/MorpheApp/morphe-patches/commit/6376142395508e76e64ce8188e4477bb181842ed))
* **YouTube - Hide ads:** Hide 'Includes paid promotion' label in miniplayer ([#1699](https://github.com/MorpheApp/morphe-patches/issues/1699)) ([c9ce526](https://github.com/MorpheApp/morphe-patches/commit/c9ce5269d1e205e84e6e4160712463b86966714d))
* **YouTube - Hide layout components:** Add "Hide 'Sync to video' button" setting ([#1694](https://github.com/MorpheApp/morphe-patches/issues/1694)) ([e870d1e](https://github.com/MorpheApp/morphe-patches/commit/e870d1eb3d008065e4700030e2a4c51f6cf4a8a4))
* **YouTube - Hide layout components:** Add "Hide Library / You bottom menu filter" setting ([#1583](https://github.com/MorpheApp/morphe-patches/issues/1583)) ([c093b60](https://github.com/MorpheApp/morphe-patches/commit/c093b60965e439e7a1b5b7cdf34717e6b159beb4))
* **YouTube - Hide layout components:** Add "Hide snackbar" setting ([#1658](https://github.com/MorpheApp/morphe-patches/issues/1658)) ([0e27c61](https://github.com/MorpheApp/morphe-patches/commit/0e27c611042dd75cf9c8c730df091eb440ea815b))
* **YouTube - Hide layout components:** Add path `&` syntax to custom filters ([#1693](https://github.com/MorpheApp/morphe-patches/issues/1693)) ([2ab0366](https://github.com/MorpheApp/morphe-patches/commit/2ab0366c8ae9dc6de3f361ed5a5d7ce446b4e8cd))
* **YouTube - Playback speed:** Add "Disable playback speed for music" setting ([#1691](https://github.com/MorpheApp/morphe-patches/issues/1691)) ([81c8f50](https://github.com/MorpheApp/morphe-patches/commit/81c8f50f408750e0d8434310d786c1e5fab59872))
* **YouTube - Save to watch later:** Add playlist queue manager ([#1648](https://github.com/MorpheApp/morphe-patches/issues/1648)) ([a5265ac](https://github.com/MorpheApp/morphe-patches/commit/a5265ac85cd758afc68172b6d073fc8e0ca4fba6))
* **YouTube - SponsorBlock:** Add channel whitelist ([#1661](https://github.com/MorpheApp/morphe-patches/issues/1661)) ([6d96cee](https://github.com/MorpheApp/morphe-patches/commit/6d96ceecb82c290b2d2545212bb7b80762fc98dc))
* **YouTube - SponsorBlock:** Add fade animation to the new segment panel ([#1577](https://github.com/MorpheApp/morphe-patches/issues/1577)) ([771f7fb](https://github.com/MorpheApp/morphe-patches/commit/771f7fbde1808c4129b01c0c95f0f0d08ff4ed4f))
* **YouTube Music - Settings:** Add icons to Morphe preference screen ([#1625](https://github.com/MorpheApp/morphe-patches/issues/1625)) ([d51c24f](https://github.com/MorpheApp/morphe-patches/commit/d51c24f846cfd0b028a1b2d31b69913ae1f7dadb))
* **YouTube Music:** Add `Enable swipe to dismiss miniplayer` patch ([#1420](https://github.com/MorpheApp/morphe-patches/issues/1420)) ([4795cc4](https://github.com/MorpheApp/morphe-patches/commit/4795cc4803cee0dc8aeefb0c0b6e968fff14698c))
* **YouTube Music - Track crossfade:** Add support for `9.x` ([#1582](https://github.com/MorpheApp/morphe-patches/issues/1582)) ([7150d06](https://github.com/MorpheApp/morphe-patches/commit/7150d06167b4a6ba699bbd48a4c5d1055d8d2789))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.22.0` ([3f443e2](https://github.com/MorpheApp/morphe-patches/commit/3f443e22ec39c3efdf98a562a0db376704212e4b))
* **Reddit:** Add experimental support for `2026.23.0` ([2d24e8d](https://github.com/MorpheApp/morphe-patches/commit/2d24e8d9ee109a83ac4ed774de5848aca38db952))
* **YouTube Music:** Add  support for `8.51.51` ([73d1d53](https://github.com/MorpheApp/morphe-patches/commit/73d1d53afbe9746bf3d54629553720eac4c89f19))
* **YouTube Music:** Add experimental support for `9.22.53` ([57f1bda](https://github.com/MorpheApp/morphe-patches/commit/57f1bdae0161748daeb6e3e4460b84938121b479))
* **YouTube:** Add experimental support for `21.22.164` ([b88b9ca](https://github.com/MorpheApp/morphe-patches/commit/b88b9cacc2af040fb2643a350d6b5caeaf19eea5))
* **YouTube:** Add experimental support for `21.23.480` ([9e0d0dd](https://github.com/MorpheApp/morphe-patches/commit/9e0d0dd66e73b4d361926637f2906237d1d0ad1d))
* **YouTube:** Add experimental support for `21.24.360` ([93f3acd](https://github.com/MorpheApp/morphe-patches/commit/93f3acd3af902edf1a5e063e4699d0471a0ef67d))


## [1.31.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.12...v1.31.0-dev.13) (2026-06-12)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Allow partial matches for "Enable Library / You bottom menu filter" setting ([59ea065](https://github.com/MorpheApp/morphe-patches/commit/59ea06565cfbd55a69be4494f42d6734a7c25668))
* **YouTube - Sanitize sharing links:** Exclude post links from shortening ([ce1dd46](https://github.com/MorpheApp/morphe-patches/commit/ce1dd46276e3cd830d8644774819b3395c355abb))

### ✨ New Features

* **YouTube - Hide ads:** Hide 'Includes paid promotion' label in miniplayer ([#1699](https://github.com/MorpheApp/morphe-patches/issues/1699)) ([c9ce526](https://github.com/MorpheApp/morphe-patches/commit/c9ce5269d1e205e84e6e4160712463b86966714d))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.24.360` ([93f3acd](https://github.com/MorpheApp/morphe-patches/commit/93f3acd3af902edf1a5e063e4699d0471a0ef67d))

## [1.31.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.11...v1.31.0-dev.12) (2026-06-11)

### 🐛 Bug Fixes

* **YouTube - Save to watch later:** Fix black queue icon in legacy player ([7416c24](https://github.com/MorpheApp/morphe-patches/commit/7416c240ca9412b50fd7a26bb638f3ce5fd375cd))
* **YouTube - Remove viewer discretion dialog:** Dialog cannot be dismissed ([#1710](https://github.com/MorpheApp/morphe-patches/issues/1710)) ([b962bd0](https://github.com/MorpheApp/morphe-patches/commit/b962bd0c485a5bea1b46bd55fee5943aefd797bd))

### ✨ New Features

* **YouTube - Change form factor:** Add "Enable tablet layout in player" setting ([#1695](https://github.com/MorpheApp/morphe-patches/issues/1695)) ([6376142](https://github.com/MorpheApp/morphe-patches/commit/6376142395508e76e64ce8188e4477bb181842ed))

## [1.31.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.10...v1.31.0-dev.11) (2026-06-10)

### 🐛 Bug Fixes

* **YouTube - Save to watch later:** Handle saved playlist is no longer available ([#1701](https://github.com/MorpheApp/morphe-patches/issues/1701)) ([bf04fb7](https://github.com/MorpheApp/morphe-patches/commit/bf04fb7c1d5c7e570bb62162066470bbaf6c388a))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide 'Sync to video' button" setting ([#1694](https://github.com/MorpheApp/morphe-patches/issues/1694)) ([e870d1e](https://github.com/MorpheApp/morphe-patches/commit/e870d1eb3d008065e4700030e2a4c51f6cf4a8a4))

## [1.31.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.9...v1.31.0-dev.10) (2026-06-09)

### 🐛 Bug Fixes

* **YouTube - Theme:** Light color theme is not applied ([#1689](https://github.com/MorpheApp/morphe-patches/issues/1689)) ([5925a8e](https://github.com/MorpheApp/morphe-patches/commit/5925a8eb84c2c77903ffba5151730f61c38cd899))

### ✨ New Features

* **YouTube - Hide layout components:** Add path `&` syntax to custom filters ([#1693](https://github.com/MorpheApp/morphe-patches/issues/1693)) ([2ab0366](https://github.com/MorpheApp/morphe-patches/commit/2ab0366c8ae9dc6de3f361ed5a5d7ce446b4e8cd))
* **YouTube - Playback speed:** Add "Disable playback speed for music" setting ([#1691](https://github.com/MorpheApp/morphe-patches/issues/1691)) ([81c8f50](https://github.com/MorpheApp/morphe-patches/commit/81c8f50f408750e0d8434310d786c1e5fab59872))

## [1.31.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.8...v1.31.0-dev.9) (2026-06-08)

### 🐛 Bug Fixes

* **YouTube - Save to watch later:** Add `ScrollView` to playlist selection dialog ([#1692](https://github.com/MorpheApp/morphe-patches/issues/1692)) ([acf2326](https://github.com/MorpheApp/morphe-patches/commit/acf2326366c403bfca16c277bf2efd721d411bc2))

## [1.31.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.7...v1.31.0-dev.8) (2026-06-07)

### 🐛 Bug Fixes

* **YouTube - Save to watch later:** Error toast is shown if app is minimized then resumed before adding to playlist ([#1670](https://github.com/MorpheApp/morphe-patches/issues/1670)) ([18ac572](https://github.com/MorpheApp/morphe-patches/commit/18ac572c8c56f3eeac1849b31c0204bc76cdc901))
* **YouTube Music - Theme:** Apply "Material You" to notification dot ([#1657](https://github.com/MorpheApp/morphe-patches/issues/1657)) ([0355a17](https://github.com/MorpheApp/morphe-patches/commit/0355a17ac8ed19b161572ec2ea2b62d86bdb6803))

### ✨ New Features

* **YouTube - SponsorBlock:** Add channel whitelist ([#1661](https://github.com/MorpheApp/morphe-patches/issues/1661)) ([6d96cee](https://github.com/MorpheApp/morphe-patches/commit/6d96ceecb82c290b2d2545212bb7b80762fc98dc))
* **YouTube Music:** Add `Enable swipe to dismiss miniplayer` patch ([#1420](https://github.com/MorpheApp/morphe-patches/issues/1420)) ([4795cc4](https://github.com/MorpheApp/morphe-patches/commit/4795cc4803cee0dc8aeefb0c0b6e968fff14698c))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.23.0` ([2d24e8d](https://github.com/MorpheApp/morphe-patches/commit/2d24e8d9ee109a83ac4ed774de5848aca38db952))

## [1.31.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.6...v1.31.0-dev.7) (2026-06-06)

### 🐛 Bug Fixes

* **YouTube - Exit fullscreen mode:** Shorts regular player does not exit fullscreen mode ([2fb96a6](https://github.com/MorpheApp/morphe-patches/commit/2fb96a6918775d344c3208871e98a4c87805493c))
* **YouTube - Save to watch later:** Correctly save queue into selected playlist ([a8d1732](https://github.com/MorpheApp/morphe-patches/commit/a8d1732d41d4e7f007e8d1d6f95dc67d8ccdb6b5))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide snackbar" setting ([#1658](https://github.com/MorpheApp/morphe-patches/issues/1658)) ([0e27c61](https://github.com/MorpheApp/morphe-patches/commit/0e27c611042dd75cf9c8c730df091eb440ea815b))
* **YouTube - Save to watch later:** Add option to swap Save and Queue actions ([#1664](https://github.com/MorpheApp/morphe-patches/issues/1664)) ([db7cc5b](https://github.com/MorpheApp/morphe-patches/commit/db7cc5becce5a4893faef9f95deb4134114b213c))

## [1.31.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.5...v1.31.0-dev.6) (2026-06-05)

### ✨ New Features

* **YouTube - Save to watch later:** Add playlist queue manager ([#1648](https://github.com/MorpheApp/morphe-patches/issues/1648)) ([a5265ac](https://github.com/MorpheApp/morphe-patches/commit/a5265ac85cd758afc68172b6d073fc8e0ca4fba6))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.23.480` ([9e0d0dd](https://github.com/MorpheApp/morphe-patches/commit/9e0d0dd66e73b4d361926637f2906237d1d0ad1d))

## [1.31.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.4...v1.31.0-dev.5) (2026-06-04)

### 🐛 Bug Fixes

* **YouTube - Miniplayer:** Restore play/pause icons for minimal miniplayer on `21.17+` ([#1644](https://github.com/MorpheApp/morphe-patches/issues/1644)) ([9f4624f](https://github.com/MorpheApp/morphe-patches/commit/9f4624f64b701d7610c34d78a41f2288cf2fcc74))
* **YouTube - Sanitize sharing links:** Fix "Copy video URL button" having tracking query parameters ([23fa3b0](https://github.com/MorpheApp/morphe-patches/commit/23fa3b01f56e282a1dc6d171e2b936bd5020d27e))

## [1.31.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.3...v1.31.0-dev.4) (2026-06-03)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** "Hide Library / You tab bottom menu" doesn't work on some versions ([1551524](https://github.com/MorpheApp/morphe-patches/commit/1551524475f0f86ad05cf5689129a6bf6a0cc08f))
* **YouTube - Open system share sheet:** Prevent PiP from being invoked ([#1635](https://github.com/MorpheApp/morphe-patches/issues/1635)) ([195e749](https://github.com/MorpheApp/morphe-patches/commit/195e749f5afd12e5bdb489a1115b2383651a0f51))
* **YouTube - Theme:** Apply dark text color to "Material You" notification dot count ([#1615](https://github.com/MorpheApp/morphe-patches/issues/1615)) ([5289c6b](https://github.com/MorpheApp/morphe-patches/commit/5289c6b6a64df89fb85c3d6f563a24bd9c7f345e))

### ✨ New Features

* **YouTube Music - Settings:** Add icons to Morphe preference screen ([#1625](https://github.com/MorpheApp/morphe-patches/issues/1625)) ([d51c24f](https://github.com/MorpheApp/morphe-patches/commit/d51c24f846cfd0b028a1b2d31b69913ae1f7dadb))

### 🚀 Updated App Support

* **YouTube Music:** Add  support for `8.51.51` ([73d1d53](https://github.com/MorpheApp/morphe-patches/commit/73d1d53afbe9746bf3d54629553720eac4c89f19))
* **YouTube Music:** Add experimental support for `9.22.53` ([57f1bda](https://github.com/MorpheApp/morphe-patches/commit/57f1bdae0161748daeb6e3e4460b84938121b479))

## [1.31.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.2...v1.31.0-dev.3) (2026-06-02)

### 🐛 Bug Fixes

* **Reddit - Hide Ask button:** Update patch to support experimental app targets ([#1623](https://github.com/MorpheApp/morphe-patches/issues/1623)) ([7c4a9fb](https://github.com/MorpheApp/morphe-patches/commit/7c4a9fbfccd6c3bd80b06f67d49404cd1ddc7019))
* **Reddit - Hide Trending Today shelf:** Hide "Trending" header ([#1622](https://github.com/MorpheApp/morphe-patches/issues/1622)) ([00e1587](https://github.com/MorpheApp/morphe-patches/commit/00e1587633aea8cf5856dd89a951ced5be75da0a))
* **YouTube - Remove background playback restrictions:** Fix Shorts background playback not working ([#1629](https://github.com/MorpheApp/morphe-patches/issues/1629)) ([250f85e](https://github.com/MorpheApp/morphe-patches/commit/250f85e2a740197e6aaeff2acb24b2aad086cf51))
* **YouTube - Sanitize sharing links:** Resolve "Open system share sheet" not working ([#1599](https://github.com/MorpheApp/morphe-patches/issues/1599)) ([24c319a](https://github.com/MorpheApp/morphe-patches/commit/24c319a78593b8cd2def3cd98146dee1f2c09a0a))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide Library / You bottom menu filter" setting ([#1583](https://github.com/MorpheApp/morphe-patches/issues/1583)) ([c093b60](https://github.com/MorpheApp/morphe-patches/commit/c093b60965e439e7a1b5b7cdf34717e6b159beb4))
* **YouTube Music - Track crossfade:** Add support for `9.x` ([#1582](https://github.com/MorpheApp/morphe-patches/issues/1582)) ([7150d06](https://github.com/MorpheApp/morphe-patches/commit/7150d06167b4a6ba699bbd48a4c5d1055d8d2789))

## [1.31.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.31.0-dev.1...v1.31.0-dev.2) (2026-05-31)

### 🐛 Bug Fixes

* **Reddit:** Resolve rare app startup crash when "Show view count" is enabled ([6cd6af1](https://github.com/MorpheApp/morphe-patches/commit/6cd6af147ec56eb4e9ba07b5b4ea6d54271669ae))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.22.0` ([3f443e2](https://github.com/MorpheApp/morphe-patches/commit/3f443e22ec39c3efdf98a562a0db376704212e4b))

## [1.31.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0...v1.31.0-dev.1) (2026-05-30)

### 🐛 Bug Fixes

* **YouTube - Loop video:** Correctly reset range if preferences are not saved ([a328ed8](https://github.com/MorpheApp/morphe-patches/commit/a328ed872f64a9fd6f3d4100d573dc3ca8a8ff2e))
* **YouTube - Loop video:** Reset loop range before set a new one ([7aa767a](https://github.com/MorpheApp/morphe-patches/commit/7aa767ab256e0ef9da9238ffc68f4ec8263f416f))

### ✨ New Features

* **YouTube - SponsorBlock:** Add fade animation to the new segment panel ([#1577](https://github.com/MorpheApp/morphe-patches/issues/1577)) ([771f7fb](https://github.com/MorpheApp/morphe-patches/commit/771f7fbde1808c4129b01c0c95f0f0d08ff4ed4f))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.22.164` ([b88b9ca](https://github.com/MorpheApp/morphe-patches/commit/b88b9cacc2af040fb2643a350d6b5caeaf19eea5))

## [1.30.0](https://github.com/MorpheApp/morphe-patches/compare/v1.29.0...v1.30.0) (2026-05-29)

### 🐛 Bug Fixes

* **YouTube - Disable DRC audio:** Resolve patch not working on `21.19+` ([#1561](https://github.com/MorpheApp/morphe-patches/issues/1561)) ([8608270](https://github.com/MorpheApp/morphe-patches/commit/8608270c1b7a517b1f863ee5f3471153b2ad3574))
* **YouTube - Hide ads:** Fix player crash ([d67d1e1](https://github.com/MorpheApp/morphe-patches/commit/d67d1e1fddcada5ca5310294b6be03a32ba636d3))
* **YouTube - Hide layout components:** Resolve "Hide mix playlists" leaving empty space ([#1526](https://github.com/MorpheApp/morphe-patches/issues/1526)) ([d2eabee](https://github.com/MorpheApp/morphe-patches/commit/d2eabeec1728bd0666e6ec611e5dbeb4062b8960))
* **YouTube - Hide Shorts components:** Hide new type of Shorts in search results ([893f2bd](https://github.com/MorpheApp/morphe-patches/commit/893f2bd68adffb5f9e8b82b4781670c16e61ff2b))
* **YouTube - Open channel of live avatar:** Deprecated old `WEB_REMIX` client in favor of `ANDROID_REELS` ([#1519](https://github.com/MorpheApp/morphe-patches/issues/1519)) ([e45b769](https://github.com/MorpheApp/morphe-patches/commit/e45b7693e43f8182c84b2b5093c37c2b381cbb2d))
* **YouTube - Open channel of live avatar:** Improved check to exclude the live avatar in the channel header ([#1544](https://github.com/MorpheApp/morphe-patches/issues/1544)) ([2b4d5b7](https://github.com/MorpheApp/morphe-patches/commit/2b4d5b79416b9da4408e3d6de2eac463335b1fef))
* **YouTube - Hide player flyout menu components:** Hide the divider in flyout menu ([#1576](https://github.com/MorpheApp/morphe-patches/issues/1576)) ([d2c53d5](https://github.com/MorpheApp/morphe-patches/commit/d2c53d508198162a1c69dc011e167dea1b233406))
* **YouTube - Reload video:** Allow reloading video that has not finished starting ([8318079](https://github.com/MorpheApp/morphe-patches/commit/8318079f1b7ec256ba7a738c0cb247ea78567135))
* **YouTube - Sanitize sharing links:** Sanitize system share sheet ([#1536](https://github.com/MorpheApp/morphe-patches/issues/1536)) ([c0338d8](https://github.com/MorpheApp/morphe-patches/commit/c0338d8bb6802a4b160100abec625a03d7b49f4e))
* **YouTube - Sanitize sharing links:** Sanitize invite URLs before shortening and added playlist links exclusion ([#1550](https://github.com/MorpheApp/morphe-patches/issues/1550)) ([86e53de](https://github.com/MorpheApp/morphe-patches/commit/86e53de6178bfcb65c7f6b5794df3c68da84af86))
* **YouTube - Theme:** Apply "Material You" to notification dot ([#1489](https://github.com/MorpheApp/morphe-patches/issues/1489)) ([bfc1a02](https://github.com/MorpheApp/morphe-patches/commit/bfc1a020cd5b06ffa08d3c311b751fbd854a0be6))

### ✨ New Features

* **Custom branding:** Add icon previews to branding selectors and new play black icon ([#1522](https://github.com/MorpheApp/morphe-patches/issues/1522)) ([adc4ec2](https://github.com/MorpheApp/morphe-patches/commit/adc4ec2db07ce0db3ab449d72d979bc52de1286c))
* **Settings:** Add haptic feedback to settings toggles ([#1575](https://github.com/MorpheApp/morphe-patches/issues/1575)) ([4a7deb8](https://github.com/MorpheApp/morphe-patches/commit/4a7deb8fb90eb3736ebb45eddd42a8918b9c592a))
* **YouTube - Hide layout components:** Add "Hide Featured channels section" setting ([#1567](https://github.com/MorpheApp/morphe-patches/issues/1567)) ([47cd714](https://github.com/MorpheApp/morphe-patches/commit/47cd7148685966e602e91687ea5297603d13d431))
* **YouTube - Hide video action buttons:** Add quick actions top margin setting ([#1574](https://github.com/MorpheApp/morphe-patches/issues/1574)) ([72424b0](https://github.com/MorpheApp/morphe-patches/commit/72424b0d810097aba43e0a26960439b8f46e63f6))
* **YouTube - Loop video:** Add loop range via long-press on loop button ([#1557](https://github.com/MorpheApp/morphe-patches/issues/1557)) ([793424c](https://github.com/MorpheApp/morphe-patches/commit/793424c911157c04d67ec62a8442767d32ba95e7))
* **YouTube - Loop video:** Add a toggle to prevent preference saving ([3ebb5eb](https://github.com/MorpheApp/morphe-patches/commit/3ebb5eb87f3d6a12e73d26f9504437c89f18a85f))
* **YouTube - SponsorBlock:** Add draggable new segment panel with persistent position ([#1560](https://github.com/MorpheApp/morphe-patches/issues/1560)) ([d4715d0](https://github.com/MorpheApp/morphe-patches/commit/d4715d015c7a6b918a66d7890f023a893b8a7b91))
* **YouTube - Swipe controls:** Add configurable zones and speed gesture ([#1527](https://github.com/MorpheApp/morphe-patches/issues/1527)) ([92e6d06](https://github.com/MorpheApp/morphe-patches/commit/92e6d065e254f4c31f17baf0cce4dc45c0c43362))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.21.0` ([78d67e0](https://github.com/MorpheApp/morphe-patches/commit/78d67e0c8668b1f8f3bd7e700a9898e319e9403d))
* **Reddit:** Add support for `2026.14.0` ([2376e91](https://github.com/MorpheApp/morphe-patches/commit/2376e91793f1c3374da937f39bd71d116ff53c8a))
* **YouTube Music:** Add experimental support for `9.20.52` ([c34abe0](https://github.com/MorpheApp/morphe-patches/commit/c34abe0b20692a3ff4780fde68700625c5494d2a))
* **YouTube Music:** Add experimental support for `9.21.51` ([3972b0c](https://github.com/MorpheApp/morphe-patches/commit/3972b0c4eb2ac11ff67c28f3d7b4c854494ad2c7))
* **YouTube:** Add experimental support for `21.21.80` ([65c35f1](https://github.com/MorpheApp/morphe-patches/commit/65c35f10536e5e1d1153fd0d3e96d6776683d245))
* **YouTube:** Add support for `20.51.39` ([d8033a8](https://github.com/MorpheApp/morphe-patches/commit/d8033a817e57fce5cc19f4f46694a099dda4606d))

## [1.30.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0-dev.5...v1.30.0-dev.6) (2026-05-28)

### 🐛 Bug Fixes

* **YouTube - Hide Shorts components:** Hide new type of Shorts in search results ([893f2bd](https://github.com/MorpheApp/morphe-patches/commit/893f2bd68adffb5f9e8b82b4781670c16e61ff2b))
* **YouTube - Hide player flyout menu components:** Hide the divider in flyout menu ([#1576](https://github.com/MorpheApp/morphe-patches/issues/1576)) ([d2c53d5](https://github.com/MorpheApp/morphe-patches/commit/d2c53d508198162a1c69dc011e167dea1b233406))
* **YouTube - Theme:** Apply "Material You" to notification dot ([#1489](https://github.com/MorpheApp/morphe-patches/issues/1489)) ([bfc1a02](https://github.com/MorpheApp/morphe-patches/commit/bfc1a020cd5b06ffa08d3c311b751fbd854a0be6))

### ✨ New Features

* **Settings:** Add haptic feedback to settings toggles ([#1575](https://github.com/MorpheApp/morphe-patches/issues/1575)) ([4a7deb8](https://github.com/MorpheApp/morphe-patches/commit/4a7deb8fb90eb3736ebb45eddd42a8918b9c592a))
* **YouTube - Hide video action buttons:** Add quick actions top margin setting ([#1574](https://github.com/MorpheApp/morphe-patches/issues/1574)) ([72424b0](https://github.com/MorpheApp/morphe-patches/commit/72424b0d810097aba43e0a26960439b8f46e63f6))
* **YouTube - Loop video:** Add loop range via long-press on loop button ([#1557](https://github.com/MorpheApp/morphe-patches/issues/1557)) ([793424c](https://github.com/MorpheApp/morphe-patches/commit/793424c911157c04d67ec62a8442767d32ba95e7))
* **YouTube - Loop video:** Add a toggle to prevent preference saving ([3ebb5eb](https://github.com/MorpheApp/morphe-patches/commit/3ebb5eb87f3d6a12e73d26f9504437c89f18a85f))
* **YouTube - SponsorBlock:** Add draggable new segment panel with persistent position ([#1560](https://github.com/MorpheApp/morphe-patches/issues/1560)) ([d4715d0](https://github.com/MorpheApp/morphe-patches/commit/d4715d015c7a6b918a66d7890f023a893b8a7b91))

### 🚀 Updated App Support

* **YouTube Music:** Add experimental support for `9.21.51` ([3972b0c](https://github.com/MorpheApp/morphe-patches/commit/3972b0c4eb2ac11ff67c28f3d7b4c854494ad2c7))

## [1.30.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0-dev.4...v1.30.0-dev.5) (2026-05-27)

### 🐛 Bug Fixes

* **YouTube - Disable DRC audio:** Resolve patch not working for `21.19+` ([#1561](https://github.com/MorpheApp/morphe-patches/issues/1561)) ([8608270](https://github.com/MorpheApp/morphe-patches/commit/8608270c1b7a517b1f863ee5f3471153b2ad3574))

### ✨ New Features

* **YouTube - Hide layout components:** Add "Hide Featured channels section" setting ([#1567](https://github.com/MorpheApp/morphe-patches/issues/1567)) ([47cd714](https://github.com/MorpheApp/morphe-patches/commit/47cd7148685966e602e91687ea5297603d13d431))

## [1.30.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0-dev.3...v1.30.0-dev.4) (2026-05-26)

### ✨ New Features

* **YouTube - Swipe controls:** Add configurable zones and speed gesture ([#1527](https://github.com/MorpheApp/morphe-patches/issues/1527)) ([92e6d06](https://github.com/MorpheApp/morphe-patches/commit/92e6d065e254f4c31f17baf0cce4dc45c0c43362))

### 🚀 Updated App Support

* **YouTube:** Add support for `20.51.39` ([d8033a8](https://github.com/MorpheApp/morphe-patches/commit/d8033a817e57fce5cc19f4f46694a099dda4606d))

## [1.30.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0-dev.2...v1.30.0-dev.3) (2026-05-25)

### 🐛 Bug Fixes

* **YouTube - Open channel of live avatar:** Improved check to exclude the live avatar in the channel header ([#1544](https://github.com/MorpheApp/morphe-patches/issues/1544)) ([2b4d5b7](https://github.com/MorpheApp/morphe-patches/commit/2b4d5b79416b9da4408e3d6de2eac463335b1fef))
* **YouTube - Sanitize sharing links:** Sanitize invite URLs before shortening and added playlist links exclusion ([#1550](https://github.com/MorpheApp/morphe-patches/issues/1550)) ([86e53de](https://github.com/MorpheApp/morphe-patches/commit/86e53de6178bfcb65c7f6b5794df3c68da84af86))

## [1.30.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.30.0-dev.1...v1.30.0-dev.2) (2026-05-24)

### 🐛 Bug Fixes

* **YouTube - Reload video:** Allow reloading video that has not finished starting ([8318079](https://github.com/MorpheApp/morphe-patches/commit/8318079f1b7ec256ba7a738c0cb247ea78567135))
* **YouTube - Sanitize sharing links:** Sanitize system share sheet ([#1536](https://github.com/MorpheApp/morphe-patches/issues/1536)) ([c0338d8](https://github.com/MorpheApp/morphe-patches/commit/c0338d8bb6802a4b160100abec625a03d7b49f4e))

## [1.30.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.29.1-dev.2...v1.30.0-dev.1) (2026-05-23)

### ✨ New Features

* **Custom branding:** Add icon previews to branding selectors and new play black icon ([#1522](https://github.com/MorpheApp/morphe-patches/issues/1522)) ([adc4ec2](https://github.com/MorpheApp/morphe-patches/commit/adc4ec2db07ce0db3ab449d72d979bc52de1286c))

### 🚀 Updated App Support

* **Reddit:** Add experimental support for `2026.21.0` ([78d67e0](https://github.com/MorpheApp/morphe-patches/commit/78d67e0c8668b1f8f3bd7e700a9898e319e9403d))
* **Reddit:** Add support for `2026.14.0` ([2376e91](https://github.com/MorpheApp/morphe-patches/commit/2376e91793f1c3374da937f39bd71d116ff53c8a))
* **YouTube Music:** Add experimental support for `9.20.52` ([c34abe0](https://github.com/MorpheApp/morphe-patches/commit/c34abe0b20692a3ff4780fde68700625c5494d2a))

## [1.29.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.29.1-dev.1...v1.29.1-dev.2) (2026-05-22)

### 🐛 Bug Fixes

* **YouTube - Hide ads:** Fix player crash ([d67d1e1](https://github.com/MorpheApp/morphe-patches/commit/d67d1e1fddcada5ca5310294b6be03a32ba636d3))

## [1.29.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.29.0...v1.29.1-dev.1) (2026-05-22)

### 🐛 Bug Fixes

* **YouTube - Hide layout components:** Resolve "Hide mix playlists" leaving empty space ([#1526](https://github.com/MorpheApp/morphe-patches/issues/1526)) ([d2eabee](https://github.com/MorpheApp/morphe-patches/commit/d2eabeec1728bd0666e6ec611e5dbeb4062b8960))
* **YouTube - Open channel of live avatar:** Deprecated old `WEB_REMIX` client in favor of `ANDROID_REELS` ([#1519](https://github.com/MorpheApp/morphe-patches/issues/1519)) ([e45b769](https://github.com/MorpheApp/morphe-patches/commit/e45b7693e43f8182c84b2b5093c37c2b381cbb2d))

### 🚀 Updated App Support

* **YouTube:** Add experimental support for `21.21.80` ([65c35f1](https://github.com/MorpheApp/morphe-patches/commit/65c35f10536e5e1d1153fd0d3e96d6776683d245))

## [1.29.0](https://github.com/MorpheApp/morphe-patches/compare/v1.28.0...v1.29.0) (2026-05-21)

### 🐛 Bug Fixes

* **Reddit:** Spoof installation source ([e62b180](https://github.com/MorpheApp/morphe-patches/commit/e62b1803a34ffc3045b93ee5669e0d3441d0a8c1))
* **YouTube - Open channel of live avatar:** Deprecate match with translations ([#1511](https://github.com/MorpheApp/morphe-patches/issues/1511)) ([4264071](https://github.com/MorpheApp/morphe-patches/commit/42640710c8be1b173984a0d052891006960bcbcc))
* **YouTube - Open channel of live avatar:** Fixed null exception after tapping on some Shorts player buttons ([#1497](https://github.com/MorpheApp/morphe-patches/issues/1497)) ([6ec2fd4](https://github.com/MorpheApp/morphe-patches/commit/6ec2fd4f8d9e77b8adffb6b91da5ebb61413f58c))
* **YouTube - PlayerOverlayButton:** Improved containers handling ([1580f02](https://github.com/MorpheApp/morphe-patches/commit/1580f02a0dfe0a75f9f636229bc6d77cab4b3699))
* **YouTube - Remove background playback restrictions:** Disable client flag that interferes with player overlay buttons ([f24cae5](https://github.com/MorpheApp/morphe-patches/commit/f24cae55007dd00bc061dadcaeb2c2f74baf3816))

### ✨ New Features

* **Reddit:** Add experimental support for `2026.20.0` ([0e6b305](https://github.com/MorpheApp/morphe-patches/commit/0e6b3054b011ac89d99dc7088dc983a1f95e99a4))

## [1.29.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.29.0-dev.2...v1.29.0-dev.3) (2026-05-20)

### 🐛 Bug Fixes

* **YouTube - Open channel of live avatar:** Deprecate match with translations ([#1511](https://github.com/MorpheApp/morphe-patches/issues/1511)) ([4264071](https://github.com/MorpheApp/morphe-patches/commit/42640710c8be1b173984a0d052891006960bcbcc))

## [1.29.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.29.0-dev.1...v1.29.0-dev.2) (2026-05-19)

### 🐛 Bug Fixes

* **YouTube - PlayerOverlayButton:** Improved containers handling ([1580f02](https://github.com/MorpheApp/morphe-patches/commit/1580f02a0dfe0a75f9f636229bc6d77cab4b3699))
* **YouTube - Remove background playback restrictions:** Disable client flag that interferes with player overlay buttons ([f24cae5](https://github.com/MorpheApp/morphe-patches/commit/f24cae55007dd00bc061dadcaeb2c2f74baf3816))

## [1.29.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.28.0...v1.29.0-dev.1) (2026-05-18)

### 🐛 Bug Fixes

* **Reddit:** Spoof installation source ([e62b180](https://github.com/MorpheApp/morphe-patches/commit/e62b1803a34ffc3045b93ee5669e0d3441d0a8c1))
* **YouTube - Open channel of live avatar:** Fixed null exception after tapping on some Shorts player buttons ([#1497](https://github.com/MorpheApp/morphe-patches/issues/1497)) ([6ec2fd4](https://github.com/MorpheApp/morphe-patches/commit/6ec2fd4f8d9e77b8adffb6b91da5ebb61413f58c))

### ✨ New Features

* **Reddit:** Add experimental support for `2026.20.0` ([0e6b305](https://github.com/MorpheApp/morphe-patches/commit/0e6b3054b011ac89d99dc7088dc983a1f95e99a4))

## [1.28.0](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0...v1.28.0) (2026-05-17)

### 🐛 Bug Fixes

* Update Crowdin translations ([b652e67](https://github.com/MorpheApp/morphe-patches/commit/b652e6731eebe67f1c20cb0e0d83ace9a94167cb))
* **YouTube - Hide ads:** Hide new type of product sticker ([#1484](https://github.com/MorpheApp/morphe-patches/issues/1484)) ([aa3637d](https://github.com/MorpheApp/morphe-patches/commit/aa3637ddb2470ad5147ebb1ccad10311d366571a))
* **YouTube - Hide layout components:** Hide new type of community post ([#1476](https://github.com/MorpheApp/morphe-patches/issues/1476)) ([50085da](https://github.com/MorpheApp/morphe-patches/commit/50085dab0ceed84778d40b40150f7a16c5ea18ec))
* **YouTube - Open channel of live avatar:** Add missing resources ([#1463](https://github.com/MorpheApp/morphe-patches/issues/1463)) ([0870e3c](https://github.com/MorpheApp/morphe-patches/commit/0870e3c3dc8a3ec3bd42af174bb7d63106658d29))
* **YouTube - Open channel of live avatar:** Fixed remaining translations ([#1491](https://github.com/MorpheApp/morphe-patches/issues/1491)) ([d3433ab](https://github.com/MorpheApp/morphe-patches/commit/d3433ab92a8bad7af00c795de44f943136dd2987))
* **YouTube - Open channel of live avatar:** Patch doesn't work for Arabic/Korean localizations ([ff16083](https://github.com/MorpheApp/morphe-patches/commit/ff160839fdcc03e24c9eff3eec4499b58febc26a))
* **YouTube - Open channel of live avatar:** patch doesn't work for Vietnamese localization ([#1479](https://github.com/MorpheApp/morphe-patches/issues/1479)) ([2a5979e](https://github.com/MorpheApp/morphe-patches/commit/2a5979ee3184ea4ca7a045c61363c853e6cbea15))
* **YouTube - Open channel of live avatar:** Patch doesn't work in video player ([3f03a18](https://github.com/MorpheApp/morphe-patches/commit/3f03a184d9997f844a934b76a05fd6b228d38529))
* **YouTube - Open channel of live avatar:** Patch may not work when app is using non English language ([#1459](https://github.com/MorpheApp/morphe-patches/issues/1459)) ([34d55c2](https://github.com/MorpheApp/morphe-patches/commit/34d55c27d9f915cc39bed37af5a9a4c1e28a3e0f))
* **YouTube - PlayerOverlayButton:** Reset `skipFirstCall` for next `updateRef` attempts ([9d12346](https://github.com/MorpheApp/morphe-patches/commit/9d12346c17a11fd9c4452ba14ee5e96312b760e8))
* **YouTube - PlayerOverlayButton:** Set `videoHeading` container reference only in upper bar constructor to avoid race condition ([#1478](https://github.com/MorpheApp/morphe-patches/issues/1478)) ([93c6300](https://github.com/MorpheApp/morphe-patches/commit/93c6300450a5fafbb815a79d112707880109f358))
* **YouTube - PlayerOverlayButton:** Video heading margin not applied when no bottom buttons present ([#1472](https://github.com/MorpheApp/morphe-patches/issues/1472)) ([12bee40](https://github.com/MorpheApp/morphe-patches/commit/12bee40312e040c7bccd17f9d1af2e56d3214972))

### ✨ New Features

* Add miscellaneous link handling preference to help change "Open with" links ([#1389](https://github.com/MorpheApp/morphe-patches/issues/1389)) ([c364ced](https://github.com/MorpheApp/morphe-patches/commit/c364ced39ccbe5a4183cb07c2e70d4a666b08c46))
* Simplify settings summary text ([#1366](https://github.com/MorpheApp/morphe-patches/issues/1366)) ([67576a8](https://github.com/MorpheApp/morphe-patches/commit/67576a8ffd2c81326acc178454148bbca315a855))
* **YouTube Music:** Add experimental support for `9.19.50` ([a2c0681](https://github.com/MorpheApp/morphe-patches/commit/a2c06815d0c3345bfc29aac0f7d555ac03f1f543))
* **YouTube:** Add experimental support for `21.20.400` ([a4d1412](https://github.com/MorpheApp/morphe-patches/commit/a4d1412849e578189adb04130f8559905cfe8f8f))

## [1.28.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.28.0-dev.3...v1.28.0-dev.4) (2026-05-16)

### 🐛 Bug Fixes

* **YouTube - Hide ads:** Hide new type of product sticker ([#1484](https://github.com/MorpheApp/morphe-patches/issues/1484)) ([aa3637d](https://github.com/MorpheApp/morphe-patches/commit/aa3637ddb2470ad5147ebb1ccad10311d366571a))
* **YouTube - PlayerOverlayButton:** Reset `skipFirstCall` for next `updateRef` attempts ([9d12346](https://github.com/MorpheApp/morphe-patches/commit/9d12346c17a11fd9c4452ba14ee5e96312b760e8))

# [1.28.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.28.0-dev.2...v1.28.0-dev.3) (2026-05-15)


### Bug Fixes

* **YouTube - Hide layout components:** Hide new type of community post ([#1476](https://github.com/MorpheApp/morphe-patches/issues/1476)) ([50085da](https://github.com/MorpheApp/morphe-patches/commit/50085dab0ceed84778d40b40150f7a16c5ea18ec))
* **YouTube - Open channel of live avatar:** Patch doesn't work for Arabic/Korean localizations ([ff16083](https://github.com/MorpheApp/morphe-patches/commit/ff160839fdcc03e24c9eff3eec4499b58febc26a))
* **YouTube - Open channel of live avatar:** Patch doesn't work for Vietnamese localization ([#1479](https://github.com/MorpheApp/morphe-patches/issues/1479)) ([2a5979e](https://github.com/MorpheApp/morphe-patches/commit/2a5979ee3184ea4ca7a045c61363c853e6cbea15))
* **YouTube - PlayerOverlayButton:** Set `videoHeading` container reference only in upper bar constructor to avoid race condition ([#1478](https://github.com/MorpheApp/morphe-patches/issues/1478)) ([93c6300](https://github.com/MorpheApp/morphe-patches/commit/93c6300450a5fafbb815a79d112707880109f358))
* **YouTube - PlayerOverlayButton:** Video heading margin not applied when no bottom buttons present ([#1472](https://github.com/MorpheApp/morphe-patches/issues/1472)) ([12bee40](https://github.com/MorpheApp/morphe-patches/commit/12bee40312e040c7bccd17f9d1af2e56d3214972))


### Features

* **YouTube:** Add experimental support for `21.20.400` ([a4d1412](https://github.com/MorpheApp/morphe-patches/commit/a4d1412849e578189adb04130f8559905cfe8f8f))

# [1.28.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.28.0-dev.1...v1.28.0-dev.2) (2026-05-14)


### Bug Fixes

* Update Crowdin translations ([b652e67](https://github.com/MorpheApp/morphe-patches/commit/b652e6731eebe67f1c20cb0e0d83ace9a94167cb))

# [1.28.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.27.1-dev.2...v1.28.0-dev.1) (2026-05-14)


### Features

* Add miscellaneous link handling preference to help change "Open with" links ([#1389](https://github.com/MorpheApp/morphe-patches/issues/1389)) ([c364ced](https://github.com/MorpheApp/morphe-patches/commit/c364ced39ccbe5a4183cb07c2e70d4a666b08c46))
* Simplify settings summary text ([#1366](https://github.com/MorpheApp/morphe-patches/issues/1366)) ([67576a8](https://github.com/MorpheApp/morphe-patches/commit/67576a8ffd2c81326acc178454148bbca315a855))
* **YouTube Music:** Add experimental support for `9.19.50` ([a2c0681](https://github.com/MorpheApp/morphe-patches/commit/a2c06815d0c3345bfc29aac0f7d555ac03f1f543))

## [1.27.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.27.1-dev.1...v1.27.1-dev.2) (2026-05-13)


### Bug Fixes

* **YouTube - Open channel of live avatar:** Add missing resources ([#1463](https://github.com/MorpheApp/morphe-patches/issues/1463)) ([0870e3c](https://github.com/MorpheApp/morphe-patches/commit/0870e3c3dc8a3ec3bd42af174bb7d63106658d29))

## [1.27.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0...v1.27.1-dev.1) (2026-05-13)


### Bug Fixes

* **YouTube - Open channel of live avatar:** Patch may not work when app is using non English language ([#1459](https://github.com/MorpheApp/morphe-patches/issues/1459)) ([34d55c2](https://github.com/MorpheApp/morphe-patches/commit/34d55c27d9f915cc39bed37af5a9a4c1e28a3e0f))

# [1.27.0](https://github.com/MorpheApp/morphe-patches/compare/v1.26.0...v1.27.0) (2026-05-12)


### Bug Fixes

* Add patch exception message for users who ignore the Manager update prompt ([87beb32](https://github.com/MorpheApp/morphe-patches/commit/87beb32f10b05fd960e86cf393bbd14bba9460b5))
* Add Reddit patch exception message for users who ignore the Manager update prompt ([875f10a](https://github.com/MorpheApp/morphe-patches/commit/875f10ab1bc502a73e271c407138511e37b90fba))
* Add YouTube patch exception message for users who ignore the Manager update prompt ([296e137](https://github.com/MorpheApp/morphe-patches/commit/296e137e63f79493fedea773c1d415cc1da94064))
* **Spoof video streams:** Change default client to Android VR ([cafec9c](https://github.com/MorpheApp/morphe-patches/commit/cafec9c61ec65740358777121172896ed7efdf18))
* **YouTube - Save to watch later:** Support saving videos to 'brand' accounts, prevent opening live Shorts from live avatar ([#1438](https://github.com/MorpheApp/morphe-patches/issues/1438)) ([0b12c81](https://github.com/MorpheApp/morphe-patches/commit/0b12c81793aac544f83aa36ee0c19c88cf81cbda))
* **YouTube - Spoof video streams:** Resolve Shorts freezing and feed scrolling issues ([#1433](https://github.com/MorpheApp/morphe-patches/issues/1433)) ([85e0b0c](https://github.com/MorpheApp/morphe-patches/commit/85e0b0c08f465e067716d52c66af396f28b267b0))


### Features

* **Reddit:** Add experimental support for `2026.19.0` ([c4f6058](https://github.com/MorpheApp/morphe-patches/commit/c4f6058872a007624aaafc1456f46733ec6e2212))
* **YouTube - Hide layout components:** Add "Hide Auto-dubbed label", "Hide Corrections section", "Hide Hyped label",  and "Hide Video details section" settings ([#1367](https://github.com/MorpheApp/morphe-patches/issues/1367)) ([43b79c6](https://github.com/MorpheApp/morphe-patches/commit/43b79c6b4679eb7bd5d9983aa4d4e3f8d2ffbb21))
* **YouTube Music:** Add experimental support for `9.18.50` ([5a9ca78](https://github.com/MorpheApp/morphe-patches/commit/5a9ca78ed1354ec415592c63d532bf8d09fb3032))
* **YouTube:** Add `Open channel of live avatar` patch ([#1408](https://github.com/MorpheApp/morphe-patches/issues/1408)) ([b221097](https://github.com/MorpheApp/morphe-patches/commit/b221097be8f1422f35f69b10d94775a2e245b01b))
* **YouTube:** Add `Save to watch later` patch ([#1274](https://github.com/MorpheApp/morphe-patches/issues/1274)) ([45cea2c](https://github.com/MorpheApp/morphe-patches/commit/45cea2c860f7447d643c3c0af59d4517989c9306))
* **YouTube:** Add experimental support for `21.19.280` ([d1c7ac7](https://github.com/MorpheApp/morphe-patches/commit/d1c7ac7b1580ddcc5a2e47211cfb572106b5ffce))

# [1.27.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0-dev.5...v1.27.0-dev.6) (2026-05-12)


### Bug Fixes

* **YouTube - Save to watch later:** Support saving videos to 'brand' accounts, prevent opening live Shorts from live avatar ([#1438](https://github.com/MorpheApp/morphe-patches/issues/1438)) ([0b12c81](https://github.com/MorpheApp/morphe-patches/commit/0b12c81793aac544f83aa36ee0c19c88cf81cbda))


### Features

* **YouTube:** Add `Open channel of live avatar` patch ([#1408](https://github.com/MorpheApp/morphe-patches/issues/1408)) ([b221097](https://github.com/MorpheApp/morphe-patches/commit/b221097be8f1422f35f69b10d94775a2e245b01b))

# [1.27.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0-dev.4...v1.27.0-dev.5) (2026-05-11)


### Bug Fixes

* **Spoof video streams:** Change default client to Android VR ([cafec9c](https://github.com/MorpheApp/morphe-patches/commit/cafec9c61ec65740358777121172896ed7efdf18))

# [1.27.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0-dev.3...v1.27.0-dev.4) (2026-05-11)


### Bug Fixes

* **YouTube - Spoof video streams:** Resolve Shorts freezing and feed scrolling issues ([#1433](https://github.com/MorpheApp/morphe-patches/issues/1433)) ([85e0b0c](https://github.com/MorpheApp/morphe-patches/commit/85e0b0c08f465e067716d52c66af396f28b267b0))

# [1.27.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0-dev.2...v1.27.0-dev.3) (2026-05-10)


### Features

* **Reddit:** Add experimental support for `2026.19.0` ([c4f6058](https://github.com/MorpheApp/morphe-patches/commit/c4f6058872a007624aaafc1456f46733ec6e2212))
* **YouTube Music:** Add experimental support for `9.18.50` ([5a9ca78](https://github.com/MorpheApp/morphe-patches/commit/5a9ca78ed1354ec415592c63d532bf8d09fb3032))

# [1.27.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.27.0-dev.1...v1.27.0-dev.2) (2026-05-08)


### Features

* **YouTube - Hide layout components:** Add "Hide Auto-dubbed label", "Hide Corrections section", "Hide Hyped label",  and "Hide Video details section" settings ([#1367](https://github.com/MorpheApp/morphe-patches/issues/1367)) ([43b79c6](https://github.com/MorpheApp/morphe-patches/commit/43b79c6b4679eb7bd5d9983aa4d4e3f8d2ffbb21))
* **YouTube:** Add `Save to watch later` patch ([#1274](https://github.com/MorpheApp/morphe-patches/issues/1274)) ([45cea2c](https://github.com/MorpheApp/morphe-patches/commit/45cea2c860f7447d643c3c0af59d4517989c9306))

# [1.27.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.26.1-dev.3...v1.27.0-dev.1) (2026-05-07)


### Features

* **YouTube:** Add experimental support for `21.19.280` ([d1c7ac7](https://github.com/MorpheApp/morphe-patches/commit/d1c7ac7b1580ddcc5a2e47211cfb572106b5ffce))

## [1.26.1-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.26.1-dev.2...v1.26.1-dev.3) (2026-05-06)


### Bug Fixes

* Add Reddit patch exception message for users who ignore the Manager update prompt ([875f10a](https://github.com/MorpheApp/morphe-patches/commit/875f10ab1bc502a73e271c407138511e37b90fba))

## [1.26.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.26.1-dev.1...v1.26.1-dev.2) (2026-05-06)


### Bug Fixes

* Add YouTube patch exception message for users who ignore the Manager update prompt ([296e137](https://github.com/MorpheApp/morphe-patches/commit/296e137e63f79493fedea773c1d415cc1da94064))

## [1.26.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.26.0...v1.26.1-dev.1) (2026-05-06)


### Bug Fixes

* Add patch exception message for users who ignore the Manager update prompt ([87beb32](https://github.com/MorpheApp/morphe-patches/commit/87beb32f10b05fd960e86cf393bbd14bba9460b5))

# [1.26.0](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0...v1.26.0) (2026-05-05)


### Bug Fixes

* Disable 'open with' link verification that prevents opening YouTube/Music/Reddit web links on some devices ([b9dbfc1](https://github.com/MorpheApp/morphe-patches/commit/b9dbfc1e05df0f2268b11caef2f3391dc3d8797d))
* Resolve patching error with older versions of Android ([84c74ae](https://github.com/MorpheApp/morphe-patches/commit/84c74ae7a9678ab7c89a660d0dd38d78db506e8f))
* **YouTube - Hide layout components:** Hide flyout menu items for experimental app targets ([#1358](https://github.com/MorpheApp/morphe-patches/issues/1358)) ([d2c324f](https://github.com/MorpheApp/morphe-patches/commit/d2c324f2d25130ac6250539a006b9ccd10d04429))
* **YouTube - Swipe controls:** 2x speed action is triggered when the status bar is visible on Android 15+ ([#1341](https://github.com/MorpheApp/morphe-patches/issues/1341)) ([e0005d3](https://github.com/MorpheApp/morphe-patches/commit/e0005d38ac9140a0a4209a28bdf9601ac9759034))


### Features

* **YouTube - Miniplayer:** Add "Disable resuming miniplayer" setting ([#1342](https://github.com/MorpheApp/morphe-patches/issues/1342)) ([0eb81a9](https://github.com/MorpheApp/morphe-patches/commit/0eb81a91c2d70d4416a56fc91f3d238e4c6f2f29))
* **YouTube - Sanitize sharing links:** Add setting to change Share links to shortened URLs ([#1346](https://github.com/MorpheApp/morphe-patches/issues/1346)) ([f24c119](https://github.com/MorpheApp/morphe-patches/commit/f24c1190796904e77a77a79e086208e6c059b09b))
* **YouTube:** Add experimental support for `21.18.163` ([1bc264a](https://github.com/MorpheApp/morphe-patches/commit/1bc264af775087244c2fa50f66b76999cad48fa0))

# [1.26.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.26.0-dev.3...v1.26.0-dev.4) (2026-05-05)


### Bug Fixes

* Resolve patching error with older versions of Android ([84c74ae](https://github.com/MorpheApp/morphe-patches/commit/84c74ae7a9678ab7c89a660d0dd38d78db506e8f))

# [1.26.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.26.0-dev.2...v1.26.0-dev.3) (2026-05-05)


### Bug Fixes

* Disable 'open with' link verification that prevents opening YouTube/Music/Reddit web links on some devices ([b9dbfc1](https://github.com/MorpheApp/morphe-patches/commit/b9dbfc1e05df0f2268b11caef2f3391dc3d8797d))


### Features

* **YouTube - Miniplayer:** Add "Disable resuming miniplayer" setting ([#1342](https://github.com/MorpheApp/morphe-patches/issues/1342)) ([0eb81a9](https://github.com/MorpheApp/morphe-patches/commit/0eb81a91c2d70d4416a56fc91f3d238e4c6f2f29))
* **YouTube - Sanitize sharing links:** Add setting to change Share links to shortened URLs ([#1346](https://github.com/MorpheApp/morphe-patches/issues/1346)) ([f24c119](https://github.com/MorpheApp/morphe-patches/commit/f24c1190796904e77a77a79e086208e6c059b09b))

# [1.26.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.26.0-dev.1...v1.26.0-dev.2) (2026-05-03)


### Bug Fixes

* **YouTube - Hide layout components:** Hide flyout menu items for experimental app targets ([#1358](https://github.com/MorpheApp/morphe-patches/issues/1358)) ([d2c324f](https://github.com/MorpheApp/morphe-patches/commit/d2c324f2d25130ac6250539a006b9ccd10d04429))

# [1.26.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0...v1.26.0-dev.1) (2026-05-03)


### Bug Fixes

* **YouTube - Swipe controls:** 2x speed action is triggered when the status bar is visible on Android 15+ ([#1341](https://github.com/MorpheApp/morphe-patches/issues/1341)) ([e0005d3](https://github.com/MorpheApp/morphe-patches/commit/e0005d38ac9140a0a4209a28bdf9601ac9759034))


### Features

* **YouTube:** Add experimental support for `21.18.163` ([1bc264a](https://github.com/MorpheApp/morphe-patches/commit/1bc264af775087244c2fa50f66b76999cad48fa0))

# [1.25.0](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0...v1.25.0) (2026-05-02)


### Bug Fixes

* **YouTube - Hide ads:** Fullscreen ads sometimes show with older versions of YouTube ([4a58cb9](https://github.com/MorpheApp/morphe-patches/commit/4a58cb9dafa51429cc46ab2b2c8098d7eb622e50))
* **YouTube - Hide layout components:** "Hide info panel" does not work in search results ([#1229](https://github.com/MorpheApp/morphe-patches/issues/1229)) ([a846ce3](https://github.com/MorpheApp/morphe-patches/commit/a846ce3096484aed65b2a3f7bf5b1a4a67cb6ecb))
* **YouTube - Hide layout components:** Hide preview comment dots ([#1208](https://github.com/MorpheApp/morphe-patches/issues/1208)) ([8a2b63b](https://github.com/MorpheApp/morphe-patches/commit/8a2b63be46400113b4556a5ef73156b44aacde9a))
* **YouTube - Hide layout components:** Resolve "Hide How this was made" not working in Shorts description ([#1257](https://github.com/MorpheApp/morphe-patches/issues/1257)) ([1a188de](https://github.com/MorpheApp/morphe-patches/commit/1a188de4e374ca659f90c0d1b955fe1080974138))
* **YouTube - Open Shorts in regular player:** Back button does not work when viewing Shorts in the regular player ([#1269](https://github.com/MorpheApp/morphe-patches/issues/1269)) ([3976592](https://github.com/MorpheApp/morphe-patches/commit/3976592a983234e2d9470bfe82496d64aed6ddde))
* **YouTube - Remove background playback restrictions:** Add in-app setting to manually turn off the patch ([#1325](https://github.com/MorpheApp/morphe-patches/issues/1325)) ([7877952](https://github.com/MorpheApp/morphe-patches/commit/7877952d5a29cf19b931227014964ea471e5d870))
* **YouTube - Theme:** Apply light/dark theme colors to `21.17.480` ([290315f](https://github.com/MorpheApp/morphe-patches/commit/290315f9847158f947adf045234e99292d7190cd))
* **YouTube Music - Hide ads:** Home feed does not load when Hide fullscreen ads setting is enabled ([0208916](https://github.com/MorpheApp/morphe-patches/commit/0208916e2774451c6fc72258005adc4221c84953))
* **YouTube Music - Track crossfade:** Crossfade does not work when screen is locked ([#1312](https://github.com/MorpheApp/morphe-patches/issues/1312)) ([cc7b8f1](https://github.com/MorpheApp/morphe-patches/commit/cc7b8f1b7b96bcbba099bf388bb7cd73db51db13))
* **YouTube Music - Track crossfade:** Stop playback when app is closed and improvements to auto-play crossfade transitions ([#1243](https://github.com/MorpheApp/morphe-patches/issues/1243)) ([676d61b](https://github.com/MorpheApp/morphe-patches/commit/676d61b5b81f2c63fe27570f38148d7d9297177e))
* **YouTube:** prevent related video hiding with restricted video confirmation watching ([#1235](https://github.com/MorpheApp/morphe-patches/issues/1235)) ([7005f13](https://github.com/MorpheApp/morphe-patches/commit/7005f13aa385768bb9c5852ee395cb028fa21d79))


### Features

* **Reddit:** Add experimental support for `2026.17.0` ([c41d0f8](https://github.com/MorpheApp/morphe-patches/commit/c41d0f8782781aadfcea25d96fbe37295074f014))
* **Reddit:** Add experimental support for `2026.18.0` ([019c338](https://github.com/MorpheApp/morphe-patches/commit/019c338c9c4c82f0b5342c117553887a4c6defce))
* Show a list of patches in the GitHub readme ([#1304](https://github.com/MorpheApp/morphe-patches/issues/1304)) ([73beef5](https://github.com/MorpheApp/morphe-patches/commit/73beef5ddf1b535161e2a3cd7e6799d129b761af))
* **YouTube - Hide layout components:** Add "Hide live chat donators bar" setting ([#1236](https://github.com/MorpheApp/morphe-patches/issues/1236)) ([d058745](https://github.com/MorpheApp/morphe-patches/commit/d0587451c26e80cead531a19843852bdca641c53))
* **YouTube - Hide Shorts components:** Add "Disable double-tap to like" setting ([#1275](https://github.com/MorpheApp/morphe-patches/issues/1275)) ([73c2c58](https://github.com/MorpheApp/morphe-patches/commit/73c2c58f27f62e1221215ce54e39fe9859feeaf5))
* **YouTube - Hide video action buttons:** Add "Hide quick actions" settings ([#1118](https://github.com/MorpheApp/morphe-patches/issues/1118)) ([590033f](https://github.com/MorpheApp/morphe-patches/commit/590033f9db845a5807e4456b03c7c5bad655e5b8))
* **YouTube - Navigation bar:** Add "Hide Cast button" setting ([#1268](https://github.com/MorpheApp/morphe-patches/issues/1268)) ([53dd12c](https://github.com/MorpheApp/morphe-patches/commit/53dd12c0b25587f6cf5ea5c54f2a7b3924b03d75))
* **YouTube - Sponsorblock:** Add highlight segment submission ([#1301](https://github.com/MorpheApp/morphe-patches/issues/1301)) ([000846f](https://github.com/MorpheApp/morphe-patches/commit/000846feb0c8fafd3c67f9d2c8c759c941c13b4d))
* **YouTube - System media controls:** Add options to hide prev/next and seekbar in notification media controls ([#1322](https://github.com/MorpheApp/morphe-patches/issues/1322)) ([71aa218](https://github.com/MorpheApp/morphe-patches/commit/71aa218979117e5cc56d4656a578860845278b38))
* **YouTube Music:** Add experimental support for `9.16.51` ([e743ba8](https://github.com/MorpheApp/morphe-patches/commit/e743ba870674f7826f81987c0d18393c97b35d1a))
* **YouTube Music:** Add experimental support for `9.17.51` ([d4cd2a6](https://github.com/MorpheApp/morphe-patches/commit/d4cd2a628219e9dc57cb15452178514ee8aaebea))
* **YouTube:** Add experimental support for `21.17.480` ([1bb6403](https://github.com/MorpheApp/morphe-patches/commit/1bb64036c33ce225d0f172d1e865e68b3f25ae72))

# [1.25.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.11...v1.25.0-dev.12) (2026-05-01)


### Features

* **Reddit:** Add experimental support for `2026.18.0` ([019c338](https://github.com/MorpheApp/morphe-patches/commit/019c338c9c4c82f0b5342c117553887a4c6defce))
* **YouTube - System media controls:** Add options to hide prev/next and seekbar in notification media controls ([#1322](https://github.com/MorpheApp/morphe-patches/issues/1322)) ([71aa218](https://github.com/MorpheApp/morphe-patches/commit/71aa218979117e5cc56d4656a578860845278b38))

# [1.25.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.10...v1.25.0-dev.11) (2026-04-30)


### Bug Fixes

* **YouTube - Hide ads:** Fullscreen ads sometimes show with older versions of YouTube ([4a58cb9](https://github.com/MorpheApp/morphe-patches/commit/4a58cb9dafa51429cc46ab2b2c8098d7eb622e50))
* **YouTube - Remove background playback restrictions:** Add in-app setting to manually turn off the patch ([#1325](https://github.com/MorpheApp/morphe-patches/issues/1325)) ([7877952](https://github.com/MorpheApp/morphe-patches/commit/7877952d5a29cf19b931227014964ea471e5d870))


### Features

* **YouTube Music:** Add experimental support for `9.17.51` ([d4cd2a6](https://github.com/MorpheApp/morphe-patches/commit/d4cd2a628219e9dc57cb15452178514ee8aaebea))

# [1.25.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.9...v1.25.0-dev.10) (2026-04-30)


### Bug Fixes

* **YouTube Music - Hide ads:** Home feed does not load when Hide fullscreen ads setting is enabled ([0208916](https://github.com/MorpheApp/morphe-patches/commit/0208916e2774451c6fc72258005adc4221c84953))

# [1.25.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.8...v1.25.0-dev.9) (2026-04-29)


### Features

* **YouTube - Sponsorblock:** Add highlight segment submission ([#1301](https://github.com/MorpheApp/morphe-patches/issues/1301)) ([000846f](https://github.com/MorpheApp/morphe-patches/commit/000846feb0c8fafd3c67f9d2c8c759c941c13b4d))

# [1.25.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.7...v1.25.0-dev.8) (2026-04-28)


### Bug Fixes

* **YouTube Music - Track crossfade:** Crossfade does not work when screen is locked ([#1312](https://github.com/MorpheApp/morphe-patches/issues/1312)) ([cc7b8f1](https://github.com/MorpheApp/morphe-patches/commit/cc7b8f1b7b96bcbba099bf388bb7cd73db51db13))

# [1.25.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.6...v1.25.0-dev.7) (2026-04-28)


### Bug Fixes

* **YouTube Music - Track crossfade:** Stop playback when app is closed and improvements to auto-play crossfade transitions ([#1243](https://github.com/MorpheApp/morphe-patches/issues/1243)) ([676d61b](https://github.com/MorpheApp/morphe-patches/commit/676d61b5b81f2c63fe27570f38148d7d9297177e))

# [1.25.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.5...v1.25.0-dev.6) (2026-04-27)


### Features

* Show a list of patches in the GitHub readme ([#1304](https://github.com/MorpheApp/morphe-patches/issues/1304)) ([73beef5](https://github.com/MorpheApp/morphe-patches/commit/73beef5ddf1b535161e2a3cd7e6799d129b761af))

# [1.25.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.4...v1.25.0-dev.5) (2026-04-27)


### Bug Fixes

* **YouTube - Open Shorts in regular player:** Back button does not work when viewing Shorts in the regular player ([#1269](https://github.com/MorpheApp/morphe-patches/issues/1269)) ([3976592](https://github.com/MorpheApp/morphe-patches/commit/3976592a983234e2d9470bfe82496d64aed6ddde))

# [1.25.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.3...v1.25.0-dev.4) (2026-04-26)


### Bug Fixes

* **YouTube - Theme:** Apply light/dark theme colors to `21.17.480` ([290315f](https://github.com/MorpheApp/morphe-patches/commit/290315f9847158f947adf045234e99292d7190cd))


### Features

* **YouTube - Hide Shorts components:** Add "Disable double-tap to like" setting ([#1275](https://github.com/MorpheApp/morphe-patches/issues/1275)) ([73c2c58](https://github.com/MorpheApp/morphe-patches/commit/73c2c58f27f62e1221215ce54e39fe9859feeaf5))

# [1.25.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.2...v1.25.0-dev.3) (2026-04-25)


### Features

* **Reddit:** Add experimental support for `2026.17.0` ([c41d0f8](https://github.com/MorpheApp/morphe-patches/commit/c41d0f8782781aadfcea25d96fbe37295074f014))
* **YouTube Music:** Add experimental support for `9.16.51` ([e743ba8](https://github.com/MorpheApp/morphe-patches/commit/e743ba870674f7826f81987c0d18393c97b35d1a))

# [1.25.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.25.0-dev.1...v1.25.0-dev.2) (2026-04-24)


### Bug Fixes

* **YouTube:** prevent related video hiding with restricted video confirmation watching ([#1235](https://github.com/MorpheApp/morphe-patches/issues/1235)) ([7005f13](https://github.com/MorpheApp/morphe-patches/commit/7005f13aa385768bb9c5852ee395cb028fa21d79))


### Features

* **YouTube - Navigation bar:** Add "Hide Cast button" setting ([#1268](https://github.com/MorpheApp/morphe-patches/issues/1268)) ([53dd12c](https://github.com/MorpheApp/morphe-patches/commit/53dd12c0b25587f6cf5ea5c54f2a7b3924b03d75))
* **YouTube:** Add experimental support for `21.17.480` ([1bb6403](https://github.com/MorpheApp/morphe-patches/commit/1bb64036c33ce225d0f172d1e865e68b3f25ae72))

# [1.25.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0...v1.25.0-dev.1) (2026-04-22)


### Bug Fixes

* **YouTube - Hide layout components:** "Hide info panel" does not work in search results ([#1229](https://github.com/MorpheApp/morphe-patches/issues/1229)) ([a846ce3](https://github.com/MorpheApp/morphe-patches/commit/a846ce3096484aed65b2a3f7bf5b1a4a67cb6ecb))
* **YouTube - Hide layout components:** Hide preview comment dots ([#1208](https://github.com/MorpheApp/morphe-patches/issues/1208)) ([8a2b63b](https://github.com/MorpheApp/morphe-patches/commit/8a2b63be46400113b4556a5ef73156b44aacde9a))
* **YouTube - Hide layout components:** Resolve "Hide How this was made" not working in Shorts description ([#1257](https://github.com/MorpheApp/morphe-patches/issues/1257)) ([1a188de](https://github.com/MorpheApp/morphe-patches/commit/1a188de4e374ca659f90c0d1b955fe1080974138))


### Features

* **YouTube - Hide layout components:** Add "Hide live chat donators bar" setting ([#1236](https://github.com/MorpheApp/morphe-patches/issues/1236)) ([d058745](https://github.com/MorpheApp/morphe-patches/commit/d0587451c26e80cead531a19843852bdca641c53))
* **YouTube - Hide video action buttons:** Add "Hide quick actions" settings ([#1118](https://github.com/MorpheApp/morphe-patches/issues/1118)) ([590033f](https://github.com/MorpheApp/morphe-patches/commit/590033f9db845a5807e4456b03c7c5bad655e5b8))

# [1.24.0](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0...v1.24.0) (2026-04-20)


### Bug Fixes

* **Reddit - Remove subreddit dialog:** Does not work with experimental app targets ([#1130](https://github.com/MorpheApp/morphe-patches/issues/1130)) ([2560192](https://github.com/MorpheApp/morphe-patches/commit/2560192985c53b63858e78311057d30d5a2887f7))
* **Settings:** Bypass click debounce for toggleable preferences ([#1175](https://github.com/MorpheApp/morphe-patches/issues/1175)) ([b7f453f](https://github.com/MorpheApp/morphe-patches/commit/b7f453fb1bdcc3c962a41d07ef840b352249d1db))
* **Spoof video streams:** Handle Number.toLocaleString() for webview versions that have issues ([#919](https://github.com/MorpheApp/morphe-patches/issues/919)) ([20b6801](https://github.com/MorpheApp/morphe-patches/commit/20b68015857502f447d85e888051dd371128676f))
* **YouTube - Hide ads:** Resolve "Hide YouTube Premium promotions" affecting YouTube Doodles ([#1135](https://github.com/MorpheApp/morphe-patches/issues/1135)) ([881f61b](https://github.com/MorpheApp/morphe-patches/commit/881f61ba200083e3ee35b7e0cf2675ee1f7678d6))
* **YouTube - Hide player flyout menu components:** Cannot hide flyout menu items with `20.21.37` ([#1158](https://github.com/MorpheApp/morphe-patches/issues/1158)) ([3374765](https://github.com/MorpheApp/morphe-patches/commit/3374765710cd3988e19a2aa15132eedc86f2b5c2))
* **YouTube - Hide player flyout menu components:** Resolve "Hide Captions footer" hiding other components ([#1160](https://github.com/MorpheApp/morphe-patches/issues/1160)) ([cf9259a](https://github.com/MorpheApp/morphe-patches/commit/cf9259ab50f5cc8aafe8c615ae7cf87215ac0160))
* **YouTube - Override YouTube Music buttons:** Support launching arbitrary third-party music clients ([#1177](https://github.com/MorpheApp/morphe-patches/issues/1177)) ([7514bf7](https://github.com/MorpheApp/morphe-patches/commit/7514bf7a7e8f0377f7804c420eeaf02106617f2d))
* **YouTube Music - Permanent repeat:** Resolve repeat state not being permanent ([#1193](https://github.com/MorpheApp/morphe-patches/issues/1193)) ([ab5a914](https://github.com/MorpheApp/morphe-patches/commit/ab5a914eb6968a0cdb3de9c2c0f45d1cd42cce4e))
* **YouTube:** Background playback PiP shows a black bar after using livestream chat ([#1173](https://github.com/MorpheApp/morphe-patches/issues/1173)) ([1a30f60](https://github.com/MorpheApp/morphe-patches/commit/1a30f6022166a11cacbce7e098ed474039458829))
* **YouTube:** Fullscreen gradient does not show with bold player layout ([d019c01](https://github.com/MorpheApp/morphe-patches/commit/d019c0172d0a3f205f457c9bde873a7fbfb54bd9))


### Features

* **Reddit:** Add `Hide Ask button` patch ([#1129](https://github.com/MorpheApp/morphe-patches/issues/1129)) ([3ff35f9](https://github.com/MorpheApp/morphe-patches/commit/3ff35f9a5288999d84b1c2323407dd533ed1db2d))
* **Reddit:** Add `Hide Reddit search` patch ([#1128](https://github.com/MorpheApp/morphe-patches/issues/1128)) ([08a1f52](https://github.com/MorpheApp/morphe-patches/commit/08a1f528199e6dede11c8f3cc94322f669a7fac1))
* **Reddit:** Add `Open links externally` patch ([#1131](https://github.com/MorpheApp/morphe-patches/issues/1131)) ([78be254](https://github.com/MorpheApp/morphe-patches/commit/78be254db96f39f93d9a2ac326c7907c2d836f6e))
* **Reddit:** Add experimental support for `2026.15.1` ([2a6442e](https://github.com/MorpheApp/morphe-patches/commit/2a6442ebbad12d858b30fb2f2594cb06c2e4a0d0))
* **Reddit:** Add experimental support for `2026.16.0` ([887c14d](https://github.com/MorpheApp/morphe-patches/commit/887c14d1d96a7d564cabcd301a03c5e7d19222cf))
* **Reddit:** Support version `2026.10.0` ([ea135fb](https://github.com/MorpheApp/morphe-patches/commit/ea135fb439b784c1b4336cc5245b64d8af5b2697))
* **YouTube - Hide layout components:** Add "Hide Settings button" setting for player ([#1187](https://github.com/MorpheApp/morphe-patches/issues/1187)) ([c665a5c](https://github.com/MorpheApp/morphe-patches/commit/c665a5ce8e39ff2e7ac10286372918ce47c35c21))
* **YouTube - Hide layout components:** Add list preference for hiding expandable cards ([#1123](https://github.com/MorpheApp/morphe-patches/issues/1123)) ([7f96bcd](https://github.com/MorpheApp/morphe-patches/commit/7f96bcd6fd4cea0c69e3aa683393e9db4ef7aab5))
* **YouTube - Hide player flyout menu components:** Add "Hide Audio track footer", "Hide Captions footer", and "Hide Captions header" settings ([#642](https://github.com/MorpheApp/morphe-patches/issues/642)) ([19c6c2d](https://github.com/MorpheApp/morphe-patches/commit/19c6c2d525c6dab715f21210d690ea68f7b22f7a))
* **YouTube Music - Hide ads:** Add "Hide fullscreen ads" setting ([#1192](https://github.com/MorpheApp/morphe-patches/issues/1192)) ([b1d704d](https://github.com/MorpheApp/morphe-patches/commit/b1d704d3be325c257abd4acce96516ec9038bd03))
* **YouTube Music:** Add `Track crossfade` patch ([#1065](https://github.com/MorpheApp/morphe-patches/issues/1065)) ([697c794](https://github.com/MorpheApp/morphe-patches/commit/697c79412dd74ffd09dfedbc8458ba7ce3e2938b))
* **YouTube Music:** Add experimental support for `9.14.51` ([e8c941f](https://github.com/MorpheApp/morphe-patches/commit/e8c941ff053e20e54e6303ed405ca5421a4e5768))
* **YouTube Music:** Add experimental support for `9.15.50` ([2399828](https://github.com/MorpheApp/morphe-patches/commit/239982892abbffd6e8e25d310692fb2e860b2c24))
* **YouTube Music:** Add support for `8.47.56` ([fc5bcdd](https://github.com/MorpheApp/morphe-patches/commit/fc5bcdd988f48e00c3ab031f41890ec2792a3a2e))
* **YouTube:** Add experimental support for `21.15.282` ([647911e](https://github.com/MorpheApp/morphe-patches/commit/647911ea660de94d771e4f9e97826ad4d28ffb89))
* **YouTube:** Add experimental support for `21.16.240` ([5a0992c](https://github.com/MorpheApp/morphe-patches/commit/5a0992c98a5e560193706a200eebf51a49f9cb06))
* **YouTube:** Add support for `20.47.62` ([b143f54](https://github.com/MorpheApp/morphe-patches/commit/b143f54c63f94651b6cd14ae1969746047f2ad60))

# [1.24.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.13...v1.24.0-dev.14) (2026-04-19)


### Bug Fixes

* **YouTube:** Resolve 20.47.62 crashing ([d472802](https://github.com/MorpheApp/morphe-patches/commit/d4728022e29c8babf811bf56f3b32174e81bdef7))

# [1.24.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.12...v1.24.0-dev.13) (2026-04-19)


### Bug Fixes

* **YouTube:** Resolve app crash when opening community post ([41a5e66](https://github.com/MorpheApp/morphe-patches/commit/41a5e66b04afb51ff25d0b620e053c50605f1939))

# [1.24.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.11...v1.24.0-dev.12) (2026-04-19)


### Bug Fixes

* **YouTube Music - Permanent repeat:** Resolve repeat state not being permanent ([#1193](https://github.com/MorpheApp/morphe-patches/issues/1193)) ([ab5a914](https://github.com/MorpheApp/morphe-patches/commit/ab5a914eb6968a0cdb3de9c2c0f45d1cd42cce4e))


### Features

* **YouTube - Hide layout components:** Add "Hide Settings button" setting for player ([#1187](https://github.com/MorpheApp/morphe-patches/issues/1187)) ([c665a5c](https://github.com/MorpheApp/morphe-patches/commit/c665a5ce8e39ff2e7ac10286372918ce47c35c21))
* **YouTube Music - Hide ads:** Add "Hide fullscreen ads" setting ([#1192](https://github.com/MorpheApp/morphe-patches/issues/1192)) ([b1d704d](https://github.com/MorpheApp/morphe-patches/commit/b1d704d3be325c257abd4acce96516ec9038bd03))

# [1.24.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.10...v1.24.0-dev.11) (2026-04-18)


### Features

* **Reddit:** Add experimental support for `2026.16.0` ([887c14d](https://github.com/MorpheApp/morphe-patches/commit/887c14d1d96a7d564cabcd301a03c5e7d19222cf))

# [1.24.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.9...v1.24.0-dev.10) (2026-04-17)


### Bug Fixes

* **YouTube:** Fullscreen gradient does not show with bold player layout ([d019c01](https://github.com/MorpheApp/morphe-patches/commit/d019c0172d0a3f205f457c9bde873a7fbfb54bd9))


### Features

* **Reddit:** Support version `2026.10.0` ([ea135fb](https://github.com/MorpheApp/morphe-patches/commit/ea135fb439b784c1b4336cc5245b64d8af5b2697))
* Use shared morphe-patches-library for common code ([#1068](https://github.com/MorpheApp/morphe-patches/issues/1068)) ([a0c5c06](https://github.com/MorpheApp/morphe-patches/commit/a0c5c060bd34159ebe3d13a172e61aa37860a887))
* **YouTube:** Add experimental support for `21.16.240` ([5a0992c](https://github.com/MorpheApp/morphe-patches/commit/5a0992c98a5e560193706a200eebf51a49f9cb06))

# [1.24.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.8...v1.24.0-dev.9) (2026-04-16)


### Features

* **YouTube Music:** Add `Track crossfade` patch ([#1065](https://github.com/MorpheApp/morphe-patches/issues/1065)) ([697c794](https://github.com/MorpheApp/morphe-patches/commit/697c79412dd74ffd09dfedbc8458ba7ce3e2938b))

# [1.24.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.7...v1.24.0-dev.8) (2026-04-15)


### Bug Fixes

* **YouTube - Override YouTube Music buttons:** Support launching arbitrary third-party music clients ([#1177](https://github.com/MorpheApp/morphe-patches/issues/1177)) ([7514bf7](https://github.com/MorpheApp/morphe-patches/commit/7514bf7a7e8f0377f7804c420eeaf02106617f2d))


### Features

* **Reddit:** Add experimental support for `2026.15.1` ([2a6442e](https://github.com/MorpheApp/morphe-patches/commit/2a6442ebbad12d858b30fb2f2594cb06c2e4a0d0))
* **YouTube Music:** Add experimental support for `9.15.50` ([2399828](https://github.com/MorpheApp/morphe-patches/commit/239982892abbffd6e8e25d310692fb2e860b2c24))

# [1.24.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.6...v1.24.0-dev.7) (2026-04-14)


### Bug Fixes

* **Settings:** Bypass click debounce for toggleable preferences ([#1175](https://github.com/MorpheApp/morphe-patches/issues/1175)) ([b7f453f](https://github.com/MorpheApp/morphe-patches/commit/b7f453fb1bdcc3c962a41d07ef840b352249d1db))
* **YouTube - Hide player flyout menu components:** Cannot hide flyout menu items with `20.21.37` ([#1158](https://github.com/MorpheApp/morphe-patches/issues/1158)) ([3374765](https://github.com/MorpheApp/morphe-patches/commit/3374765710cd3988e19a2aa15132eedc86f2b5c2))
* **YouTube - Hide player flyout menu components:** Resolve "Hide Captions footer" hiding other components ([#1160](https://github.com/MorpheApp/morphe-patches/issues/1160)) ([cf9259a](https://github.com/MorpheApp/morphe-patches/commit/cf9259ab50f5cc8aafe8c615ae7cf87215ac0160))
* **YouTube:** Background playback PiP shows a black bar after using livestream chat ([#1173](https://github.com/MorpheApp/morphe-patches/issues/1173)) ([1a30f60](https://github.com/MorpheApp/morphe-patches/commit/1a30f6022166a11cacbce7e098ed474039458829))

# [1.24.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.5...v1.24.0-dev.6) (2026-04-12)


### Features

* **YouTube - Hide layout components:** Add list preference for hiding expandable cards ([#1123](https://github.com/MorpheApp/morphe-patches/issues/1123)) ([7f96bcd](https://github.com/MorpheApp/morphe-patches/commit/7f96bcd6fd4cea0c69e3aa683393e9db4ef7aab5))
* **YouTube Music:** Add support for `8.47.56` ([fc5bcdd](https://github.com/MorpheApp/morphe-patches/commit/fc5bcdd988f48e00c3ab031f41890ec2792a3a2e))
* **YouTube:** Add support for `20.47.62` ([b143f54](https://github.com/MorpheApp/morphe-patches/commit/b143f54c63f94651b6cd14ae1969746047f2ad60))

# [1.24.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.4...v1.24.0-dev.5) (2026-04-11)


### Bug Fixes

* **YouTube - Hide ads:** Resolve "Hide YouTube Premium promotions" affecting YouTube Doodles ([#1135](https://github.com/MorpheApp/morphe-patches/issues/1135)) ([881f61b](https://github.com/MorpheApp/morphe-patches/commit/881f61ba200083e3ee35b7e0cf2675ee1f7678d6))


### Features

* **Reddit:** Add `Hide Ask button` patch ([#1129](https://github.com/MorpheApp/morphe-patches/issues/1129)) ([3ff35f9](https://github.com/MorpheApp/morphe-patches/commit/3ff35f9a5288999d84b1c2323407dd533ed1db2d))
* **Reddit:** Add `Hide Reddit search` patch ([#1128](https://github.com/MorpheApp/morphe-patches/issues/1128)) ([08a1f52](https://github.com/MorpheApp/morphe-patches/commit/08a1f528199e6dede11c8f3cc94322f669a7fac1))
* **Reddit:** Add `Open links externally` patch ([#1131](https://github.com/MorpheApp/morphe-patches/issues/1131)) ([78be254](https://github.com/MorpheApp/morphe-patches/commit/78be254db96f39f93d9a2ac326c7907c2d836f6e))
* **Reddit:** Add experimental support for `2026.15.0` ([784c83c](https://github.com/MorpheApp/morphe-patches/commit/784c83c676c48525fb4c4575fbce00bcf0b6c024))

# [1.24.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.3...v1.24.0-dev.4) (2026-04-10)


### Bug Fixes

* **YouTube:** Use legacy layout parameters with older app targets ([329473a](https://github.com/MorpheApp/morphe-patches/commit/329473aadec23209800ad54aa4daa5df5a24e8f3))


### Features

* **YouTube Music:** Add experimental support for `9.14.51` ([e8c941f](https://github.com/MorpheApp/morphe-patches/commit/e8c941ff053e20e54e6303ed405ca5421a4e5768))

# [1.24.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.2...v1.24.0-dev.3) (2026-04-10)


### Bug Fixes

* **YouTube - SponsorBlock:** 400 error is shown when closing 21.15.282 video player ([c9a5530](https://github.com/MorpheApp/morphe-patches/commit/c9a553048c318ec79ae893c06b0fe3aaf381528d))


### Features

* **YouTube - Hide player flyout menu components:** Add "Hide Audio track footer", "Hide Captions footer", and "Hide Captions header" settings ([#642](https://github.com/MorpheApp/morphe-patches/issues/642)) ([19c6c2d](https://github.com/MorpheApp/morphe-patches/commit/19c6c2d525c6dab715f21210d690ea68f7b22f7a))

# [1.24.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.24.0-dev.1...v1.24.0-dev.2) (2026-04-10)


### Bug Fixes

* **Reddit - Remove subreddit dialog:** Does not work with experimental app targets ([#1130](https://github.com/MorpheApp/morphe-patches/issues/1130)) ([2560192](https://github.com/MorpheApp/morphe-patches/commit/2560192985c53b63858e78311057d30d5a2887f7))
* **YouTube - Playback speed:** 21.15.282 speed button text alignment is wrong ([16104ac](https://github.com/MorpheApp/morphe-patches/commit/16104ac969c89cb58ca49d47c04792a0918ba173))

# [1.24.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0...v1.24.0-dev.1) (2026-04-09)


### Features

* **YouTube:** Add experimental support for `21.15.282` ([647911e](https://github.com/MorpheApp/morphe-patches/commit/647911ea660de94d771e4f9e97826ad4d28ffb89))

# [1.23.0](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0...v1.23.0) (2026-04-09)


### Bug Fixes

* **Change package name:** DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION is not updated correctly ([#1091](https://github.com/MorpheApp/morphe-patches/issues/1091)) ([39c5b47](https://github.com/MorpheApp/morphe-patches/commit/39c5b47cbd41163bac6fff1a397e186a8e9c567a))
* Notification icon entries key mismatch ([#1040](https://github.com/MorpheApp/morphe-patches/issues/1040)) ([01ef1ea](https://github.com/MorpheApp/morphe-patches/commit/01ef1ea731196325a00de060d6f34f51644a94c5))
* **Spoof video streams:** Expose patch to root (mount) install since the patch now works again with rooted devices ([0363d75](https://github.com/MorpheApp/morphe-patches/commit/0363d75d19ac6a6ec02319562f8f687db5027d6f))
* **YouTube - Change start page:** Remove explore and trending start pages that YouTube no longer supports ([f165f0c](https://github.com/MorpheApp/morphe-patches/commit/f165f0c2a44f37ab3e2f036644eb5057f0a89bd4))
* **YouTube - Disable video codecs:** Improve setting summary if the spoof video client does not support forcing AVC ([0238d14](https://github.com/MorpheApp/morphe-patches/commit/0238d14df83198f41c9cbddd4aa4933ba995581d))
* **YouTube - Hide layout components:** Hide new type of community post ([#1114](https://github.com/MorpheApp/morphe-patches/issues/1114)) ([9fc6aef](https://github.com/MorpheApp/morphe-patches/commit/9fc6aefba130629cbeefb5d4bfa1cd798e9ce995))
* **YouTube - Hide player overlay buttons:** Do not hide Morphe player buttons if hide fullscreen button is enabled ([96c5789](https://github.com/MorpheApp/morphe-patches/commit/96c5789e45ea2f5827db93319d9be7405c8cee19))
* **YouTube - Overlay buttons:** Always use thin player overlay buttons with 20.21.37 ([db96e8e](https://github.com/MorpheApp/morphe-patches/commit/db96e8e34d7e0c1393562a7f1dfa5fd0fb1f9c5d))
* **YouTube - Theme:** Carbon background color does not use custom background color with experimental app targets ([fa2439d](https://github.com/MorpheApp/morphe-patches/commit/fa2439d09286db83a0d588b407bbc5248e1589cf))
* **YouTube:** "Restore old setings menu" does not work with experimental app targets ([#1127](https://github.com/MorpheApp/morphe-patches/issues/1127)) ([74826e6](https://github.com/MorpheApp/morphe-patches/commit/74826e6aea75dec8e7290f33e4bf9eb476d2abe8))
* **YouTube:** Bold player buttons break under certain conditions ([#1126](https://github.com/MorpheApp/morphe-patches/issues/1126)) ([8d928f5](https://github.com/MorpheApp/morphe-patches/commit/8d928f596323b4d33cd2ae071a6c47101a61404b))
* **YouTube:** Swiping back on home feed does not close the app ([74a5074](https://github.com/MorpheApp/morphe-patches/commit/74a5074991ec935d0588843b1067a084944c2e42))


### Features

* Add search and file export to debug logs ([#997](https://github.com/MorpheApp/morphe-patches/issues/997)) ([a53a6c3](https://github.com/MorpheApp/morphe-patches/commit/a53a6c3b0c8f534e4bca4a015a25452d2c73ae8a))
* **Reddit:** Add experimental support for `2026.13.0` ([722f5bf](https://github.com/MorpheApp/morphe-patches/commit/722f5bf34f986c51b9631575cd09eb64dac47314))
* **Reddit:** Add experimental support for `2026.14.0` ([921fa89](https://github.com/MorpheApp/morphe-patches/commit/921fa89a37a4e318ed3ba5a0cb090b00f0a4c3af))
* **YouTube - Hide layout components:** Add "Hide search term thumbnails" setting ([#1116](https://github.com/MorpheApp/morphe-patches/issues/1116)) ([61d5fd6](https://github.com/MorpheApp/morphe-patches/commit/61d5fd62f300640240a82f477bb56c82cbedfbee))
* **YouTube - Seekbar:** Add "Enable livestream DVR" setting ([#1092](https://github.com/MorpheApp/morphe-patches/issues/1092)) ([8af85d0](https://github.com/MorpheApp/morphe-patches/commit/8af85d07b68e08f8e2731a77a4a08a1931348911))
* **YouTube - Seekbar:** Add "Expand livestream DVR duration" setting ([#1110](https://github.com/MorpheApp/morphe-patches/issues/1110)) ([1a446d0](https://github.com/MorpheApp/morphe-patches/commit/1a446d089c969993813a5017150ac8e648e26786))
* **YouTube Music:** Add experimental support for `9.13.50` ([bd462e5](https://github.com/MorpheApp/morphe-patches/commit/bd462e5ab274968878314295b7238ae9371564d0))
* **YouTube:** Add `Play all` patch ([#1012](https://github.com/MorpheApp/morphe-patches/issues/1012)) ([b3ac238](https://github.com/MorpheApp/morphe-patches/commit/b3ac238aa15342706d60532ea0bba12f45fef2ac))
* **YouTube:** Add experimental support for `21.14.482` ([bb6f79f](https://github.com/MorpheApp/morphe-patches/commit/bb6f79f5a0ad36383a047586895d1c40212dae48))
* **YouTube:** Add Morphe bold style player buttons ([#954](https://github.com/MorpheApp/morphe-patches/issues/954)) ([7f70b6f](https://github.com/MorpheApp/morphe-patches/commit/7f70b6f10ab5e600f4297d4208641a0ea2d817b1))

# [1.23.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.10...v1.23.0-dev.11) (2026-04-09)


### Bug Fixes

* **YouTube:** "Restore old setings menu" does not work with experimental app targets ([#1127](https://github.com/MorpheApp/morphe-patches/issues/1127)) ([74826e6](https://github.com/MorpheApp/morphe-patches/commit/74826e6aea75dec8e7290f33e4bf9eb476d2abe8))
* **YouTube:** Bold player buttons break under certain conditions ([#1126](https://github.com/MorpheApp/morphe-patches/issues/1126)) ([8d928f5](https://github.com/MorpheApp/morphe-patches/commit/8d928f596323b4d33cd2ae071a6c47101a61404b))

# [1.23.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.9...v1.23.0-dev.10) (2026-04-09)


### Features

* **YouTube - Seekbar:** Add "Expand livestream DVR duration" setting ([#1110](https://github.com/MorpheApp/morphe-patches/issues/1110)) ([1a446d0](https://github.com/MorpheApp/morphe-patches/commit/1a446d089c969993813a5017150ac8e648e26786))

# [1.23.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.8...v1.23.0-dev.9) (2026-04-08)


### Bug Fixes

* **YouTube - Hide layout components:** Hide new type of community post ([#1114](https://github.com/MorpheApp/morphe-patches/issues/1114)) ([9fc6aef](https://github.com/MorpheApp/morphe-patches/commit/9fc6aefba130629cbeefb5d4bfa1cd798e9ce995))


### Features

* **YouTube - Hide layout components:** Add "Hide search term thumbnails" setting ([#1116](https://github.com/MorpheApp/morphe-patches/issues/1116)) ([61d5fd6](https://github.com/MorpheApp/morphe-patches/commit/61d5fd62f300640240a82f477bb56c82cbedfbee))

# [1.23.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.7...v1.23.0-dev.8) (2026-04-06)


### Bug Fixes

* **YouTube - Overlay buttons:** Always use thin player overlay buttons with 20.21.37 ([db96e8e](https://github.com/MorpheApp/morphe-patches/commit/db96e8e34d7e0c1393562a7f1dfa5fd0fb1f9c5d))

# [1.23.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.6...v1.23.0-dev.7) (2026-04-06)


### Bug Fixes

* **YouTube - Change start page:** Remove explore and trending start pages that YouTube no longer supports ([f165f0c](https://github.com/MorpheApp/morphe-patches/commit/f165f0c2a44f37ab3e2f036644eb5057f0a89bd4))


### Features

* **YouTube:** Add `Play all` patch ([#1012](https://github.com/MorpheApp/morphe-patches/issues/1012)) ([b3ac238](https://github.com/MorpheApp/morphe-patches/commit/b3ac238aa15342706d60532ea0bba12f45fef2ac))

# [1.23.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.5...v1.23.0-dev.6) (2026-04-05)


### Bug Fixes

* **Change package name:** DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION is not updated correctly ([#1091](https://github.com/MorpheApp/morphe-patches/issues/1091)) ([39c5b47](https://github.com/MorpheApp/morphe-patches/commit/39c5b47cbd41163bac6fff1a397e186a8e9c567a))
* **YouTube - Disable video codecs:** Improve setting summary if the spoof video client does not support forcing AVC ([0238d14](https://github.com/MorpheApp/morphe-patches/commit/0238d14df83198f41c9cbddd4aa4933ba995581d))


### Features

* **YouTube - Seekbar:** Add "Enable livestream DVR" setting ([#1092](https://github.com/MorpheApp/morphe-patches/issues/1092)) ([8af85d0](https://github.com/MorpheApp/morphe-patches/commit/8af85d07b68e08f8e2731a77a4a08a1931348911))

# [1.23.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.4...v1.23.0-dev.5) (2026-04-04)


### Features

* **Reddit:** Add experimental support for `2026.14.0` ([921fa89](https://github.com/MorpheApp/morphe-patches/commit/921fa89a37a4e318ed3ba5a0cb090b00f0a4c3af))

# [1.23.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.3...v1.23.0-dev.4) (2026-04-03)


### Bug Fixes

* **Spoof video streams:** Expose patch to root (mount) install since the patch now works again with rooted devices ([0363d75](https://github.com/MorpheApp/morphe-patches/commit/0363d75d19ac6a6ec02319562f8f687db5027d6f))
* **YouTube - Hide player overlay buttons:** Do not hide Morphe player buttons if hide fullscreen button is enabled ([96c5789](https://github.com/MorpheApp/morphe-patches/commit/96c5789e45ea2f5827db93319d9be7405c8cee19))


### Features

* Add search and file export to debug logs ([#997](https://github.com/MorpheApp/morphe-patches/issues/997)) ([a53a6c3](https://github.com/MorpheApp/morphe-patches/commit/a53a6c3b0c8f534e4bca4a015a25452d2c73ae8a))
* **YouTube:** Add experimental support for `21.14.482` ([bb6f79f](https://github.com/MorpheApp/morphe-patches/commit/bb6f79f5a0ad36383a047586895d1c40212dae48))

# [1.23.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.2...v1.23.0-dev.3) (2026-04-02)


### Bug Fixes

* **YouTube:** Swiping back on home feed does not close the app ([74a5074](https://github.com/MorpheApp/morphe-patches/commit/74a5074991ec935d0588843b1067a084944c2e42))


### Features

* **YouTube Music:** Add experimental support for `9.13.50` ([bd462e5](https://github.com/MorpheApp/morphe-patches/commit/bd462e5ab274968878314295b7238ae9371564d0))

# [1.23.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.23.0-dev.1...v1.23.0-dev.2) (2026-03-30)


### Bug Fixes

* Notification icon entries key mismatch ([#1040](https://github.com/MorpheApp/morphe-patches/issues/1040)) ([01ef1ea](https://github.com/MorpheApp/morphe-patches/commit/01ef1ea731196325a00de060d6f34f51644a94c5))


### Features

* **Reddit:** Add experimental support for `2026.13.0` ([722f5bf](https://github.com/MorpheApp/morphe-patches/commit/722f5bf34f986c51b9631575cd09eb64dac47314))

# [1.23.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0...v1.23.0-dev.1) (2026-03-29)


### Bug Fixes

* **YouTube - Theme:** Carbon background color does not use custom background color with experimental app targets ([fa2439d](https://github.com/MorpheApp/morphe-patches/commit/fa2439d09286db83a0d588b407bbc5248e1589cf))


### Features

* **YouTube:** Add Morphe bold style player buttons ([#954](https://github.com/MorpheApp/morphe-patches/issues/954)) ([7f70b6f](https://github.com/MorpheApp/morphe-patches/commit/7f70b6f10ab5e600f4297d4208641a0ea2d817b1))

# [1.22.0](https://github.com/MorpheApp/morphe-patches/compare/v1.21.1...v1.22.0) (2026-03-28)


### Bug Fixes

* **Reddit - Hide sidebar components:** Update patch to work with `2026.12.0` ([bdcde63](https://github.com/MorpheApp/morphe-patches/commit/bdcde634e457912e61bce21192fd6e8d8bad3ea2))
* **Reddit:** App side bar may not be shown ([7df05c2](https://github.com/MorpheApp/morphe-patches/commit/7df05c2637fbcc370d7f10950ca8f586134e09e1))
* **Settings:** Improve back gesture, prevent double-clicks, and fix theme update ([#920](https://github.com/MorpheApp/morphe-patches/issues/920)) ([a2e86d2](https://github.com/MorpheApp/morphe-patches/commit/a2e86d28171e13179d672766929f9c7e9afe3003))
* **YouTube - Hide ads:** Hide all promotion banner ads ([#987](https://github.com/MorpheApp/morphe-patches/issues/987)) ([9096bcd](https://github.com/MorpheApp/morphe-patches/commit/9096bcd4cea53c57a8cb336421d53302ea8cd444))
* **YouTube - Hide layout components:** Resolve patch failing on `20.21.37` and `20.31.42` ([#971](https://github.com/MorpheApp/morphe-patches/issues/971)) ([387df8c](https://github.com/MorpheApp/morphe-patches/commit/387df8cc609b26ff2591b3a97e3865996e425db3))


### Features

* Per-theme notification and monochrome icons, add Play icon ([#978](https://github.com/MorpheApp/morphe-patches/issues/978)) ([ddc59c9](https://github.com/MorpheApp/morphe-patches/commit/ddc59c9a96d4b77ca72642e4919e27b9872beee0))
* **Reddit:** Add experimental support for `2026.12.0` ([#999](https://github.com/MorpheApp/morphe-patches/issues/999)) ([8df2a01](https://github.com/MorpheApp/morphe-patches/commit/8df2a010ef2950c503dcb640b19207357da0d248))
* Set notification icon independently of the launcher icon ([#1006](https://github.com/MorpheApp/morphe-patches/issues/1006)) ([f21c62d](https://github.com/MorpheApp/morphe-patches/commit/f21c62de9e2897c5096d1545a40cfe21c6c25f44))
* **YouTube - Navigation bar:** Add "Disable auto-hide navigation bar" setting ([#973](https://github.com/MorpheApp/morphe-patches/issues/973)) ([f04d001](https://github.com/MorpheApp/morphe-patches/commit/f04d00108539368894aca6820e160324ab102559))
* **YouTube Music:** Add experimental support for `9.12.51` ([746bdb9](https://github.com/MorpheApp/morphe-patches/commit/746bdb9649ebbb252ac222110a3ca09eda227458))
* **YouTube:** Add experimental support for `21.13.163` ([ef345ba](https://github.com/MorpheApp/morphe-patches/commit/ef345ba5579a3631420ca5f29d2e415ae7f19948))


### Performance Improvements

* **Litho filtering:** Use Boyer-Moore-Horspool algorithm instead of KMP ([#960](https://github.com/MorpheApp/morphe-patches/issues/960)) ([5b65548](https://github.com/MorpheApp/morphe-patches/commit/5b655488bea90372ccf0e103cdb3229b51b8bfbd))

# [1.22.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.6...v1.22.0-dev.7) (2026-03-28)


### Bug Fixes

* **YouTube - Hide ads:** Hide all promotion banner ads ([#987](https://github.com/MorpheApp/morphe-patches/issues/987)) ([9096bcd](https://github.com/MorpheApp/morphe-patches/commit/9096bcd4cea53c57a8cb336421d53302ea8cd444))


### Features

* **YouTube Music:** Add experimental support for `9.12.51` ([746bdb9](https://github.com/MorpheApp/morphe-patches/commit/746bdb9649ebbb252ac222110a3ca09eda227458))
* **YouTube:** Add experimental support for `21.13.163` ([ef345ba](https://github.com/MorpheApp/morphe-patches/commit/ef345ba5579a3631420ca5f29d2e415ae7f19948))

# [1.22.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.5...v1.22.0-dev.6) (2026-03-26)


### Bug Fixes

* **Settings:** Improve back gesture, prevent double-clicks, and fix theme update ([#920](https://github.com/MorpheApp/morphe-patches/issues/920)) ([a2e86d2](https://github.com/MorpheApp/morphe-patches/commit/a2e86d28171e13179d672766929f9c7e9afe3003))


### Features

* Set notification icon independently of the launcher icon ([#1006](https://github.com/MorpheApp/morphe-patches/issues/1006)) ([f21c62d](https://github.com/MorpheApp/morphe-patches/commit/f21c62de9e2897c5096d1545a40cfe21c6c25f44))


### Performance Improvements

* **Litho filtering:** Use Boyer-Moore-Horspool algorithm instead of KMP ([#960](https://github.com/MorpheApp/morphe-patches/issues/960)) ([5b65548](https://github.com/MorpheApp/morphe-patches/commit/5b655488bea90372ccf0e103cdb3229b51b8bfbd))

# [1.22.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.4...v1.22.0-dev.5) (2026-03-24)


### Bug Fixes

* **Reddit - Hide sidebar components:** Update patch to work with `2026.12.0` ([bdcde63](https://github.com/MorpheApp/morphe-patches/commit/bdcde634e457912e61bce21192fd6e8d8bad3ea2))

# [1.22.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.3...v1.22.0-dev.4) (2026-03-24)


### Bug Fixes

* **Reddit:** App side bar may not be shown ([7df05c2](https://github.com/MorpheApp/morphe-patches/commit/7df05c2637fbcc370d7f10950ca8f586134e09e1))

# [1.22.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.2...v1.22.0-dev.3) (2026-03-24)


### Features

* Per-theme notification and monochrome icons, add Play icon ([#978](https://github.com/MorpheApp/morphe-patches/issues/978)) ([ddc59c9](https://github.com/MorpheApp/morphe-patches/commit/ddc59c9a96d4b77ca72642e4919e27b9872beee0))

# [1.22.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.22.0-dev.1...v1.22.0-dev.2) (2026-03-24)


### Features

* **Reddit:** Add experimental support for `2026.12.0` ([#999](https://github.com/MorpheApp/morphe-patches/issues/999)) ([8df2a01](https://github.com/MorpheApp/morphe-patches/commit/8df2a010ef2950c503dcb640b19207357da0d248))

# [1.22.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.21.1...v1.22.0-dev.1) (2026-03-23)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve patch failing on `20.21.37` and `20.31.42` ([#971](https://github.com/MorpheApp/morphe-patches/issues/971)) ([387df8c](https://github.com/MorpheApp/morphe-patches/commit/387df8cc609b26ff2591b3a97e3865996e425db3))


### Features

* **YouTube - Navigation bar:** Add "Disable auto-hide navigation bar" setting ([#973](https://github.com/MorpheApp/morphe-patches/issues/973)) ([f04d001](https://github.com/MorpheApp/morphe-patches/commit/f04d00108539368894aca6820e160324ab102559))

## [1.21.1](https://github.com/MorpheApp/morphe-patches/compare/v1.21.0...v1.21.1) (2026-03-22)


### Bug Fixes

* Change to patcher 1.3.2 ([b8e63dc](https://github.com/MorpheApp/morphe-patches/commit/b8e63dc7f18fc496a1159472a12f2ece7f76b273))

## [1.21.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.21.0...v1.21.1-dev.1) (2026-03-22)


### Bug Fixes

* Change to patcher 1.3.2 ([b8e63dc](https://github.com/MorpheApp/morphe-patches/commit/b8e63dc7f18fc496a1159472a12f2ece7f76b273))

# [1.21.0](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0...v1.21.0) (2026-03-22)


### Bug Fixes

* Change to patcher 1.3.1 ([02b09cf](https://github.com/MorpheApp/morphe-patches/commit/02b09cfa7aebe4a4cf954aa9490fcbf06884dfce))
* **YouTube - Hide player flyout menu items:** Do not hide speed flyout menu if 'Hide loop video' is enabled ([46834e5](https://github.com/MorpheApp/morphe-patches/commit/46834e5fdbba474e6aff693caad7ae14b6f0eb65))


### Features

* **YouTube - Hide layout components:** Add "Hide Info button" setting ([#944](https://github.com/MorpheApp/morphe-patches/issues/944)) ([d43fbeb](https://github.com/MorpheApp/morphe-patches/commit/d43fbeb9b790eba32f62656a95a613c06d8ef021))
* **YouTube - Navigation bar:** Add "Show Settings" in Toolbar and "Settings button action" in Navigation buttons ([#750](https://github.com/MorpheApp/morphe-patches/issues/750)) ([7bd589e](https://github.com/MorpheApp/morphe-patches/commit/7bd589eaf4abd1a69989be336b2f6e5521581bd5))

# [1.21.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.21.0-dev.2...v1.21.0-dev.3) (2026-03-22)


### Bug Fixes

* Change to patcher 1.3.1 ([02b09cf](https://github.com/MorpheApp/morphe-patches/commit/02b09cfa7aebe4a4cf954aa9490fcbf06884dfce))

# [1.21.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.21.0-dev.1...v1.21.0-dev.2) (2026-03-22)


### Bug Fixes

* **YouTube - Hide player flyout menu items:** Do not hide speed flyout menu if 'Hide loop video' is enabled ([46834e5](https://github.com/MorpheApp/morphe-patches/commit/46834e5fdbba474e6aff693caad7ae14b6f0eb65))


### Features

* **YouTube - Navigation bar:** Add "Show Settings" in Toolbar and "Settings button action" in Navigation buttons ([#750](https://github.com/MorpheApp/morphe-patches/issues/750)) ([7bd589e](https://github.com/MorpheApp/morphe-patches/commit/7bd589eaf4abd1a69989be336b2f6e5521581bd5))

# [1.21.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0...v1.21.0-dev.1) (2026-03-22)


### Features

* **YouTube - Hide layout components:** Add "Hide Info button" setting ([#944](https://github.com/MorpheApp/morphe-patches/issues/944)) ([d43fbeb](https://github.com/MorpheApp/morphe-patches/commit/d43fbeb9b790eba32f62656a95a613c06d8ef021))

# [1.20.0](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0...v1.20.0) (2026-03-20)


### Bug Fixes

* **Settings:** Prevent duplicate dialogs on rapid preference clicks ([#900](https://github.com/MorpheApp/morphe-patches/issues/900)) ([478d97a](https://github.com/MorpheApp/morphe-patches/commit/478d97aa0856b6ebd7cbf41d5c10850295ba2fb8))
* **YouTube - Captions:** Captions disabled due to incorrect hooking ([#908](https://github.com/MorpheApp/morphe-patches/issues/908)) ([a03f245](https://github.com/MorpheApp/morphe-patches/commit/a03f24563a567a6ebd7bf55e1844ef6f2c06529c))
* **YouTube - Change miniplayer color:** Fix patching experimental app target changes ([1c6c61f](https://github.com/MorpheApp/morphe-patches/commit/1c6c61f82e0fbbf4e8609b84c26b005ed3c50df2))
* **YouTube - LithoFilter:** Press the back button twice instead of once to exit the app ([#907](https://github.com/MorpheApp/morphe-patches/issues/907)) ([c450c5a](https://github.com/MorpheApp/morphe-patches/commit/c450c5abecc416e05b335fa178382501b0e3d7b3))
* **YouTube - Navigation bar:** Use updated activity hook for toolbar settings menu ([fafac89](https://github.com/MorpheApp/morphe-patches/commit/fafac89df0680a9fd8fe3dc09983f99c157b8dca))
* **YouTube - Playback speed:** Playback speed menu opens from the feed flyout menu when `Restore old playback speed menu` is off ([#906](https://github.com/MorpheApp/morphe-patches/issues/906)) ([3bb93a9](https://github.com/MorpheApp/morphe-patches/commit/3bb93a9fd1b838593ed5e3f38314855cade17c3f))
* **YouTube - Swipe controls:** Swipe controls sometimes do not work ([#905](https://github.com/MorpheApp/morphe-patches/issues/905)) ([bd23813](https://github.com/MorpheApp/morphe-patches/commit/bd23813b31ade167e4b1cff3b636163c41696c49))
* **YouTube:** Advanced video quality menu does not work ([3381026](https://github.com/MorpheApp/morphe-patches/commit/3381026a63c91460243cb512554e64d0f3662a70))


### Features

* Add Import/Export settings from/to a file ([#865](https://github.com/MorpheApp/morphe-patches/issues/865)) ([098a0d8](https://github.com/MorpheApp/morphe-patches/commit/098a0d8e8993baff5e85676aae6ff5a66d615473))
* **GmsCore support:** Add a setting to not prompt to disable MicroG battery optimization ([#921](https://github.com/MorpheApp/morphe-patches/issues/921)) ([4632fb6](https://github.com/MorpheApp/morphe-patches/commit/4632fb69f9359a709e96d4699d9bfb05133c3a5c))
* **Reddit:** Add Crowdin translations ([#882](https://github.com/MorpheApp/morphe-patches/issues/882)) ([c08ccdb](https://github.com/MorpheApp/morphe-patches/commit/c08ccdb30b460ccbe7ca70b2a5c427b05ba29a3c))
* **Spoof video streams:** Default client maintenance ([#928](https://github.com/MorpheApp/morphe-patches/issues/928)) ([0884870](https://github.com/MorpheApp/morphe-patches/commit/088487090bc59b1c6358551f4e4634f2a847e781))
* **YouTube - Hide layout components:** Add "Comments carousel filter" setting ([#909](https://github.com/MorpheApp/morphe-patches/issues/909)) ([4239720](https://github.com/MorpheApp/morphe-patches/commit/42397200183b8c4b5edd6bd3d27cd8f2b6706756))
* **YouTube Music:** Add `Miniplayer previous and next buttons` patch ([#818](https://github.com/MorpheApp/morphe-patches/issues/818)) ([7e7e08d](https://github.com/MorpheApp/morphe-patches/commit/7e7e08dbfff859890b3bce26fcc882cff1074f4a))
* **YouTube Music:** Add experimental support for `9.11.54` ([73eb7f1](https://github.com/MorpheApp/morphe-patches/commit/73eb7f1475161517a965c0d9ebbb0f8e67a7af93))
* **YouTube:** Add `Reload video` patch ([#873](https://github.com/MorpheApp/morphe-patches/issues/873)) ([fad0e95](https://github.com/MorpheApp/morphe-patches/commit/fad0e95e6be8b29bd32bcec4ef518efff3bcc0eb))
* **YouTube:** Add experimental support for `21.12.521` ([#925](https://github.com/MorpheApp/morphe-patches/issues/925)) ([039e982](https://github.com/MorpheApp/morphe-patches/commit/039e9827fe22562e6b4b9c103621a04f08509fc4))
* **YouTube:** Add support for `20.45.36` ([c22a6df](https://github.com/MorpheApp/morphe-patches/commit/c22a6dfd07a9e1e980e5f5eb9ad22565b1da7f42))


### Performance Improvements

* Reduce patches bundle size ([#891](https://github.com/MorpheApp/morphe-patches/issues/891)) ([74c4611](https://github.com/MorpheApp/morphe-patches/commit/74c461185ac19a3d7258f738e92f49da74721703))

# [1.20.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0-dev.4...v1.20.0-dev.5) (2026-03-20)


### Bug Fixes

* **YouTube - Change miniplayer color:** Fix patching experimental app target changes ([1c6c61f](https://github.com/MorpheApp/morphe-patches/commit/1c6c61f82e0fbbf4e8609b84c26b005ed3c50df2))
* **YouTube - Navigation bar:** Use updated activity hook for toolbar settings menu ([fafac89](https://github.com/MorpheApp/morphe-patches/commit/fafac89df0680a9fd8fe3dc09983f99c157b8dca))

# [1.20.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0-dev.3...v1.20.0-dev.4) (2026-03-20)


### Bug Fixes

* **YouTube - LithoFilter:** Press the back button twice instead of once to exit the app ([#907](https://github.com/MorpheApp/morphe-patches/issues/907)) ([c450c5a](https://github.com/MorpheApp/morphe-patches/commit/c450c5abecc416e05b335fa178382501b0e3d7b3))


### Features

* **GmsCore support:** Add a setting to not prompt to disable MicroG battery optimization ([#921](https://github.com/MorpheApp/morphe-patches/issues/921)) ([4632fb6](https://github.com/MorpheApp/morphe-patches/commit/4632fb69f9359a709e96d4699d9bfb05133c3a5c))
* **Spoof video streams:** Default client maintenance ([#928](https://github.com/MorpheApp/morphe-patches/issues/928)) ([0884870](https://github.com/MorpheApp/morphe-patches/commit/088487090bc59b1c6358551f4e4634f2a847e781))
* **YouTube:** Add `Reload video` patch ([#873](https://github.com/MorpheApp/morphe-patches/issues/873)) ([fad0e95](https://github.com/MorpheApp/morphe-patches/commit/fad0e95e6be8b29bd32bcec4ef518efff3bcc0eb))
* **YouTube:** Add experimental support for `21.12.521` ([#925](https://github.com/MorpheApp/morphe-patches/issues/925)) ([039e982](https://github.com/MorpheApp/morphe-patches/commit/039e9827fe22562e6b4b9c103621a04f08509fc4))

# [1.20.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0-dev.2...v1.20.0-dev.3) (2026-03-19)


### Bug Fixes

* **YouTube - Swipe controls:** Swipe controls sometimes do not work ([#905](https://github.com/MorpheApp/morphe-patches/issues/905)) ([bd23813](https://github.com/MorpheApp/morphe-patches/commit/bd23813b31ade167e4b1cff3b636163c41696c49))


### Features

* **YouTube - Hide layout components:** Add "Comments carousel filter" setting ([#909](https://github.com/MorpheApp/morphe-patches/issues/909)) ([4239720](https://github.com/MorpheApp/morphe-patches/commit/42397200183b8c4b5edd6bd3d27cd8f2b6706756))
* **YouTube Music:** Add experimental support for `9.11.54` ([73eb7f1](https://github.com/MorpheApp/morphe-patches/commit/73eb7f1475161517a965c0d9ebbb0f8e67a7af93))
* **YouTube:** Add support for `20.45.36` ([c22a6df](https://github.com/MorpheApp/morphe-patches/commit/c22a6dfd07a9e1e980e5f5eb9ad22565b1da7f42))

# [1.20.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.20.0-dev.1...v1.20.0-dev.2) (2026-03-18)


### Bug Fixes

* **Settings:** Prevent duplicate dialogs on rapid preference clicks ([#900](https://github.com/MorpheApp/morphe-patches/issues/900)) ([478d97a](https://github.com/MorpheApp/morphe-patches/commit/478d97aa0856b6ebd7cbf41d5c10850295ba2fb8))
* **YouTube - Captions:** Captions disabled due to incorrect hooking ([#908](https://github.com/MorpheApp/morphe-patches/issues/908)) ([a03f245](https://github.com/MorpheApp/morphe-patches/commit/a03f24563a567a6ebd7bf55e1844ef6f2c06529c))
* **YouTube - Playback speed:** Playback speed menu opens from the feed flyout menu when `Restore old playback speed menu` is off ([#906](https://github.com/MorpheApp/morphe-patches/issues/906)) ([3bb93a9](https://github.com/MorpheApp/morphe-patches/commit/3bb93a9fd1b838593ed5e3f38314855cade17c3f))


### Features

* **YouTube Music:** Add `Miniplayer previous and next buttons` patch ([#818](https://github.com/MorpheApp/morphe-patches/issues/818)) ([7e7e08d](https://github.com/MorpheApp/morphe-patches/commit/7e7e08dbfff859890b3bce26fcc882cff1074f4a))


### Performance Improvements

* Reduce patches bundle size ([#891](https://github.com/MorpheApp/morphe-patches/issues/891)) ([74c4611](https://github.com/MorpheApp/morphe-patches/commit/74c461185ac19a3d7258f738e92f49da74721703))

# [1.20.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0...v1.20.0-dev.1) (2026-03-17)


### Bug Fixes

* **YouTube:** Advanced video quality menu does not work ([3381026](https://github.com/MorpheApp/morphe-patches/commit/3381026a63c91460243cb512554e64d0f3662a70))


### Features

* Add Import/Export settings from/to a file ([#865](https://github.com/MorpheApp/morphe-patches/issues/865)) ([098a0d8](https://github.com/MorpheApp/morphe-patches/commit/098a0d8e8993baff5e85676aae6ff5a66d615473))
* **Reddit:** Add Crowdin translations ([#882](https://github.com/MorpheApp/morphe-patches/issues/882)) ([c08ccdb](https://github.com/MorpheApp/morphe-patches/commit/c08ccdb30b460ccbe7ca70b2a5c427b05ba29a3c))

# [1.19.0](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0...v1.19.0) (2026-03-16)


### Bug Fixes

* **Sanitize sharing links:** Sanitize new `is` sharing parameter ([18b1fdb](https://github.com/MorpheApp/morphe-patches/commit/18b1fdb80c76a2fc4510fc53775437f5cbfc8bd9))
* **YouTube - Alternative thumbnails:** Use correct DeArrow parameter casing ([a35a012](https://github.com/MorpheApp/morphe-patches/commit/a35a01243b2bfa674d5711f3db0a0f675f4ebc6f))
* **YouTube - Captions:** Sometimes auto captions are not disabled in Shorts ([#872](https://github.com/MorpheApp/morphe-patches/issues/872)) ([8efba43](https://github.com/MorpheApp/morphe-patches/commit/8efba43064c21652f6221954fddca436cb89e011))
* **YouTube - Change form factor:** Explore button sometimes shows in Automotive layout ([#820](https://github.com/MorpheApp/morphe-patches/issues/820)) ([2980489](https://github.com/MorpheApp/morphe-patches/commit/2980489f3c0e6c95d9fd71c8b094ae9423da2a1b))
* **YouTube - Disable Shorts resuming on startup:** Resolve patch not working on experimental versions ([#848](https://github.com/MorpheApp/morphe-patches/issues/848)) ([0b8e77a](https://github.com/MorpheApp/morphe-patches/commit/0b8e77ac56ffc637bf2186e98189857362a14438))
* **YouTube - Hide layout components:** Resolve "Hide community posts" not working when selecting a channel from subscribed channels bar in Subscriptions tab ([#816](https://github.com/MorpheApp/morphe-patches/issues/816)) ([416d4ea](https://github.com/MorpheApp/morphe-patches/commit/416d4ea2b1c7d545d5c9c6ec1af1ce58a8ff5904))
* **YouTube - Hide Shorts components:** Hide Shorts shelf hides autoplaying videos in the feed ([#788](https://github.com/MorpheApp/morphe-patches/issues/788)) ([01328e7](https://github.com/MorpheApp/morphe-patches/commit/01328e7f048949384186f0ce6fd4230f81e32702))
* **YouTube - Hide Shorts components:** Resolve "Hide 'Use this sound' button" and "Hide 'Use this template' button" breaking Shorts player ([#830](https://github.com/MorpheApp/morphe-patches/issues/830)) ([ffff45a](https://github.com/MorpheApp/morphe-patches/commit/ffff45a529f788707464eed85b7cc6c2c7e513fb))
* **YouTube - Hide Shorts components:** Resolve "Hide 'Use this sound' button" and "Hide 'Use this template' button" not working ([#815](https://github.com/MorpheApp/morphe-patches/issues/815)) ([9f2a67b](https://github.com/MorpheApp/morphe-patches/commit/9f2a67bd38ac2b8fd038197736f8db0483960c7d))
* **YouTube - Hide Shorts components:** Shorts shelves are sometimes not hidden ([#870](https://github.com/MorpheApp/morphe-patches/issues/870)) ([301d3b0](https://github.com/MorpheApp/morphe-patches/commit/301d3b0528415b56f49979ef4cf7797d034ad308))
* **YouTube - Playback speed:** Old playback speed menu does not show with experimental app targets ([d90579f](https://github.com/MorpheApp/morphe-patches/commit/d90579fd93bea9628f787df34e2bbf3302c23e85))
* **YouTube - Shorts autoplay:** Shorts do not autoplay when using older app targets ([1c6478e](https://github.com/MorpheApp/morphe-patches/commit/1c6478e02a6e2a0c795f40608c653ed115292e5e))
* **YouTube - Video quality:** Initial video quality is not overridden ([#822](https://github.com/MorpheApp/morphe-patches/issues/822)) ([753026a](https://github.com/MorpheApp/morphe-patches/commit/753026a6a11552be34b41d55f5d6c0bc728858c7))
* **YouTube:** Do not show fullscreen black gradient with 21.03+ experimental app targets ([0202d57](https://github.com/MorpheApp/morphe-patches/commit/0202d57a2cb0af94257f06163f0c8e219346ac95))
* **YouTube:** Prompt to restart app on first launch of clean install ([#874](https://github.com/MorpheApp/morphe-patches/issues/874)) ([35634b7](https://github.com/MorpheApp/morphe-patches/commit/35634b772b8a7a437d560dcd7e6bf667148957de))


### Features

* **Reddit:** Add "Disable modern home" and "Show view count", fix "Hide navigation buttons" ([#823](https://github.com/MorpheApp/morphe-patches/issues/823)) ([d7c26f2](https://github.com/MorpheApp/morphe-patches/commit/d7c26f257470b66d319bc8e156d9651552a7aac0))
* **Spoof video streams:** Update yt-dlp-ejs ([#871](https://github.com/MorpheApp/morphe-patches/issues/871)) ([0fd599a](https://github.com/MorpheApp/morphe-patches/commit/0fd599a08145c9a78d0882342095a26f6a230102))
* **Theme:** Use dynamic system accents for Material You colors ([#693](https://github.com/MorpheApp/morphe-patches/issues/693)) ([1a2e61c](https://github.com/MorpheApp/morphe-patches/commit/1a2e61ce2e64f82adc51f215ed79b8c02cf6b869))
* **YouTube - Playback speed:** Allows disabling tap and hold speed ([#819](https://github.com/MorpheApp/morphe-patches/issues/819)) ([948a8a1](https://github.com/MorpheApp/morphe-patches/commit/948a8a1c4d29b2d8855225706cb7db9c060d7a18))
* **YouTube:** Add experimental support for `21.11.480` ([d8ced89](https://github.com/MorpheApp/morphe-patches/commit/d8ced89845969bc09275ae540af82229f67799b3))

# [1.19.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.6...v1.19.0-dev.7) (2026-03-16)


### Bug Fixes

* **YouTube:** Prompt to restart app on first launch of clean install ([#874](https://github.com/MorpheApp/morphe-patches/issues/874)) ([35634b7](https://github.com/MorpheApp/morphe-patches/commit/35634b772b8a7a437d560dcd7e6bf667148957de))

# [1.19.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.5...v1.19.0-dev.6) (2026-03-16)


### Bug Fixes

* **YouTube - Captions:** Sometimes auto captions are not disabled in Shorts ([#872](https://github.com/MorpheApp/morphe-patches/issues/872)) ([8efba43](https://github.com/MorpheApp/morphe-patches/commit/8efba43064c21652f6221954fddca436cb89e011))
* **YouTube - Hide Shorts components:** Shorts shelves are sometimes not hidden ([#870](https://github.com/MorpheApp/morphe-patches/issues/870)) ([301d3b0](https://github.com/MorpheApp/morphe-patches/commit/301d3b0528415b56f49979ef4cf7797d034ad308))
* **YouTube - Playback speed:** Old playback speed menu does not show with experimental app targets ([d90579f](https://github.com/MorpheApp/morphe-patches/commit/d90579fd93bea9628f787df34e2bbf3302c23e85))


### Features

* **Spoof video streams:** Update yt-dlp-ejs ([#871](https://github.com/MorpheApp/morphe-patches/issues/871)) ([0fd599a](https://github.com/MorpheApp/morphe-patches/commit/0fd599a08145c9a78d0882342095a26f6a230102))

# [1.19.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.4...v1.19.0-dev.5) (2026-03-15)


### Bug Fixes

* **YouTube - Disable Shorts resuming on startup:** Resolve patch not working on experimental versions ([#848](https://github.com/MorpheApp/morphe-patches/issues/848)) ([0b8e77a](https://github.com/MorpheApp/morphe-patches/commit/0b8e77ac56ffc637bf2186e98189857362a14438))

# [1.19.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.3...v1.19.0-dev.4) (2026-03-15)


### Features

* **Reddit:** Add "Disable modern home" and "Show view count", fix "Hide navigation buttons" ([#823](https://github.com/MorpheApp/morphe-patches/issues/823)) ([d7c26f2](https://github.com/MorpheApp/morphe-patches/commit/d7c26f257470b66d319bc8e156d9651552a7aac0))

# [1.19.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.2...v1.19.0-dev.3) (2026-03-14)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve "Hide community posts" not working when selecting a channel from subscribed channels bar in Subscriptions tab ([#816](https://github.com/MorpheApp/morphe-patches/issues/816)) ([416d4ea](https://github.com/MorpheApp/morphe-patches/commit/416d4ea2b1c7d545d5c9c6ec1af1ce58a8ff5904))
* **YouTube - Hide Shorts components:** Resolve "Hide 'Use this sound' button" and "Hide 'Use this template' button" breaking Shorts player ([#830](https://github.com/MorpheApp/morphe-patches/issues/830)) ([ffff45a](https://github.com/MorpheApp/morphe-patches/commit/ffff45a529f788707464eed85b7cc6c2c7e513fb))
* **YouTube - Video quality:** Initial video quality is not overridden ([#822](https://github.com/MorpheApp/morphe-patches/issues/822)) ([753026a](https://github.com/MorpheApp/morphe-patches/commit/753026a6a11552be34b41d55f5d6c0bc728858c7))
* **YouTube:** Do not show fullscreen black gradient with 21.03+ experimental app targets ([0202d57](https://github.com/MorpheApp/morphe-patches/commit/0202d57a2cb0af94257f06163f0c8e219346ac95))

# [1.19.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.19.0-dev.1...v1.19.0-dev.2) (2026-03-13)


### Bug Fixes

* **Sanitize sharing links:** Sanitize new `is` sharing parameter ([18b1fdb](https://github.com/MorpheApp/morphe-patches/commit/18b1fdb80c76a2fc4510fc53775437f5cbfc8bd9))
* **YouTube - Change form factor:** Explore button sometimes shows in Automotive layout ([#820](https://github.com/MorpheApp/morphe-patches/issues/820)) ([2980489](https://github.com/MorpheApp/morphe-patches/commit/2980489f3c0e6c95d9fd71c8b094ae9423da2a1b))


### Features

* **YouTube:** Add experimental support for `21.11.480` ([d8ced89](https://github.com/MorpheApp/morphe-patches/commit/d8ced89845969bc09275ae540af82229f67799b3))

# [1.19.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.18.1-dev.2...v1.19.0-dev.1) (2026-03-12)


### Bug Fixes

* **YouTube - Hide Shorts components:** Resolve "Hide 'Use this sound' button" and "Hide 'Use this template' button" not working ([#815](https://github.com/MorpheApp/morphe-patches/issues/815)) ([9f2a67b](https://github.com/MorpheApp/morphe-patches/commit/9f2a67bd38ac2b8fd038197736f8db0483960c7d))


### Features

* **Theme:** Use dynamic system accents for Material You colors ([#693](https://github.com/MorpheApp/morphe-patches/issues/693)) ([1a2e61c](https://github.com/MorpheApp/morphe-patches/commit/1a2e61ce2e64f82adc51f215ed79b8c02cf6b869))
* **YouTube - Playback speed:** Allows disabling tap and hold speed ([#819](https://github.com/MorpheApp/morphe-patches/issues/819)) ([948a8a1](https://github.com/MorpheApp/morphe-patches/commit/948a8a1c4d29b2d8855225706cb7db9c060d7a18))

## [1.18.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.18.1-dev.1...v1.18.1-dev.2) (2026-03-11)


### Bug Fixes

* **YouTube - Shorts autoplay:** Shorts do not autoplay when using older app targets ([1c6478e](https://github.com/MorpheApp/morphe-patches/commit/1c6478e02a6e2a0c795f40608c653ed115292e5e))

## [1.18.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0...v1.18.1-dev.1) (2026-03-11)


### Bug Fixes

* **YouTube - Alternative thumbnails:** Use correct DeArrow parameter casing ([a35a012](https://github.com/MorpheApp/morphe-patches/commit/a35a01243b2bfa674d5711f3db0a0f675f4ebc6f))
* **YouTube - Hide Shorts components:** Hide Shorts shelf hides autoplaying videos in the feed ([#788](https://github.com/MorpheApp/morphe-patches/issues/788)) ([01328e7](https://github.com/MorpheApp/morphe-patches/commit/01328e7f048949384186f0ce6fd4230f81e32702))

# [1.18.0](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0...v1.18.0) (2026-03-10)


### Bug Fixes

* **Custom branding:** Safely clone bitmaps to prevent native recycled crash in Glide ([#732](https://github.com/MorpheApp/morphe-patches/issues/732)) ([f5ffa47](https://github.com/MorpheApp/morphe-patches/commit/f5ffa4735097f4d9aaf33c55d469fdf20fcd3d83))
* **YouTube - Hide layout components:** Replace "Hide AI comments summary" with "Sanitize category bar" ([#731](https://github.com/MorpheApp/morphe-patches/issues/731)) ([bb0debf](https://github.com/MorpheApp/morphe-patches/commit/bb0debfc6343afd2b723411a15354209a734c691))
* **YouTube - Hide player flyout menu items:** Do not hide entire flyout menu for eperimental app targets ([7407796](https://github.com/MorpheApp/morphe-patches/commit/7407796551978351a74db742715154ca8e96493e))
* **YouTube - Hide Shorts components:** Hide Shorts in search nav button ([#749](https://github.com/MorpheApp/morphe-patches/issues/749)) ([4bb1162](https://github.com/MorpheApp/morphe-patches/commit/4bb11623be6828e4e0d53afc736678c34400266f))
* **YouTube - Hide video action buttons:** Some action buttons cannot be hidden in YouTube 20.22+ ([#736](https://github.com/MorpheApp/morphe-patches/issues/736)) ([61ebf75](https://github.com/MorpheApp/morphe-patches/commit/61ebf754b8e92a072ed9721573fb26cfe468e888))


### Features

* Add `Disable Play Store updates`, `Custom branding name for Reddit`, improve `Change package name` ([#575](https://github.com/MorpheApp/morphe-patches/issues/575)) ([60a2f9e](https://github.com/MorpheApp/morphe-patches/commit/60a2f9e5b27ca126c4cce3a7207c197675f10d80))
* Add Kurmanji Crowdin translations ([2413a08](https://github.com/MorpheApp/morphe-patches/commit/2413a083ddd6c6768e5db5bd7e814107c97cb8e1))
* **Reddit:** Add experimental support for `2026.10.0` ([#762](https://github.com/MorpheApp/morphe-patches/issues/762)) ([7117724](https://github.com/MorpheApp/morphe-patches/commit/711772404d3a4cee3ac51b6837d15de2e419de3b))
* **Spoof video streams:** Default client maintenance ([#789](https://github.com/MorpheApp/morphe-patches/issues/789)) ([142367e](https://github.com/MorpheApp/morphe-patches/commit/142367e1c0ee3f03341fa5c3c0483aed7384c208))
* **YouTube Music:** Add `Enable forced miniplayer` patch ([#720](https://github.com/MorpheApp/morphe-patches/issues/720)) ([9c6f5f5](https://github.com/MorpheApp/morphe-patches/commit/9c6f5f542d47222a8d7e1873b3742647455d6bf9))
* **YouTube:** Add experimental support for `21.10.493` ([c09049d](https://github.com/MorpheApp/morphe-patches/commit/c09049d46b94b5fa0097f3a53398469356b440f1))

# [1.18.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0-dev.4...v1.18.0-dev.5) (2026-03-10)


### Features

* **Spoof video streams:** Default client maintenance ([#789](https://github.com/MorpheApp/morphe-patches/issues/789)) ([142367e](https://github.com/MorpheApp/morphe-patches/commit/142367e1c0ee3f03341fa5c3c0483aed7384c208))

# [1.18.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0-dev.3...v1.18.0-dev.4) (2026-03-09)


### Bug Fixes

* **YouTube - Hide layout components:** Replace "Hide AI comments summary" with "Sanitize category bar" ([#731](https://github.com/MorpheApp/morphe-patches/issues/731)) ([bb0debf](https://github.com/MorpheApp/morphe-patches/commit/bb0debfc6343afd2b723411a15354209a734c691))

# [1.18.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0-dev.2...v1.18.0-dev.3) (2026-03-08)


### Bug Fixes

* **YouTube - Hide video action buttons:** Some action buttons cannot be hidden in YouTube 20.22+ ([#736](https://github.com/MorpheApp/morphe-patches/issues/736)) ([61ebf75](https://github.com/MorpheApp/morphe-patches/commit/61ebf754b8e92a072ed9721573fb26cfe468e888))

# [1.18.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.18.0-dev.1...v1.18.0-dev.2) (2026-03-07)


### Bug Fixes

* **Custom branding:** Safely clone bitmaps to prevent native recycled crash in Glide ([#732](https://github.com/MorpheApp/morphe-patches/issues/732)) ([f5ffa47](https://github.com/MorpheApp/morphe-patches/commit/f5ffa4735097f4d9aaf33c55d469fdf20fcd3d83))
* **YouTube - Hide Shorts components:** Hide Shorts in search nav button ([#749](https://github.com/MorpheApp/morphe-patches/issues/749)) ([4bb1162](https://github.com/MorpheApp/morphe-patches/commit/4bb11623be6828e4e0d53afc736678c34400266f))


### Features

* Add `Disable Play Store updates`, `Custom branding name for Reddit`, improve `Change package name` ([#575](https://github.com/MorpheApp/morphe-patches/issues/575)) ([60a2f9e](https://github.com/MorpheApp/morphe-patches/commit/60a2f9e5b27ca126c4cce3a7207c197675f10d80))
* **Reddit:** Add experimental support for `2026.10.0` ([#762](https://github.com/MorpheApp/morphe-patches/issues/762)) ([7117724](https://github.com/MorpheApp/morphe-patches/commit/711772404d3a4cee3ac51b6837d15de2e419de3b))
* **YouTube Music:** Add `Enable forced miniplayer` patch ([#720](https://github.com/MorpheApp/morphe-patches/issues/720)) ([9c6f5f5](https://github.com/MorpheApp/morphe-patches/commit/9c6f5f542d47222a8d7e1873b3742647455d6bf9))

# [1.18.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.17.1-dev.1...v1.18.0-dev.1) (2026-03-07)


### Features

* Add Kurmanji Crowdin translations ([2413a08](https://github.com/MorpheApp/morphe-patches/commit/2413a083ddd6c6768e5db5bd7e814107c97cb8e1))
* **YouTube:** Add experimental support for `21.10.493` ([c09049d](https://github.com/MorpheApp/morphe-patches/commit/c09049d46b94b5fa0097f3a53398469356b440f1))

## [1.17.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0...v1.17.1-dev.1) (2026-03-06)


### Bug Fixes

* **YouTube - Hide player flyout menu items:** Do not hide entire flyout menu for eperimental app targets ([7407796](https://github.com/MorpheApp/morphe-patches/commit/7407796551978351a74db742715154ca8e96493e))

# [1.17.0](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0...v1.17.0) (2026-03-06)


### Bug Fixes

* **Custom branding:** Do not override base app name for root installation ([8eb6d48](https://github.com/MorpheApp/morphe-patches/commit/8eb6d483a53e99eaa5aece259f0d5a27d2ef5053))
* **Spoof video streams:** Show TV client deobfuscate toast only if debugging is enabled ([b9b685c](https://github.com/MorpheApp/morphe-patches/commit/b9b685c6aac6aac59aab04f6b5b28252bc424683))
* **YouTube - Hide layout components:** Resolve "Hide Explore the podcast" not working ([#691](https://github.com/MorpheApp/morphe-patches/issues/691)) ([fd50458](https://github.com/MorpheApp/morphe-patches/commit/fd504587cacaf665816c908b5db124f7a2e7bdd1))
* **YouTube - LithoFilterPatch:** Use an encoded native byte array for buffer searching ([#654](https://github.com/MorpheApp/morphe-patches/issues/654)) ([bb5cc01](https://github.com/MorpheApp/morphe-patches/commit/bb5cc0198ee87f292795c3b03127a6a82ef72647))


### Features

* **Spoof video streams:** Add "Force player JavaScript hash" and "Player JavaScript hash" ([#722](https://github.com/MorpheApp/morphe-patches/issues/722)) ([c184dbe](https://github.com/MorpheApp/morphe-patches/commit/c184dbe74aac4f2c2f7cb74955a05063209a9f2e))
* **YouTube - Navigation bar:** Add "Hide navigation bar", "Replace Create with Settings", and "Show Settings" settings ([#688](https://github.com/MorpheApp/morphe-patches/issues/688)) ([1b87895](https://github.com/MorpheApp/morphe-patches/commit/1b8789530e9ca50f439653cb4c55ae1a031d980b))
* **YouTube Music:** Add experimental support for `9.09.52` ([e42d9c1](https://github.com/MorpheApp/morphe-patches/commit/e42d9c1bbdd6985378be47c8f9138ccdb22ead1e))
* **YouTube Music:** Add support for `8.44.54` ([113e0b3](https://github.com/MorpheApp/morphe-patches/commit/113e0b3f67a5470e000c0e15d91d0c44ab18b66d))
* **YouTube:** Add `Hide releated videos` patch ([#685](https://github.com/MorpheApp/morphe-patches/issues/685)) ([7a960e1](https://github.com/MorpheApp/morphe-patches/commit/7a960e1a9f52ee2dcaea84298a62e9e2867100b7))
* **YouTube:** Add support for `20.44.38` ([b022292](https://github.com/MorpheApp/morphe-patches/commit/b022292192de08a913429400a44003fdc2622c3c))

# [1.17.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.7...v1.17.0-dev.8) (2026-03-06)


### Features

* **Spoof video streams:** Minor improvements reflecting code review ([#730](https://github.com/MorpheApp/morphe-patches/issues/730)) ([cbfe030](https://github.com/MorpheApp/morphe-patches/commit/cbfe03035683ee6b7c205327eabcd3e515c35ec8))

# [1.17.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.6...v1.17.0-dev.7) (2026-03-06)


### Bug Fixes

* **Spoof video streams:** Show TV client deobfuscate toast only if debugging is enabled ([b9b685c](https://github.com/MorpheApp/morphe-patches/commit/b9b685c6aac6aac59aab04f6b5b28252bc424683))

# [1.17.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.5...v1.17.0-dev.6) (2026-03-05)


### Bug Fixes

* Resolve navigation bar patch not working ([9e21cfd](https://github.com/MorpheApp/morphe-patches/commit/9e21cfd1c55b880e01f3ffd9296dcdab36e2282b))

# [1.17.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.4...v1.17.0-dev.5) (2026-03-05)


### Features

* **Spoof video streams:** Add "Force player JavaScript hash" and "Player JavaScript hash" ([#722](https://github.com/MorpheApp/morphe-patches/issues/722)) ([c184dbe](https://github.com/MorpheApp/morphe-patches/commit/c184dbe74aac4f2c2f7cb74955a05063209a9f2e))
* **YouTube Music:** Add support for `8.44.54` ([113e0b3](https://github.com/MorpheApp/morphe-patches/commit/113e0b3f67a5470e000c0e15d91d0c44ab18b66d))
* **YouTube:** Add support for `20.44.38` ([b022292](https://github.com/MorpheApp/morphe-patches/commit/b022292192de08a913429400a44003fdc2622c3c))

# [1.17.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.3...v1.17.0-dev.4) (2026-03-05)


### Features

* **YouTube - Navigation bar:** Add "Hide navigation bar", "Replace Create with Settings", and "Show Settings" settings ([#688](https://github.com/MorpheApp/morphe-patches/issues/688)) ([1b87895](https://github.com/MorpheApp/morphe-patches/commit/1b8789530e9ca50f439653cb4c55ae1a031d980b))

# [1.17.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.2...v1.17.0-dev.3) (2026-03-04)


### Features

* **YouTube Music:** Add experimental support for `9.09.52` ([e42d9c1](https://github.com/MorpheApp/morphe-patches/commit/e42d9c1bbdd6985378be47c8f9138ccdb22ead1e))

# [1.17.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.17.0-dev.1...v1.17.0-dev.2) (2026-03-04)


### Bug Fixes

* **Custom branding:** Do not override base app name for root installation ([8eb6d48](https://github.com/MorpheApp/morphe-patches/commit/8eb6d483a53e99eaa5aece259f0d5a27d2ef5053))

# [1.17.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.16.1-dev.2...v1.17.0-dev.1) (2026-03-04)


### Features

* **YouTube:** Add `Hide releated videos` patch ([#685](https://github.com/MorpheApp/morphe-patches/issues/685)) ([7a960e1](https://github.com/MorpheApp/morphe-patches/commit/7a960e1a9f52ee2dcaea84298a62e9e2867100b7))

## [1.16.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.16.1-dev.1...v1.16.1-dev.2) (2026-03-03)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve "Hide Explore the podcast" not working ([#691](https://github.com/MorpheApp/morphe-patches/issues/691)) ([fd50458](https://github.com/MorpheApp/morphe-patches/commit/fd504587cacaf665816c908b5db124f7a2e7bdd1))

## [1.16.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0...v1.16.1-dev.1) (2026-03-03)


### Bug Fixes

* **YouTube - LithoFilterPatch:** Use an encoded native byte array for buffer searching ([#654](https://github.com/MorpheApp/morphe-patches/issues/654)) ([bb5cc01](https://github.com/MorpheApp/morphe-patches/commit/bb5cc0198ee87f292795c3b03127a6a82ef72647))

# [1.16.0](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0...v1.16.0) (2026-03-03)


### Bug Fixes

* **YouTube - Double tap to seek:** Playback setting menu does not open when patched with CLI pre-release ([ba1784d](https://github.com/MorpheApp/morphe-patches/commit/ba1784df70cb4cbfe786e991e75bb1d8f97a6dbf))
* **YouTube - Hide end screen suggested video:** Add user dialogs to minimize user confusion ([#637](https://github.com/MorpheApp/morphe-patches/issues/637)) ([6d4af87](https://github.com/MorpheApp/morphe-patches/commit/6d4af87dd6880d6114c24815109da4149df3c3b8))
* **YouTube - Hide Shorts components:** Resolve Shorts header not being hidden ([#649](https://github.com/MorpheApp/morphe-patches/issues/649)) ([84901c2](https://github.com/MorpheApp/morphe-patches/commit/84901c261ea0808514cca24c5bd7687389acae5c))
* **YouTube Music - Change start page:** Hide Podcast option that shows an error message for users in unsupported countries ([b0a9fb6](https://github.com/MorpheApp/morphe-patches/commit/b0a9fb68ba2909889612165f1f1df5bff8fecd21))


### Features

* **YouTube - Navigation bar:** Add `Show search button` setting ([#634](https://github.com/MorpheApp/morphe-patches/issues/634)) ([b46e492](https://github.com/MorpheApp/morphe-patches/commit/b46e4923592ce5f752d6e2db156a3838c25f4f4f))
* **YouTube Music:** Add `Change header` patch ([#650](https://github.com/MorpheApp/morphe-patches/issues/650)) ([f6f03e5](https://github.com/MorpheApp/morphe-patches/commit/f6f03e55d01863f3d436e00108cc608d933ddbd9))
* **YouTube Music:** Add `Change start page` patch ([#653](https://github.com/MorpheApp/morphe-patches/issues/653)) ([bc3c1bd](https://github.com/MorpheApp/morphe-patches/commit/bc3c1bda7afd3748f3bd7c7a9831ae4bad64b80f))
* **YouTube:** Add `Open system share sheet` patch ([#625](https://github.com/MorpheApp/morphe-patches/issues/625)) ([64ff907](https://github.com/MorpheApp/morphe-patches/commit/64ff9079777a2b935886c35eae0e454984d56b52))
* **YouTube:** Add `Override YouTube Music actions` patch ([#677](https://github.com/MorpheApp/morphe-patches/issues/677)) ([904dcda](https://github.com/MorpheApp/morphe-patches/commit/904dcda3f17faf26753529351d5c4b57cdbda162))

# [1.16.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.8...v1.16.0-dev.9) (2026-03-02)


### Features

* **YouTube:** Add `Override YouTube Music actions` patch ([#677](https://github.com/MorpheApp/morphe-patches/issues/677)) ([904dcda](https://github.com/MorpheApp/morphe-patches/commit/904dcda3f17faf26753529351d5c4b57cdbda162))

# [1.16.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.7...v1.16.0-dev.8) (2026-03-01)


### Bug Fixes

* **YouTube Music - Change start page:** Hide Podcast option that shows an error message for users in unsupported countries ([b0a9fb6](https://github.com/MorpheApp/morphe-patches/commit/b0a9fb68ba2909889612165f1f1df5bff8fecd21))

# [1.16.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.6...v1.16.0-dev.7) (2026-03-01)


### Features

* **YouTube Music:** Add `Change start page` patch ([#653](https://github.com/MorpheApp/morphe-patches/issues/653)) ([bc3c1bd](https://github.com/MorpheApp/morphe-patches/commit/bc3c1bda7afd3748f3bd7c7a9831ae4bad64b80f))

# [1.16.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.5...v1.16.0-dev.6) (2026-03-01)


### Features

* **YouTube Music:** Add `Change header` patch ([#650](https://github.com/MorpheApp/morphe-patches/issues/650)) ([f6f03e5](https://github.com/MorpheApp/morphe-patches/commit/f6f03e55d01863f3d436e00108cc608d933ddbd9))

# [1.16.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.4...v1.16.0-dev.5) (2026-03-01)


### Bug Fixes

* **YouTube - Double tap to seek:** Playback setting menu does not open when patched with CLI pre-release ([ba1784d](https://github.com/MorpheApp/morphe-patches/commit/ba1784df70cb4cbfe786e991e75bb1d8f97a6dbf))

# [1.16.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.3...v1.16.0-dev.4) (2026-03-01)


### Bug Fixes

* **YouTube - Hide Shorts components:** Resolve Shorts header not being hidden ([#649](https://github.com/MorpheApp/morphe-patches/issues/649)) ([84901c2](https://github.com/MorpheApp/morphe-patches/commit/84901c261ea0808514cca24c5bd7687389acae5c))

# [1.16.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.2...v1.16.0-dev.3) (2026-02-28)


### Bug Fixes

* **YouTube - Hide end screen suggested video:** Add user dialogs to minimize user confusion ([#637](https://github.com/MorpheApp/morphe-patches/issues/637)) ([6d4af87](https://github.com/MorpheApp/morphe-patches/commit/6d4af87dd6880d6114c24815109da4149df3c3b8))

# [1.16.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.16.0-dev.1...v1.16.0-dev.2) (2026-02-27)


### Features

* **YouTube:** Add `Open system share sheet` patch ([#625](https://github.com/MorpheApp/morphe-patches/issues/625)) ([64ff907](https://github.com/MorpheApp/morphe-patches/commit/64ff9079777a2b935886c35eae0e454984d56b52))

# [1.16.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0...v1.16.0-dev.1) (2026-02-26)


### Features

* **YouTube - Navigation bar:** Add `Show search button` setting ([#634](https://github.com/MorpheApp/morphe-patches/issues/634)) ([b46e492](https://github.com/MorpheApp/morphe-patches/commit/b46e4923592ce5f752d6e2db156a3838c25f4f4f))

# [1.15.0](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0...v1.15.0) (2026-02-25)


### Bug Fixes

* **YouTube - Captions:** Captions are not available in Shorts when `Auto captions visibility` is `Never show` ([#591](https://github.com/MorpheApp/morphe-patches/issues/591)) ([e386664](https://github.com/MorpheApp/morphe-patches/commit/e3866641aa544598174e5a65ef22654410b3e5c5))
* **YouTube - Hide ads:** Hide new type of ad ([#594](https://github.com/MorpheApp/morphe-patches/issues/594)) ([87c2d24](https://github.com/MorpheApp/morphe-patches/commit/87c2d24725e4ceccb9a000c95e1b7487ff9fc6b6))
* **YouTube - Hide layout components:** Replace "Hide search suggestions" with "Hide You may like section" ([#581](https://github.com/MorpheApp/morphe-patches/issues/581)) ([29d891c](https://github.com/MorpheApp/morphe-patches/commit/29d891c63c6b5c937420f7e9fb796b530c45847f))
* **YouTube - Hide Shorts components:** Resolve hiding Shorts not working ([#610](https://github.com/MorpheApp/morphe-patches/issues/610)) ([dbef1c4](https://github.com/MorpheApp/morphe-patches/commit/dbef1c419e6b871e5587e9c6f800ff622e962c2c))


### Features

* Add `Disable QUIC protocol` patch ([#586](https://github.com/MorpheApp/morphe-patches/issues/586)) ([41fac61](https://github.com/MorpheApp/morphe-patches/commit/41fac61cfdfeb0e469f13eb8d4e54e7cb054f34d))
* **Spoof video streams:** Add `Android Reel` client ([#580](https://github.com/MorpheApp/morphe-patches/issues/580)) ([01bbde3](https://github.com/MorpheApp/morphe-patches/commit/01bbde3dfea162eedf9af36dddffaba5d750db73))
* **YouTube - Disable haptic feedback:** Add `Disable tap and hold haptics` setting ([#592](https://github.com/MorpheApp/morphe-patches/issues/592)) ([279722a](https://github.com/MorpheApp/morphe-patches/commit/279722a153573cc4d93bbe8becef31aa930cf0aa))
* **YouTube - Hide ads:** Add `Hide player popup ads` setting ([#583](https://github.com/MorpheApp/morphe-patches/issues/583)) ([82c9f29](https://github.com/MorpheApp/morphe-patches/commit/82c9f29f0903416bade9613a6672822003968893))
* **YouTube:** Add experimental support for `21.08.261` ([#582](https://github.com/MorpheApp/morphe-patches/issues/582)) ([87d3ac9](https://github.com/MorpheApp/morphe-patches/commit/87d3ac955fc1f0a777b785e4294401d6451de330))

# [1.15.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.8...v1.15.0-dev.9) (2026-02-24)


### Bug Fixes

* **YouTube - Hide ads:** Hide new type of ad ([#594](https://github.com/MorpheApp/morphe-patches/issues/594)) ([87c2d24](https://github.com/MorpheApp/morphe-patches/commit/87c2d24725e4ceccb9a000c95e1b7487ff9fc6b6))

# [1.15.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.7...v1.15.0-dev.8) (2026-02-23)


### Features

* **YouTube - Disable haptic feedback:** Add `Disable tap and hold haptics` setting ([#592](https://github.com/MorpheApp/morphe-patches/issues/592)) ([279722a](https://github.com/MorpheApp/morphe-patches/commit/279722a153573cc4d93bbe8becef31aa930cf0aa))

# [1.15.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.6...v1.15.0-dev.7) (2026-02-22)


### Bug Fixes

* **YouTube - Hide Shorts components:** Resolve hiding Shorts not working ([#610](https://github.com/MorpheApp/morphe-patches/issues/610)) ([dbef1c4](https://github.com/MorpheApp/morphe-patches/commit/dbef1c419e6b871e5587e9c6f800ff622e962c2c))

# [1.15.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.5...v1.15.0-dev.6) (2026-02-22)


### Bug Fixes

* **YouTube - Captions:** Captions are not available in Shorts when `Auto captions visibility` is `Never show` ([#591](https://github.com/MorpheApp/morphe-patches/issues/591)) ([e386664](https://github.com/MorpheApp/morphe-patches/commit/e3866641aa544598174e5a65ef22654410b3e5c5))

# [1.15.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.4...v1.15.0-dev.5) (2026-02-21)


### Features

* **YouTube - Hide ads:** Add `Hide player popup ads` setting ([#583](https://github.com/MorpheApp/morphe-patches/issues/583)) ([82c9f29](https://github.com/MorpheApp/morphe-patches/commit/82c9f29f0903416bade9613a6672822003968893))

# [1.15.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.3...v1.15.0-dev.4) (2026-02-20)


### Features

* **Spoof video streams:** Add `Android Reel` client ([#580](https://github.com/MorpheApp/morphe-patches/issues/580)) ([01bbde3](https://github.com/MorpheApp/morphe-patches/commit/01bbde3dfea162eedf9af36dddffaba5d750db73))

# [1.15.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2026-02-20)


### Features

* Add `Disable QUIC protocol` patch ([#586](https://github.com/MorpheApp/morphe-patches/issues/586)) ([41fac61](https://github.com/MorpheApp/morphe-patches/commit/41fac61cfdfeb0e469f13eb8d4e54e7cb054f34d))

# [1.15.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.15.0-dev.1...v1.15.0-dev.2) (2026-02-19)


### Bug Fixes

* **YouTube - Hide layout components:** Replace "Hide search suggestions" with "Hide You may like section" ([#581](https://github.com/MorpheApp/morphe-patches/issues/581)) ([29d891c](https://github.com/MorpheApp/morphe-patches/commit/29d891c63c6b5c937420f7e9fb796b530c45847f))

# [1.15.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0...v1.15.0-dev.1) (2026-02-19)


### Features

* **YouTube:** Add experimental support for `21.08.261` ([#582](https://github.com/MorpheApp/morphe-patches/issues/582)) ([87d3ac9](https://github.com/MorpheApp/morphe-patches/commit/87d3ac955fc1f0a777b785e4294401d6451de330))

# [1.14.0](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0...v1.14.0) (2026-02-18)


### Bug Fixes

* **Override certificate pinning:** Handle element missing from network config ([#574](https://github.com/MorpheApp/morphe-patches/issues/574)) ([7b4d015](https://github.com/MorpheApp/morphe-patches/commit/7b4d015e4fb37163127257a23de7757c5d2a1f9d))
* **Spoof video streams:** Using the TV client can cause a V8 runtime memory leak ([#564](https://github.com/MorpheApp/morphe-patches/issues/564)) ([59a4061](https://github.com/MorpheApp/morphe-patches/commit/59a4061b28b4be38c4a836a22aa2af429edad5e2))
* **YouTube:** Add experimental support for `21.07.240` ([015d66a](https://github.com/MorpheApp/morphe-patches/commit/015d66a3d9fb352f5be47af59139d736fe43b26b))


### Features

* Add `Disable DRC audio` patch ([#461](https://github.com/MorpheApp/morphe-patches/issues/461)) ([e1bd7bd](https://github.com/MorpheApp/morphe-patches/commit/e1bd7bda5bc6916c6142a9b1102d094411a5a89f))
* **Reddit:** Support version `2026.04.0` ([#545](https://github.com/MorpheApp/morphe-patches/issues/545)) ([c59a0fc](https://github.com/MorpheApp/morphe-patches/commit/c59a0fc966cbe3f94c5bf3886fd96eaa80049b98))
* Use Morphe patcher 1.1.1 ([#347](https://github.com/MorpheApp/morphe-patches/issues/347)) ([f0178c3](https://github.com/MorpheApp/morphe-patches/commit/f0178c3048a001f7aa4ffae4cccbdb756b64553c))
* **YouTube - Hide layout components:** Add "Hide channel tab filter" setting ([#540](https://github.com/MorpheApp/morphe-patches/issues/540)) ([5cca175](https://github.com/MorpheApp/morphe-patches/commit/5cca175398ade42675b3c5e082d8fbe7b1043ab1))
* **YouTube - Hide layout components:** Add "Hide feed flyout menu filter" setting ([#535](https://github.com/MorpheApp/morphe-patches/issues/535)) ([06c8215](https://github.com/MorpheApp/morphe-patches/commit/06c8215d4320b38ad5f168eabcb5fc29a6ce4640))
* **YouTube - Navigation bar:** Add "Hide voice search button" setting ([#513](https://github.com/MorpheApp/morphe-patches/issues/513)) ([b59ec4b](https://github.com/MorpheApp/morphe-patches/commit/b59ec4b9e67c00e6fa284b50de294c805c255399))

# [1.14.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.8...v1.14.0-dev.9) (2026-02-18)


### Bug Fixes

* **Override certificate pinning:** Handle element missing from network config ([#574](https://github.com/MorpheApp/morphe-patches/issues/574)) ([7b4d015](https://github.com/MorpheApp/morphe-patches/commit/7b4d015e4fb37163127257a23de7757c5d2a1f9d))

# [1.14.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.7...v1.14.0-dev.8) (2026-02-18)


### Features

* **YouTube - Navigation bar:** Add "Hide voice search button" setting ([#513](https://github.com/MorpheApp/morphe-patches/issues/513)) ([b59ec4b](https://github.com/MorpheApp/morphe-patches/commit/b59ec4b9e67c00e6fa284b50de294c805c255399))

# [1.14.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.6...v1.14.0-dev.7) (2026-02-18)


### Bug Fixes

* **Spoof video streams:** Using the TV client can cause a V8 runtime memory leak ([#564](https://github.com/MorpheApp/morphe-patches/issues/564)) ([59a4061](https://github.com/MorpheApp/morphe-patches/commit/59a4061b28b4be38c4a836a22aa2af429edad5e2))

# [1.14.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.5...v1.14.0-dev.6) (2026-02-17)


### Features

* **Reddit:** Support version `2026.04.0` ([#545](https://github.com/MorpheApp/morphe-patches/issues/545)) ([c59a0fc](https://github.com/MorpheApp/morphe-patches/commit/c59a0fc966cbe3f94c5bf3886fd96eaa80049b98))

# [1.14.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.4...v1.14.0-dev.5) (2026-02-16)


### Features

* **YouTube - Hide layout components:** Add "Hide channel tab filter" setting ([#540](https://github.com/MorpheApp/morphe-patches/issues/540)) ([5cca175](https://github.com/MorpheApp/morphe-patches/commit/5cca175398ade42675b3c5e082d8fbe7b1043ab1))

# [1.14.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.3...v1.14.0-dev.4) (2026-02-15)


### Features

* Add `Disable DRC audio` patch ([#461](https://github.com/MorpheApp/morphe-patches/issues/461)) ([e1bd7bd](https://github.com/MorpheApp/morphe-patches/commit/e1bd7bda5bc6916c6142a9b1102d094411a5a89f))

# [1.14.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.2...v1.14.0-dev.3) (2026-02-14)


### Bug Fixes

* Use jsdelivr for patch bundle hosting ([3b8b3f0](https://github.com/MorpheApp/morphe-patches/commit/3b8b3f087859ebb17b9beffd4c2ce3fdca627a4a))

# [1.14.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.14.0-dev.1...v1.14.0-dev.2) (2026-02-14)


### Features

* **YouTube - Hide layout components:** Add "Hide feed flyout menu filter" setting ([#535](https://github.com/MorpheApp/morphe-patches/issues/535)) ([06c8215](https://github.com/MorpheApp/morphe-patches/commit/06c8215d4320b38ad5f168eabcb5fc29a6ce4640))

# [1.14.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.13.1-dev.1...v1.14.0-dev.1) (2026-02-13)


### Features

* Use Morphe patcher 1.1.1 ([#347](https://github.com/MorpheApp/morphe-patches/issues/347)) ([f0178c3](https://github.com/MorpheApp/morphe-patches/commit/f0178c3048a001f7aa4ffae4cccbdb756b64553c))

## [1.13.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0...v1.13.1-dev.1) (2026-02-13)


### Bug Fixes

* **YouTube:** Add experimental support for `21.07.240` ([015d66a](https://github.com/MorpheApp/morphe-patches/commit/015d66a3d9fb352f5be47af59139d736fe43b26b))

# [1.13.0](https://github.com/MorpheApp/morphe-patches/compare/v1.12.0...v1.13.0) (2026-02-12)


### Bug Fixes

* **Spoof video streams:** Change patch to default excluded for root ([546580d](https://github.com/MorpheApp/morphe-patches/commit/546580d53c87329c53ed69809b1e1301998e9fb9))
* **YouTube - Hide layout components:** Resolve "Hide comments section in Home feed" not hiding comments ([#473](https://github.com/MorpheApp/morphe-patches/issues/473)) ([915849b](https://github.com/MorpheApp/morphe-patches/commit/915849b888ff66007af4051cdb307573047285fa))
* **YouTube - Hide layout components:** Resolve "Hide community posts" not working in search results ([#485](https://github.com/MorpheApp/morphe-patches/issues/485)) ([9083a16](https://github.com/MorpheApp/morphe-patches/commit/9083a16bd3f0098acabebee91e660f15b676d1fb))
* **YouTube - Hide layout components:** Resolve community posts sometimes showing in the player suggestions ([0d0886a](https://github.com/MorpheApp/morphe-patches/commit/0d0886a1d45cb33bb9b43542009b14849fd47849))
* **YouTube - Hide Shorts components:** Resolve hiding Shorts also hiding channel page headers ([#518](https://github.com/MorpheApp/morphe-patches/issues/518)) ([966232b](https://github.com/MorpheApp/morphe-patches/commit/966232b6e7bd610b09b2b7ce40ade735115f7748))
* **YouTube - Navigation bar:** Resolve experimental player black bar when "Disable translucent status bar" is enabled ([#464](https://github.com/MorpheApp/morphe-patches/issues/464)) ([1a9dd11](https://github.com/MorpheApp/morphe-patches/commit/1a9dd1128b13161318157e632e8e4125140081b3))
* **YouTube - Theme:** Apply dark color to 21.06+ experimental app targets ([#495](https://github.com/MorpheApp/morphe-patches/issues/495)) ([62ca1be](https://github.com/MorpheApp/morphe-patches/commit/62ca1bed0f3cc4713420b3299872ce2fb285c03e))
* **YouTube:** Resolve experimental patching of `21.06.257` ([62f68a4](https://github.com/MorpheApp/morphe-patches/commit/62f68a47a690d027f16e0d05b963ea399f6237bb))


### Features

* **YouTube - Hide layout components:** Add "Hide collapse button" and "Hide fullscreen button" settings ([#511](https://github.com/MorpheApp/morphe-patches/issues/511)) ([91f1aad](https://github.com/MorpheApp/morphe-patches/commit/91f1aadb386ccfd58cfaf0cf44601af48225f40c))
* **YouTube - Hide layout components:** Add "Hide comment prompts" setting ([#463](https://github.com/MorpheApp/morphe-patches/issues/463)) ([3ca9551](https://github.com/MorpheApp/morphe-patches/commit/3ca95517f45acbc34a25c569e975e903e6eafa1f))
* **YouTube:** Add `Disable layout updates` patch ([#493](https://github.com/MorpheApp/morphe-patches/issues/493)) ([0399388](https://github.com/MorpheApp/morphe-patches/commit/039938837397317471e676e9608e4fcbc25f46ec))

# [1.13.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.14...v1.13.0-dev.15) (2026-02-12)


### Bug Fixes

* **YouTube - Hide Shorts components:** Resolve hiding Shorts also hiding channel page headers ([#518](https://github.com/MorpheApp/morphe-patches/issues/518)) ([966232b](https://github.com/MorpheApp/morphe-patches/commit/966232b6e7bd610b09b2b7ce40ade735115f7748))

# [1.13.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.13...v1.13.0-dev.14) (2026-02-12)


### Bug Fixes

* **YouTube:** Resolve experimental patching of `21.06.257` ([62f68a4](https://github.com/MorpheApp/morphe-patches/commit/62f68a47a690d027f16e0d05b963ea399f6237bb))

# [1.13.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.12...v1.13.0-dev.13) (2026-02-11)


### Bug Fixes

* **Spoof video streams:** Change patch to default excluded for root ([546580d](https://github.com/MorpheApp/morphe-patches/commit/546580d53c87329c53ed69809b1e1301998e9fb9))

# [1.13.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.11...v1.13.0-dev.12) (2026-02-11)


### Features

* **YouTube - Hide layout components:** Add "Hide collapse button" and "Hide fullscreen button" settings ([#511](https://github.com/MorpheApp/morphe-patches/issues/511)) ([91f1aad](https://github.com/MorpheApp/morphe-patches/commit/91f1aadb386ccfd58cfaf0cf44601af48225f40c))

# [1.13.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.10...v1.13.0-dev.11) (2026-02-11)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve community posts sometimes showing in the player suggestions ([0d0886a](https://github.com/MorpheApp/morphe-patches/commit/0d0886a1d45cb33bb9b43542009b14849fd47849))

# [1.13.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.9...v1.13.0-dev.10) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Resolve theme color incorrectly applying to player overlay ([bbf94ec](https://github.com/MorpheApp/morphe-patches/commit/bbf94ec0b24a1684d8c565a5eec4bf4aefd6bf57))

# [1.13.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.8...v1.13.0-dev.9) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Override missing 21.06+ light theme color ([a338f0f](https://github.com/MorpheApp/morphe-patches/commit/a338f0f5e5885cd04539ffd831930d1643303c26))

# [1.13.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.7...v1.13.0-dev.8) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Show correct icon light/dark mode if using YouTube light/dark manual override ([3f5d75a](https://github.com/MorpheApp/morphe-patches/commit/3f5d75a39a7450262207bc26e43ef2c3862c9e47))

# [1.13.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.6...v1.13.0-dev.7) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Adjust theme color replacement ([12fc228](https://github.com/MorpheApp/morphe-patches/commit/12fc2284bd719d9992045474f2b7e0cf20b976fd))

# [1.13.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.5...v1.13.0-dev.6) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Adjust black color overrides ([b779c12](https://github.com/MorpheApp/morphe-patches/commit/b779c1245e241b2ad2929cc01767e86ea814cfc4))

# [1.13.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.4...v1.13.0-dev.5) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Use correct theme color for settings icon ([a6d472d](https://github.com/MorpheApp/morphe-patches/commit/a6d472d35c19ad3aa3a6aa1b2544d61d4070b78e))

# [1.13.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.3...v1.13.0-dev.4) (2026-02-10)


### Bug Fixes

* **YouTube - Theme:** Apply dark color to 21.06+ experimental app targets ([#495](https://github.com/MorpheApp/morphe-patches/issues/495)) ([62ca1be](https://github.com/MorpheApp/morphe-patches/commit/62ca1bed0f3cc4713420b3299872ce2fb285c03e))


### Features

* **YouTube:** Add `Disable layout updates` patch ([#493](https://github.com/MorpheApp/morphe-patches/issues/493)) ([0399388](https://github.com/MorpheApp/morphe-patches/commit/039938837397317471e676e9608e4fcbc25f46ec))

# [1.13.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.2...v1.13.0-dev.3) (2026-02-09)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve "Hide community posts" not working in search results ([#485](https://github.com/MorpheApp/morphe-patches/issues/485)) ([9083a16](https://github.com/MorpheApp/morphe-patches/commit/9083a16bd3f0098acabebee91e660f15b676d1fb))

# [1.13.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.13.0-dev.1...v1.13.0-dev.2) (2026-02-08)


### Bug Fixes

* **YouTube - Hide layout components:** Resolve "Hide comments section in Home feed" not hiding comments ([#473](https://github.com/MorpheApp/morphe-patches/issues/473)) ([915849b](https://github.com/MorpheApp/morphe-patches/commit/915849b888ff66007af4051cdb307573047285fa))

# [1.13.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.12.0...v1.13.0-dev.1) (2026-02-08)


### Bug Fixes

* **YouTube - Navigation bar:** Resolve experimental player black bar when "Disable translucent status bar" is enabled ([#464](https://github.com/MorpheApp/morphe-patches/issues/464)) ([1a9dd11](https://github.com/MorpheApp/morphe-patches/commit/1a9dd1128b13161318157e632e8e4125140081b3))


### Features

* **YouTube - Hide layout components:** Add "Hide comment prompts" setting ([#463](https://github.com/MorpheApp/morphe-patches/issues/463)) ([3ca9551](https://github.com/MorpheApp/morphe-patches/commit/3ca95517f45acbc34a25c569e975e903e6eafa1f))

# [1.12.0](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0...v1.12.0) (2026-02-07)


### Features

* **Spoof video streams:** Default client maintenance ([#448](https://github.com/MorpheApp/morphe-patches/issues/448)) ([36817a3](https://github.com/MorpheApp/morphe-patches/commit/36817a35c0f337f7d988624d8aebac418424a5f2))
* **YouTube - Spoof app version:** Remove target version `19.35.36` ([#458](https://github.com/MorpheApp/morphe-patches/issues/458)) ([8c87a2c](https://github.com/MorpheApp/morphe-patches/commit/8c87a2ccb529fa7b69dc98eaa6fcd4741e05508b))
* **YouTube - Video quality:** Add "Prioritize video quality" setting ([#449](https://github.com/MorpheApp/morphe-patches/issues/449)) ([9819078](https://github.com/MorpheApp/morphe-patches/commit/98190781e890e56eeb0771496af43ce710e8443d))

# [1.12.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.12.0-dev.1...v1.12.0-dev.2) (2026-02-07)


### Features

* **YouTube - Spoof app version:** Remove target version `19.35.36` ([#458](https://github.com/MorpheApp/morphe-patches/issues/458)) ([8c87a2c](https://github.com/MorpheApp/morphe-patches/commit/8c87a2ccb529fa7b69dc98eaa6fcd4741e05508b))

# [1.12.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0...v1.12.0-dev.1) (2026-02-07)


### Features

* **Spoof video streams:** Default client maintenance ([#448](https://github.com/MorpheApp/morphe-patches/issues/448)) ([36817a3](https://github.com/MorpheApp/morphe-patches/commit/36817a35c0f337f7d988624d8aebac418424a5f2))
* **YouTube - Video quality:** Add "Prioritize video quality" setting ([#449](https://github.com/MorpheApp/morphe-patches/issues/449)) ([9819078](https://github.com/MorpheApp/morphe-patches/commit/98190781e890e56eeb0771496af43ce710e8443d))

# [1.11.0](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0...v1.11.0) (2026-02-06)


### Bug Fixes

* **Custom branding:** Show user provided custom icon everywhere ([c0433ab](https://github.com/MorpheApp/morphe-patches/commit/c0433abbd8be4797c085d6637aa4ebe8ae20f9a6))
* **YouTube - Ambient mode:** Resolve "Bypass Ambient mode restrictions" not bypassing ([#392](https://github.com/MorpheApp/morphe-patches/issues/392)) ([f5b71b2](https://github.com/MorpheApp/morphe-patches/commit/f5b71b2582f3919ee02cc58b40ce0a1a49c50b91))
* **YouTube - Hide ads:** Empty space is left when ads are hidden on tablets ([#377](https://github.com/MorpheApp/morphe-patches/issues/377)) ([da12960](https://github.com/MorpheApp/morphe-patches/commit/da12960ceb4d93490b8d41f0ea616d686eb609eb))
* **YouTube - Hide layout components:** "Hide Featured places" also hide watch history shelf ([#420](https://github.com/MorpheApp/morphe-patches/issues/420)) ([fcb6758](https://github.com/MorpheApp/morphe-patches/commit/fcb675828b3465e5ea7b88cc659bbad284f6daa1))
* **YouTube - Hide layout components:** "Hide Show more button" leaves empty space ([#422](https://github.com/MorpheApp/morphe-patches/issues/422)) ([d44862d](https://github.com/MorpheApp/morphe-patches/commit/d44862d81dc8d4b07cfcf1af7109e3dd6feae414))
* **YouTube - Hide layout components:** "Hide subscribed channels bar" leaves empty space ([#404](https://github.com/MorpheApp/morphe-patches/issues/404)) ([6b68416](https://github.com/MorpheApp/morphe-patches/commit/6b6841626d76c9679b4b9bebfa98ccab9d617fd2))
* **YouTube - Hide layout components:** Resolve "Hide subscribed channels bar" leaves empty space in landscape mode ([#421](https://github.com/MorpheApp/morphe-patches/issues/421)) ([83230a6](https://github.com/MorpheApp/morphe-patches/commit/83230a61bc7b9909af87869456580927047a5aac))
* **YouTube - Miniplayer:** Minimal miniplayer has wrong play icon ([2eddce0](https://github.com/MorpheApp/morphe-patches/commit/2eddce052761c6e7cd519ef3f57e098ca4044c3e))
* **YouTube - Navigation bar:** Rename "Switch Create with Notifications" to "Swap Create with Notifications" ([#384](https://github.com/MorpheApp/morphe-patches/issues/384)) ([6472dee](https://github.com/MorpheApp/morphe-patches/commit/6472dee35dae7d3b0ba08dd2b4348b535ce48da7))
* **YouTube - SponsorBlock:** Resolve segments not fetching on experimental app targets ([46a5d9a](https://github.com/MorpheApp/morphe-patches/commit/46a5d9a0de18231b5dd4e664d6992b36663386ee))


### Features

* Show an experimental user on the first launch of an experimental app target ([#414](https://github.com/MorpheApp/morphe-patches/issues/414)) ([d52b9c9](https://github.com/MorpheApp/morphe-patches/commit/d52b9c97bc581a67708a0c9efe01472b24e0df5d))
* **YouTube - Hide layout components:** Add "Hide comments section in Home feed" setting ([#382](https://github.com/MorpheApp/morphe-patches/issues/382)) ([b20f629](https://github.com/MorpheApp/morphe-patches/commit/b20f6294236cad32b1be29b73e761659193e464b))
* **YouTube - Hide layout components:** Add "Hide explore this course" setting ([#410](https://github.com/MorpheApp/morphe-patches/issues/410)) ([42eaca0](https://github.com/MorpheApp/morphe-patches/commit/42eaca0d04c51ff5ae30b418ed8d2b9dd771ccc5))
* **YouTube - Hide layout components:** Add "Hide Quizzes" setting ([#425](https://github.com/MorpheApp/morphe-patches/issues/425)) ([c843c32](https://github.com/MorpheApp/morphe-patches/commit/c843c32e69c078a6b8da2d1c3045f0b31898c53e))
* **YouTube - Hide Shorts components:** Add "Hide AI button" setting ([#436](https://github.com/MorpheApp/morphe-patches/issues/436)) ([eea4657](https://github.com/MorpheApp/morphe-patches/commit/eea4657c94887d4e5f1e59a0392ee1f477bcd72b))
* **YouTube - Hide Shorts components:** Add "Hide in video description" setting ([#426](https://github.com/MorpheApp/morphe-patches/issues/426)) ([7c01227](https://github.com/MorpheApp/morphe-patches/commit/7c01227b49f3feb4382e895fe768cd1cc3e6afd4))
* **YouTube - Spoof app version:** Add target version `20.28.41` ([#375](https://github.com/MorpheApp/morphe-patches/issues/375)) ([3793689](https://github.com/MorpheApp/morphe-patches/commit/3793689be432ee1643e27670e2c845d4462a80b3))
* **YouTube - Spoof app version:** Add target version `20.39.41` ([9ef0d22](https://github.com/MorpheApp/morphe-patches/commit/9ef0d2211aab5d5cb2d274678b2707ae0296499e))
* **YouTube - Video quality:** Add `Hide Premium video quality` setting ([#423](https://github.com/MorpheApp/morphe-patches/issues/423)) ([fb3cb36](https://github.com/MorpheApp/morphe-patches/commit/fb3cb368ea0bb9a05cefacf0509a35acbded5ae5))
* **YouTube:** Add `Ambient mode` patch ([#367](https://github.com/MorpheApp/morphe-patches/issues/367)) ([91a68f5](https://github.com/MorpheApp/morphe-patches/commit/91a68f5200d1f4061821aaba9f955a0fc9ec2cf1))
* **YouTube:** Add experimental support for `21.06.251` ([3872f34](https://github.com/MorpheApp/morphe-patches/commit/3872f34adf76b7b20c554d3c9af4890ba06f38e6))

# [1.11.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.15...v1.11.0-dev.16) (2026-02-06)


### Bug Fixes

* **YouTube:** Add experimental support for `21.06.251` ([3872f34](https://github.com/MorpheApp/morphe-patches/commit/3872f34adf76b7b20c554d3c9af4890ba06f38e6))

# [1.11.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.14...v1.11.0-dev.15) (2026-02-05)


### Features

* **YouTube - Hide Shorts components:** Add "Hide AI button" setting ([#436](https://github.com/MorpheApp/morphe-patches/issues/436)) ([eea4657](https://github.com/MorpheApp/morphe-patches/commit/eea4657c94887d4e5f1e59a0392ee1f477bcd72b))

# [1.11.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.13...v1.11.0-dev.14) (2026-02-05)


### Bug Fixes

* **YouTube - SponsorBlock:** Resolve segments not fetching on experimental app targets ([46a5d9a](https://github.com/MorpheApp/morphe-patches/commit/46a5d9a0de18231b5dd4e664d6992b36663386ee))

# [1.11.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.12...v1.11.0-dev.13) (2026-02-05)


### Features

* **YouTube - Hide Shorts components:** Add "Hide in video description" setting ([#426](https://github.com/MorpheApp/morphe-patches/issues/426)) ([7c01227](https://github.com/MorpheApp/morphe-patches/commit/7c01227b49f3feb4382e895fe768cd1cc3e6afd4))

# [1.11.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.11...v1.11.0-dev.12) (2026-02-05)


### Features

* **YouTube - Hide layout components:** Add "Hide Quizzes" setting ([#425](https://github.com/MorpheApp/morphe-patches/issues/425)) ([c843c32](https://github.com/MorpheApp/morphe-patches/commit/c843c32e69c078a6b8da2d1c3045f0b31898c53e))

# [1.11.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.10...v1.11.0-dev.11) (2026-02-05)


### Bug Fixes

* **YouTube - Hide layout components:** `Hide Featured places` also hide watch history shelf ([#420](https://github.com/MorpheApp/morphe-patches/issues/420)) ([fcb6758](https://github.com/MorpheApp/morphe-patches/commit/fcb675828b3465e5ea7b88cc659bbad284f6daa1))

# [1.11.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.9...v1.11.0-dev.10) (2026-02-04)


### Bug Fixes

* **YouTube - Hide layout components:** `Hide Show more button` leaves empty space ([#422](https://github.com/MorpheApp/morphe-patches/issues/422)) ([d44862d](https://github.com/MorpheApp/morphe-patches/commit/d44862d81dc8d4b07cfcf1af7109e3dd6feae414))
* **YouTube - Hide layout components:** Resolve "Hide subscribed channels bar" leaves empty space in landscape mode ([#421](https://github.com/MorpheApp/morphe-patches/issues/421)) ([83230a6](https://github.com/MorpheApp/morphe-patches/commit/83230a61bc7b9909af87869456580927047a5aac))


### Features

* **YouTube - Video quality:** Add `Hide Premium video quality` setting ([#423](https://github.com/MorpheApp/morphe-patches/issues/423)) ([fb3cb36](https://github.com/MorpheApp/morphe-patches/commit/fb3cb368ea0bb9a05cefacf0509a35acbded5ae5))

# [1.11.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.8...v1.11.0-dev.9) (2026-02-04)


### Bug Fixes

* **Custom branding:** Show user provided custom icon everywhere ([c0433ab](https://github.com/MorpheApp/morphe-patches/commit/c0433abbd8be4797c085d6637aa4ebe8ae20f9a6))

# [1.11.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.7...v1.11.0-dev.8) (2026-02-04)


### Bug Fixes

* **YouTube - Ambient mode:** Resolve "Bypass Ambient mode restrictions" not bypassing ([#392](https://github.com/MorpheApp/morphe-patches/issues/392)) ([f5b71b2](https://github.com/MorpheApp/morphe-patches/commit/f5b71b2582f3919ee02cc58b40ce0a1a49c50b91))
* **YouTube - Miniplayer:** Minimal miniplayer has wrong play icon ([2eddce0](https://github.com/MorpheApp/morphe-patches/commit/2eddce052761c6e7cd519ef3f57e098ca4044c3e))

# [1.11.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.6...v1.11.0-dev.7) (2026-02-04)


### Features

* Show an experimental user dialog message on the first launch of an experimental app target ([#414](https://github.com/MorpheApp/morphe-patches/issues/414)) ([d52b9c9](https://github.com/MorpheApp/morphe-patches/commit/d52b9c97bc581a67708a0c9efe01472b24e0df5d))

# [1.11.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.5...v1.11.0-dev.6) (2026-02-03)


### Features

* **YouTube - Hide layout components:** Add "Hide explore this course" setting ([#410](https://github.com/MorpheApp/morphe-patches/issues/410)) ([42eaca0](https://github.com/MorpheApp/morphe-patches/commit/42eaca0d04c51ff5ae30b418ed8d2b9dd771ccc5))

# [1.11.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.4...v1.11.0-dev.5) (2026-02-03)


### Features

* **YouTube - Spoof app version:** Add target version `20.39.41` ([9ef0d22](https://github.com/MorpheApp/morphe-patches/commit/9ef0d2211aab5d5cb2d274678b2707ae0296499e))

# [1.11.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.3...v1.11.0-dev.4) (2026-02-03)


### Bug Fixes

* **YouTube - Hide layout components:** `Hide subscribed channels bar` leaves empty space ([#404](https://github.com/MorpheApp/morphe-patches/issues/404)) ([6b68416](https://github.com/MorpheApp/morphe-patches/commit/6b6841626d76c9679b4b9bebfa98ccab9d617fd2))

# [1.11.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.2...v1.11.0-dev.3) (2026-02-02)


### Bug Fixes

* **YouTube - Spoof app version:** Resolve experimental patching of `21.05.264` ([3d7c0e6](https://github.com/MorpheApp/morphe-patches/commit/3d7c0e6fc953775048c58a77004a4938e4df7ba8))

# [1.11.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.11.0-dev.1...v1.11.0-dev.2) (2026-02-02)


### Bug Fixes

* **YouTube - Hide ads:** Empty space is left when ads are hidden on tablets ([#377](https://github.com/MorpheApp/morphe-patches/issues/377)) ([da12960](https://github.com/MorpheApp/morphe-patches/commit/da12960ceb4d93490b8d41f0ea616d686eb609eb))
* **YouTube - Navigation bar:** Rename "Switch Create with Notifications" to "Swap Create with Notifications" ([#384](https://github.com/MorpheApp/morphe-patches/issues/384)) ([6472dee](https://github.com/MorpheApp/morphe-patches/commit/6472dee35dae7d3b0ba08dd2b4348b535ce48da7))


### Features

* **YouTube - Spoof app version:** Add target version `20.28.41` ([#375](https://github.com/MorpheApp/morphe-patches/issues/375)) ([3793689](https://github.com/MorpheApp/morphe-patches/commit/3793689be432ee1643e27670e2c845d4462a80b3))
* **YouTube:** Add `Ambient mode` patch ([#367](https://github.com/MorpheApp/morphe-patches/issues/367)) ([91a68f5](https://github.com/MorpheApp/morphe-patches/commit/91a68f5200d1f4061821aaba9f955a0fc9ec2cf1))

# [1.11.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.10.1-dev.2...v1.11.0-dev.1) (2026-02-02)


### Features

* **YouTube - Hide layout components:** Add "Hide comments section in Home feed" setting ([#382](https://github.com/MorpheApp/morphe-patches/issues/382)) ([b20f629](https://github.com/MorpheApp/morphe-patches/commit/b20f6294236cad32b1be29b73e761659193e464b))

## [1.10.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.10.1-dev.1...v1.10.1-dev.2) (2026-02-02)


### Bug Fixes

* **YouTube:** Resolve experimental `21.05.264` video description crash ([90a7fae](https://github.com/MorpheApp/morphe-patches/commit/90a7faeb5adf0eb60cb519d7ae455102236e9e2d))

## [1.10.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0...v1.10.1-dev.1) (2026-02-02)


### Bug Fixes

* **YouTube:** Resolve experimental `21.05.264` Shorts crash ([eda285a](https://github.com/MorpheApp/morphe-patches/commit/eda285a096024cc262eaf2233e6fbdc4ce77d275))

# [1.10.0](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0...v1.10.0) (2026-02-02)


### Bug Fixes

* **Spoof video streams:** Spoofing does not work if the default client is not `TV` ([#373](https://github.com/MorpheApp/morphe-patches/issues/373)) ([8a40c96](https://github.com/MorpheApp/morphe-patches/commit/8a40c96bdcb13d20f2f2c2055735f9678fc92bce))
* **YouTube - Downloads:** Change Seal to hidden preset and add Seal pre-release ([#371](https://github.com/MorpheApp/morphe-patches/issues/371)) ([0406aee](https://github.com/MorpheApp/morphe-patches/commit/0406aee91b0bf14430ce33dc39d3a06b4434ce0c))
* **YouTube - Hide ads:** Fix "Hide YouTube Premium promotions" hiding YouTube Doodles ([#370](https://github.com/MorpheApp/morphe-patches/issues/370)) ([61860b7](https://github.com/MorpheApp/morphe-patches/commit/61860b7784a2ad4946fd71fb211ae2d2c56d4d1b))


### Features

* **Spoof video streams:** Default client maintenance ([#340](https://github.com/MorpheApp/morphe-patches/issues/340)) ([d72cfbe](https://github.com/MorpheApp/morphe-patches/commit/d72cfbe5ccad91ca4527a23da9aa8a55bfb161f1))
* **YouTube - Captions:** Add "Set caption cookies" and "Fix transcript" settings ([#341](https://github.com/MorpheApp/morphe-patches/issues/341)) ([0e50fc7](https://github.com/MorpheApp/morphe-patches/commit/0e50fc7de9b667f6f9b1e61cec2cfd2f6011e126))
* **YouTube - Downloads:** Add "Seal Plus" as a hidden preset downloader ([#357](https://github.com/MorpheApp/morphe-patches/issues/357)) ([077128c](https://github.com/MorpheApp/morphe-patches/commit/077128c9115ae0f168c9710fc2d1bb8f1a5ee236))
* **YouTube - Hide layout components:** Add "Hide course progress" setting ([#351](https://github.com/MorpheApp/morphe-patches/issues/351)) ([4a83b54](https://github.com/MorpheApp/morphe-patches/commit/4a83b54c292a66f5ca2825c0f4a45a5650c528d4))
* **YouTube:** Add experimental support for `21.05.264` ([#335](https://github.com/MorpheApp/morphe-patches/issues/335)) ([a3f1a5c](https://github.com/MorpheApp/morphe-patches/commit/a3f1a5c1a6fc21d2d6b1e30a600c0d5eaf0c2bf5))

# [1.10.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0-dev.5...v1.10.0-dev.6) (2026-02-02)


### Bug Fixes

* **YouTube - Downloads:** Change Seal to hidden preset and add Seal pre-release ([#371](https://github.com/MorpheApp/morphe-patches/issues/371)) ([0406aee](https://github.com/MorpheApp/morphe-patches/commit/0406aee91b0bf14430ce33dc39d3a06b4434ce0c))
* **YouTube - Hide ads:** Fix "Hide YouTube Premium promotions" hiding YouTube Doodles ([#370](https://github.com/MorpheApp/morphe-patches/issues/370)) ([61860b7](https://github.com/MorpheApp/morphe-patches/commit/61860b7784a2ad4946fd71fb211ae2d2c56d4d1b))


### Features

* **YouTube:** Add experimental support for `21.05.264` ([#335](https://github.com/MorpheApp/morphe-patches/issues/335)) ([a3f1a5c](https://github.com/MorpheApp/morphe-patches/commit/a3f1a5c1a6fc21d2d6b1e30a600c0d5eaf0c2bf5))

# [1.10.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0-dev.4...v1.10.0-dev.5) (2026-02-02)


### Bug Fixes

* **Spoof video streams:** Spoofing does not work if the default client is not `TV` ([#373](https://github.com/MorpheApp/morphe-patches/issues/373)) ([8a40c96](https://github.com/MorpheApp/morphe-patches/commit/8a40c96bdcb13d20f2f2c2055735f9678fc92bce))

# [1.10.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0-dev.3...v1.10.0-dev.4) (2026-02-01)


### Features

* **YouTube - Downloads:** Add "Seal Plus" as a hidden preset downloader ([#357](https://github.com/MorpheApp/morphe-patches/issues/357)) ([077128c](https://github.com/MorpheApp/morphe-patches/commit/077128c9115ae0f168c9710fc2d1bb8f1a5ee236))

# [1.10.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0-dev.2...v1.10.0-dev.3) (2026-02-01)


### Features

* **YouTube - Hide layout components:** Add "Hide course progress" setting ([#351](https://github.com/MorpheApp/morphe-patches/issues/351)) ([4a83b54](https://github.com/MorpheApp/morphe-patches/commit/4a83b54c292a66f5ca2825c0f4a45a5650c528d4))

# [1.10.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.10.0-dev.1...v1.10.0-dev.2) (2026-02-01)


### Features

* **YouTube - Captions:** Add "Set caption cookies" and "Fix transcript" settings ([#341](https://github.com/MorpheApp/morphe-patches/issues/341)) ([0e50fc7](https://github.com/MorpheApp/morphe-patches/commit/0e50fc7de9b667f6f9b1e61cec2cfd2f6011e126))

# [1.10.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0...v1.10.0-dev.1) (2026-02-01)


### Features

* **Spoof video streams:** Default client maintenance ([#340](https://github.com/MorpheApp/morphe-patches/issues/340)) ([d72cfbe](https://github.com/MorpheApp/morphe-patches/commit/d72cfbe5ccad91ca4527a23da9aa8a55bfb161f1))

# [1.9.0](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0...v1.9.0) (2026-01-31)


### Bug Fixes

* **YouTube:** Show a more descriptive error message if attempting to patch a region specific APKM that does not contain languages for all regions ([0f2700d](https://github.com/MorpheApp/morphe-patches/commit/0f2700db110a2e8d041e1213e0d95ed50f6d54ac))


### Features

* **Reddit:** Add ability to hide Games button on nav bar ([#315](https://github.com/MorpheApp/morphe-patches/issues/315)) ([07b9fc2](https://github.com/MorpheApp/morphe-patches/commit/07b9fc250b24c0219e8f650883f3c22ea7dfa23f))
* **Reddit:** Add support for Reddit `2026.04.0` ([#276](https://github.com/MorpheApp/morphe-patches/issues/276)) ([0203cf6](https://github.com/MorpheApp/morphe-patches/commit/0203cf62d7214fe79b42a804fc51111e805f2afd))
* **YouTube - Hide layout components:** Add "Hide Latest videos button" setting ([#305](https://github.com/MorpheApp/morphe-patches/issues/305)) ([aed3e34](https://github.com/MorpheApp/morphe-patches/commit/aed3e343885732bb86647ddf626efdc173ca2ed6))
* **YouTube - Hide layout components:** Add "Hide live chat replay button" setting ([#330](https://github.com/MorpheApp/morphe-patches/issues/330)) ([7a6c697](https://github.com/MorpheApp/morphe-patches/commit/7a6c69791cafc9247a55ac4c6ad30dcabba96d70))
* **YouTube - Hide layout components:** Add "Hide video title" setting ([#309](https://github.com/MorpheApp/morphe-patches/issues/309)) ([2c7a973](https://github.com/MorpheApp/morphe-patches/commit/2c7a973d73644d81da1dd4a82a3b10056863ac70))
* **YouTube - Navigation bar:** Add settings to hide toolbar buttons ([#298](https://github.com/MorpheApp/morphe-patches/issues/298)) ([73fd722](https://github.com/MorpheApp/morphe-patches/commit/73fd722c0d76148323ae60ddc64ae05c8d95b5d4))
* **YouTube:** Add `Restore old search filters` patch ([#285](https://github.com/MorpheApp/morphe-patches/issues/285)) ([c088723](https://github.com/MorpheApp/morphe-patches/commit/c0887234612bb24ad8184fe211af14cf0640d8ec))

# [1.9.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.10...v1.9.0-dev.11) (2026-01-30)


### Bug Fixes

* **Reddit:** Change recommended app target to `2026.03.0` ([7a5cda5](https://github.com/MorpheApp/morphe-patches/commit/7a5cda571d4ec5e6324cc2905d0c8dec3b0c8f52))

# [1.9.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.9...v1.9.0-dev.10) (2026-01-30)


### Features

* **YouTube - Hide layout components:** Add "Hide live chat replay button" setting ([#330](https://github.com/MorpheApp/morphe-patches/issues/330)) ([7a6c697](https://github.com/MorpheApp/morphe-patches/commit/7a6c69791cafc9247a55ac4c6ad30dcabba96d70))

# [1.9.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.8...v1.9.0-dev.9) (2026-01-29)


### Bug Fixes

* **Reddit:** Handle navigation bar buttons hidden behind feature flags ([#328](https://github.com/MorpheApp/morphe-patches/issues/328)) ([2b8c337](https://github.com/MorpheApp/morphe-patches/commit/2b8c33702293acfbd859cdfbdf1342e5f9e96bc2))

# [1.9.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.7...v1.9.0-dev.8) (2026-01-29)


### Features

* **YouTube - Hide layout components:** Add "Hide Latest videos button" setting ([#305](https://github.com/MorpheApp/morphe-patches/issues/305)) ([aed3e34](https://github.com/MorpheApp/morphe-patches/commit/aed3e343885732bb86647ddf626efdc173ca2ed6))

# [1.9.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.6...v1.9.0-dev.7) (2026-01-28)


### Bug Fixes

* **Reddit:** Fix Recently Visited Shelf patch not being usable ([#316](https://github.com/MorpheApp/morphe-patches/issues/316)) ([49bab2b](https://github.com/MorpheApp/morphe-patches/commit/49bab2becde7f1adf593266b88abba0b876925ba))


### Features

* **Reddit:** Add ability to hide Games button on nav bar ([#315](https://github.com/MorpheApp/morphe-patches/issues/315)) ([07b9fc2](https://github.com/MorpheApp/morphe-patches/commit/07b9fc250b24c0219e8f650883f3c22ea7dfa23f))

# [1.9.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.5...v1.9.0-dev.6) (2026-01-27)


### Features

* **Reddit:** Add support for Reddit `2026.04.0` ([#276](https://github.com/MorpheApp/morphe-patches/issues/276)) ([0203cf6](https://github.com/MorpheApp/morphe-patches/commit/0203cf62d7214fe79b42a804fc51111e805f2afd))

# [1.9.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.4...v1.9.0-dev.5) (2026-01-27)


### Features

* **YouTube - Hide layout components:** Add "Hide video title" setting ([#309](https://github.com/MorpheApp/morphe-patches/issues/309)) ([2c7a973](https://github.com/MorpheApp/morphe-patches/commit/2c7a973d73644d81da1dd4a82a3b10056863ac70))

# [1.9.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.3...v1.9.0-dev.4) (2026-01-27)


### Bug Fixes

* **YouTube:** Consolidate toolbar "Hide cast button" into existing hide cast button setting ([c22a2a1](https://github.com/MorpheApp/morphe-patches/commit/c22a2a1c7a74b6370bad7b47ce79cab9b49846ad))

# [1.9.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.2...v1.9.0-dev.3) (2026-01-27)


### Bug Fixes

* **YouTube:** Show a more descriptive error message if attempting to patch a region specific APKM that does not contain languages for all regions ([0f2700d](https://github.com/MorpheApp/morphe-patches/commit/0f2700db110a2e8d041e1213e0d95ed50f6d54ac))

# [1.9.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.9.0-dev.1...v1.9.0-dev.2) (2026-01-27)


### Features

* **YouTube - Navigation bar:** Add settings to hide toolbar buttons ([#298](https://github.com/MorpheApp/morphe-patches/issues/298)) ([73fd722](https://github.com/MorpheApp/morphe-patches/commit/73fd722c0d76148323ae60ddc64ae05c8d95b5d4))

# [1.9.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0...v1.9.0-dev.1) (2026-01-26)


### Features

* **YouTube:** Add `Restore old search filters` patch ([#285](https://github.com/MorpheApp/morphe-patches/issues/285)) ([c088723](https://github.com/MorpheApp/morphe-patches/commit/c0887234612bb24ad8184fe211af14cf0640d8ec))

# [1.8.0](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0...v1.8.0) (2026-01-25)


### Bug Fixes

* **Custom branding:** Resolve background playback crash with custom branded root installation ([3039650](https://github.com/MorpheApp/morphe-patches/commit/3039650460fdd2731b9ac1622127aa04a2b8a322))
* **Spoof video streams:** Disable client flag that breaks playback with experimental app targets ([8cace8b](https://github.com/MorpheApp/morphe-patches/commit/8cace8b442d32c07b2fcd4da3b596497608e626c))
* **YouTube - Hide ads:** `Hide video ads` does not hide Shorts ads ([#260](https://github.com/MorpheApp/morphe-patches/issues/260)) ([9078d92](https://github.com/MorpheApp/morphe-patches/commit/9078d92c444d1d6abe095a3a694a518e7fb078e9))
* **YouTube - Hide Shorts components:** Fix "Hide sound metadata label" hiding other components ([#277](https://github.com/MorpheApp/morphe-patches/issues/277)) ([b55ebe4](https://github.com/MorpheApp/morphe-patches/commit/b55ebe4f0fac71905ce8c02185a174c661627b70))
* **YouTube:** Replace themed like animation applied from wrong version due to server-side fault ([#261](https://github.com/MorpheApp/morphe-patches/issues/261)) ([556dbb6](https://github.com/MorpheApp/morphe-patches/commit/556dbb68839d5c73dea20e23079d91b20f02d109))


### Features

* **Enable debugging:** Allow overriding String/long/double flags in debug flag manager ([11b61b5](https://github.com/MorpheApp/morphe-patches/commit/11b61b5a509a4d659e69e9cfd9c3cdcad70dd9cb))
* **YouTube Music:** Support version `8.40.54` ([639819d](https://github.com/MorpheApp/morphe-patches/commit/639819de0bec5f06fee4ff11c33f149521117d2b))
* **YouTube:** Add experimental support for `21.04.221` ([ba2e581](https://github.com/MorpheApp/morphe-patches/commit/ba2e581bfbe1ebe9fb10fa49b33df43726c966f2))
* **YouTube:** Support version `20.40.45` ([9514870](https://github.com/MorpheApp/morphe-patches/commit/9514870fba460f21627ebfd6f849510c01321d91))

# [1.8.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.8...v1.8.0-dev.9) (2026-01-24)


### Bug Fixes

* **Custom branding:** Resolve background playback crash with custom branded root installation ([3039650](https://github.com/MorpheApp/morphe-patches/commit/3039650460fdd2731b9ac1622127aa04a2b8a322))

# [1.8.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.7...v1.8.0-dev.8) (2026-01-24)


### Bug Fixes

* **YouTube - Hide Shorts components:** Fix "Hide sound metadata label" hiding other components ([#277](https://github.com/MorpheApp/morphe-patches/issues/277)) ([b55ebe4](https://github.com/MorpheApp/morphe-patches/commit/b55ebe4f0fac71905ce8c02185a174c661627b70))

# [1.8.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.6...v1.8.0-dev.7) (2026-01-24)


### Bug Fixes

* **YouTube:** Replace themed like animation applied from wrong version due to server-side fault ([#261](https://github.com/MorpheApp/morphe-patches/issues/261)) ([556dbb6](https://github.com/MorpheApp/morphe-patches/commit/556dbb68839d5c73dea20e23079d91b20f02d109))

# [1.8.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.5...v1.8.0-dev.6) (2026-01-24)


### Bug Fixes

* **YouTube - Hide ads:** `Hide video ads` does not hide Shorts ads ([#260](https://github.com/MorpheApp/morphe-patches/issues/260)) ([9078d92](https://github.com/MorpheApp/morphe-patches/commit/9078d92c444d1d6abe095a3a694a518e7fb078e9))

# [1.8.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.4...v1.8.0-dev.5) (2026-01-24)


### Features

* Skip publishing to GitHub packages ([#275](https://github.com/MorpheApp/morphe-patches/issues/275)) ([71b7db4](https://github.com/MorpheApp/morphe-patches/commit/71b7db4d38ac44ce6d0b9de111599485e1de015a))

# [1.8.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.3...v1.8.0-dev.4) (2026-01-24)


### Features

* **Enable debugging:** Allow overriding String/long/double flags in debug flag manager ([11b61b5](https://github.com/MorpheApp/morphe-patches/commit/11b61b5a509a4d659e69e9cfd9c3cdcad70dd9cb))

# [1.8.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.2...v1.8.0-dev.3) (2026-01-23)


### Bug Fixes

* **Spoof video streams:** Disable client flag that breaks playback with experimental app targets ([8cace8b](https://github.com/MorpheApp/morphe-patches/commit/8cace8b442d32c07b2fcd4da3b596497608e626c))

# [1.8.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.8.0-dev.1...v1.8.0-dev.2) (2026-01-23)


### Features

* **YouTube:** Add experimental support for `21.04.221` ([ba2e581](https://github.com/MorpheApp/morphe-patches/commit/ba2e581bfbe1ebe9fb10fa49b33df43726c966f2))

# [1.8.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0...v1.8.0-dev.1) (2026-01-23)


### Features

* **YouTube Music:** Support version `8.40.54` ([639819d](https://github.com/MorpheApp/morphe-patches/commit/639819de0bec5f06fee4ff11c33f149521117d2b))
* **YouTube:** Support version `20.40.45` ([9514870](https://github.com/MorpheApp/morphe-patches/commit/9514870fba460f21627ebfd6f849510c01321d91))

# [1.7.0](https://github.com/MorpheApp/morphe-patches/compare/v1.6.0...v1.7.0) (2026-01-22)


### Features

* **Spoof video streams:** Default client maintenance ([#249](https://github.com/MorpheApp/morphe-patches/issues/249)) ([ea01bfc](https://github.com/MorpheApp/morphe-patches/commit/ea01bfca9afdf0592f0486795047ef5b0abcb5ff))
* **YouTube - SponsorBlock:** Show skip button if player overlay controls are active ([#243](https://github.com/MorpheApp/morphe-patches/issues/243)) ([9f90d0e](https://github.com/MorpheApp/morphe-patches/commit/9f90d0e386d8518ebd027a469ad72b52808048ab))
* **YouTube - Theme:** Add "Hide splash screen" setting ([#245](https://github.com/MorpheApp/morphe-patches/issues/245)) ([d8ae327](https://github.com/MorpheApp/morphe-patches/commit/d8ae327bc74b23237ef877f352828c6c7c97ea53))
* **YouTube Music:** Add experimental support for `9.03.52` ([80c0198](https://github.com/MorpheApp/morphe-patches/commit/80c019889f51a1cf44a1e4f73da008a6b513ed90))
* **YouTube:** Add experimental support for `21.03.34` ([#233](https://github.com/MorpheApp/morphe-patches/issues/233)) ([4b9d7a6](https://github.com/MorpheApp/morphe-patches/commit/4b9d7a6c8769e87e80727aa64dbc7d761513a259))

# [1.7.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.6...v1.7.0-dev.7) (2026-01-22)


### Bug Fixes

* **YouTube - SponsorBlock:** Do not show context toast when auto skipping videos in the feed ([17d8bd0](https://github.com/MorpheApp/morphe-patches/commit/17d8bd0b90d11193c7a9f3411f119ddf1aa058bd))

# [1.7.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.5...v1.7.0-dev.6) (2026-01-22)


### Features

* **Spoof video streams:** Default client maintenance ([#249](https://github.com/MorpheApp/morphe-patches/issues/249)) ([ea01bfc](https://github.com/MorpheApp/morphe-patches/commit/ea01bfca9afdf0592f0486795047ef5b0abcb5ff))

# [1.7.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.4...v1.7.0-dev.5) (2026-01-21)


### Bug Fixes

* **YouTube - SponsorBlock:** Show correct nested skip segment in overlay controls when seeking to an earlier video time ([1e13236](https://github.com/MorpheApp/morphe-patches/commit/1e1323670c1265466532919424c52016cd661492))

# [1.7.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.3...v1.7.0-dev.4) (2026-01-21)


### Features

* **YouTube Music:** Add experimental support for `9.03.52` ([80c0198](https://github.com/MorpheApp/morphe-patches/commit/80c019889f51a1cf44a1e4f73da008a6b513ed90))

# [1.7.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.2...v1.7.0-dev.3) (2026-01-20)


### Features

* **YouTube - Theme:** Add "Hide splash screen" setting ([#245](https://github.com/MorpheApp/morphe-patches/issues/245)) ([d8ae327](https://github.com/MorpheApp/morphe-patches/commit/d8ae327bc74b23237ef877f352828c6c7c97ea53))

# [1.7.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.7.0-dev.1...v1.7.0-dev.2) (2026-01-19)


### Features

* **YouTube - SponsorBlock:** Show skip button if player overlay controls are active ([#243](https://github.com/MorpheApp/morphe-patches/issues/243)) ([9f90d0e](https://github.com/MorpheApp/morphe-patches/commit/9f90d0e386d8518ebd027a469ad72b52808048ab))

# [1.7.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.6.0...v1.7.0-dev.1) (2026-01-18)


### Features

* **YouTube:** Add experimental support for `21.03.34` ([#233](https://github.com/MorpheApp/morphe-patches/issues/233)) ([4b9d7a6](https://github.com/MorpheApp/morphe-patches/commit/4b9d7a6c8769e87e80727aa64dbc7d761513a259))

# [1.6.0](https://github.com/MorpheApp/morphe-patches/compare/v1.5.0...v1.6.0) (2026-01-17)


### Bug Fixes

* **YouTube - Hide Shorts components:** Hide new type of sound metadata label ([35931e6](https://github.com/MorpheApp/morphe-patches/commit/35931e6ddf287790c6a405b58e7b7d46c718bb0a))


### Features

* **YouTube - Hide layout components:** Add "Hide subscribed channels bar" setting ([#226](https://github.com/MorpheApp/morphe-patches/issues/226)) ([bbaad3a](https://github.com/MorpheApp/morphe-patches/commit/bbaad3af85b43a7addc0e984a5a13e12986f6263))
* **YouTube Music:** Add experimental support for `9.02.50` ([977cb8b](https://github.com/MorpheApp/morphe-patches/commit/977cb8bfcdfb193b035b62ae2660d20eccdc6702))
* **YouTube:** Add `Hide autoplay preview` patch ([#218](https://github.com/MorpheApp/morphe-patches/issues/218)) ([4d105bd](https://github.com/MorpheApp/morphe-patches/commit/4d105bd3d1a54ad0c59520156b0d88c68ea007ae))

# [1.6.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.6.0-dev.3...v1.6.0-dev.4) (2026-01-16)


### Features

* **YouTube - Hide layout components:** Add "Hide subscribed channels bar" setting ([#226](https://github.com/MorpheApp/morphe-patches/issues/226)) ([bbaad3a](https://github.com/MorpheApp/morphe-patches/commit/bbaad3af85b43a7addc0e984a5a13e12986f6263))

# [1.6.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.6.0-dev.2...v1.6.0-dev.3) (2026-01-16)


### Features

* **YouTube:** Add `Hide autoplay preview` patch ([#218](https://github.com/MorpheApp/morphe-patches/issues/218)) ([4d105bd](https://github.com/MorpheApp/morphe-patches/commit/4d105bd3d1a54ad0c59520156b0d88c68ea007ae)), closes [/github.com/inotia00/revanced-patches/blob/revanced-extended/patches/src/main/kotlin/app/revanced/patches/youtube/player/fullscreen/FullscreenComponentsPatch.kt#L155-L170](https://github.com//github.com/inotia00/revanced-patches/blob/revanced-extended/patches/src/main/kotlin/app/revanced/patches/youtube/player/fullscreen/FullscreenComponentsPatch.kt/issues/L155-L170)

# [1.6.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.6.0-dev.1...v1.6.0-dev.2) (2026-01-16)


### Bug Fixes

* **YouTube - Hide Shorts components:** Hide new type of sound metadata label ([35931e6](https://github.com/MorpheApp/morphe-patches/commit/35931e6ddf287790c6a405b58e7b7d46c718bb0a))

# [1.6.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.5.0...v1.6.0-dev.1) (2026-01-16)


### Features

* **YouTube Music:** Add experimental support for `9.02.50` ([977cb8b](https://github.com/MorpheApp/morphe-patches/commit/977cb8bfcdfb193b035b62ae2660d20eccdc6702))

# [1.5.0](https://github.com/MorpheApp/morphe-patches/compare/v1.4.0...v1.5.0) (2026-01-15)


### Features

* **YouTube - Navigation buttons:** Add setting to use narrow navigation bar buttons ([1074c6a](https://github.com/MorpheApp/morphe-patches/commit/1074c6a6f70199ef8173524246be23bddcbb46d2))
* **YouTube:** Add "Hide search box trending results" setting ([#40](https://github.com/MorpheApp/morphe-patches/issues/40)) ([dc1a898](https://github.com/MorpheApp/morphe-patches/commit/dc1a898924f1cf4eaa94a29e967d7e966ae7a243))

# [1.5.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.5.0-dev.1...v1.5.0-dev.2) (2026-01-13)


### Features

* **YouTube:** Add "Hide search box trending results" setting ([#40](https://github.com/MorpheApp/morphe-patches/issues/40)) ([dc1a898](https://github.com/MorpheApp/morphe-patches/commit/dc1a898924f1cf4eaa94a29e967d7e966ae7a243))

# [1.5.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.4.0...v1.5.0-dev.1) (2026-01-12)


### Features

* **YouTube - Navigation buttons:** Add setting to use narrow navigation bar buttons ([1074c6a](https://github.com/MorpheApp/morphe-patches/commit/1074c6a6f70199ef8173524246be23bddcbb46d2))

# [1.4.0](https://github.com/MorpheApp/morphe-patches/compare/v1.3.2...v1.4.0) (2026-01-12)


### Bug Fixes

* **YouTube - Hide ads:** Hide new type of player ad ([#187](https://github.com/MorpheApp/morphe-patches/issues/187)) ([4702043](https://github.com/MorpheApp/morphe-patches/commit/4702043ea35fb3b1439ad30406b41179d019f2a1))


### Features

* **YouTube:** Add `Double tap to seek` patch ([1a57a34](https://github.com/MorpheApp/morphe-patches/commit/1a57a34734d31b803820b0a530e0c57c50963f63))

# [1.4.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.4.0-dev.2...v1.4.0-dev.3) (2026-01-12)


### Bug Fixes

* Remove restrictions on AGP due to the use of hardcoded registers in LithoFilterPatch ([#41](https://github.com/MorpheApp/morphe-patches/issues/41)) ([223ed8f](https://github.com/MorpheApp/morphe-patches/commit/223ed8f78561d8cb046d371baed9646b4e8138f3))

# [1.4.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.4.0-dev.1...v1.4.0-dev.2) (2026-01-11)


### Bug Fixes

* **YouTube - Hide ads:** Hide new type of player ad ([#187](https://github.com/MorpheApp/morphe-patches/issues/187)) ([4702043](https://github.com/MorpheApp/morphe-patches/commit/4702043ea35fb3b1439ad30406b41179d019f2a1))

# [1.4.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.3.2...v1.4.0-dev.1) (2026-01-11)


### Features

* **YouTube:** Add `Double tap to seek` patch ([1a57a34](https://github.com/MorpheApp/morphe-patches/commit/1a57a34734d31b803820b0a530e0c57c50963f63))

## [1.3.2](https://github.com/MorpheApp/morphe-patches/compare/v1.3.1...v1.3.2) (2026-01-10)


### Bug Fixes

* **Custom branding:** Resolve startup crash if custom branding is excluded in expert mode ([3f2d733](https://github.com/MorpheApp/morphe-patches/commit/3f2d7338f587ef8a4ff8331621d6e68dd160d746))

## [1.3.2-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.3.1...v1.3.2-dev.1) (2026-01-10)


### Bug Fixes

* **Custom branding:** Resolve startup crash if custom branding is excluded in expert mode ([3f2d733](https://github.com/MorpheApp/morphe-patches/commit/3f2d7338f587ef8a4ff8331621d6e68dd160d746))

## [1.3.1](https://github.com/MorpheApp/morphe-patches/compare/v1.3.0...v1.3.1) (2026-01-10)


### Bug Fixes

* **Custom branding:** Default to user‑provided icon and name when provided ([eef8798](https://github.com/MorpheApp/morphe-patches/commit/eef8798602ebf805eb3cff08e010025a0a8e93ab))
* **YouTube - Auto captions:** Cannot disable auto captions with 20.21 app target ([#145](https://github.com/MorpheApp/morphe-patches/issues/145)) ([dc43944](https://github.com/MorpheApp/morphe-patches/commit/dc43944adbcef5aa4754ca3d1fecd07a502277f3))
* **YouTube - Hide end screen cards:** Resolve patching `20.31.42` ([3033432](https://github.com/MorpheApp/morphe-patches/commit/3033432644fc986930f4eec51d4fc233f6389c23))
* **YouTube - Hide layout components:** Fix "Hide ticket shelf" not working when "Hide horizontal shelves" is off ([#124](https://github.com/MorpheApp/morphe-patches/issues/124)) ([84eeb0d](https://github.com/MorpheApp/morphe-patches/commit/84eeb0d9f949657a7d468d9babfaca37d03b0d78))

## [1.3.1-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.3.1-dev.3...v1.3.1-dev.4) (2026-01-09)


### Bug Fixes

* **YouTube - Hide layout components:** Fix "Hide ticket shelf" not working when "Hide horizontal shelves" is off ([#124](https://github.com/MorpheApp/morphe-patches/issues/124)) ([84eeb0d](https://github.com/MorpheApp/morphe-patches/commit/84eeb0d9f949657a7d468d9babfaca37d03b0d78))

## [1.3.1-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.3.1-dev.2...v1.3.1-dev.3) (2026-01-09)


### Bug Fixes

* **YouTube - Auto captions:** Cannot disable auto captions with 20.21 app target ([#145](https://github.com/MorpheApp/morphe-patches/issues/145)) ([dc43944](https://github.com/MorpheApp/morphe-patches/commit/dc43944adbcef5aa4754ca3d1fecd07a502277f3))

## [1.3.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.3.1-dev.1...v1.3.1-dev.2) (2026-01-09)


### Bug Fixes

* **YouTube - Hide end screen cards:** Resolve patching `20.31.42` ([3033432](https://github.com/MorpheApp/morphe-patches/commit/3033432644fc986930f4eec51d4fc233f6389c23))

## [1.3.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.3.0...v1.3.1-dev.1) (2026-01-09)


### Bug Fixes

* **Custom branding:** Default to user‑provided icon and name when provided ([eef8798](https://github.com/MorpheApp/morphe-patches/commit/eef8798602ebf805eb3cff08e010025a0a8e93ab))

# [1.3.0](https://github.com/MorpheApp/morphe-patches/compare/v1.2.0...v1.3.0) (2026-01-09)


### Bug Fixes

* **Spoof video streams:** Change default client to VR 1.47.48 ([#116](https://github.com/MorpheApp/morphe-patches/issues/116)) ([2bc5775](https://github.com/MorpheApp/morphe-patches/commit/2bc577554f54fd2ecfcd682b83844511461effe4))
* **YouTube - Hide layout components:** Fix certain description components not working ([#143](https://github.com/MorpheApp/morphe-patches/issues/143)) ([4efcb4d](https://github.com/MorpheApp/morphe-patches/commit/4efcb4d2c0f2085b6dbd0d203ef2979a041d512a))
* **YouTube - Remove background playback restrictions:** Fix background playback not working with certain offline videos ([bb38f76](https://github.com/MorpheApp/morphe-patches/commit/bb38f763f271d14b80166d517a3e840578d1f5b9))
* **YouTube:** Change "Hide mix playlist" to default off ([00f1240](https://github.com/MorpheApp/morphe-patches/commit/00f124004efd758092a5a8330aaea92f08064172))


### Features

* **YouTube:** Add experimental support for `21.02.32` ([#138](https://github.com/MorpheApp/morphe-patches/issues/138)) ([660699d](https://github.com/MorpheApp/morphe-patches/commit/660699da7ee6b623d5010b42fe575e63947b450a))

# [1.3.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.3.0-dev.1...v1.3.0-dev.2) (2026-01-09)


### Bug Fixes

* **YouTube - Hide layout components:** Fix certain description components not working ([#143](https://github.com/MorpheApp/morphe-patches/issues/143)) ([4efcb4d](https://github.com/MorpheApp/morphe-patches/commit/4efcb4d2c0f2085b6dbd0d203ef2979a041d512a))

# [1.3.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.2.1-dev.2...v1.3.0-dev.1) (2026-01-09)


### Features

* **YouTube:** Add experimental support for `21.02.32` ([#138](https://github.com/MorpheApp/morphe-patches/issues/138)) ([660699d](https://github.com/MorpheApp/morphe-patches/commit/660699da7ee6b623d5010b42fe575e63947b450a))

## [1.2.1-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.2.1-dev.1...v1.2.1-dev.2) (2026-01-07)


### Bug Fixes

* **YouTube:** Change "Hide mix playlist" to default off ([00f1240](https://github.com/MorpheApp/morphe-patches/commit/00f124004efd758092a5a8330aaea92f08064172))

## [1.2.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.2.0...v1.2.1-dev.1) (2026-01-07)


### Bug Fixes

* **Spoof video streams:** Change default client to VR 1.47.48 ([#116](https://github.com/MorpheApp/morphe-patches/issues/116)) ([2bc5775](https://github.com/MorpheApp/morphe-patches/commit/2bc577554f54fd2ecfcd682b83844511461effe4))
* **YouTube - Remove background playback restrictions:** Fix background playback not working with certain offline videos ([bb38f76](https://github.com/MorpheApp/morphe-patches/commit/bb38f763f271d14b80166d517a3e840578d1f5b9))

# [1.2.0](https://github.com/MorpheApp/morphe-patches/compare/v1.1.0...v1.2.0) (2026-01-07)


### Bug Fixes

* **YouTube - Hide ads:** Hide new type of general ad, movie ad and web search result ([#92](https://github.com/MorpheApp/morphe-patches/issues/92)) ([ed5c287](https://github.com/MorpheApp/morphe-patches/commit/ed5c2875be27a178368203251e7c07caa18556cf))
* **YouTube - Hide layout components:** Do not change system nav bar transparency when disabling status bar transparency ([2b1330c](https://github.com/MorpheApp/morphe-patches/commit/2b1330c364cbed8ae243554616d88205fcf96376))


### Features

* **YouTube - Auto-captions:** Add an option to disable auto-captions when the device volume is muted ([#37](https://github.com/MorpheApp/morphe-patches/issues/37)) ([369f91e](https://github.com/MorpheApp/morphe-patches/commit/369f91e509d5b273624be5c75466757d9ed20a2a))

# [1.2.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.2.0-dev.3...v1.2.0-dev.4) (2026-01-07)


### Bug Fixes

* Changing default enum setting type setting does not always always clear preference data ([302fa77](https://github.com/MorpheApp/morphe-patches/commit/302fa773b97d032e6d0a1ff0f1de26b8ef348f13))

# [1.2.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.2.0-dev.2...v1.2.0-dev.3) (2026-01-06)


### Bug Fixes

* **YouTube - Hide ads:** Hide new type of general ad, movie ad and web search result ([#92](https://github.com/MorpheApp/morphe-patches/issues/92)) ([ed5c287](https://github.com/MorpheApp/morphe-patches/commit/ed5c2875be27a178368203251e7c07caa18556cf))

# [1.2.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.2.0-dev.1...v1.2.0-dev.2) (2026-01-06)


### Bug Fixes

* **YouTube - Hide layout components:** Do not change system nav bar transparency when disabling status bar transparency ([2b1330c](https://github.com/MorpheApp/morphe-patches/commit/2b1330c364cbed8ae243554616d88205fcf96376))

# [1.2.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.1.0...v1.2.0-dev.1) (2026-01-06)


### Features

* **YouTube - Auto-captions:** Add an option to disable auto-captions when the device volume is muted ([#37](https://github.com/MorpheApp/morphe-patches/issues/37)) ([369f91e](https://github.com/MorpheApp/morphe-patches/commit/369f91e509d5b273624be5c75466757d9ed20a2a))

# [1.1.0](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0...v1.1.0) (2026-01-05)


### Bug Fixes

* **YouTube - Settings:** Icon doesn't change immediately with the theme ([#85](https://github.com/MorpheApp/morphe-patches/issues/85)) ([88e0fb8](https://github.com/MorpheApp/morphe-patches/commit/88e0fb8247b89122c197b99c65e99a6e53f7093c))
* **YouTube - Spoof app version:** Change oldest spoof target to `19.35.36` ([#86](https://github.com/MorpheApp/morphe-patches/issues/86)) ([53ae587](https://github.com/MorpheApp/morphe-patches/commit/53ae587629e129c80be628b87779bfefadf0c2fb))
* **YouTube:** Do not show bold icons if old settings menus is enabled ([bee9bb3](https://github.com/MorpheApp/morphe-patches/commit/bee9bb37b39f39a3db7dfe9c59147457b7cdefd0))


### Features

* **YouTube - Hide layout components:** Add "Hide Featured links", "Hide Featured videos", "Hide Join button", and "Hide Subscribe button" options ([#72](https://github.com/MorpheApp/morphe-patches/issues/72)) ([727c2d9](https://github.com/MorpheApp/morphe-patches/commit/727c2d9d9d6af82d0c565472a6e120a7ec43e94a))
* **YouTube - Hide Shorts components:** Add "Hide 'Auto-dubbed' label" and "Hide live preview" options ([#70](https://github.com/MorpheApp/morphe-patches/issues/70)) ([5239e43](https://github.com/MorpheApp/morphe-patches/commit/5239e434ef44433b5efacbbaa122c8c036e1f57d))

# [1.1.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.1.0-dev.2...v1.1.0-dev.3) (2026-01-05)


### Bug Fixes

* **YouTube - Spoof app version:** Change oldest spoof target to `19.35.36` ([#86](https://github.com/MorpheApp/morphe-patches/issues/86)) ([53ae587](https://github.com/MorpheApp/morphe-patches/commit/53ae587629e129c80be628b87779bfefadf0c2fb))

# [1.1.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.1.0-dev.1...v1.1.0-dev.2) (2026-01-04)


### Bug Fixes

* **YouTube:** Do not show bold icons if old settings menus is enabled ([bee9bb3](https://github.com/MorpheApp/morphe-patches/commit/bee9bb37b39f39a3db7dfe9c59147457b7cdefd0))

# [1.1.0-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.0.1-dev.1...v1.1.0-dev.1) (2026-01-04)


### Features

* **YouTube - Hide layout components:** Add "Hide Featured links", "Hide Featured videos", "Hide Join button", and "Hide Subscribe button" options ([#72](https://github.com/MorpheApp/morphe-patches/issues/72)) ([727c2d9](https://github.com/MorpheApp/morphe-patches/commit/727c2d9d9d6af82d0c565472a6e120a7ec43e94a))
* **YouTube - Hide Shorts components:** Add "Hide 'Auto-dubbed' label" and "Hide live preview" options ([#70](https://github.com/MorpheApp/morphe-patches/issues/70)) ([5239e43](https://github.com/MorpheApp/morphe-patches/commit/5239e434ef44433b5efacbbaa122c8c036e1f57d))

## [1.0.1-dev.1](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0...v1.0.1-dev.1) (2026-01-04)


### Bug Fixes

* **YouTube - Settings:** Icon doesn't change immediately with the theme ([#85](https://github.com/MorpheApp/morphe-patches/issues/85)) ([88e0fb8](https://github.com/MorpheApp/morphe-patches/commit/88e0fb8247b89122c197b99c65e99a6e53f7093c))

# 1.0.0 (2026-01-01)


### Bug Fixes

* **AddResources:** Change resource system to per app, remove per patch resource system that is problematic with Crowdin ([#12](https://github.com/MorpheApp/morphe-patches/issues/12)) ([3d8b223](https://github.com/MorpheApp/morphe-patches/commit/3d8b223e390004ace9c02e138e708477e3d220ae))
* **GmsCore support:** Change recommended MicroG to MicroG-RE ([87fe57d](https://github.com/MorpheApp/morphe-patches/commit/87fe57dae2eac232741abf7c7530cc228cf95955))
* **Spoof video streams:** Restore missing file during commit conflict resolution ([69823a5](https://github.com/MorpheApp/morphe-patches/commit/69823a5d8788fd3391d32260341895fcc28f1051))
* **YouTube - Exit fullscreen mode:** Handle exiting fullscreen on the first video opened ([2d12182](https://github.com/MorpheApp/morphe-patches/commit/2d121828132dbbc5992084bed8527117c129973b))
* **YouTube - Hide ads:** Hide new type of ad ([066a3ff](https://github.com/MorpheApp/morphe-patches/commit/066a3ff6c53656d60ef5eb32c48042f6ed970c41))
* **YouTube - Hide ads:** Support `Hide fullscreen ads` on Android 13+ devices ([#17](https://github.com/MorpheApp/morphe-patches/issues/17)) ([e016b8b](https://github.com/MorpheApp/morphe-patches/commit/e016b8be4a631d6ccf123464f7fb5bd2062b7b99))
* **YouTube - Hide ads:** YouTube Doodles are unclickable when Hide ads is turned on ([1ba6238](https://github.com/MorpheApp/morphe-patches/commit/1ba623899ad6f89e4d4c44114dcea090118887d3))
* **YouTube - Hide layout components:** Fix side effect of Disable translucent status bar ([48bf054](https://github.com/MorpheApp/morphe-patches/commit/48bf0542c1417fc374bd88fee12b7af1b78eabe5))
* **YouTube - Hide Shorts components:** Action buttons are not hidden in YouTube 20.22+ ([#4](https://github.com/MorpheApp/morphe-patches/issues/4)) ([171351a](https://github.com/MorpheApp/morphe-patches/commit/171351a3989cbc8a17990789fd34b1d7b35ffad8))
* **YouTube - Hide video action buttons:** Update hide like and subscribe button glow for 20.22+ ([0fec09c](https://github.com/MorpheApp/morphe-patches/commit/0fec09c816cc2584e279d5290d082d391136bc0b))
* **YouTube - Loop video:** `Enable loop video` setting not working in playlist ([#14](https://github.com/MorpheApp/morphe-patches/issues/14)) ([77df0a3](https://github.com/MorpheApp/morphe-patches/commit/77df0a33f3ad29cdfeb859a4b89068efe9d6a860))
* **YouTube - Loop video:** Fix looping button state ([#22](https://github.com/MorpheApp/morphe-patches/issues/22)) ([d02c00e](https://github.com/MorpheApp/morphe-patches/commit/d02c00e325d967c48a9153269d52b9e94ae68f24))
* **YouTube - Open Shorts in regular player:** Fix back to exit with 20.51 ([6203858](https://github.com/MorpheApp/morphe-patches/commit/62038585df427364e7aeb4aa37f5c1b1e0639478))
* **YouTube - Open Shorts in regular player:** Resolve back button sometimes closing the app instead of exiting fullscreen mode ([d22f9b6](https://github.com/MorpheApp/morphe-patches/commit/d22f9b6ae16b4bfa0f9133fd3f902372533a6e9e))
* **YouTube - Remove viewer discretion dialog:** Not working on YouTube 20.14.43+ ([#19](https://github.com/MorpheApp/morphe-patches/issues/19)) ([d951f2e](https://github.com/MorpheApp/morphe-patches/commit/d951f2ef952f6e7858699c9e981e6a375a88ef55))
* **YouTube - Return YouTube Dislike:** Sometimes incorrect dislike counts shown in Shorts ([6401688](https://github.com/MorpheApp/morphe-patches/commit/640168818c9ada91ed7c429de7b75f08f0b79f9c))
* **YouTube - Return YouTube Dislike:** Sometimes incorrect dislike counts shown when the dislike button is clicked and then canceled ([b598b22](https://github.com/MorpheApp/morphe-patches/commit/b598b22b8c0ca5c5c37f18bf0f02ff7a97463a20))
* **YouTube - ReturnYouTubeDislike:** Fix dislikes not showing with 20.31+ ([f238b81](https://github.com/MorpheApp/morphe-patches/commit/f238b8112f0a46dc24118cf2e8b9138cfdb932c3))
* **YouTube - Spoof video streams:** Age-restricted videos do not play in the `Android No SDK` client ([#3](https://github.com/MorpheApp/morphe-patches/issues/3)) ([c8096b1](https://github.com/MorpheApp/morphe-patches/commit/c8096b14685c8822e36a9acbe7f7729d95f754e8))
* **YouTube Music - Hide buttons:** An exception is thrown due to an invalid fingerprint format ([81042aa](https://github.com/MorpheApp/morphe-patches/commit/81042aa5a7fb8afd1da8dc2a7e854ac0a5b0958c))
* **YouTube Music - Navigation bar:** Hide library tab with 8.24+ ([789dd2a](https://github.com/MorpheApp/morphe-patches/commit/789dd2a59fb2b3ace4a3d57b270d4f4ff13a38b2))
* **YouTube Music:** Change recommended version to `8.37.56` ([ab6033c](https://github.com/MorpheApp/morphe-patches/commit/ab6033c294215e4d9c50db7fe95546c2f9524da4))
* **YouTube:** Changes the default values for some settings ([#10](https://github.com/MorpheApp/morphe-patches/issues/10)) ([fc0f0b8](https://github.com/MorpheApp/morphe-patches/commit/fc0f0b82427acabe225567ce570aa08490b9f15a))
* **YouTube:** Move loop video setting to player menu ([cd82e1e](https://github.com/MorpheApp/morphe-patches/commit/cd82e1e807533e7f39bc40b1d9171929166ff9bb))
* **YouTube:** Remove `19.43.41` that YouTube no longer supports ([ae1a03b](https://github.com/MorpheApp/morphe-patches/commit/ae1a03b7e40cb033575e6f1d2e5c49f54e44c5f3))
* **YT Music:** Support `8.49.52` ([052629c](https://github.com/MorpheApp/morphe-patches/commit/052629ce202ae978a311c35751ab3f771a2fed9c))


### Features

* Add dark icon ([#16](https://github.com/MorpheApp/morphe-patches/issues/16)) ([980e4ac](https://github.com/MorpheApp/morphe-patches/commit/980e4ac8804948c5a577097dc33c498e0ca89de5))
* Add less restrictive license for build related code ([43cbf13](https://github.com/MorpheApp/morphe-patches/commit/43cbf133a1f3bdb550d6af1332a5122b9ccfc25e))
* Add new About dialog style ([#21](https://github.com/MorpheApp/morphe-patches/issues/21)) ([69ee718](https://github.com/MorpheApp/morphe-patches/commit/69ee718af2462f9fffd0289d38dec1b94fa9a9db))
* Add overlay buttons animation ([#20](https://github.com/MorpheApp/morphe-patches/issues/20)) ([a105d4c](https://github.com/MorpheApp/morphe-patches/commit/a105d4c35c9ca198eb8040bce548712f644a6349))
* Generate new release ([ad7d1c3](https://github.com/MorpheApp/morphe-patches/commit/ad7d1c3a1c5f8d75859e0a8f3f92b5c8d708e794))
* Perform full search of free registers ([7a04ba3](https://github.com/MorpheApp/morphe-patches/commit/7a04ba3ba7ac11dea565bdf6e1daa53a707e4ecf))
* **Spoof video streams:** Add an option to sign-in to Android VR ([#23](https://github.com/MorpheApp/morphe-patches/issues/23)) ([a780f67](https://github.com/MorpheApp/morphe-patches/commit/a780f67a5a068a3274b4a4969a46daecbbdc0a60))
* **Spoof video streams:** Default client maintenance ([#11](https://github.com/MorpheApp/morphe-patches/issues/11)) ([339f897](https://github.com/MorpheApp/morphe-patches/commit/339f897e422cfaa5d34b8ffcf0334b96ce50d5e7))
* **YouTube - LithoFilterPatch:** Add support for accessibility filtering ([#1](https://github.com/MorpheApp/morphe-patches/issues/1)) ([61fb9c2](https://github.com/MorpheApp/morphe-patches/commit/61fb9c2498ad261ae526b347fb89d4faf1723704))
* **YouTube Music:** Unofficial support of `8.50.51` ([a392f3f](https://github.com/MorpheApp/morphe-patches/commit/a392f3f69148e1d20c61f61b11e0d167fd920e61))

# [1.0.0-dev.34](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.33...v1.0.0-dev.34) (2026-01-01)


### Features

* Add less restrictive license for build related code ([43cbf13](https://github.com/MorpheApp/morphe-patches/commit/43cbf133a1f3bdb550d6af1332a5122b9ccfc25e))

# [1.0.0-dev.33](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.32...v1.0.0-dev.33) (2026-01-01)


### Bug Fixes

* Remove PAT from GitHub actions ([92b1089](https://github.com/MorpheApp/morphe-patches/commit/92b108961c947698b21b63ca5a182d28ea094edb))

# [1.0.0-dev.32](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.31...v1.0.0-dev.32) (2026-01-01)


### Bug Fixes

* **GmsCore support:** Remove vendor id patch option ([8fa44d2](https://github.com/MorpheApp/morphe-patches/commit/8fa44d21662d74c2103c29672f01e73863ec0c5f))

# [1.0.0-dev.31](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.30...v1.0.0-dev.31) (2025-12-31)


### Features

* **Spoof video streams:** Add an option to sign-in to Android VR ([#23](https://github.com/MorpheApp/morphe-patches/issues/23)) ([a780f67](https://github.com/MorpheApp/morphe-patches/commit/a780f67a5a068a3274b4a4969a46daecbbdc0a60))

# [1.0.0-dev.30](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.29...v1.0.0-dev.30) (2025-12-29)


### Bug Fixes

* **YouTube - Loop video:** Fix looping button state ([#22](https://github.com/MorpheApp/morphe-patches/issues/22)) ([d02c00e](https://github.com/MorpheApp/morphe-patches/commit/d02c00e325d967c48a9153269d52b9e94ae68f24))

# [1.0.0-dev.29](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.28...v1.0.0-dev.29) (2025-12-28)


### Bug Fixes

* Use more informative patch error if the same APK is patched twice ([9112491](https://github.com/MorpheApp/morphe-patches/commit/9112491a61f5a5a2c16ce56f5bdb838a367df7d7))

# [1.0.0-dev.28](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.27...v1.0.0-dev.28) (2025-12-26)


### Bug Fixes

* **YouTube - Hide ads:** Support `Hide fullscreen ads` on Android 13+ devices ([#17](https://github.com/MorpheApp/morphe-patches/issues/17)) ([e016b8b](https://github.com/MorpheApp/morphe-patches/commit/e016b8be4a631d6ccf123464f7fb5bd2062b7b99))
* **YouTube - Remove viewer discretion dialog:** Not working on YouTube 20.14.43+ ([#19](https://github.com/MorpheApp/morphe-patches/issues/19)) ([d951f2e](https://github.com/MorpheApp/morphe-patches/commit/d951f2ef952f6e7858699c9e981e6a375a88ef55))

# [1.0.0-dev.27](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.26...v1.0.0-dev.27) (2025-12-26)


### Bug Fixes

* **YouTube - Hide layout components:** Fix side effect of Disable translucent status bar ([48bf054](https://github.com/MorpheApp/morphe-patches/commit/48bf0542c1417fc374bd88fee12b7af1b78eabe5))


### Features

* Add new About dialog style ([#21](https://github.com/MorpheApp/morphe-patches/issues/21)) ([69ee718](https://github.com/MorpheApp/morphe-patches/commit/69ee718af2462f9fffd0289d38dec1b94fa9a9db))

# [1.0.0-dev.26](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.25...v1.0.0-dev.26) (2025-12-26)


### Bug Fixes

* **YouTube - Exit fullscreen mode:** Handle exiting fullscreen on the first video opened ([2d12182](https://github.com/MorpheApp/morphe-patches/commit/2d121828132dbbc5992084bed8527117c129973b))

# [1.0.0-dev.25](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.24...v1.0.0-dev.25) (2025-12-25)


### Bug Fixes

* **YouTube Music:** Change recommended version to `8.37.56` ([ab6033c](https://github.com/MorpheApp/morphe-patches/commit/ab6033c294215e4d9c50db7fe95546c2f9524da4))

# [1.0.0-dev.24](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.23...v1.0.0-dev.24) (2025-12-25)


### Bug Fixes

* Create pre-release build for testing ([931017d](https://github.com/MorpheApp/morphe-patches/commit/931017d3a97a9f40b2f1acf4fc0b636c85faf210))

# [1.0.0-dev.23](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.22...v1.0.0-dev.23) (2025-12-25)


### Bug Fixes

* Change recommended version to 20.37.48 ([5361d03](https://github.com/MorpheApp/morphe-patches/commit/5361d03c5aec922429b6cffc6b5b60690c9b608e))

# [1.0.0-dev.22](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.21...v1.0.0-dev.22) (2025-12-24)


### Features

* **YouTube Music:** Unofficial support of `8.50.51` ([a392f3f](https://github.com/MorpheApp/morphe-patches/commit/a392f3f69148e1d20c61f61b11e0d167fd920e61))

# [1.0.0-dev.21](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.20...v1.0.0-dev.21) (2025-12-24)


### Features

* Add overlay buttons animation ([#20](https://github.com/MorpheApp/morphe-patches/issues/20)) ([a105d4c](https://github.com/MorpheApp/morphe-patches/commit/a105d4c35c9ca198eb8040bce548712f644a6349))

# [1.0.0-dev.20](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.19...v1.0.0-dev.20) (2025-12-24)


### Bug Fixes

* **YouTube Music - Navigation bar:** Hide library tab with 8.24+ ([789dd2a](https://github.com/MorpheApp/morphe-patches/commit/789dd2a59fb2b3ace4a3d57b270d4f4ff13a38b2))

# [1.0.0-dev.19](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.18...v1.0.0-dev.19) (2025-12-24)


### Bug Fixes

* Resolve ssl connection timeout in ci (test) ([031ffba](https://github.com/MorpheApp/morphe-patches/commit/031ffba84ed17cd742356fb3321198c73c99ab29))

# [1.0.0-dev.18](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.17...v1.0.0-dev.18) (2025-12-23)


### Bug Fixes

* **GmsCore support:** Change recommended MicroG to MicroG-RE ([87fe57d](https://github.com/MorpheApp/morphe-patches/commit/87fe57dae2eac232741abf7c7530cc228cf95955))

# [1.0.0-dev.17](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.16...v1.0.0-dev.17) (2025-12-21)


### Bug Fixes

* **YouTube - Open Shorts in regular player:** Fix back to exit with 20.51 ([6203858](https://github.com/MorpheApp/morphe-patches/commit/62038585df427364e7aeb4aa37f5c1b1e0639478))

# [1.0.0-dev.16](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.15...v1.0.0-dev.16) (2025-12-20)


### Features

* Add dark icon ([#16](https://github.com/MorpheApp/morphe-patches/issues/16)) ([980e4ac](https://github.com/MorpheApp/morphe-patches/commit/980e4ac8804948c5a577097dc33c498e0ca89de5))

# [1.0.0-dev.15](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.14...v1.0.0-dev.15) (2025-12-18)


### Features

* Perform full search of free registers ([7a04ba3](https://github.com/MorpheApp/morphe-patches/commit/7a04ba3ba7ac11dea565bdf6e1daa53a707e4ecf))

# [1.0.0-dev.14](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.13...v1.0.0-dev.14) (2025-12-17)


### Bug Fixes

* **YouTube - Loop video:** `Enable loop video` setting not working in playlist ([#14](https://github.com/MorpheApp/morphe-patches/issues/14)) ([77df0a3](https://github.com/MorpheApp/morphe-patches/commit/77df0a33f3ad29cdfeb859a4b89068efe9d6a860))
* **YouTube - Loop video:** Wrong icon applied ([#13](https://github.com/MorpheApp/morphe-patches/issues/13)) ([92f1325](https://github.com/MorpheApp/morphe-patches/commit/92f13251c0005b44c7859c11f442ddb3a9f5375a))
* **YouTube - Open Shorts in regular player:** Resolve back button sometimes closing the app instead of exiting fullscreen mode ([d22f9b6](https://github.com/MorpheApp/morphe-patches/commit/d22f9b6ae16b4bfa0f9133fd3f902372533a6e9e))
* **YouTube:** Changes the default values for some settings ([#10](https://github.com/MorpheApp/morphe-patches/issues/10)) ([fc0f0b8](https://github.com/MorpheApp/morphe-patches/commit/fc0f0b82427acabe225567ce570aa08490b9f15a))
* **YouTube:** Remove `19.43.41` that YouTube no longer supports ([ae1a03b](https://github.com/MorpheApp/morphe-patches/commit/ae1a03b7e40cb033575e6f1d2e5c49f54e44c5f3))

# [1.0.0-dev.13](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.12...v1.0.0-dev.13) (2025-12-17)


### Bug Fixes

* **Spoof video streams:** Restore missing file during commit conflict resolution ([69823a5](https://github.com/MorpheApp/morphe-patches/commit/69823a5d8788fd3391d32260341895fcc28f1051))


### Features

* **Spoof video streams:** Default client maintenance ([#11](https://github.com/MorpheApp/morphe-patches/issues/11)) ([339f897](https://github.com/MorpheApp/morphe-patches/commit/339f897e422cfaa5d34b8ffcf0334b96ce50d5e7))

# [1.0.0-dev.12](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.11...v1.0.0-dev.12) (2025-12-16)


### Bug Fixes

* **AddResources:** Change resource system to per app, remove per patch resource system that is problematic with Crowdin ([#12](https://github.com/MorpheApp/morphe-patches/issues/12)) ([3d8b223](https://github.com/MorpheApp/morphe-patches/commit/3d8b223e390004ace9c02e138e708477e3d220ae))
* **YouTube - Hide player flyout menu items:** Hide additional menu items with 20.22+ ([734bfb3](https://github.com/MorpheApp/morphe-patches/commit/734bfb344e846339378a3aa5bb050b01a6b76223))
* **YouTube - Hide video action buttons:** Update hide like and subscribe button glow for 20.22+ ([0fec09c](https://github.com/MorpheApp/morphe-patches/commit/0fec09c816cc2584e279d5290d082d391136bc0b))

# [1.0.0-dev.11](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.10...v1.0.0-dev.11) (2025-12-15)


### Bug Fixes

* Use 'notification' language instead of 'toast' ([06d18b8](https://github.com/MorpheApp/morphe-patches/commit/06d18b8c900e473f2859bb5aaf3b4eb68009e311))

# [1.0.0-dev.10](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.9...v1.0.0-dev.10) (2025-12-13)


### Bug Fixes

* `backtick` is replaced with an empty string in bash ([#9](https://github.com/MorpheApp/morphe-patches/issues/9)) ([a29ac22](https://github.com/MorpheApp/morphe-patches/commit/a29ac22799417bde5c5d3f047b1dd4c09b7137c2))

# [1.0.0-dev.9](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.8...v1.0.0-dev.9) (2025-12-12)


### Bug Fixes

* `backtick` is replaced with an empty string in bash ([#8](https://github.com/MorpheApp/morphe-patches/issues/8)) ([4858494](https://github.com/MorpheApp/morphe-patches/commit/485849403488c3a44e770266d5d3af65ee8c1e63))

# [1.0.0-dev.8](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.7...v1.0.0-dev.8) (2025-12-11)


### Bug Fixes

* Rename `bundleBundles` to `generatePatchesList` ([0bcc12f](https://github.com/MorpheApp/morphe-patches/commit/0bcc12f64aab9045df6f94c2ab20a52fb52ca096))

# [1.0.0-dev.7](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.6...v1.0.0-dev.7) (2025-12-11)


### Bug Fixes

* **YT Music:** Support `8.49.52` ([052629c](https://github.com/MorpheApp/morphe-patches/commit/052629ce202ae978a311c35751ab3f771a2fed9c))

# [1.0.0-dev.6](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.5...v1.0.0-dev.6) (2025-12-09)


### Bug Fixes

* **YouTube - Hide player flyout menu items:** Remove hide submenu items for 20.22+ ([5d5d1f1](https://github.com/MorpheApp/morphe-patches/commit/5d5d1f1630a08899b4423f1482d602102f12e8ca))

# [1.0.0-dev.5](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.4...v1.0.0-dev.5) (2025-12-09)


### Features

* Generate new release ([ad7d1c3](https://github.com/MorpheApp/morphe-patches/commit/ad7d1c3a1c5f8d75859e0a8f3f92b5c8d708e794))

# [1.0.0-dev.4](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.3...v1.0.0-dev.4) (2025-12-08)


### Bug Fixes

* Revert Android Studio automatic changes ([f59279b](https://github.com/MorpheApp/morphe-patches/commit/f59279b8f9d2e6c1ab9e1d6716ded469a7db486c))

# [1.0.0-dev.3](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.2...v1.0.0-dev.3) (2025-12-08)


### Bug Fixes

* Remove DSL from fingerprints ([#6](https://github.com/MorpheApp/morphe-patches/issues/6)) ([ea41840](https://github.com/MorpheApp/morphe-patches/commit/ea41840e7ef6d678ab84bb3bfd10f8c84070f4e8))

# [1.0.0-dev.2](https://github.com/MorpheApp/morphe-patches/compare/v1.0.0-dev.1...v1.0.0-dev.2) (2025-12-07)


### Bug Fixes

* Fix publish? ([864f2ee](https://github.com/MorpheApp/morphe-patches/commit/864f2ee5cd4717930d7a74e3de597bfca6eeb2aa))

# 1.0.0-dev.1 (2025-12-07)


### Bug Fixes

* Move all classes to morphe namespace ([9948922](https://github.com/MorpheApp/morphe-patches/commit/9948922e4e2015fa15af27a7ebb5e2cbffc1c01c))
* Remove installation nag screen that prevent sharing with close friends, but also will never stop counterfeit sites ([e7f3497](https://github.com/MorpheApp/morphe-patches/commit/e7f3497d4197f10e028be0fc2623e152375b52b6))
* Restore code ([2e4979a](https://github.com/MorpheApp/morphe-patches/commit/2e4979ae17533eb80658aca7f50a9cb62cba478b))
* **YouTube - Hide ads:** Hide new type of ad ([066a3ff](https://github.com/MorpheApp/morphe-patches/commit/066a3ff6c53656d60ef5eb32c48042f6ed970c41))
* **YouTube - Hide ads:** YouTube Doodles are unclickable when Hide ads is turned on ([1ba6238](https://github.com/MorpheApp/morphe-patches/commit/1ba623899ad6f89e4d4c44114dcea090118887d3))
* **YouTube - Hide ads:** YouTube Doodles are unclickable when Hide ads is turned on ([d3a54c1](https://github.com/MorpheApp/morphe-patches/commit/d3a54c1b9c2c9f3179dacc07611792ee4852fc9e))
* **YouTube - Hide Shorts components:** Action buttons are not hidden in YouTube 20.22+ ([#4](https://github.com/MorpheApp/morphe-patches/issues/4)) ([171351a](https://github.com/MorpheApp/morphe-patches/commit/171351a3989cbc8a17990789fd34b1d7b35ffad8))
* **YouTube - Return YouTube Dislike:** Sometimes incorrect dislike counts shown in Shorts ([6401688](https://github.com/MorpheApp/morphe-patches/commit/640168818c9ada91ed7c429de7b75f08f0b79f9c))
* **YouTube - Return YouTube Dislike:** Sometimes incorrect dislike counts shown when the dislike button is clicked and then canceled ([b598b22](https://github.com/MorpheApp/morphe-patches/commit/b598b22b8c0ca5c5c37f18bf0f02ff7a97463a20))
* **YouTube - ReturnYouTubeDislike:** Fix dislikes not showing with 20.31+ ([f238b81](https://github.com/MorpheApp/morphe-patches/commit/f238b8112f0a46dc24118cf2e8b9138cfdb932c3))
* **YouTube - Spoof video streams:** Age-restricted videos do not play in the `Android No SDK` client ([#3](https://github.com/MorpheApp/morphe-patches/issues/3)) ([c8096b1](https://github.com/MorpheApp/morphe-patches/commit/c8096b14685c8822e36a9acbe7f7729d95f754e8))
* **YouTube Music - Hide buttons:** An exception is thrown due to an invalid fingerprint format ([81042aa](https://github.com/MorpheApp/morphe-patches/commit/81042aa5a7fb8afd1da8dc2a7e854ac0a5b0958c))
* **YouTube:** Move loop video setting to player menu ([cd82e1e](https://github.com/MorpheApp/morphe-patches/commit/cd82e1e807533e7f39bc40b1d9171929166ff9bb))


### Features

* **YouTube - LithoFilterPatch:** Add support for accessibility filtering ([#1](https://github.com/MorpheApp/morphe-patches/issues/1)) ([61fb9c2](https://github.com/MorpheApp/morphe-patches/commit/61fb9c2498ad261ae526b347fb89d4faf1723704))
