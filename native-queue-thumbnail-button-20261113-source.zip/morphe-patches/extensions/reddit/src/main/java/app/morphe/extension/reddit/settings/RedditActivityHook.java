/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.reddit.settings;

import static app.morphe.extension.shared.StringRef.str;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.Objects;

import app.morphe.extension.reddit.settings.preference.RedditPreferenceFragment;
import app.morphe.extension.reddit.ui.MorpheSettingsIconVectorDrawable;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceUtils;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.settings.preference.AbstractPreferenceFragment;
import app.morphe.extension.shared.theme.ThemeUtils;
import app.morphe.extension.shared.ui.Dim;
import kotlin.jvm.functions.Function0;

@SuppressWarnings({"deprecation", "unused"})
public class RedditActivityHook {
    private static final Drawable MORPHE_ICON = MorpheSettingsIconVectorDrawable.getIcon();
    private static final String MORPHE_LABEL = "Morphe";
    private static final String EXTRA_INITIAL_URL = "com.reddit.extra.initial_url";
    private static final String PRIVACY_POLICY_URI = Objects.requireNonNull(
            ResourceUtils.getString("privacy_policy_uri"));

    /**
     * Injection point.
     * 2026.29.0 and older.
     */
    public static Drawable getSettingIcon() {
        return MORPHE_ICON;
    }

    /**
     * Injection point.
     * 2026.29.0 and older.
     */
    public static String getSettingLabel() {
        return MORPHE_LABEL;
    }

    /**
     * Injection point.
     */
    public static Function0<Object> getGoogleSignInFunction() {
        // Must use anonymous declaration.
        // Using a lambda creates a different bytecode that doesn't work.
        // noinspection Convert2Lambda
        return new Function0<>() {
            @Override
            public Object invoke() {
                Utils.showToastLong(str("morphe_google_signin_not_available_toast"));
                return null;
            }
        };
    }

    /**
     * Injection point.
     */
    public static boolean hook(Activity activity) {
        if (isMorpheSettingsActivity(activity)) {
            initialize(activity);
            return true;
        }

        return false;
    }

    private static boolean isMorpheSettingsActivity(Activity activity) {
        return MORPHE_LABEL.equals(activity.getIntent().getStringExtra(EXTRA_INITIAL_URL));
    }

    /**
     * Injection point.
     * 2026.29.0 and older.
     * <p>
     * Overrides {@link Activity#finish()} of the settings activity.
     *
     * @return If the restart dialog is shown, and the original finish method must not run yet.
     */
    public static boolean handleFinish(Activity activity) {
        if (!isMorpheSettingsActivity(activity)) {
            return false;
        }

        return AbstractPreferenceFragment.showRestartDialogIfNeeded(activity);
    }

    /**
     * Injection point.
     */
    public static Intent initializeByIntent(Context context) {
        Intent intent = new Intent();
        intent.setClassName(context, "com.reddit.webembed.browser.WebBrowserActivity");
        intent.putExtra(EXTRA_INITIAL_URL, MORPHE_LABEL);
        return intent;
    }

    /**
     * Injection point.
     */
    public static void initialize(Activity activity) {
        int fragmentId = View.generateViewId();
        FrameLayout fragment = new FrameLayout(activity);
        fragment.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        fragment.setId(fragmentId);

        LinearLayout linearLayout = new LinearLayout(activity);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setFitsSystemWindows(true);
        linearLayout.setTransitionGroup(true);
        linearLayout.addView(fragment);
        linearLayout.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        activity.setContentView(linearLayout);

        activity.getFragmentManager()
                .beginTransaction()
                .replace(fragmentId, new RedditPreferenceFragment())
                .commit();
    }

    /**
     * Injection point.
     */
    public static boolean isAcknowledgment(Enum<?> e) {
        return e != null && "ACKNOWLEDGMENTS".equals(e.name());
    }

    /**
     * Injection point.
     */
    public static boolean openMorpheSettings(Activity activity, Uri uri) {
        Logger.printInfo(() -> "Uri: " + uri);
        if (PRIVACY_POLICY_URI.equals(uri.toString())) {
            new MorpheSettingsDialog().show(activity.getFragmentManager(), "morphe_settings");
            return true;
        }
        return false;
    }

    public static class MorpheSettingsDialog extends DialogFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setStyle(STYLE_NO_TITLE, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new Dialog(getActivity(), getTheme()) {
                @Override
                @SuppressLint("GestureBackNavigation")
                public void onBackPressed() {
                    closeSettings();
                }
            };
        }

        /**
         * Closes the settings, after first showing the restart dialog if a changed setting requires it.
         */
        private void closeSettings() {
            if (!AbstractPreferenceFragment.showRestartDialogIfNeeded(getActivity())) {
                dismiss();
            }
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            Activity activity = getActivity();
            final int appForegroundColor = ThemeUtils.getAppForegroundColor();
            final int appBackgroundColor = ThemeUtils.getAppBackgroundColor();

            // Ensure the dialog window fills the screen and shows the status bar.
            Dialog dialog = getDialog();
            if (dialog != null) {
                Window window = dialog.getWindow();
                if (window != null) {
                    window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    window.setStatusBarColor(appBackgroundColor);
                    window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                }
            }

            LinearLayout linearLayout = new LinearLayout(activity);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setBackgroundColor(appBackgroundColor);
            linearLayout.setFitsSystemWindows(true);

            final int actionBarSize;
            TypedValue tv = new TypedValue();
            if (activity.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
                actionBarSize = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
            } else {
                actionBarSize = (int) (56 * getResources().getDisplayMetrics().density);
            }

            Toolbar toolbar = new Toolbar(activity);
            toolbar.setLayoutParams(new LinearLayout.LayoutParams(-1, actionBarSize));
            toolbar.setBackgroundColor(appBackgroundColor);
            toolbar.setTitle(MORPHE_LABEL);
            toolbar.setTitleTextColor(appForegroundColor);
            toolbar.setElevation(Dim.dp2);

            toolbar.post(() -> {
                TextView titleTextView = Utils.getChildView(toolbar, false,
                        view -> view instanceof TextView);
                if (titleTextView != null) {
                    titleTextView.setTextSize(18);
                }
            });

            Drawable backIcon = Objects.requireNonNull(ResourceUtils.getDrawable("icon_arrow_back"));
            backIcon.setTint(appForegroundColor);
            toolbar.setNavigationIcon(backIcon);
            toolbar.setNavigationOnClickListener(v -> closeSettings());
            linearLayout.addView(toolbar);

            final int fragmentId = View.generateViewId();
            FrameLayout fragmentContainer = new FrameLayout(activity);
            fragmentContainer.setId(fragmentId);
            linearLayout.addView(fragmentContainer, new LinearLayout.LayoutParams(-1, -1));

            getChildFragmentManager().beginTransaction()
                    .replace(fragmentId, new RedditPreferenceFragment())
                    .commit();

            return linearLayout;
        }
    }
}
