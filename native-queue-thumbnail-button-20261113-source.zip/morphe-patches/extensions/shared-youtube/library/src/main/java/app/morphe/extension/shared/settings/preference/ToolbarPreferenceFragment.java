/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * Original hard forked code:
 * https://github.com/ReVanced/revanced-patches/commit/724e6d61b2ecd868c1a9a37d465a688e83a74799
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to Morphe contributions.
 */

package app.morphe.extension.shared.settings.preference;

import static app.morphe.extension.shared.StringRef.str;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.preference.Preference;
import android.preference.PreferenceGroup;
import android.preference.PreferenceScreen;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.annotation.Nullable;

import java.lang.reflect.Method;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceUtils;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.patches.BaseAppRefreshRatePatch;
import app.morphe.extension.shared.patches.CustomFontPatch;
import app.morphe.extension.shared.settings.BaseActivityHook;
import app.morphe.extension.shared.theme.ThemeUtils;
import app.morphe.extension.shared.ui.Dim;

@SuppressWarnings({"deprecation", "RedundantSuppression"})
public class ToolbarPreferenceFragment extends AbstractPreferenceFragment {

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CustomFontFilePreference.PICK_FONT_REQUEST_CODE && CustomFontPatch.isPatchIncluded()) {
            CustomFontFilePreference.handleActivityResult(getContext(), resultCode, data);
        }
    }

    /**
     * Removes the list of preferences from this fragment, if they exist.
     * @param keys Preference keys.
     */
    protected void removePreferences(String ... keys) {
        for (String key : keys) {
            Preference pref = findPreference(key);
            if (pref != null) {
                PreferenceGroup parent = pref.getParent();
                if (parent != null) {
                    Logger.printDebug(() -> "Removing preference: " + key);
                    parent.removePreference(pref);
                }
            }
        }
    }

    /**
     * Sets toolbar for all nested preference screens.
     */
    protected void setPreferenceScreenToolbar(PreferenceScreen parentScreen) {
        for (int i = 0, count = parentScreen.getPreferenceCount(); i < count; i++) {
            Preference childPreference = parentScreen.getPreference(i);
            setPreferenceIconColor(childPreference);

            if (childPreference instanceof PreferenceScreen) {
                ScreenInfoCategory screenInfo = removeScreenInfo((PreferenceScreen) childPreference);

                // Recursively set sub preferences.
                setPreferenceScreenToolbar((PreferenceScreen) childPreference);

                childPreference.setOnPreferenceClickListener(
                        childScreen -> {
                            Dialog preferenceScreenDialog = ((PreferenceScreen) childScreen).getDialog();
                            ViewGroup rootView = (ViewGroup) preferenceScreenDialog
                                    .findViewById(android.R.id.content)
                                    .getParent();

                            // Allow package-specific background customization.
                            customizeDialogBackground(rootView);

                            // Fix the system navigation bar color for submenus.
                            setNavigationBarColor(preferenceScreenDialog.getWindow());

                            // Set the refresh rate for submenus.
                            BaseAppRefreshRatePatch.setWindowRefreshRate(
                                    childScreen.getContext(),
                                    preferenceScreenDialog.getWindow()
                            );

                            // Fix edge-to-edge screen with Android 15 and YT 19.45+
                            // https://developer.android.com/develop/ui/views/layout/edge-to-edge#system-bars-insets
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                rootView.setOnApplyWindowInsetsListener((v, insets) -> {
                                    Insets statusInsets = insets.getInsets(WindowInsets.Type.statusBars());
                                    Insets navInsets = insets.getInsets(WindowInsets.Type.navigationBars());
                                    Insets cutoutInsets = insets.getInsets(WindowInsets.Type.displayCutout());

                                    // Apply padding for display cutout in landscape,
                                    // and in portrait if the status bar is hidden.
                                    int leftPadding = cutoutInsets.left;
                                    int rightPadding = cutoutInsets.right;
                                    int topPadding = Math.max(statusInsets.top, cutoutInsets.top);
                                    int bottomPadding = navInsets.bottom;

                                    v.setPadding(leftPadding, topPadding, rightPadding, bottomPadding);
                                    return insets;
                                });
                            }

                            Toolbar toolbar = new Toolbar(childScreen.getContext());
                            // The title can have a new setting dot, which is not shown here.
                            toolbar.setTitle(childScreen.getTitle().toString());
                            toolbar.setNavigationIcon(getBackButtonDrawable());
                            toolbar.setNavigationContentDescription(str("morphe_settings_navigate_up"));
                            toolbar.setNavigationOnClickListener(view -> preferenceScreenDialog.dismiss());

                            toolbar.setTitleMargin(Dim.dp16, 0, Dim.dp16, 0);

                            TextView toolbarTextView = Utils.getChildView(toolbar,
                                    true, TextView.class::isInstance);
                            if (toolbarTextView != null) {
                                toolbarTextView.setTextColor(ThemeUtils.getAppForegroundColor());
                                toolbarTextView.setTextSize(20);
                            }

                            if (screenInfo != null) {
                                addToolbarButton(toolbar, "morphe_settings_screen_00_about",
                                        str("morphe_settings_screen_info_title"),
                                        () -> screenInfo.showDialog(toolbar.getContext(), childScreen.getTitle().toString()));
                            }

                            // Allow package-specific toolbar customization.
                            customizeToolbar(toolbar);

                            // Allow package-specific post-toolbar setup.
                            onPostToolbarSetup(toolbar, preferenceScreenDialog);

                            rootView.addView(toolbar, 0);
                            return false;
                        }
                );
            }
        }
    }

    @Nullable
    private static ScreenInfoCategory removeScreenInfo(PreferenceScreen screen) {
        for (int i = 0, count = screen.getPreferenceCount(); i < count; i++) {
            Preference preference = screen.getPreference(i);
            if (preference instanceof ScreenInfoCategory) {
                // Removed before search collects the preferences, the text is only for the dialog.
                screen.removePreference(preference);
                return (ScreenInfoCategory) preference;
            }
        }
        return null;
    }

    /**
     * Clicks a preference as if its row was tapped. A nested PreferenceScreen opens its screen.
     *
     * @param preference The preference to click.
     * @param rootScreen The main screen of the fragment that holds the preference.
     */
    @SuppressWarnings("all")
    public static void performClick(Preference preference, PreferenceScreen rootScreen) {
        try {
            Method m = Preference.class.getDeclaredMethod("performClick", PreferenceScreen.class);
            m.setAccessible(true);
            m.invoke(preference, rootScreen);
        } catch (Exception e) {
            Logger.printException(() -> "Failed to invoke performClick()", e);
        }
    }

    /**
     * Adds an icon button to the toolbar, such as search or screen info.
     *
     * @param iconName Drawable name, the "_bold" variant is used with bold icons.
     */
    @SuppressLint("AlwaysShowAction")
    public static MenuItem addToolbarButton(Toolbar toolbar, String iconName,
                                            CharSequence description, Runnable onClick) {
        MenuItem item = toolbar.getMenu().add(description);
        item.setIcon(getToolbarIconDrawable(iconName));
        item.setContentDescription(description);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        item.setOnMenuItemClickListener(menuItem -> {
            onClick.run();
            return true;
        });
        return item;
    }

    /**
     * @return The icon, bold or not depending on the Morphe UI setting, and colored like
     *         everything else Morphe draws. The drawable follows the text color of the platform,
     *         which is not the foreground color of the app.
     */
    public static Drawable getToolbarIconDrawable(String iconName) {
        Drawable icon = ResourceUtils.getDrawableOrThrow(
                Utils.appIsUsingBoldIcons() ? iconName + "_bold" : iconName);

        // Mutate, otherwise every user of the same drawable is colored as well.
        Drawable mutated = icon.mutate();
        mutated.setTint(ThemeUtils.getAppForegroundColor());
        return mutated;
    }

    /**
     * Sets the system navigation bar color for the activity.
     * Applies the background color obtained from {@link ThemeUtils#getAppBackgroundColor()} to the navigation bar.
     * For Android 10 (API 29) and above, enforces navigation bar contrast to ensure visibility.
     */
    public static void setNavigationBarColor(@Nullable Window window) {
        if (window == null) {
            Logger.printDebug(() -> "Cannot set navigation bar color, window is null");
            return;
        }

        window.setNavigationBarColor(ThemeUtils.getAppBackgroundColor());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(true);
        }
    }

    /**
     * Colors the icon of a preference, which is drawn with the text color of the platform and
     * not with the color the app uses for its foreground.
     */
    private static void setPreferenceIconColor(Preference preference) {
        Drawable icon = preference.getIcon();
        if (icon == null) {
            return;
        }

        // Mutate, otherwise every user of the same drawable is colored as well.
        Drawable mutated = icon.mutate();
        mutated.setTint(ThemeUtils.getAppForegroundColor());
        preference.setIcon(mutated);
    }

    /**
     * Returns the drawable for the back button.
     */
    @SuppressLint("UseCompatLoadingForDrawables")
    public static Drawable getBackButtonDrawable() {
        Drawable drawable = ResourceUtils.getDrawableOrThrow(
                Utils.appIsUsingBoldIcons()
                        ? "morphe_settings_toolbar_arrow_left_bold"
                        : "morphe_settings_toolbar_arrow_left");
        customizeBackButtonDrawable(drawable);
        return drawable;
    }

    /**
     * Customizes the back button drawable.
     */
    protected static void customizeBackButtonDrawable(Drawable drawable) {
        drawable.setTint(ThemeUtils.getAppForegroundColor());
    }

    /**
     * Allows subclasses to customize the dialog's root view background.
     */
    protected void customizeDialogBackground(ViewGroup rootView) {
        rootView.setBackgroundColor(ThemeUtils.getAppBackgroundColor());
    }

    /**
     * Allows subclasses to customize the toolbar.
     */
    protected void customizeToolbar(Toolbar toolbar) {
        BaseActivityHook.setToolbarLayoutParams(toolbar);
    }

    /**
     * Allows subclasses to perform actions after toolbar setup.
     */
    protected void onPostToolbarSetup(Toolbar toolbar, Dialog preferenceScreenDialog) {}
}
