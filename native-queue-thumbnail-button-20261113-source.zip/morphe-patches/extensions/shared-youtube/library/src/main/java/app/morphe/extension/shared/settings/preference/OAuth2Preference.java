package app.morphe.extension.shared.settings.preference;

import static app.morphe.extension.shared.StringRef.str;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.oauth2.object.AccessTokenData;
import app.morphe.extension.shared.oauth2.object.ActivationCodeData;
import app.morphe.extension.shared.oauth2.requests.OAuth2Requester;
import app.morphe.extension.shared.settings.Setting;
import app.morphe.extension.shared.settings.SharedYouTubeSettings;
import app.morphe.extension.shared.ui.CustomDialog;

@SuppressWarnings({"unused", "deprecation"})
public abstract class OAuth2Preference extends Preference implements Preference.OnPreferenceClickListener {

    {
        setOnPreferenceClickListener(this);
    }

    private final SharedPreferences.OnSharedPreferenceChangeListener listener = (sharedPreferences, str) -> {
        // Because this listener may run before the Morphe settings fragment updates Settings,
        // this could show the prior config and not the current.
        //
        // Push this call to the end of the main run queue,
        // so all other listeners are done and Settings is up to date.
        Utils.runOnMainThread(this::updateUI);
    };

    /**
     * How many times to try to get a refresh token after the user returns to the app.
     */
    private static final int GET_REFRESH_TOKENS_MAX_ATTEMPTS = 5;

    /**
     * Interval of fetched {@link ActivationCodeData#interval}.
     */
    private int getTokenIntervalCheckMilliseconds;

    /**
     * How many get token attempts are left. Used to prevent re-trying if the user abandons
     * the website sign-in process.
     */
    private int getTokenAttemptsLeft;

    /**
     * The last time token auth was checked. Required to prevent "too_fast" errors
     * if re-checking too quickly.
     */
    private long lastGetTokenAttemptTime;

    /**
     * If a get token attempt is scheduled for the future.
     */
    private boolean getTokenAttemptScheduled;

    /**
     * Callback when the app is resumed. Used to automatically finish the client side sign in process.
     */
    private final Application.ActivityLifecycleCallbacks ACTIVITY_LIFECYCLE_CALLBACKS
            = new Application.ActivityLifecycleCallbacks() {

        public void onActivityResumed(@NonNull Activity activity) {
            // Check for auth approval when the app resumes.
            // This could be done in the background on a timer, but the Google update interval is
            // usually 5 seconds which means if the user returns to the app there could be up to 5-second
            // delay before showing the success dialog.
            //
            // Instead, check when the app resumes with some logic to wait a few seconds if the
            // user is changing back and forth before auth is approved.
            Logger.printDebug(() -> "onActivityResumed");
            if (OAuth2Requester.isActivationCodeDataAvailable()) {
                if (getTokenAttemptScheduled) {
                    return;
                }

                final long now = System.currentTimeMillis();
                if (System.currentTimeMillis() > (lastGetTokenAttemptTime + getTokenIntervalCheckMilliseconds)) {
                    lastGetTokenAttemptTime = now;
                    getRefreshToken();
                } else {
                    getTokenAttemptScheduled = true;
                    // Too soon to check again. Schedule a check in the future.
                    final long delayMillis = getTokenIntervalCheckMilliseconds - (now - lastGetTokenAttemptTime);
                    Logger.printDebug(() -> "Scheduling get token check in: " + delayMillis + "ms");
                    Utils.runOnMainThreadDelayed(() -> {
                        lastGetTokenAttemptTime = System.currentTimeMillis();
                        getTokenAttemptScheduled = false;
                        getRefreshToken();
                    }, delayMillis);
                }
            }
        }

        public void onActivityCreated(@NonNull Activity a, @Nullable Bundle b) {}
        public void onActivityStarted(@NonNull Activity a) {}
        public void onActivityPaused(@NonNull Activity a) {}
        public void onActivityStopped(@NonNull Activity a) {}
        public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle b) {}
        public void onActivityDestroyed(@NonNull Activity a) {}
    };

    private void unregisterApplicationOnResumeCallback() {
        ((Application) getContext().getApplicationContext()).unregisterActivityLifecycleCallbacks(
                ACTIVITY_LIFECYCLE_CALLBACKS
        );
    }

    @Override
    protected void onAttachedToHierarchy(PreferenceManager preferenceManager) {
        super.onAttachedToHierarchy(preferenceManager);
        updateUI();
        Setting.preferences.preferences.registerOnSharedPreferenceChangeListener(listener);
    }

    @Override
    protected void onPrepareForRemoval() {
        super.onPrepareForRemoval();
        Setting.preferences.preferences.unregisterOnSharedPreferenceChangeListener(listener);
        // Remove just in case the user never finished signing in.
        unregisterApplicationOnResumeCallback();
    }

    protected boolean isRefreshTokenSaved() {
        return !SharedYouTubeSettings.OAUTH2_REFRESH_TOKEN.get().isEmpty();
    }

    protected void updateUI(boolean currentlySignedIn) {
        final boolean isSettingEnabled = isSettingEnabled();
        setEnabled(isSettingEnabled);

        String summaryKey;
        if (isSettingEnabled) {
            summaryKey = currentlySignedIn
                    ? "morphe_spoof_video_streams_sign_in_android_vr_about_summary_signed_in"
                    : "morphe_spoof_video_streams_sign_in_android_vr_about_summary";
        } else {
            summaryKey = "morphe_spoof_video_streams_sign_in_android_vr_about_summary_disabled";
        }
        setSummary(str(summaryKey));
    }

    protected void updateUI() {
        updateUI(isRefreshTokenSaved());
    }

    public OAuth2Preference(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        updateUI();
    }

    public OAuth2Preference(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        updateUI();
    }

    public OAuth2Preference(Context context, AttributeSet attrs) {
        super(context, attrs);
        updateUI();
    }

    public OAuth2Preference(Context context) {
        super(context);
        updateUI();
    }

    /**
     * @return If the app spoof settings are configured in a way to allow using VR sign in.
     */
    protected abstract boolean isSettingEnabled();

    @Override
    public boolean onPreferenceClick(Preference preference) {
        String titleKey;
        String messageKey;
        String okButtonTextKey;
        Runnable okButtonRunnable;

        if (isRefreshTokenSaved()) {
            titleKey = "morphe_spoof_video_streams_sign_in_android_vr_about_summary_signed_in";
            messageKey = "morphe_spoof_video_streams_sign_in_android_vr_success_dialog_message";
            okButtonTextKey = "morphe_spoof_video_streams_sign_in_android_vr_dialog_reset";
            okButtonRunnable = () -> {
                OAuth2Requester.revokeToken(SharedYouTubeSettings.OAUTH2_REFRESH_TOKEN.get());
                // Don't wait for revoke to finish and clear the token now so UI is up to date.
                SharedYouTubeSettings.OAUTH2_REFRESH_TOKEN.resetToDefault();
                updateUI(false);
            };
        } else {
            titleKey = "morphe_spoof_video_streams_sign_in_android_vr_dialog_title";
            messageKey = "morphe_spoof_video_streams_sign_in_android_vr_dialog_not_signed_in_message";
            okButtonTextKey = "gms_core_dialog_continue_text";
            okButtonRunnable = this::showActivationCodeDialog;
        }

        CustomDialog.create(
                getContext(),
                // Title.
                str(titleKey),
                // Message.
                BulletPointPreference.formatIntoBulletPoints(str(messageKey)),
                // No EditText.
                null,
                // OK button text.
                str(okButtonTextKey),
                // OK button action.
                okButtonRunnable,
                // Cancel button action.
                () -> {

                },
                // Neutral button text.
                null,
                // Neutral button action.
                null,
                // Dismiss dialog when onNeutralClick.
                true
        ).first.show();

        return true;
    }

    private void showActivationCodeDialog() {
        getTokenAttemptsLeft = GET_REFRESH_TOKENS_MAX_ATTEMPTS;
        Context context = getContext();

        Utils.runOnBackgroundThread(() -> {
            ActivationCodeData activationCodeData = OAuth2Requester.getActivationCodeData();
            if (activationCodeData == null) {
                Utils.showToastLong(str("morphe_spoof_video_streams_sign_in_android_vr_toast_get_activation_code_failed"));
                return;
            }

            Utils.runOnMainThread(() -> {
                String userCode = activationCodeData.userCode;
                String verificationUrl = activationCodeData.verificationUrl;
                getTokenIntervalCheckMilliseconds = 1000 * activationCodeData.interval;

                CustomDialog.create(
                        context,
                        // Title.
                        str("morphe_spoof_video_streams_sign_in_android_vr_activation_code_dialog_title"),
                        // Message.
                        str("morphe_spoof_video_streams_sign_in_android_vr_activation_code_dialog_message", userCode),
                        // No EditText.
                        null,
                        // OK button text.
                        str("gms_core_dialog_open_website_text"),
                        // OK button action.
                        () -> openInBrowser(context, userCode, verificationUrl),
                        // Cancel button action (dismiss only).
                        null,
                        // Neutral button text.
                        null,
                        // Neutral button action.
                        null,
                        // Dismiss dialog when onNeutralClick.
                        false
                ).first.show();
            });
        });
    }

    private void getRefreshToken() {
        final boolean reachedMaxGetTokenAttempts = --getTokenAttemptsLeft <= 0;
        if (reachedMaxGetTokenAttempts) {
            unregisterApplicationOnResumeCallback();
        }

        Context context = getContext();

        Utils.runOnBackgroundThread(() -> {
            AccessTokenData accessTokenData = OAuth2Requester.getRefreshTokenData(reachedMaxGetTokenAttempts);

            Utils.runOnMainThread(() -> {
                if (accessTokenData == null) {
                    Logger.printDebug(() -> "No refresh token found");
                    if (reachedMaxGetTokenAttempts) {
                        Utils.showToastLong(str("morphe_spoof_video_streams_sign_in_android_vr_toast_get_authorization_code_failed"));
                    }
                    return;
                }
                String refreshToken = accessTokenData.refreshToken;
                if (!Utils.isNotEmpty(refreshToken)) {
                    Logger.printException(() -> "No refresh token found");
                    return;
                }

                unregisterApplicationOnResumeCallback();

                SharedYouTubeSettings.OAUTH2_REFRESH_TOKEN.save(refreshToken);
                OAuth2Requester.setAuthorization(accessTokenData);

                updateUI(true);

                CustomDialog.create(
                        context,
                        // Title.
                        str("morphe_spoof_video_streams_sign_in_android_vr_success_dialog_title"),
                        // Message.
                        BulletPointPreference.formatIntoBulletPoints(
                                str("morphe_spoof_video_streams_sign_in_android_vr_success_dialog_message")
                        ),
                        // No EditText.
                        null,
                        // OK button text.
                        null,
                        // OK button action.
                        () -> {
                        },
                        // Cancel button action.
                        null,
                        // Neutral button text.
                        null,
                        // Neutral button action.
                        null,
                        // Dismiss dialog when onNeutralClick.
                        true
                ).first.show();
            });
        });
    }

    // Check in-app browser availability.
    @Nullable
    private String getDefaultCustomTabsBrowser(Context context) {
        Intent activityIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://"));
        Intent serviceIntent = new Intent("android.support.customtabs.action.CustomTabsService");
        PackageManager packageManager = context.getPackageManager();
        ResolveInfo resolveInfo = packageManager.resolveActivity(activityIntent, 0);
        if (resolveInfo != null) {
            String packageName = resolveInfo.activityInfo.packageName;
            serviceIntent.setPackage(packageName);
            if (packageManager.resolveService(serviceIntent, 0) != null) {
                return packageName;
            }
        }

        return null;
    }

    private void openInBrowser(Context context, String userCode, String verificationUrl) {
        // Automatically fetch the auth token after the user returns.
        ((Application) getContext().getApplicationContext()).registerActivityLifecycleCallbacks(
                ACTIVITY_LIFECYCLE_CALLBACKS
        );
        Utils.setClipboard(userCode);
        Intent baseIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(verificationUrl));

        try {
            // Try opening it in the in-app browser first.
            Intent intent = baseIntent.cloneFilter();
            intent.putExtra("android.support.customtabs.extra.SESSION", (Bundle) null);
            intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 1);
            String packageName = getDefaultCustomTabsBrowser(context);
            if (packageName != null) {
                intent.setPackage(packageName);
            }
            context.startActivity(intent);
        } catch (Exception ex) {
            // Fallback to legacy method.
            Logger.printDebug(() -> "Could not open in-app browser, using legacy method", ex);
            context.startActivity(baseIntent.cloneFilter());
        }
    }
}
