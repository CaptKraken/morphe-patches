/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.shared.oauth2.requests;

import java.io.IOException;
import java.net.HttpURLConnection;

import app.morphe.extension.shared.requests.Requester;
import app.morphe.extension.shared.requests.Route;

@SuppressWarnings("unused")
final class OAuth2Routes {
    private static final String OAUTH2_GOOGLE_API_URL = "https://oauth2.googleapis.com/";
    private static final String OAUTH2_YOUTUBE_API_URL = "https://www.youtube.com/o/oauth2/";
    private static final String USER_AGENT =
            "com.google.android.apps.youtube.vr.pico/1.73.21(Linux; U; Android 10; en_US; A8110 Build/5.13.7) gzip";

    /**
     * TCP connection and HTTP read timeout.
     */
    private static final int CONNECTION_TIMEOUT_MILLISECONDS = 10 * 1000; // 10 Seconds.

    static final Route ACCESS_TOKEN = new Route(Route.Method.POST, "token");
    static final Route DEVICE_CODE = new Route(Route.Method.POST, "device/code");
    static final Route REVOKE_TOKEN = new Route(Route.Method.POST, "revoke");

    private OAuth2Routes() {
    }

    private static void applyCommonPostRequestSettings(HttpURLConnection connection) {
        connection.setRequestProperty("Pragma", "no-cache");
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setConnectTimeout(CONNECTION_TIMEOUT_MILLISECONDS);
        connection.setReadTimeout(CONNECTION_TIMEOUT_MILLISECONDS);
    }

    static HttpURLConnection getJsonConnectionFromRoute(Route route, String... params) throws IOException {
        HttpURLConnection connection = Requester.getConnectionFromRoute(OAUTH2_YOUTUBE_API_URL, route, params);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Accept", "application/json");
        applyCommonPostRequestSettings(connection);
        return connection;
    }

    @SuppressWarnings("SameParameterValue")
    static HttpURLConnection getUrlConnectionFromRoute(Route route, String... params) throws IOException {
        HttpURLConnection connection = Requester.getConnectionFromRoute(OAUTH2_GOOGLE_API_URL, route, params);
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        applyCommonPostRequestSettings(connection);
        return connection;
    }
}
