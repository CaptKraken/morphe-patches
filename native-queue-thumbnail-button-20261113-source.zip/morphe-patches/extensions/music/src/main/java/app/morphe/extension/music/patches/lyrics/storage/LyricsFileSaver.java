/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2625
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.storage;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

import app.morphe.extension.music.patches.lyrics.model.CreditInfo;
import app.morphe.extension.music.patches.lyrics.model.Lyrics;
import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.model.TrackInfo;
import app.morphe.extension.music.patches.lyrics.model.Word;
import app.morphe.extension.music.patches.lyrics.parsers.LRCParser;
import app.morphe.extension.music.patches.lyrics.parsers.TTMLGenerator;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceUtils;

/**
 * Saves raw lyrics text to the device's Downloads directory via MediaStore.
 * No storage permissions required on API 29+.
 */
public final class LyricsFileSaver {

    private LyricsFileSaver() {
    }

    @Nullable
    public static String save(Context context, TrackInfo track, Lyrics lyrics,
                              @Nullable CreditInfo creditInfo,
                              @Nullable List<String> translatedLines,
                              @Nullable List<LyricsLine> romanizedLines,
                              @Nullable String translatedLang,
                              @Nullable String romanizedLang) {
        try {
            return saveUnchecked(context, track, lyrics, creditInfo,
                    translatedLines, romanizedLines, translatedLang, romanizedLang);
        } catch (Exception ex) {
            Logger.printException(() -> "save failure", ex);
            return null;
        }
    }

    @Nullable
    private static String saveUnchecked(Context context, TrackInfo track, Lyrics lyrics,
                                        @Nullable CreditInfo creditInfo,
                                        @Nullable List<String> translatedLines,
                                        @Nullable List<LyricsLine> romanizedLines,
                                        @Nullable String translatedLang,
                                        @Nullable String romanizedLang) {
        String primaryPath = saveSource(context, track, lyrics);
        if (primaryPath == null) {
            return null;
        }

        String ttmlContent = TTMLGenerator.generate(lyrics, track, creditInfo,
                translatedLines, romanizedLines, translatedLang, romanizedLang);
        if (ttmlContent != null && !ttmlContent.isEmpty()) {
            writeFile(context, track, lyrics, ttmlContent, "ttml", true);
        }

        return primaryPath;
    }

    private static String saveSource(Context context, TrackInfo track, Lyrics lyrics) {
        String content = lyrics.rawFormat();
        String formatType = lyrics.formatType();

        if (content == null || content.isEmpty()) {
            if (lyrics.lines() == null || lyrics.lines().isEmpty()) {
                return null;
            }

            if ("krc".equals(formatType)) {
                content = rebuildKrc(lyrics.lines());
            } else if ("lrc".equals(formatType)) {
                content = rebuildLrc(lyrics.lines());
            } else if ("lyl".equals(formatType)) {
                content = rebuildLyricifyLines(lyrics.lines());
            } else if ("lys".equals(formatType)) {
                content = rebuildLyricifySyllable(lyrics.lines());
            } else if ("dzr.json".equals(formatType)) {
                content = rebuildDzrJson(lyrics.lines());
            } else {
                content = rebuildPlainText(lyrics.lines());
                formatType = "txt";
            }
        }

        if (formatType == null || formatType.isEmpty()) {
            formatType = "txt";
        }

        return writeFile(context, track, lyrics, content, formatType, false);
    }

    @Nullable
    private static String writeFile(Context context, TrackInfo track, Lyrics lyrics,
                                    String content, String formatType, boolean isGenerated) {
        if (content == null || content.isEmpty()) {
            return null;
        }

        String fileName = fileName(track, lyrics, formatType, isGenerated);

        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, getMimeType(formatType));
        String directoryName = ResourceUtils.getString("morphe_custom_branding_name_entry_2");
        values.put(MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/" + directoryName);

        values.put(MediaStore.Downloads.IS_PENDING, 1);

        Uri insertUri = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            insertUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        }
        if (insertUri == null) {
            return null;
        }

        boolean written = false;
        try (OutputStream out = resolver.openOutputStream(insertUri)) {
            if (out == null) {
                resolver.delete(insertUri, null, null);
                return null;
            }
            out.write(content.getBytes(StandardCharsets.UTF_8));
            out.flush();
            written = true;
            return Environment.DIRECTORY_DOWNLOADS + "/" + directoryName + "/" + fileName;
        } catch (Exception ex) {
            Logger.printException(() -> "Could not save lyrics file", ex);
            try {
                resolver.delete(insertUri, null, null);
            } catch (Exception deleteEx) {
                Logger.printException(() -> "Could not delete partial lyrics file", deleteEx);
            }
            return null;
        } finally {
            if (written) {
                try {
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(insertUri, values, null, null);
                } catch (Exception ex) {
                    Logger.printException(() -> "Could not publish saved lyrics file", ex);
                }
            }
        }
    }

    private static String rebuildKrc(List<LyricsLine> lines) {
        StringBuilder sb = new StringBuilder(50 * lines.size());
        for (LyricsLine line : lines) {
            final long lineDuration = line.endTimeMs() - line.startTimeMs();
            sb.append('[').append(line.startTimeMs()).append(',').append(lineDuration).append(']');
            List<Word> words = line.words();
            if (words != null && !words.isEmpty()) {
                for (int i = 0, size = words.size(); i < size; i++) {
                    Word word = words.get(i);
                    final long offset = word.startMs() - line.startTimeMs();
                    final long wordDuration = word.endMs() - word.startMs();
                    sb.append('<').append(offset).append(',').append(wordDuration).append(",0>").append(word.text());
                }
            } else {
                sb.append(line.text());
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static String rebuildLrc(List<LyricsLine> lines) {
        StringBuilder sb = new StringBuilder(50 * lines.size());
        for (LyricsLine line : lines) {
            sb.append('[')
                    .append(LRCParser.formatCentiseconds(line.startTimeMs()))
                    .append(']')
                    .append(line.text())
                    .append('\n');
        }
        return sb.toString();
    }

    private static String rebuildLyricifyLines(List<LyricsLine> lines) {
        StringBuilder sb = new StringBuilder();
        sb.append("[type:LyricifyLines]\n");
        for (LyricsLine line : lines) {
            sb.append('[').append(line.startTimeMs())
                    .append(',').append(line.endTimeMs())
                    .append(']').append(line.text())
                    .append('\n');
        }
        return sb.toString();
    }

    private static String rebuildLyricifySyllable(List<LyricsLine> lines) {
        StringBuilder sb = new StringBuilder();
        sb.append("[from:AppleSyllable]\n");
        for (int i = 0; i < lines.size(); i++) {
            LyricsLine line = lines.get(i);
            sb.append('[').append(i + 1).append(']');
            if (line.hasWords()) {
                List<Word> words = line.words();
                for (int j = 0; j < words.size(); j++) {
                    Word word = words.get(j);
                    long durMs = word.endMs() - word.startMs();
                    sb.append(word.text())
                            .append('(').append(word.startMs())
                            .append(',').append(durMs).append(')');
                }
            } else {
                sb.append(line.text());
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static String rebuildPlainText(List<LyricsLine> lines) {
        StringBuilder sb = new StringBuilder(50 * lines.size());
        for (int i = 0, size = lines.size(); i < size; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines.get(i).text());
        }
        return sb.toString();
    }

    private static String rebuildDzrJson(List<LyricsLine> lines) {
        JSONArray arr = new JSONArray();
        for (LyricsLine line : lines) {
            JSONObject obj = new JSONObject();
            try {
                final long ms = line.startTimeMs();
                obj.put("lrcTimestamp", "[" + LRCParser.formatCentiseconds(ms) + "]");
                obj.put("line", line.text());
                obj.put("milliseconds", ms);
                obj.put("duration", line.endTimeMs() - line.startTimeMs());
                arr.put(obj);
            } catch (Exception ex) {
                Logger.printDebug(() -> "rebuildDzrJson failure", ex);
            }
        }
        return arr.toString();
    }

    private static String sanitizeFileName(String name) {
        return name.replaceAll("[\\\\/:*?\"<>|]", "_").replaceAll("\\s+", " ").trim();
    }

    private static String fileName(TrackInfo track, Lyrics lyrics, String formatType, boolean isGenerated) {
        String name = sanitizeFileName(track.artist() + " - " + track.title());
        String provider;
        if (isGenerated && "ttml".equals(formatType)) {
            provider = "Morphe";
        } else {
            provider = sanitizeFileName(lyrics.providerName());
        }
        if (!provider.isEmpty()) {
            name += " [" + provider + "]";
        }
        return name + "." + formatType;
    }

    private static String getMimeType(String formatType) {
        return switch (formatType) {
            case "ttml" -> "application/ttml+xml";
            case "lyricsfile.yaml" -> "text/yaml";
            case "json", "mxm.json", "sp.json", "dzr.json", "ytm.json" -> "application/json";
            case "plain", "txt" -> "text/plain";
            default -> "application/octet-stream";
        };
    }
}
