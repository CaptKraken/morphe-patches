/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2269
 * https://github.com/MorpheApp/morphe-patches/pull/2625
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.requests;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import app.morphe.extension.music.patches.lyrics.model.Lyrics;
import app.morphe.extension.music.patches.lyrics.model.LyricsFilterDefaults;
import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.model.TrackInfo;
import app.morphe.extension.music.patches.lyrics.model.Word;
import app.morphe.extension.music.patches.lyrics.utils.CharactersConverter;
import app.morphe.extension.music.settings.Settings;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.requests.Requester;

/**
 * Shared HTTP helpers for the lyrics providers.
 */
public final class LyricsRequests {

    public static final String SIMPLIFIED_CHINESE = "zh-Hans";
    /**
     * For the endpoints that turn away an unrecognized client. Providers that answer only
     * to a mobile agent keep one of their own.
     */
    public static final String CHROME_DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36";
    /** Open to anyone, in need of no token. */
    public static final String ITUNES_SEARCH_URL = "https://itunes.apple.com/search";
    public static final int SOFT_MIN = 2;
    public static final int VIDEO_ID_TRUST = 10;
    public static final int NEUTRAL = 6;
    static final int MAX_CANDIDATES = 5;
    private static final int CONNECT_TIMEOUT_MILLISECONDS = 5 * 1000;
    private static final int READ_TIMEOUT_MILLISECONDS = 5 * 1000;
    private static volatile boolean customMatchMode;
    private static volatile String decorationRegexSource;
    private static volatile Pattern decorationPattern;

    private LyricsRequests() {
    }

    public static boolean isCustomMatchMode() {
        return customMatchMode;
    }

    public static void setCustomMatchMode(boolean on) {
        customMatchMode = on;
    }

    static String userAgent() {
        return "Morphe/" + Utils.getAppVersionName()
                + " (" + Utils.getPatchesReleaseVersion() + ")"
                + " https://github.com/MorpheApp/morphe-patches";
    }

    public static String deviceLanguage() {
        Locale locale = Requester.getAppLocale();
        String lang = locale.getLanguage().toLowerCase(Locale.ROOT);
        // Normalize legacy Android ISO-639 language codes
        switch (lang) {
            case "iw":
                return "he";
            case "in":
                return "id";
            case "ji":
                return "yi";
            case "fil":
                return "tl";
            case "kmr":
                return "ku";
            default:
                break;
        }
        if ("zh".equals(lang)) {
            String script = locale.getScript();
            if ("Hant".equalsIgnoreCase(script)) {
                return "zh-TW";
            }
            if ("Hans".equalsIgnoreCase(script)) {
                return "zh-CN";
            }
            String country = locale.getCountry().toUpperCase(Locale.ROOT);
            if ("TW".equals(country) || "HK".equals(country) || "MO".equals(country)) {
                return "zh-TW";
            }
            return "zh-CN";
        }
        if ("pt".equals(lang)) {
            String country = locale.getCountry().toUpperCase(Locale.ROOT);
            if ("PT".equals(country)) {
                return "pt-PT";
            }
            return "pt-BR";
        }
        return lang;
    }

    public static String translationLanguage() {
        String language = Settings.LYRICS_TRANSLATION_LANGUAGE.get();
        return "DEFAULT".equalsIgnoreCase(language)
                ? deviceLanguage()
                : language.toLowerCase(Locale.ROOT);
    }

    /** "Automatic" resolves to the device language, the way {@link #translationLanguage()} does. */
    public static String romanizationLanguage() {
        String language = Settings.LYRICS_ROMANIZE_LANGUAGE.get();
        return "DEFAULT".equalsIgnoreCase(language)
                ? deviceLanguage()
                : language.toLowerCase(Locale.ROOT);
    }

    /** The resolved ruby language for reading/ruby prompts. */
    public static String rubyLanguage() {
        String language = Settings.LYRICS_RUBY_LANGUAGE.get();
        return "DEFAULT".equalsIgnoreCase(language)
                ? deviceLanguage()
                : language.toLowerCase(Locale.ROOT);
    }

    /** Whether the user turned the romanization off, which leaves only the ruby. */
    public static boolean isRomanizationOff() {
        return "NONE".equalsIgnoreCase(Settings.LYRICS_ROMANIZE_LANGUAGE.get());
    }

    /** Whether romanization is left on "Automatic", which reads the lyrics instead. */
    public static boolean isDefaultRomanizationLanguage() {
        return "DEFAULT".equalsIgnoreCase(Settings.LYRICS_ROMANIZE_LANGUAGE.get());
    }

    /** The leading subtag of a BCP-47 tag, which is what two spellings of one language share. */
    public static String primarySubtag(@Nullable String language) {
        if (language == null) {
            return "";
        }
        int idx = language.indexOf('-');
        String subtag = (idx >= 0 ? language.substring(0, idx) : language).toLowerCase(Locale.ROOT);
        return switch (subtag) {
            case "iw" -> "he";
            case "in" -> "id";
            case "ji" -> "yi";
            case "fil" -> "tl";
            case "kmr" -> "ku";
            default -> subtag;
        };
    }

    @NonNull
    public static String resolvedScript(@Nullable String language) {
        final String declared = declaredScript(language);
        if (!declared.isEmpty()) {
            return declared;
        }
        if (!"zh".equals(primarySubtag(language))) {
            return "";
        }
        final String region = chineseScriptOfRegion(regionSubtag(language));
        if (!region.isEmpty()) {
            return region;
        }
        final Locale device = Requester.getAppLocale();
        final String script = device.getScript();
        if (!script.isEmpty()) {
            return script;
        }
        final String country = chineseScriptOfRegion(device.getCountry());
        // Chinese with no region settles is read as the mainland writes it.
        return country.isEmpty() ? "Hans" : country;
    }

    /** Whether the user reads Chinese as the mainland writes it. */
    public static boolean isSimplifiedChinese() {
        return "Hans".equals(resolvedScript(translationLanguage()));
    }

    @NonNull
    private static String declaredScript(@Nullable String language) {
        if (language == null) {
            return "";
        }
        for (String part : language.split("[-_]")) {
            // Tags arrive spelled both ways round, so the shape counts, not the casing.
            if (part.length() == 4 && isScriptSpelling(part)) {
                return Character.toUpperCase(part.charAt(0))
                        + part.substring(1).toLowerCase(Locale.ROOT);
            }
        }
        return "";
    }

    private static boolean isScriptSpelling(String part) {
        for (int i = 0; i < part.length(); i++) {
            if (!Character.isLetter(part.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    @NonNull
    private static String regionSubtag(@Nullable String language) {
        if (language == null) {
            return "";
        }
        // The leading subtag is the language, so it is skipped.
        final String[] parts = language.split("[-_]");
        for (int i = 1; i < parts.length; i++) {
            final String part = parts[i];
            if (part.length() == 2 && Character.isLetter(part.charAt(0))
                    && Character.isLetter(part.charAt(1))) {
                return part.toUpperCase(Locale.ROOT);
            }
        }
        return "";
    }

    @NonNull
    private static String chineseScriptOfRegion(@Nullable String region) {
        if (region == null) {
            return "";
        }
        if ("TW".equals(region) || "HK".equals(region) || "MO".equals(region)) {
            return "Hant";
        }
        if ("CN".equals(region) || "SG".equals(region) || "MY".equals(region)) {
            return "Hans";
        }
        return "";
    }

    public static long fractionToMs(String fraction) {
        if (fraction == null || fraction.isEmpty()) {
            throw new NumberFormatException("Empty LRC fraction");
        }
        if (fraction.length() == 1) {
            return Long.parseLong(fraction) * 100L;
        }
        if (fraction.length() == 2) {
            return Long.parseLong(fraction) * 10L;
        }
        return Long.parseLong(fraction.substring(0, 3));
    }

    public static List<LyricsLine> applyOffset(List<LyricsLine> lines, long offsetMs) {
        if (lines == null || lines.isEmpty() || offsetMs == 0L) {
            return lines;
        }
        List<LyricsLine> adjusted = new ArrayList<>(lines.size());
        for (LyricsLine line : lines) {
            long newStart = line.startTimeMs() + offsetMs;
            long newEnd = line.endTimeMs() != LyricsLine.NO_TIME
                    ? line.endTimeMs() + offsetMs : LyricsLine.NO_TIME;
            List<Word> adjustedWords = new ArrayList<>(line.words().size());
            for (Word word : line.words()) {
                adjustedWords.add(new Word(
                        word.startMs() + offsetMs,
                        word.endMs() + offsetMs,
                        word.text(),
                        word.romaji(),
                        word.endsWithSpace(),
                        word.ruby()));
            }
            adjusted.add(new LyricsLine(newStart, newEnd, line.text(), adjustedWords,
                    line.agentId(), line.isDuet(), line.isBG(), line.songPart()));
        }
        return adjusted;
    }

    /**
     * Opens a GET connection. LRCLIB asks clients to identify themselves in the
     * User-Agent header, and rate limits requests that do not.
     */
    static HttpURLConnection openConnection(String url) throws IOException {
        // A canceled lookup may still be finishing one blocking request.
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Lyrics lookup cancelled");
        }
        HttpURLConnection connection = Requester.openConnection(url);
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MILLISECONDS);
        connection.setReadTimeout(READ_TIMEOUT_MILLISECONDS);
        connection.setRequestProperty("User-Agent", userAgent());
        return connection;
    }

    /**
     * Opens a GET connection with configurable timeouts and extra headers.
     */
    static HttpURLConnection openConnection(String url,
                                            Map<String, String> headers) throws IOException {
        // A canceled lookup may still be finishing one blocking request.
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Lyrics lookup cancelled");
        }
        HttpURLConnection connection = Requester.openConnection(url);
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("User-Agent", userAgent());
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                connection.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        return connection;
    }

    /**
     * Opens a POST connection with a JSON body. The caller reads the response with
     * one of the {@link app.morphe.extension.shared.requests.Requester} parse helpers.
     */
    static HttpURLConnection postJson(String url, String json) throws IOException {
        return postConnection(url, json, "application/json; charset=utf-8", null);
    }

    static HttpURLConnection postJson(String url, String json, Map<String, String> headers) throws IOException {
        return postConnection(url, json, "application/json; charset=utf-8", headers);
    }

    /**
     * Opens a POST connection with an {@code application/x-www-form-urlencoded} body.
     */
    static HttpURLConnection postForm(String url, String form) throws IOException {
        return postConnection(url, form, "application/x-www-form-urlencoded; charset=utf-8", null);
    }

    /**
     * Like {@link #postForm(String, String)} but with extra request headers, applied
     * before the body is written so they are sent.
     */
    static HttpURLConnection postForm(String url, String form, Map<String, String> headers) throws IOException {
        return postConnection(url, form, "application/x-www-form-urlencoded; charset=utf-8", headers);
    }

    private static HttpURLConnection postConnection(String url, String body, String contentType,
                                                    Map<String, String> headers) throws IOException {
        // A canceled lookup may still be finishing one blocking request.
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Lyrics lookup cancelled");
        }
        HttpURLConnection connection = Requester.openConnection(url);
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MILLISECONDS);
        connection.setReadTimeout(READ_TIMEOUT_MILLISECONDS);
        connection.setRequestProperty("User-Agent", userAgent());
        connection.setRequestProperty("Content-Type", contentType);
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                connection.setRequestProperty(entry.getKey(), entry.getValue());
            }
        }
        connection.setDoOutput(true);
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream output = connection.getOutputStream()) {
            output.write(bytes);
        }
        return connection;
    }

    static void logFailure(String provider, HttpURLConnection connection) {
        try {
            final int code = connection.getResponseCode();
            String message = connection.getResponseMessage();
            Logger.printDebug(() -> provider + " request failed: " + code + " " + message);
        } catch (IOException ex) {
            Logger.printDebug(() -> provider + " request failed", ex);
        } finally {
            connection.disconnect();
        }
    }

    /**
     * The Charset overload of encode() needs API 33, so the charset is named instead.
     */
    @SuppressWarnings("CharsetObjectCanBeUsed")
    static String encode(String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, "UTF-8");
    }

    /** Walks nested objects, returning null as soon as a link of the chain is missing. */
    @Nullable
    static JSONObject optPath(@Nullable JSONObject root, String... keys) {
        JSONObject node = root;
        for (String key : keys) {
            if (node == null) {
                return null;
            }
            node = node.optJSONObject(key);
        }
        return node;
    }

    @Nullable
    static String optString(JSONObject object, String key) {
        if (object.isNull(key)) {
            return null;
        }
        final String value = object.optString(key, "");
        return value.trim().isEmpty() ? null : value;
    }

    static List<String> stringList(JSONArray array) {
        if (array == null) {
            return List.of();
        }
        final List<String> out = new ArrayList<>(array.length());
        for (int i = 0; i < array.length(); i++) {
            final String value = array.optString(i, "").trim();
            if (!value.isEmpty()) {
                out.add(value);
            }
        }
        return out;
    }

    static List<String> stringList(JSONObject object, String key) {
        return stringList(object.optJSONArray(key));
    }

    static String parseGzipString(HttpURLConnection connection) throws IOException {
        final InputStream raw = connection.getInputStream();
        final InputStream stream = "gzip".equalsIgnoreCase(connection.getContentEncoding())
                ? new GZIPInputStream(raw) : raw;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            final StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        }
    }

    static JSONObject parseGzipJsonObject(HttpURLConnection connection)
            throws org.json.JSONException, IOException {
        return new JSONObject(parseGzipString(connection));
    }

    static List<LyricsLine> parsePlainTextLines(String text) {
        final List<LyricsLine> lines = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return lines;
        }
        for (String line : text.split("\\r?\\n")) {
            final String trimmed = line.trim();
            if (!trimmed.isEmpty()) {
                lines.add(new LyricsLine(LyricsLine.NO_TIME, trimmed));
            }
        }
        return lines;
    }

    static void throttle(AtomicLong lastRequestTime, long minIntervalMs) {
        final long now = System.currentTimeMillis();
        final long elapsed = now - lastRequestTime.get();
        if (elapsed < minIntervalMs) {
            try {
                Thread.sleep(minIntervalMs - elapsed);
            } catch (InterruptedException ex) {
                Logger.printDebug(() -> "Interrupted during throttle sleep", ex);
                // Sleeping cleared the flag, so it is restored to keep the cancellation
                // visible to the lookup that is being abandoned.
                Thread.currentThread().interrupt();
            }
        }
        lastRequestTime.set(System.currentTimeMillis());
    }

    public static PreparedTrack prepare(TrackInfo track) {
        return new PreparedTrack(track);
    }

    /**
     * Normalizes a string for matching: NFKC, lowercase, canonical Chinese spelling, decoration strip,
     * fullwidth punctuation fold and whitespace collapse. Semantic decorations
     * (years, part numbers, live/acoustic/feat, …) are kept so that distinct
     * versions do not collapse into a false EQUAL.
     */
    public static String normalizeForMatch(@Nullable String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.trim();
        if (s.isEmpty()) {
            return "";
        }
        s = Normalizer.normalize(s, Normalizer.Form.NFKC);
        s = s.toLowerCase(Locale.ROOT);
        // Providers spell metadata Traditional or Simplified, so both are compared. ICU does
        // not map 妳 to 你, so that observed title variant is folded explicitly.
        s = CharactersConverter.toSimplified(s).replace('妳', '你');
        s = stripDecorations(s);
        s = foldPunctuation(s);
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    private static String stripDecorations(String s) {
        String regex = LyricsFilterDefaults.LYRICS_CUSTOM_REGEX.get();
        if (regex.trim().isEmpty()) {
            return s;
        }
        Pattern pattern = decorationPattern;
        if (pattern == null || !regex.equals(decorationRegexSource)) {
            try {
                pattern = Pattern.compile(regex);
            } catch (Exception ex) {
                Logger.printDebug(() -> "Invalid lyrics decoration regex", ex);
                return s;
            }
            decorationPattern = pattern;
            decorationRegexSource = regex;
        }
        return pattern.matcher(s).replaceAll("");
    }

    private static String foldPunctuation(String s) {
        final StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0xFF01 && c <= 0xFF5E) {
                c = (char) (c - 0xFEE0);
            }
            if (c == '·' || c == '•' || c == '・') {
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    public static boolean containsEither(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) {
            return false;
        }
        if (a.contains(b) || b.contains(a)) {
            final String shorter = a.length() <= b.length() ? a : b;
            final String longer = a.length() <= b.length() ? b : a;
            if (shorter.length() < 4 && !isCjk(shorter.charAt(0))) {
                return longer.length() <= shorter.length() + 6;
            }
            if (shorter.length() < 2 && isCjk(shorter.charAt(0))) {
                return longer.length() <= shorter.length() + 4;
            }
            return true;
        }
        return false;
    }

    private static boolean splitArtistHits(String candidateArtist, String queryArtist) {
        final String[] parts = candidateArtist.split("\\s*(?:和|&|feat\\.?|ft\\.?|,|/|×)\\s*");
        for (String part : parts) {
            final String p = part.trim();
            if (p.isEmpty()) {
                continue;
            }
            if (p.equals(queryArtist)) {
                return true;
            }
            if (p.length() >= 2 || queryArtist.length() < 4) {
                if (containsEither(p, queryArtist)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isCjk(char c) {
        return Character.UnicodeScript.of(c) == Character.UnicodeScript.HAN;
    }

    static double jaccard(String a, String b) {
        final Set<String> ta = tokens(a);
        final Set<String> tb = tokens(b);
        if (ta.isEmpty() || tb.isEmpty()) {
            return 0;
        }
        int inter = 0;
        for (String t : ta) {
            if (tb.contains(t)) {
                inter++;
            }
        }
        final int union = ta.size() + tb.size() - inter;
        return union == 0 ? 0 : (double) inter / union;
    }

    private static Set<String> tokens(String s) {
        final Set<String> out = new LinkedHashSet<>();
        final StringBuilder cur = new StringBuilder();
        for (int i = 0; i < s.length(); ) {
            final int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isLetterOrDigit(cp)) {
                cur.appendCodePoint(cp);
            } else {
                //noinspection SizeReplaceableByIsEmpty
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
            }
        }
        //noinspection SizeReplaceableByIsEmpty
        if (cur.length() > 0) {
            out.add(cur.toString());
        }
        return out;
    }

    /**
     * High-match gate for first display / fallback eligibility.
     * Channel A: aggregate score ≥ 7; Channel B: exact title with no counter-evidence.
     * Artist mismatch is a hard veto.
     */
    public static boolean isHighMatch(MatchVerdict v) {
        if (customMatchMode) {
            return true;
        }
        if (v.title() == Evidence.NONE || v.title() == Evidence.MISSING) {
            return false;
        }
        if (v.artist() == Evidence.MISMATCH) {
            return false;
        }
        if (v.score() >= 7) {
            return v.duration() != Evidence.MISMATCH || v.artist() == Evidence.MATCH;
        }
        return v.title() == Evidence.EQUAL
                && v.duration() != Evidence.MISMATCH
                && v.album() != Evidence.MISMATCH;
    }

    public static MatchVerdict evaluate(String title, String artist, long durationSec,
                                        TrackInfo track) {
        return prepare(track).evaluate(title, artist, durationSec, null);
    }

    public static int scoreTrackCandidate(String title, String artist, long durationSec,
                                          TrackInfo track) {
        return scoreTrackCandidate(title, artist, durationSec, null, track);
    }

    public static int scoreTrackCandidate(String title, String artist, long durationSec,
                                          @Nullable String album, TrackInfo track) {
        // Evaluated before adapters swap the candidate metadata for the query metadata
        // through FetchResult.of(lyrics, track), so a counter-matching title is still rejected.
        MatchVerdict verdict = prepare(track).evaluate(title, artist, durationSec, album);
        if (customMatchMode) {
            return rankScore(verdict);
        }
        return isHighMatch(verdict) ? verdict.score() : -1;
    }

    static int rankScore(MatchVerdict v) {
        if (v.artist() == Evidence.MISMATCH) {
            return 2;
        }
        return Math.max(v.score(), 5);
    }

    public static int syncRank(Lyrics lyrics) {
        for (LyricsLine line : lyrics.lines()) {
            if (line.hasWordTimings()) {
                return 2;
            }
        }
        return lyrics.synced() ? 1 : 0;
    }

    public static int scoreLyricsCandidate(String title, String artist, long durationSec,
                                           Lyrics lyrics, TrackInfo track) {
        int score = scoreTrackCandidate(title, artist, durationSec, track);
        return score < 0 ? score : score + syncRank(lyrics);
    }

    /**
     * Queue composite: match score dominates; sync rank breaks ties;
     * a query-variant penalty keeps original metadata ahead of derived variants.
     */
    public static int composite(int matchScore, Lyrics lyrics, int variantPenalty) {
        return matchScore * 10 + syncRank(lyrics) - variantPenalty;
    }

    public static int scoreSingleResult(Lyrics lyrics) {
        return 6 + syncRank(lyrics);
    }

    public enum Evidence {
        EQUAL,
        MATCH,
        PARTIAL,
        MISSING,
        MISMATCH,
        NONE
    }

    public static final class MusicBrainzClient {

        private static final String BASE_URL = "https://musicbrainz.org/ws/2/";

        private static final long REQUEST_THROTTLE_MS = 1100;

        private static final int RESULT_LIMIT = 10;

        private static final AtomicLong lastRequestTime = new AtomicLong();

        private MusicBrainzClient() {
        }

        /** Recording titles matching {@code query}, most relevant first, de-duplicated. */
        @NonNull
        public static List<String> suggestTitles(@NonNull String query) {
            String clause = phrase("recording", query);
            if (clause == null) {
                return List.of();
            }
            String url = BASE_URL + "recording?query=" + clause
                    + "&fmt=json&limit=" + RESULT_LIMIT;
            try {
                JSONArray recordings = search(url).optJSONArray("recordings");
                if (recordings == null) {
                    return List.of();
                }
                LinkedHashSet<String> titles = new LinkedHashSet<>();
                for (int i = 0; i < recordings.length(); i++) {
                    JSONObject recording = recordings.optJSONObject(i);
                    if (recording == null) {
                        continue;
                    }
                    String title = recording.optString("title", "").trim();
                    if (!title.isEmpty()) {
                        titles.add(title);
                    }
                }
                return List.copyOf(titles);
            } catch (Exception ex) {
                Logger.printDebug(() -> "MusicBrainz title suggestions failed", ex);
                return List.of();
            }
        }

        /** Artist names and aliases matching {@code query}, de-duplicated. */
        @NonNull
        public static List<String> suggestArtists(@NonNull String query) {
            String clause = phrase("artist", query);
            if (clause == null) {
                return List.of();
            }
            String url = BASE_URL + "artist?query=" + clause
                    + "&fmt=json&limit=" + RESULT_LIMIT;
            try {
                JSONArray artists = search(url).optJSONArray("artists");
                if (artists == null) {
                    return List.of();
                }
                LinkedHashSet<String> names = new LinkedHashSet<>();
                for (int i = 0; i < artists.length(); i++) {
                    JSONObject artist = artists.optJSONObject(i);
                    if (artist == null) {
                        continue;
                    }
                    String name = artist.optString("name", "").trim();
                    if (!name.isEmpty()) {
                        names.add(name);
                    }
                    JSONArray aliases = artist.optJSONArray("aliases");
                    if (aliases == null) {
                        continue;
                    }
                    for (int j = 0; j < aliases.length(); j++) {
                        JSONObject alias = aliases.optJSONObject(j);
                        if (alias == null) {
                            continue;
                        }
                        String aliasName = alias.optString("name", "").trim();
                        if (!aliasName.isEmpty()) {
                            names.add(aliasName);
                        }
                    }
                }
                return List.copyOf(names);
            } catch (Exception ex) {
                Logger.printDebug(() -> "MusicBrainz artist suggestions failed", ex);
                return List.of();
            }
        }

        private static JSONObject search(String url) throws Exception {
            throttle(lastRequestTime, REQUEST_THROTTLE_MS);
            HttpURLConnection connection = openConnection(url);
            try {
                if (connection.getResponseCode() != Requester.HTTP_STATUS_CODE_SUCCESS) {
                    return new JSONObject();
                }
                return parseGzipJsonObject(connection);
            } finally {
                connection.disconnect();
            }
        }

        /**
         * The Lucene {@code field:"phrase"} clause for the query, URL encoded, or null when the
         * query says nothing or cannot be encoded. Only quotes and backslashes would end a quoted
         * phrase, so everything else in the typed term is kept as it is.
         */
        @Nullable
        private static String phrase(String field, String query) {
            String trimmed = query == null ? "" : query.trim();
            String cleaned = trimmed.replace("\\", " ").replace("\"", " ").trim();
            if (cleaned.isEmpty()) {
                return null;
            }
            try {
                return encode(field + ":\"" + cleaned + "\"");
            } catch (Exception ex) {
                Logger.printDebug(() -> "MusicBrainz query encoding failed", ex);
                return null;
            }
        }
    }

    /**
     * Result of evaluating a candidate's metadata against a prepared track.
     *
     * @param score    0–11 ranking score (title 0–5 + artist 0–3 + duration 0–2 + album 0–1)
     * @param title    title evidence
     * @param artist   artist evidence
     * @param duration duration evidence (MISSING when either side unknown)
     * @param album    album evidence
     */
    public record MatchVerdict(int score, Evidence title, Evidence artist,
                               Evidence duration, Evidence album) {

        public static MatchVerdict videoIdTrust() {
            return new MatchVerdict(VIDEO_ID_TRUST, Evidence.MATCH, Evidence.MISSING,
                    Evidence.MISSING, Evidence.MISSING);
        }
    }

    public static final class PreparedTrack {
        final String title;
        final String artist;
        final String album;
        final int durationSec;
        final boolean titleValid;

        PreparedTrack(TrackInfo track) {
            this.title = normalizeForMatch(track.title());
            this.artist = normalizeForMatch(track.artist());
            this.album = normalizeForMatch(track.album());
            this.durationSec = track.durationSeconds();
            this.titleValid = !this.title.isEmpty();
        }

        public MatchVerdict evaluate(@Nullable String title, @Nullable String artist,
                                     long durationSec, @Nullable String album) {
            final String t = normalizeForMatch(title);
            final String a = normalizeForMatch(artist);
            final String al = normalizeForMatch(album);

            final Evidence titleEv;
            int titleScore;
            if (!titleValid) {
                titleEv = Evidence.MISSING;
                titleScore = 0;
            } else if (t.isEmpty()) {
                titleEv = Evidence.NONE;
                titleScore = 0;
            } else if (t.equals(this.title)) {
                titleEv = Evidence.EQUAL;
                titleScore = 5;
            } else if (containsEither(t, this.title)) {
                titleEv = Evidence.MATCH;
                titleScore = 3;
            } else {
                final double j = jaccard(t, this.title);
                if (j >= 0.6) {
                    titleEv = Evidence.PARTIAL;
                    titleScore = 2;
                } else if (j >= 0.35) {
                    titleEv = Evidence.PARTIAL;
                    titleScore = 1;
                } else {
                    titleEv = Evidence.NONE;
                    titleScore = 0;
                }
            }

            final Evidence artistEv;
            int artistScore;
            if (a.isEmpty()) {
                artistEv = Evidence.MISSING;
                artistScore = 0;
            } else if (this.artist.isEmpty()) {
                artistEv = Evidence.MISSING;
                artistScore = 0;
            } else if (a.equals(this.artist)) {
                artistEv = Evidence.MATCH;
                artistScore = 3;
            } else if (containsEither(a, this.artist)) {
                artistEv = Evidence.MATCH;
                artistScore = 3;
            } else if (splitArtistHits(a, this.artist)) {
                artistEv = Evidence.PARTIAL;
                artistScore = 1;
            } else {
                artistEv = Evidence.MISMATCH;
                artistScore = 0;
            }

            final Evidence durationEv;
            int durationScore;
            if (durationSec <= 0 || this.durationSec <= 0) {
                durationEv = Evidence.MISSING;
                durationScore = 0;
            } else {
                final long delta = Math.abs(durationSec - this.durationSec);
                if (delta > 15) {
                    durationEv = Evidence.MISMATCH;
                    durationScore = 0;
                } else if (delta <= 2) {
                    durationEv = Evidence.MATCH;
                    durationScore = 2;
                } else if (delta <= 5) {
                    durationEv = Evidence.PARTIAL;
                    durationScore = 1;
                } else {
                    durationEv = Evidence.PARTIAL;
                    durationScore = 0;
                }
            }

            final Evidence albumEv;
            int albumScore;
            if (al.isEmpty() || this.album.isEmpty()) {
                albumEv = Evidence.MISSING;
                albumScore = 0;
            } else if (al.equals(this.album) || containsEither(al, this.album)) {
                albumEv = Evidence.MATCH;
                albumScore = 1;
            } else {
                albumEv = Evidence.MISMATCH;
                albumScore = 0;
            }

            return new MatchVerdict(titleScore + artistScore + durationScore + albumScore,
                    titleEv, artistEv, durationEv, albumEv);
        }
    }
}
