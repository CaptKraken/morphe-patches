/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2625
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.parsers;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import app.morphe.extension.music.patches.lyrics.model.Lyrics;
import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.model.Word;
import app.morphe.extension.music.patches.lyrics.utils.TextTrim;
import app.morphe.extension.shared.Logger;

public final class LyricsFileParser {

    private static final String[] CREDIT_META_KEYS = {"title", "artist", "album"};

    private LyricsFileParser() {
    }

    @Nullable
    public static Lyrics parse(@Nullable String yaml, String providerName) {
        return parse(yaml, providerName, null);
    }

    @Nullable
    public static Lyrics parse(@Nullable String yaml, String providerName,
                               @Nullable String sourceUrl) {
        if (yaml == null || yaml.isEmpty()) {
            return null;
        }

        List<String> lines = new ArrayList<>();
        for (String raw : yaml.split("\\r?\\n")) {
            if (!raw.trim().isEmpty()) {
                lines.add(raw.replace("\t", "    "));
            }
        }
        if (lines.isEmpty()) {
            return null;
        }

        Cursor cursor = new Cursor();
        Object root = readValue(lines, cursor, 0);
        if (!(root instanceof Map<?, ?> top)) {
            return null;
        }

        // FIXME: reject files whose "version" is not exactly 1.0 once all files migrate

        List<String> creditLines = new ArrayList<>();
        boolean instrumental = false;
        Object metaObject = top.get("metadata");
        if (metaObject instanceof Map<?, ?> metadata) {
            Object instrumentalValue = metadata.get("instrumental");
            if (instrumentalValue instanceof Boolean) {
                instrumental = (Boolean) instrumentalValue;
            } else if (instrumentalValue instanceof String) {
                instrumental = Boolean.parseBoolean((String) instrumentalValue);
            }
            for (String key : CREDIT_META_KEYS) {
                Object value = metadata.get(key);
                if (value instanceof String && !((String) value).isEmpty()) {
                    creditLines.add(key + ": " + value);
                }
            }
        }

        List<LyricsLine> parsedLines = new ArrayList<>();
        Object linesObject = top.get("lines");
        if (linesObject instanceof List) {
            for (Object item : (List<?>) linesObject) {
                LyricsLine line = toLine(item);
                if (line != null) {
                    parsedLines.add(line);
                }
            }
        }

        List<String> creditLinesOut = creditLines.isEmpty() ? null : creditLines;

        if (instrumental) {
            return parsedLines.isEmpty()
                    ? Lyrics.NOT_FOUND
                    : fileLyrics(parsedLines, providerName, true, creditLinesOut, yaml, sourceUrl);
        }

        boolean synced = parsedLines.stream()
                .anyMatch(line -> line.startTimeMs() != LyricsLine.NO_TIME);
        if (synced) {
            return fileLyrics(parsedLines, providerName, true, creditLinesOut, yaml, sourceUrl);
        }

        Object plainObject = top.get("plain");
        if (plainObject instanceof String) {
            List<LyricsLine> plain = LRCParser.parsePlain((String) plainObject);
            if (!plain.isEmpty()) {
                return fileLyrics(plain, providerName, false, creditLinesOut, yaml, sourceUrl);
            }
        }
        return Lyrics.NOT_FOUND;
    }

    private static Lyrics fileLyrics(List<LyricsLine> lines, String providerName, boolean synced,
                                     @Nullable List<String> creditLines, String yaml,
                                     @Nullable String sourceUrl) {
        return new Lyrics(lines, providerName, synced, null, null, null,
                null, creditLines, yaml, "lyricsfile.yaml", sourceUrl, null, null);
    }

    @Nullable
    private static LyricsLine toLine(Object item) {
        if (!(item instanceof Map<?, ?> map)) {
            return null;
        }

        Object textObject = map.get("text");
        String text = textObject instanceof String ? (String) textObject : "";

        List<Word> words = new ArrayList<>();
        boolean wordTimingsUsable = true;
        Object wordsObject = map.get("words");
        if (wordsObject instanceof List) {
            for (Object wordObject : (List<?>) wordsObject) {
                if (!(wordObject instanceof Map<?, ?> wordMap)) {
                    continue;
                }
                Object wordText = wordMap.get("text");
                String wordString = wordText instanceof String ? (String) wordText : "";
                long start = asLong(wordMap.get("start_ms"));
                // A word with no start of its own has nothing to be lit by, and the ends its
                // neighbors lend it would be counted off a number that is not a time. The
                // line keeps its own timing and is sung in one go instead. The text is rebuilt
                // from the words below, so the words are only given up after that has happened.
                if (start < 0) {
                    wordTimingsUsable = false;
                    break;
                }
                long end = asLong(wordMap.get("end_ms"));
                words.add(new Word(start, end, wordString));
            }
        }

        if (text.isEmpty()) {
            StringBuilder builder = new StringBuilder();
            for (Word word : words) {
                String wordText = word.text();
                if (wordText.isEmpty()) {
                    continue;
                }
                //noinspection SizeReplaceableByIsEmpty
                if (builder.length() > 0) {
                    builder.append(' ');
                }
                builder.append(wordText);
            }
            text = builder.toString();
        }

        if (!wordTimingsUsable) {
            words.clear();
        }

        LRCParser.inferMissingWordEnds(words, 800);

        return new LyricsLine(asLong(map.get("start_ms")), text, words);
    }

    private static long asLong(Object value) {
        if (value instanceof Long) {
            return (Long) value;
        }
        if (value instanceof Integer) {
            return (Integer) value;
        }
        if (value instanceof String) {
            try {
                return Long.parseLong(((String) value).trim());
            } catch (NumberFormatException ex) {
                Logger.printDebug(() -> "Could not parse long value in LyricsFileParser", ex);
                return LyricsLine.NO_TIME;
            }
        }
        return LyricsLine.NO_TIME;
    }

    private static Object readValue(List<String> lines, Cursor cursor, int indent) {
        if (cursor.index >= lines.size()) {
            return new LinkedHashMap<>();
        }
        if (isSequenceItem(lines.get(cursor.index), indent)) {
            return readSequence(lines, cursor, indent);
        }
        return readMapping(lines, cursor, indent);
    }

    private static boolean isSequenceItem(String line, int indent) {
        return indentOf(line) == indent && line.trim().startsWith("- ");
    }

    private static Object readSequence(List<String> lines, Cursor cursor, int indent) {
        List<Object> sequence = new ArrayList<>();
        while (cursor.index < lines.size()) {
            String line = lines.get(cursor.index);
            if (indentOf(line) != indent || !line.trim().startsWith("- ")) {
                break;
            }
            String rest = line.trim().substring(2).trim();
            if (rest.isEmpty()) {
                cursor.index++;
                if (cursor.index >= lines.size()) {
                    break;
                }
                sequence.add(readValue(lines, cursor, indent + 2));
            } else {
                lines.set(cursor.index, TextTrim.spaces(indent + 2) + rest);
                sequence.add(readMapping(lines, cursor, indent + 2));
            }
        }
        return sequence;
    }

    private static Object readMapping(List<String> lines, Cursor cursor, int indent) {
        Map<String, Object> map = new LinkedHashMap<>();
        while (cursor.index < lines.size()) {
            String line = lines.get(cursor.index);
            if (indentOf(line) != indent) {
                break;
            }
            int colon = line.indexOf(':');
            if (colon < 0) {
                cursor.index++;
                continue;
            }
            String key = line.substring(indent, colon).trim();
            String value = line.substring(colon + 1).trim();
            cursor.index++;

            if (value.isEmpty()) {
                if (cursor.index < lines.size() && indentOf(lines.get(cursor.index)) > indent) {
                    map.put(key, readValue(lines, cursor, indentOf(lines.get(cursor.index))));
                } else {
                    map.put(key, "");
                }
            } else if (isBlockScalar(value)) {
                map.put(key, readBlockScalar(lines, cursor, indent));
            } else {
                map.put(key, unquote(value));
            }
        }
        return map;
    }

    private static boolean isBlockScalar(String value) {
        return value.equals("|") || value.equals(">") || value.startsWith("|-")
                || value.startsWith(">-") || value.startsWith("|+") || value.startsWith(">+");
    }

    private static String readBlockScalar(List<String> lines, Cursor cursor, int indent) {
        if (cursor.index >= lines.size()) {
            return "";
        }
        // The first line of the block sets the indentation stripped from all of them.
        int base = indentOf(lines.get(cursor.index));
        if (base <= indent) {
            return "";
        }

        StringBuilder builder = new StringBuilder();
        while (cursor.index < lines.size()) {
            String line = lines.get(cursor.index);
            if (indentOf(line) <= indent) {
                break;
            }
            //noinspection SizeReplaceableByIsEmpty
            if (builder.length() > 0) {
                builder.append('\n');
            }
            int strip = Math.min(base, line.length());
            builder.append(line.substring(strip));
            cursor.index++;
        }
        return builder.toString();
    }

    private static String unquote(String value) {
        String string = value.trim();
        if (string.length() >= 2 && string.startsWith("'") && string.endsWith("'")) {
            return string.substring(1, string.length() - 1).replace("''", "'");
        }
        if (string.length() >= 2 && string.startsWith("\"") && string.endsWith("\"")) {
            return string.substring(1, string.length() - 1)
                    .replace("\\n", "\n")
                    .replace("\\t", "\t")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
        }
        return string;
    }

    private static int indentOf(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    private static final class Cursor {
        int index;
    }
}
