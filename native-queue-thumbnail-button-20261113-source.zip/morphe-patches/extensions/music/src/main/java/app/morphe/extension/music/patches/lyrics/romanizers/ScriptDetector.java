/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/3750
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.romanizers;

import androidx.annotation.Nullable;

import java.util.List;

/**
 * Decides which script a line is written in, since a romanizer is only correct for one of them
 * and the wrong one reads as a translation of something else. Lines are judged on their own:
 * a song mixes scripts, which is what a verdict for the whole song gets wrong.
 *
 * <p>The counters are indexed by {@link Script}, so a new script only needs a line in {@link #classify}.
 *
 * <p>The per-character checks below are the only place these blocks are listed, so another reader
 * of scripts, such as {@link app.morphe.extension.music.patches.lyrics.derive.LyricsLanguageDetector}, counts them here rather than repeating them.
 */
public final class ScriptDetector {

    private static final Script[] SCRIPTS = Script.values();
    /** Kana below this, in a line of Han characters, is a loanword rather than Japanese. */
    private static final int MIN_KANA = 3;
    private static final int KANA_PER_HAN = 6;
    /** Hiragana is written for grammar and never for a loanword, so its count settles a line. */
    private static final int HIRAGANA = SCRIPTS.length;
    private static final int COUNTS = SCRIPTS.length + 1;

    private ScriptDetector() {
    }

    @Nullable
    public static Script detect(String line) {
        if (line == null) return null;
        return classify(count(line));
    }

    public static Script detect(List<String> lines) {
        int[] total = new int[COUNTS];
        for (String line : lines) {
            if (line == null) continue;
            add(total, count(line));
        }
        return classify(total);
    }

    private static int[] count(CharSequence line) {
        int[] found = new int[COUNTS];
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (isHan(c)) {
                found[Script.HAN.ordinal()]++;
            } else if (isKana(c)) {
                found[Script.JAPANESE.ordinal()]++;
                if (isHiragana(c)) found[HIRAGANA]++;
            } else if (isHangul(c)) {
                found[Script.KOREAN.ordinal()]++;
            } else if (isCyrillic(c)) {
                found[Script.CYRILLIC.ordinal()]++;
            } else if (isGeorgian(c)) {
                found[Script.GEORGIAN.ordinal()]++;
            } else if (isArmenian(c)) {
                found[Script.ARMENIAN.ordinal()]++;
            } else if (isGreek(c)) {
                found[Script.GREEK.ordinal()]++;
            } else if (isHebrew(c)) {
                found[Script.HEBREW.ordinal()]++;
            } else if (isArabic(c)) {
                found[Script.ARABIC.ordinal()]++;
            } else if (isEthiopic(c)) {
                found[Script.ETHIOPIC.ordinal()]++;
            } else if (isSyriac(c)) {
                found[Script.SYRIAC.ordinal()]++;
            }
        }
        return found;
    }

    private static void add(int[] total, int[] found) {
        for (int i = 0; i < found.length; i++) {
            total[i] += found[i];
        }
    }

    private static Script classify(int[] found) {
        int han = found[Script.HAN.ordinal()];
        int kana = found[Script.JAPANESE.ordinal()];
        int hangul = found[Script.KOREAN.ordinal()];
        int cyrillic = found[Script.CYRILLIC.ordinal()];
        int georgian = found[Script.GEORGIAN.ordinal()];
        int armenian = found[Script.ARMENIAN.ordinal()];
        int greek = found[Script.GREEK.ordinal()];
        int hebrew = found[Script.HEBREW.ordinal()];
        int arabic = found[Script.ARABIC.ordinal()];
        int ethiopic = found[Script.ETHIOPIC.ordinal()];
        int syriac = found[Script.SYRIAC.ordinal()];

        if (hangul > 0 && hangul * 2 >= han + kana) return Script.KOREAN;
        // Kana with no Han at all is Japanese: nothing else that uses kana has none. Hiragana settles a
        // line with Han too, being what grammar is written in and what no language borrows a word into.
        // Katakana a Chinese line carries for a loanword, so it is only counted.
        if (kana > 0 && (han == 0 || found[HIRAGANA] > 0
                || (kana >= MIN_KANA && kana * KANA_PER_HAN >= han))) {
            return Script.JAPANESE;
        }
        if (han > 0) return Script.HAN;
        // Each of these is a block of its own, so none of them can crowd the others out.
        if (cyrillic > 0) return Script.CYRILLIC;
        if (georgian > 0) return Script.GEORGIAN;
        if (armenian > 0) return Script.ARMENIAN;
        if (greek > 0) return Script.GREEK;
        if (hebrew > 0) return Script.HEBREW;
        if (arabic > 0) return Script.ARABIC;
        if (ethiopic > 0) return Script.ETHIOPIC;
        return syriac > 0 ? Script.SYRIAC : Script.OTHER;
    }

    public static boolean contains(@Nullable CharSequence text, Character.UnicodeScript... scripts) {
        if (text == null) return false;
        for (int i = 0; i < text.length(); ) {
            final int cp = Character.codePointAt(text, i);
            i += Character.charCount(cp);
            final Character.UnicodeScript script = Character.UnicodeScript.of(cp);
            for (Character.UnicodeScript wanted : scripts) {
                if (script == wanted) return true;
            }
        }
        return false;
    }

    public static boolean containsKana(@Nullable CharSequence text) {
        return contains(text, Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA);
    }

    public static boolean containsCjk(@Nullable CharSequence text) {
        return contains(text, Character.UnicodeScript.HAN, Character.UnicodeScript.HIRAGANA,
                Character.UnicodeScript.KATAKANA, Character.UnicodeScript.HANGUL);
    }

    public static boolean containsRtl(@Nullable CharSequence text) {
        return contains(text, Character.UnicodeScript.ARABIC, Character.UnicodeScript.HEBREW);
    }

    /**
     * Checks if a line predominantly consists of RTL characters (Arabic, Hebrew, Persian, etc.).
     * Requires RTL characters to meet or exceed LTR characters, avoiding false positives from stray symbols.
     */
    public static boolean isLineRtl(@Nullable CharSequence text) {
        //noinspection SizeReplaceableByIsEmpty
        if (text == null || text.length() == 0) {
            return false;
        }
        int rtlCount = 0;
        int ltrCount = 0;
        final int len = text.length();
        for (int i = 0; i < len; ) {
            int cp = Character.codePointAt(text, i);
            i += Character.charCount(cp);
            byte dir = Character.getDirectionality(cp);
            if (dir == Character.DIRECTIONALITY_RIGHT_TO_LEFT || dir == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC) {
                rtlCount++;
            } else if (dir == Character.DIRECTIONALITY_LEFT_TO_RIGHT) {
                ltrCount++;
            }
        }
        return rtlCount > 0 && rtlCount >= ltrCount;
    }

    /** The blocks a modern lyric line is written with. */
    public static boolean isHan(char c) {
        return (c >= 0x4E00 && c <= 0x9FFF)
                || (c >= 0x3400 && c <= 0x4DBF)
                || (c >= 0xF900 && c <= 0xFAFF);
    }

    public static boolean isKana(char c) {
        return (c >= 0x3040 && c <= 0x309F)
                || (c >= 0x30A0 && c <= 0x30FF)
                || (c >= 0x31F0 && c <= 0x31FF);
    }

    static boolean isHangul(char c) {
        return c >= 0xAC00 && c <= 0xD7A3;
    }

    /** A code point written as a syllable of its own: Han, Hangul or kana. */
    public static boolean isCjkCodePoint(int cp) {
        return cp <= Character.MAX_VALUE
                && (isHan((char) cp) || isKana((char) cp) || isHangul((char) cp));
    }

    /** Hangul syllables, jamo and compatibility jamo, which is every way Korean is spelled. */
    public static boolean isAnyHangul(char c) {
        return isHangul(c) || (c >= 0x1100 && c <= 0x11FF) || (c >= 0x3130 && c <= 0x318F);
    }

    static boolean isHiragana(char c) {
        return (c >= 0x3041 && c <= 0x3096) || c == 0x309D || c == 0x309E;
    }

    public static boolean isGreek(char c) {
        return (c >= 0x0370 && c <= 0x03FF) || (c >= 0x1F00 && c <= 0x1FFF);
    }

    static boolean isCyrillic(char c) {
        return (c >= 0x0400 && c <= 0x04FF) || (c >= 0x0500 && c <= 0x052F);
    }

    public static boolean isGeorgian(char c) {
        return (c >= 0x10A0 && c <= 0x10FF) || (c >= 0x1C90 && c <= 0x1CBF);
    }

    public static boolean isArmenian(char c) {
        return c >= 0x0530 && c <= 0x058F;
    }

    public static boolean isHebrew(char c) {
        return c >= 0x0590 && c <= 0x05FF;
    }

    static boolean isArabic(char c) {
        return (c >= 0x0600 && c <= 0x06FF)
                || (c >= 0x0750 && c <= 0x077F)
                || (c >= 0x08A0 && c <= 0x08FF)
                || (c >= 0xFB50 && c <= 0xFDFF)
                || (c >= 0xFE70 && c <= 0xFEFF);
    }

    static boolean isEthiopic(char c) {
        return (c >= 0x1200 && c <= 0x137F)
                || (c >= 0x1380 && c <= 0x139F)
                || (c >= 0x2D80 && c <= 0x2DDF)
                || (c >= 0xAB00 && c <= 0xAB2F);
    }

    static boolean isSyriac(char c) {
        return c >= 0x0700 && c <= 0x074F;
    }

    public static boolean isLatin(char c) {
        return (c >= 0x0041 && c <= 0x005A)
                || (c >= 0x0061 && c <= 0x007A)
                || (c >= 0x00C0 && c <= 0x024F)
                || (c >= 0x1E00 && c <= 0x1EFF)
                // Full-width spellings, which a Japanese lyric uses for a title.
                || (c >= 0xFF21 && c <= 0xFF3A)
                || (c >= 0xFF41 && c <= 0xFF5A);
    }

    public static boolean isThai(char c) {
        return c >= 0x0E00 && c <= 0x0E7F;
    }

    public enum Script {
        /** Han with too little kana to be Japanese, which is how Chinese reads. */
        HAN,
        JAPANESE,
        KOREAN,
        CYRILLIC,
        GEORGIAN,
        ARMENIAN,
        GREEK,
        HEBREW,
        ARABIC,
        ETHIOPIC,
        SYRIAC,
        /** Latin script, digits or punctuation only: nothing here needs a romanizer. */
        OTHER
    }
}
