Native playlist queue — 21.20.405 retest
Built from feature/youtube-native-playlist-queue-dev commit f6d38511ad6c933311b7375462db0fea0e7d6e02.
Extract the MPP from this ZIP and import it into Morphe Manager.
Supported YouTube versions: 20.51.39, 21.16.256, 21.20.405.
20.21.37 is not supported; its experimental code is excluded.
Native playlist queue remains selected by default.
Disable Morphe's Premium-style queue setting when testing Native playlist queue.

This rebuild includes the committed visible shuffle command and the two verified
version compatibility changes. Queue runtime is unchanged from the tested source.
Existing real-APK SDK/DEX/hierarchy/resource and related-patch checks cover the
committed implementation on all three targets. Those expensive checks were not
repeated for this rebuild. Patch tests passed from Gradle cache (14 passed, 5 unrelated APK-dependent skips);
buildAndroid completed in 13 seconds for this delivery.
The exact delivered archive is checked for Android DEX, checksums, current YouTube
extension and Kotlin payloads, patch-loader inventory and target metadata.

For the 21.20.405 retest, cover creation/miniplayer, Play next/last, shuffle/repeat,
reordering, remove/Clear and Undo, background skips, Shorts return, fullscreen,
whole-queue Save to existing/new playlists, and ordinary playlist/player Save.
