/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/3851
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.ui;

import static app.morphe.extension.shared.StringRef.str;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.requests.LyricsRequests;
import app.morphe.extension.music.settings.Settings;
import app.morphe.extension.music.settings.preference.LyricsTargetLanguagePreference;
import app.morphe.extension.shared.ui.Dim;

/** All of it is static and reads no state of its own, which is why it lives outside the view. */
final class LyricsViewSupport {

    /** Lines other than the active one shrink a little, on top of dimming. */
    static final float ACTIVE_LINE_SCALE = 1.0f;
    static final float INACTIVE_LINE_SCALE = 0.95f;
    static final float INACTIVE_LINE_ALPHA = 0.35f;
    /** Every line while the lyrics are scrolled by hand, so all of them read alike. */
    static final float BROWSING_LINE_ALPHA = 0.60f;
    /** Compose LinearOutSlowInEasing. */
    static final TimeInterpolator LINEAR_OUT_SLOW_IN =
            new PathInterpolator(0f, 0f, 0.2f, 1f);
    /** The Compose FastOutSlowInEasing. */
    static final TimeInterpolator FAST_OUT_SLOW_IN =
            new PathInterpolator(0.4f, 0f, 0.2f, 1f);
    /** The CSS ease curve, which line looks and the instrumental break dots change along. */
    static final TimeInterpolator EASE =
            new PathInterpolator(0.25f, 0.1f, 0.25f, 1f);
    private static final float FOOTER_ALPHA = 0.6f;
    private static final long HIGHLIGHT_FADE_DURATION_MILLISECONDS = 320;
    private static final String LYRICS_SOURCE_KEY = "morphe_music_lyrics_source_label";
    private static final float FOOTER_TEXT_SIZE_SP = 16;
    private static final float BACKGROUND_TEXT_SIZE_FACTOR = 0.7f;
    private static final float SECTION_TAG_TEXT_SIZE_FACTOR = 0.45f;
    private static final float SECTION_DOT_INSET_FACTOR = 0.18f;
    private static final ArgbEvaluator BUTTON_COLOR_EVALUATOR = new ArgbEvaluator();

    private LyricsViewSupport() {
    }

    /** Bolds a paint for lyrics; a typeface set on it afterward undoes the weight. */
    static void applyLyricsBoldPaint(Paint paint) {
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setFlags(paint.getFlags()
                | Paint.ANTI_ALIAS_FLAG
                | Paint.SUBPIXEL_TEXT_FLAG
                | Paint.LINEAR_TEXT_FLAG);
        paint.setFontVariationSettings(null);
        paint.setFakeBoldText(false);
    }

    /** Draws a line a little tighter, except a joining script, which spacing would break apart. */
    static float lineLetterSpacing(@Nullable CharSequence text, float textSizeSp) {
        return LyricsTextUtils.containsJoiningScript(text) ? 0f : -0.5f / Math.max(12f, textSizeSp);
    }

    static int leadingRegionSize(Layout layout, int start, int end) {
        if (start != 0 || end <= start || end > layout.getText().length()) {
            return 0;
        }
        return layout.getLineBottom(layout.getLineForOffset(end - 1));
    }

    static int trailingRegionSize(Layout layout, int start, int end) {
        if (start <= 0 || end <= start || end > layout.getText().length()) {
            return 0;
        }
        return layout.getHeight() - layout.getLineTop(layout.getLineForOffset(start));
    }

    static int rowHeightOutsideText(View row, View text) {
        if (!(row instanceof ViewGroup group)) {
            return 0;
        }
        int total = 0;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child == text || child.getVisibility() == View.GONE) {
                continue;
            }
            int height = child.getHeight();
            ViewGroup.LayoutParams lp = child.getLayoutParams();
            if (height <= 0 && lp != null && lp.height > 0) {
                height = lp.height;
            }
            total += height;
            if (lp instanceof ViewGroup.MarginLayoutParams margins) {
                total += margins.topMargin + margins.bottomMargin;
            }
        }
        return total;
    }


    /**
     * The words the karaoke pass paints for one line.
     *
     * <p>An only mode drops the original and measures its reading against the text it draws, so the
     * reading's words already sit on the {@code originalStart} base and the originals are not in that text
     * at all; a plain mode keeps the original, which is the base {@link #withReading} moves the reading's
     * onto. Deciding by the reading alone would rob a plain mode of the words it paints.
     */
    static List<WordTiming> wordSpansFor(
            LyricsSpanBuilder.BuildResult result, boolean only,
            List<WordTiming> lineTimings) {
        if (!only) {
            // Syllable readings are drawn by the view from the same timings that light the lyric.
            if (result.showSyllableRomanization()) {
                return result.readingSpans();
            }
            return withReading(lineTimings, result);
        }
        List<WordTiming> spans = result.readingSpans();
        return spans == null || spans.isEmpty() ? Collections.emptyList() : spans;
    }

    /**
     * Puts the reading's words on the line's offset base: the view adds {@code originalTextStart} to
     * every offset it is given, and the reading sits elsewhere in the text, so its offsets move by the
     * difference.
     */
    static List<WordTiming> withReading(
            List<WordTiming> lineTimings,
            LyricsSpanBuilder.BuildResult result) {
        List<WordTiming> readingSpans = result.readingSpans();
        if (readingSpans == null || readingSpans.isEmpty() || result.romaStart() < 0) {
            return lineTimings;
        }
        final int shift = result.romaStart() - result.originalStart();
        List<WordTiming> combined =
                new ArrayList<>(lineTimings.size() + readingSpans.size());
        combined.addAll(lineTimings);
        for (WordTiming span : readingSpans) {
            combined.add(new WordTiming(
                    span.start() + shift, span.end() + shift, span.startMs(), span.endMs(),
                    null, span.hasTrailingSpace(), null, span.averaged()));
        }
        return combined;
    }

    /* Eases the highlight between lines the way the built-in panel does, shrinking the dimmed ones. */

    /** {@return the alpha of an inactive line this many lines from the sung one, in spotlight mode} */
    static float spotlightAlpha(int distance) {
        return switch (distance) {
            case 0 -> INACTIVE_LINE_ALPHA;
            case 1 -> 0.28f;
            case 2 -> 0.20f;
            case 3 -> 0.14f;
            default -> 0.10f;
        };
    }

    /** {@return the scale of an inactive line this many lines from the sung one, in spotlight mode} */
    static float spotlightScale(int distance) {
        if (distance <= 1) return 0.97f;
        if (distance <= 3) return 0.93f;
        if (distance == 4) return 0.90f;
        return 0.85f;
    }

    static void fadeTo(TextView lineView, float alpha) {
        if (!(lineView instanceof LyricsLineView view)) {
            return;
        }
        if (view.isSecondary()) {
            // A background vocal shows and hides with its own expansion instead.
            if (view.fadeAnimator != null) {
                view.fadeAnimator.cancel();
                view.fadeAnimator = null;
            }
            view.lineAlpha = 1f;
            view.fadeTargetAlpha = 1f;
            return;
        }
        // Called on every highlight tick, so a fade already heading here is left to finish.
        if (view.fadeAnimator != null && Math.abs(view.fadeTargetAlpha - alpha) < 0.005f) {
            return;
        }
        if (view.fadeAnimator != null) {
            view.fadeAnimator.cancel();
            view.fadeAnimator = null;
        }
        view.fadeTargetAlpha = alpha;
        final float targetScale = alpha >= 1f ? ACTIVE_LINE_SCALE : INACTIVE_LINE_SCALE;
        final float startAlpha = view.lineAlpha;
        final float startScale = view.lineScale;
        if (Math.abs(startAlpha - alpha) < 0.01f && Math.abs(startScale - targetScale) < 0.005f) {
            view.lineAlpha = alpha;
            view.lineScale = targetScale;
            applyLineScaleTransform(view, targetScale);
            view.invalidate();
            return;
        }
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(HIGHLIGHT_FADE_DURATION_MILLISECONDS);
        animator.setInterpolator(FAST_OUT_SLOW_IN);
        animator.addUpdateListener(animation -> {
            final float t = (float) animation.getAnimatedValue();
            view.lineAlpha = startAlpha + (alpha - startAlpha) * t;
            view.lineScale = startScale + (targetScale - startScale) * t;
            applyLineScaleTransform(view, view.lineScale);
            view.invalidate();
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (view.fadeAnimator == animation) {
                    view.fadeAnimator = null;
                }
            }
        });
        view.fadeAnimator = animator;
        animator.start();
    }

    static void applyLineScaleTransform(LyricsLineView view, float scale) {
        if (view.isSecondary()) {
            return;
        }
        final int w = view.getWidth();
        final int h = view.getHeight();
        if (w > 0) {
            final boolean isEnd = view.isRightAligned();
            view.setPivotX(view.isCentered() ? w / 2f : (isEnd ? w - view.getPaddingRight() : view.getPaddingLeft()));
        }
        if (h > 0) {
            view.setPivotY(h * 0.5f);
        }
        view.setScaleX(scale);
        view.setScaleY(scale);
    }

    static void applyFooterStyle(TextView footer) {
        footer.setTextSize(TypedValue.COMPLEX_UNIT_SP, FOOTER_TEXT_SIZE_SP);
        footer.setTextColor(LyricsColors.secondaryTextColor());
        // The secondary color alone is brighter than the app draws this line, which
        // sits dimmer than even the inactive lyrics above it.
        footer.setAlpha(FOOTER_ALPHA);
    }

    static int lineTextSizeSp(boolean isBackground, int textSize) {
        return isBackground
                ? Math.round(textSize * BACKGROUND_TEXT_SIZE_FACTOR)
                : textSize;
    }

    static int sectionTagTextSizeSp() {
        return Math.round(Settings.LYRICS_TEXT_SIZE.get() * SECTION_TAG_TEXT_SIZE_FACTOR);
    }

    static int scaledPixels(@NonNull Context context, float factor) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
                Settings.LYRICS_TEXT_SIZE.get() * factor,
                context.getResources().getDisplayMetrics()));
    }

    static int sectionTagPaddingHorizontal(@NonNull Context context) {
        return scaledPixels(context, LyricsPanelView.SECTION_TAG_PADDING_HORIZONTAL_FACTOR);
    }

    static int sectionDotInset(@NonNull Context context) {
        return scaledPixels(context, SECTION_DOT_INSET_FACTOR);
    }

    static void fadeDualButtonOut(View button) {
        button.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f)
                .setDuration(LyricsPanelView.BUTTON_STATE_FADE_MILLISECONDS).start();
    }

    /** So the next merge starts from whole again. */
    static void resetDualButton(View button) {
        button.animate().cancel();
        button.setAlpha(1f);
        button.setScaleX(1f);
        button.setScaleY(1f);
    }

    static void fadeDualButtonIn(View button) {
        button.setAlpha(0f);
        button.setScaleX(0.6f);
        button.setScaleY(0.6f);
        button.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(LyricsPanelView.BUTTON_STATE_FADE_MILLISECONDS).start();
    }

    /**
     * Eases a button between its two colors: pill, label and icon change at once, so a single animator
     * drives all of them.
     */
    static void fadeButtonColors(TextView button, int background, int foreground) {
        // The tag is free on these buttons and keeps the running animator with its view.
        if (button.getTag() instanceof ValueAnimator running) {
            running.cancel();
        }

        GradientDrawable pill;
        if (button.getBackground() instanceof GradientDrawable existing) {
            pill = existing;
        } else {
            pill = new GradientDrawable();
            pill.setShape(GradientDrawable.RECTANGLE);
            pill.setCornerRadius(Dim.dp20);
            button.setBackground(pill);
        }

        ColorStateList pillColor = pill.getColor();
        final int fromBackground = pillColor == null ? background : pillColor.getDefaultColor();
        final int fromForeground = button.getCurrentTextColor();
        // All of them: the dual pill's far twin would keep the inactive tint while it is up.
        Drawable[] icons = button.getCompoundDrawablesRelative();

        // Nothing to ease from before the panel is on screen, or when nothing changed.
        if (!button.isAttachedToWindow()
                || (fromBackground == background && fromForeground == foreground)) {
            setButtonColors(button, pill, icons, background, foreground);
            return;
        }

        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(LyricsPanelView.BUTTON_STATE_FADE_MILLISECONDS);
        animator.addUpdateListener(update -> {
            final float fraction = update.getAnimatedFraction();
            setButtonColors(button, pill, icons,
                    (int) BUTTON_COLOR_EVALUATOR.evaluate(fraction, fromBackground, background),
                    (int) BUTTON_COLOR_EVALUATOR.evaluate(fraction, fromForeground, foreground));
        });
        button.setTag(animator);
        animator.start();
    }

    static void setButtonColors(TextView button, GradientDrawable pill,
                                @NonNull Drawable[] icons, int background, int foreground) {
        pill.setColor(background);
        button.setTextColor(foreground);
        for (Drawable icon : icons) {
            if (icon != null) {
                icon.mutate().setTint(foreground);
            }
        }
        button.invalidate();
    }

    static boolean hasTranslation(@Nullable List<String> translated, List<LyricsLine> originals) {
        if (translated == null) {
            return false;
        }
        final int size = Math.min(translated.size(), originals.size());
        for (int i = 0; i < size; i++) {
            String text = translated.get(i);
            if (text != null && !text.isEmpty() && !text.equals(originals.get(i).text())) {
                return true;
            }
        }
        return false;
    }

    static CharSequence sourceText(String providerName, boolean translated,
                                   boolean translatedFromGoogle, boolean translatedFromAI, @Nullable String translatedAiModel,
                                   boolean romanized, boolean romanizedFromGoogle, boolean romanizedFromAI, boolean romanizedFromEmbedded,
                                   @Nullable String romanizedAiModel, LyricsPanelView.OnlyMode onlyMode,
                                   @Nullable String romanizedLocalDictionary,
                                   @Nullable Runnable onTranslationLanguage,
                                   @Nullable Runnable onRomanizationLanguage,
                                   @Nullable Runnable onSourceClicked) {
        SpannableStringBuilder text = new SpannableStringBuilder();
        appendSourceLine(text, String.format(str(LYRICS_SOURCE_KEY), providerName), onSourceClicked);

        if (onlyMode != LyricsPanelView.OnlyMode.ROMA) {
            if (translated && translatedFromGoogle) {
                appendLink(text, str("morphe_music_lyrics_translated_by_google"),
                        true, onTranslationLanguage);
            } else if (translated && translatedFromAI && translatedAiModel != null) {
                appendLink(text, String.format(str("morphe_music_lyrics_translated_by_ai"),
                        translatedAiModel), true, onTranslationLanguage);
            }
        }
        if (onlyMode != LyricsPanelView.OnlyMode.TRANS) {
            final String rubyProvider = LyricsTargetLanguagePreference.rubyProviderLabel();
            String source = null;
            if (LyricsRequests.isRomanizationOff()) {
                // No romanization, so the ruby takes its place.
                if (rubyProvider != null) {
                    source = String.format(str("morphe_music_lyrics_romanized_by_local"), rubyProvider);
                }
            } else if (romanized) {
                if (romanizedFromGoogle) {
                    source = str("morphe_music_lyrics_romanized_by_google");
                } else if (romanizedFromAI && romanizedAiModel != null) {
                    source = String.format(str("morphe_music_lyrics_romanized_by_ai"), romanizedAiModel);
                } else if (romanizedLocalDictionary != null) {
                    // Named and nothing more: the licenses are in the licenses dialog.
                    source = String.format(str("morphe_music_lyrics_romanized_by_local"),
                            romanizedLocalDictionary);
                } else if (romanizedFromEmbedded && rubyProvider != null) {
                    source = String.format(str("morphe_music_lyrics_romanized_by_local"), rubyProvider);
                }
                if (source != null && rubyProvider != null && !source.contains(rubyProvider)) {
                    source = str("morphe_music_lyrics_with_ruby_provider", source, rubyProvider);
                }
            }
            if (source != null) {
                appendLink(text, source, false, onRomanizationLanguage);
            }
        }
        return text;
    }

    /** Appends a source line that opens its URL, not a language picker. */
    private static void appendSourceLine(SpannableStringBuilder out, String line, Runnable onSource) {
        out.append(line);
        final int start = out.length() - line.length();
        final int end = out.length();
        out.setSpan(new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (onSource != null) onSource.run();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                ds.setUnderlineText(false);
            }
        }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** Appends {@code line} as its own line, tappable to open its side's language picker. */
    private static void appendLink(SpannableStringBuilder out, String line, boolean translation,
                                   @Nullable Runnable onPicked) {
        out.append('\n');
        final int start = out.length();
        out.append(line);
        out.setSpan(new LanguageSpan(translation, onPicked), start, out.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** A footer line that opens the target language picker for its side. */
    static final class LanguageSpan extends ClickableSpan {
        final boolean translation;
        @Nullable
        final Runnable onPicked;

        LanguageSpan(boolean translation, @Nullable Runnable onPicked) {
            this.translation = translation;
            this.onPicked = onPicked;
        }

        @Override
        public void onClick(View widget) {
            LyricsTargetLanguagePreference.showLanguageDialog(
                    widget.getContext(), translation, onPicked);
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
        }
    }
}
