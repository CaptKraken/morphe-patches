/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2625
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.requests;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import app.morphe.extension.music.patches.lyrics.model.Lyrics;
import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.model.TrackInfo;
import app.morphe.extension.music.patches.lyrics.model.Word;
import app.morphe.extension.music.patches.lyrics.parsers.LRCParser;
import app.morphe.extension.music.settings.Settings;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.requests.Requester;

public final class SpotifyProvider implements LyricsProvider {

    private static final String SECRETS_URL =
            "https://raw.githubusercontent.com/xyloflake/spot-secrets-go/refs/heads/main/secrets/secretDict.json";
    private static final String TOKEN_URL = "https://open.spotify.com/api/token";
    private static final String SERVER_TIME_URL = "https://open.spotify.com/api/server-time";
    private static final String CLIENT_TOKEN_URL = "https://clienttoken.spotify.com/v1/clienttoken";
    private static final String PARTNER_GRAPHQL_URL =
            "https://api-partner.spotify.com/pathfinder/v2/query";
    private static final String[] SEARCH_HASHES = {
            "0dff51c99e552b992377a2a6f40d213dc42b62db86ca0bcf16cf3934aec1aae6",
            "75bbf6bfcfdf85b8fc828417bfad92b7cd66bf7f556d85670f4da8292373ebec",
    };
    private static final String LYRICS_URL = "https://spclient.wg.spotify.com/color-lyrics/v2/track/";
    private static final String CLIENT_VERSION = "1.2.57.183.g8c1b7eb0";

    private static final int SEARCH_RETRIES = 2;
    private static final int SECRET_FETCH_RETRIES = 2;

    private static final long MAX_RETRY_AFTER_MS = 30_000;

    private static final String USER_AGENT = LyricsRequests.CHROME_DESKTOP_USER_AGENT;
    private static final long SECRET_REFRESH_INTERVAL_MS = 60 * 60 * 1000;
    private static final int[] FALLBACK_SECRET_DATA = {
            99, 111, 47, 88, 49, 56, 118, 65, 52, 67, 50, 104,
            117, 101, 55, 94, 95, 75, 94, 49, 69, 36, 85, 64, 74, 60
    };
    private static final String FALLBACK_TOTP_VERSION = "19";
    @Nullable
    private static volatile String cachedAccessToken;
    @Nullable
    private static volatile String cachedClientToken;
    private static long clientTokenExpiry = 0;
    @Nullable
    private static String cachedClientId;
    @Nullable
    private static String[] cachedTotpSecrets;  // XOR-decoded decimal string (HMAC key = UTF-8 bytes of this)
    @Nullable
    private static String cachedTotpVersion;
    private static long lastSecretFetchTime = 0;

    private static HttpURLConnection openSearchConnection(String accessToken,
                                                          @Nullable String clientToken,
                                                          byte[] bodyBytes) throws IOException {
        final HttpURLConnection connection = (HttpURLConnection)
                new URL(PARTNER_GRAPHQL_URL).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(8000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Authorization", "Bearer " + accessToken);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("app-platform", "WebPlayer");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Referer", "https://open.spotify.com/");
        connection.setRequestProperty("Origin", "https://open.spotify.com");
        connection.setRequestProperty("spotify-app-version", CLIENT_VERSION);
        if (clientToken != null) {
            connection.setRequestProperty("client-token", clientToken);
        }

        connection.setFixedLengthStreamingMode(bodyBytes.length);
        try (OutputStream os = connection.getOutputStream()) {
            os.write(bodyBytes);
        }
        return connection;
    }

    private static List<String> artistNames(JSONObject node) {
        final List<String> out = new ArrayList<>();
        final JSONArray artists = node.optJSONArray("artists");
        if (artists != null) {
            for (int i = 0; i < artists.length(); i++) {
                final JSONObject artist = artists.optJSONObject(i);
                if (artist == null) continue;
                final String name = LyricsRequests.optString(artist, "name");
                if (name != null) {
                    out.add(name);
                }
            }
            if (!out.isEmpty()) {
                return out;
            }
        }
        final JSONObject connection = node.optJSONObject("artists");
        if (connection != null) {
            final JSONArray edges = connection.optJSONArray("edges");
            if (edges != null) {
                for (int i = 0; i < edges.length(); i++) {
                    final JSONObject edge = edges.optJSONObject(i);
                    final JSONObject artistNode =
                            edge != null ? edge.optJSONObject("node") : null;
                    final String name = artistNode != null
                            ? LyricsRequests.optString(artistNode, "name") : null;
                    if (name != null) {
                        out.add(name);
                    }
                }
            }
        }
        if (out.isEmpty()) {
            final String artist = LyricsRequests.optString(node, "artist");
            if (artist != null) {
                out.add(artist);
            }
        }
        return out;
    }

    private static List<Word> parseSyllables(JSONArray syllablesArr, String lineText) {
        final List<Word> words = new ArrayList<>(syllablesArr.length());
        int charOffset = 0;

        for (int j = 0; j < syllablesArr.length(); j++) {
            JSONObject syllable = syllablesArr.optJSONObject(j);
            if (syllable == null) {
                continue;
            }

            final long startMs = parseStartTimeMs(syllable);
            final long endMs = syllable.optLong("endTimeMs", startMs);
            final int numChars = syllable.optInt("numChars", 0);
            if (numChars <= 0) {
                continue;
            }

            // Spaces before the syllable are not part of it.
            while (charOffset < lineText.length() && Character.isWhitespace(lineText.charAt(charOffset))) {
                charOffset++;
            }
            if (charOffset >= lineText.length()) {
                break;
            }

            final int end = Math.min(charOffset + numChars, lineText.length());
            final String wordText = lineText.substring(charOffset, end);
            final boolean spaceAfter = (end < lineText.length() && Character.isWhitespace(lineText.charAt(end)));
            words.add(new Word(startMs, endMs, wordText, null, spaceAfter));
            charOffset = end;
        }

        return words;
    }

    static long parseStartTimeMs(JSONObject obj) {
        final String raw = LyricsRequests.optString(obj, "startTimeMs");
        if (raw == null || raw.isEmpty()) {
            return LyricsLine.NO_TIME;
        }
        try {
            return Long.parseLong(raw);
        } catch (NumberFormatException ex) {
            Logger.printDebug(() -> "Could not parse start time in Spotify lyrics line", ex);
            return LyricsLine.NO_TIME;
        }
    }

    private static HttpURLConnection openServerTimeConnection(String spDc, int readTimeoutMs) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(SERVER_TIME_URL).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(readTimeoutMs);
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Origin", "https://open.spotify.com/");
        connection.setRequestProperty("Referer", "https://open.spotify.com/");
        connection.setRequestProperty("Cookie", "sp_dc=" + spDc);
        return connection;
    }

    private static String generateTotp(long timestampMs, String secret)
            throws NoSuchAlgorithmException, InvalidKeyException {
        final long epochSeconds = timestampMs / 1000;
        final long counter = epochSeconds / 30;

        final byte[] counterBytes = new byte[8];
        long tmp = counter;
        for (int i = 7; i >= 0; i--) {
            counterBytes[i] = (byte) (tmp & 0xFF);
            tmp >>= 8;
        }

        final Mac mac = Mac.getInstance("HmacSHA1");
        final byte[] secretBytes = secret.getBytes(StandardCharsets.UTF_8);
        mac.init(new SecretKeySpec(secretBytes, "HmacSHA1"));
        final byte[] hash = mac.doFinal(counterBytes);

        final int offset = hash[hash.length - 1] & 0x0F;
        final int binary = ((hash[offset] & 0x7F) << 24)
                | ((hash[offset + 1] & 0xFF) << 16)
                | ((hash[offset + 2] & 0xFF) << 8)
                | (hash[offset + 3] & 0xFF);

        final int otp = binary % 1_000_000;
        return String.format(Locale.US, "%06d", otp);
    }

    @Nullable
    private static String fetchSecrets() {
        for (int attempt = 0; attempt <= SECRET_FETCH_RETRIES; attempt++) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection)
                        new URL(SECRETS_URL).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("User-Agent", USER_AGENT);

                final int code = connection.getResponseCode();
                if (code == 200) {
                    return Requester.parseString(connection);
                }
            } catch (IOException ex) {
                Logger.printDebug(() -> "Could not read the response", ex);
            } finally {
                if (connection != null) connection.disconnect();
            }
            if (attempt < SECRET_FETCH_RETRIES) {
                try {
                    Thread.sleep(1000L * (attempt + 1));
                } catch (InterruptedException ex) {
                    Logger.printDebug(() -> "Interrupted during secret fetch retry sleep", ex);
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        }
        return null;
    }

    static String decimalStringFromInts(int[] values) {
        final StringBuilder sb = new StringBuilder(values.length);
        for (int v : values) {
            sb.append(v);
        }
        return sb.toString();
    }

    private static long parseRetryAfter(HttpURLConnection connection) {
        final String retryAfter = connection.getHeaderField("Retry-After");
        if (retryAfter != null) {
            try {
                final long seconds = Long.parseLong(retryAfter.trim());
                if (seconds > 0) {
                    return Math.min(seconds, MAX_RETRY_AFTER_MS / 1000) * 1000;
                }
            } catch (NumberFormatException ex) {
                Logger.printDebug(() -> "Could not parse Retry-After header", ex);
            }
        }
        return 3000;
    }

    public static void invalidateToken() {
        cachedAccessToken = null;
        cachedClientToken = null;
        clientTokenExpiry = 0;
        cachedClientId = null;
    }

    public static boolean validateToken(String spDc) {
        if (spDc == null || spDc.trim().isEmpty()) return false;
        HttpURLConnection connection = null;
        try {
            connection = openServerTimeConnection(spDc, 8000);
            return connection.getResponseCode() == Requester.HTTP_STATUS_CODE_SUCCESS;
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not validate Spotify token", ex);
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Override
    public String name() {
        return "Spotify";
    }

    @Nullable
    @Override
    public FetchResult fetch(TrackInfo track) throws Exception {
        final String spDc = Settings.SPOTIFY_TOKEN.get();
        if (spDc.trim().isEmpty()) {
            return null;
        }

        SearchHit hit = searchTrack(spDc, track.title(), track.artist());
        if (hit == null) {
            return null;
        }

        final String sourceUrl = "https://open.spotify.com/track/" + hit.id();
        JSONObject lyricsResponse = fetchLyrics(spDc, hit.id());
        if (lyricsResponse == null) {
            return null;
        }

        final String rawJson = lyricsResponse.toString();
        return FetchResult.searched(parseLyrics(lyricsResponse, rawJson, sourceUrl),
                List.of(hit.title()), hit.artists(), 0L, track);
    }

    @Nullable
    private SearchHit searchTrack(String spDc, String title, String artist) throws Exception {
        final String accessToken = getAccessToken(spDc);
        if (accessToken == null) {
            return null;
        }

        final String clientToken = getClientToken(spDc);

        final String query = title + " " + artist;

        for (String hash : SEARCH_HASHES) {
            final String body = new JSONObject()
                    .put("extensions", new JSONObject()
                            .put("persistedQuery", new JSONObject()
                                    .put("sha256Hash", hash)
                                    .put("version", 1)))
                    .put("operationName", "searchDesktop")
                    .put("variables", new JSONObject()
                            .put("searchTerm", query)
                            .put("limit", 5)
                            .put("numberOfTopResults", 5)
                            .put("offset", 0))
                    .toString();

            SearchHit hit = executeSearch(accessToken, clientToken, body);
            if (hit != null) {
                return hit;
            }
        }

        return null;
    }

    @Nullable
    private SearchHit executeSearch(String accessToken, @Nullable String clientToken,
                                    String body) throws Exception {
        final byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
        long retryAfterMs = 0;

        for (int attempt = 0; attempt <= SEARCH_RETRIES; attempt++) {
            if (retryAfterMs > 0) {
                try {
                    Thread.sleep(Math.min(retryAfterMs, MAX_RETRY_AFTER_MS));
                } catch (InterruptedException ex) {
                    Logger.printDebug(() -> "Interrupted during search retry sleep", ex);
                    Thread.currentThread().interrupt();
                    return null;
                }
            }

            final HttpURLConnection connection =
                    openSearchConnection(accessToken, clientToken, bodyBytes);

            final int code = connection.getResponseCode();

            if (code == 200) {
                final String json = Requester.parseString(connection);
                connection.disconnect();

                SearchHit hit = parseSearchResult(json);
                if (hit != null) {
                    return hit;
                }
                break;
            }

            if (code == 429) {
                retryAfterMs = parseRetryAfter(connection);
                connection.disconnect();
                continue;
            }

            connection.disconnect();
            return null;
        }

        return null;
    }

    @Nullable
    private SearchHit parseSearchResult(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONObject data = root.optJSONObject("data");
            if (data == null) return null;

            JSONObject searchV2 = data.optJSONObject("searchV2");
            if (searchV2 == null) return null;

            JSONArray items = null;
            JSONObject tracks = searchV2.optJSONObject("tracks");
            if (tracks != null) {
                items = tracks.optJSONArray("items");
            }
            if (items == null || items.length() == 0) {
                JSONObject search = data.optJSONObject("search");
                if (search != null) {
                    JSONObject searchTracks = search.optJSONObject("tracks");
                    if (searchTracks != null) {
                        items = searchTracks.optJSONArray("items");
                    }
                }
            }
            if (items == null || items.length() == 0) {
                return null;
            }

            return extractSearchHit(items);
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not search Spotify track ID", ex);
            return null;
        }
    }

    @Nullable
    private SearchHit extractSearchHit(JSONArray items) {
        for (int i = 0; i < items.length(); i++) {
            JSONObject itemWrapper = items.optJSONObject(i);
            if (itemWrapper == null) continue;

            JSONObject dataNode = itemWrapper.optJSONObject("data");
            JSONObject node = dataNode != null ? dataNode : itemWrapper;

            String id = LyricsRequests.optString(node, "id");
            if (id == null || id.isEmpty()) {
                final String uri = LyricsRequests.optString(node, "uri");
                if (uri != null && uri.startsWith("spotify:track:")) {
                    id = uri.substring("spotify:track:".length());
                }
            }
            if (id != null && !id.isEmpty()) {
                final String title = LyricsRequests.optString(node, "name");
                return new SearchHit(id, title != null ? title : "", artistNames(node));
            }
        }

        return null;
    }

    @Nullable
    private JSONObject fetchLyrics(String spDc, String trackId) throws Exception {
        final String accessToken = getAccessToken(spDc);
        if (accessToken == null) {
            return null;
        }

        final String url = LYRICS_URL + trackId + "?format=json&market=from_token";
        HttpURLConnection connection = LyricsRequests.openConnection(url);
        connection.setRequestProperty("Authorization", "Bearer " + accessToken);
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("app-platform", "WebPlayer");

        final int code = connection.getResponseCode();
        if (code != 200) {
            LyricsRequests.logFailure(name(), connection);
            return null;
        }

        final String json = LyricsRequests.parseGzipString(connection);
        return new JSONObject(json);
    }

    @Nullable
    private Lyrics parseLyrics(JSONObject response, String rawJson, @Nullable String sourceUrl) {
        JSONObject lyricsObj = response.optJSONObject("lyrics");
        if (lyricsObj == null) {
            return null;
        }

        final String syncType = lyricsObj.optString("syncType", "UNSYNCED");
        final String provider = LyricsRequests.optString(lyricsObj, "provider");
        final String providerName = (provider != null && !provider.isEmpty())
                ? name() + " (via " + provider + ")" : name();
        final JSONArray linesArr = lyricsObj.optJSONArray("lines");
        if (linesArr == null || linesArr.length() == 0) {
            return null;
        }

        if ("SYLLABLE_SYNCED".equals(syncType)) {
            return parseSyllableLines(linesArr, providerName, rawJson, sourceUrl);
        } else if (!"UNSYNCED".equals(syncType)) {
            return parseSyncedLines(linesArr, providerName, rawJson, sourceUrl);
        } else {
            return parsePlainLines(linesArr, providerName, rawJson, sourceUrl);
        }
    }

    @Nullable
    private Lyrics parseSyncedLines(JSONArray linesArr, String providerName, String rawJson, @Nullable String sourceUrl) {
        final List<LyricsLine> lines = new ArrayList<>(linesArr.length());

        for (int i = 0; i < linesArr.length(); i++) {
            JSONObject lineObj = linesArr.optJSONObject(i);
            if (lineObj == null) {
                continue;
            }

            final long startTimeMs = parseStartTimeMs(lineObj);
            final String text = lineObj.optString("words", "").trim();
            if (text.isEmpty()) {
                continue;
            }

            lines.add(new LyricsLine(startTimeMs, text));
        }

        if (lines.isEmpty()) {
            return null;
        }

        LRCParser.fillEstimatedEnds(lines);

        return new Lyrics(lines, providerName, true, null, null, null, null, rawJson, "sp.json", sourceUrl);
    }

    @Nullable
    private Lyrics parseSyllableLines(JSONArray linesArr, String providerName,
                                      String rawJson, @Nullable String sourceUrl) {
        List<LyricsLine> lines = new ArrayList<>(linesArr.length());

        for (int i = 0, length = linesArr.length(); i < length; i++) {
            JSONObject lineObj = linesArr.optJSONObject(i);
            if (lineObj == null) {
                continue;
            }

            final long startTimeMs = parseStartTimeMs(lineObj);
            String text = lineObj.optString("words", "").trim();
            if (text.isEmpty()) {
                continue;
            }

            JSONArray syllablesArr = lineObj.optJSONArray("syllables");
            List<Word> words;
            if (syllablesArr != null && syllablesArr.length() > 0) {
                words = parseSyllables(syllablesArr, text);
            } else {
                words = List.of();
            }

            lines.add(new LyricsLine(startTimeMs, text, words));
        }

        if (lines.isEmpty()) {
            return null;
        }

        LRCParser.fillEstimatedEnds(lines);

        return new Lyrics(lines, providerName, true, null, null, null, null, rawJson, "sp.json", sourceUrl);
    }

    @Nullable
    private Lyrics parsePlainLines(JSONArray linesArr, String providerName,
                                   String rawJson, @Nullable String sourceUrl) {
        final List<LyricsLine> lines = new ArrayList<>(linesArr.length());

        for (int i = 0; i < linesArr.length(); i++) {
            JSONObject lineObj = linesArr.optJSONObject(i);
            if (lineObj == null) {
                continue;
            }

            final String text = lineObj.optString("words", "").trim();
            if (text.isEmpty()) {
                continue;
            }
            lines.add(new LyricsLine(LyricsLine.NO_TIME, text));
        }

        if (lines.isEmpty()) {
            return null;
        }
        return new Lyrics(lines, providerName, false, null, null, null, null, rawJson, "sp.json", sourceUrl);
    }

    @Nullable
    private synchronized String getAccessToken(String spDc) {
        if (cachedAccessToken != null) {
            return cachedAccessToken;
        }

        HttpURLConnection connection = null;
        try {
            ensureTotpSecrets();
            final String[] totpSecrets = cachedTotpSecrets;
            if (totpSecrets == null || totpSecrets.length == 0) {
                return null;
            }

            final long serverTimeMs = getServerTime(spDc);

            final String totpValue = generateTotp(serverTimeMs, totpSecrets[0]);

            final String url = TOKEN_URL
                    + "?reason=init&productType=web-player"
                    + "&totp=" + totpValue
                    + "&totpVer=" + cachedTotpVersion
                    + "&totpServer=" + totpValue;

            connection = (HttpURLConnection)
                    new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(8000);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("App-Platform", "WebPlayer");
            connection.setRequestProperty("Referer", "https://open.spotify.com/");
            connection.setRequestProperty("Cookie", "sp_dc=" + spDc);

            final int code = connection.getResponseCode();
            if (code != 200) {
                return null;
            }

            final String body = Requester.parseString(connection);
            JSONObject json = new JSONObject(body);
            final String token = json.optString("accessToken", "");
            if (token.trim().isEmpty()) {
                return null;
            }
            cachedAccessToken = token;

            final String clientId = LyricsRequests.optString(json, "clientId");
            if (clientId != null && !clientId.isEmpty()) {
                cachedClientId = clientId;
            }

            return cachedAccessToken;
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not fetch Spotify access token", ex);
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Nullable
    private synchronized String getClientToken(String spDc) {
        final long now = System.currentTimeMillis();
        if (cachedClientToken != null && now < clientTokenExpiry) {
            return cachedClientToken;
        }

        try {
            final String accessToken = getAccessToken(spDc);
            if (accessToken == null) {
                return null;
            }

            final String clientId = cachedClientId;
            if (clientId == null || clientId.isEmpty()) {
                return null;
            }

            final String deviceId = UUID.randomUUID().toString();
            JSONObject jsSdkData = new JSONObject()
                    .put("device_brand", "unknown")
                    .put("device_model", "unknown")
                    .put("os", "linux")
                    .put("os_version", "unknown")
                    .put("device_id", deviceId)
                    .put("device_type", "computer");

            JSONObject clientData = new JSONObject()
                    .put("client_version", CLIENT_VERSION)
                    .put("client_id", clientId)
                    .put("js_sdk_data", jsSdkData);

            JSONObject requestBody = new JSONObject()
                    .put("client_data", clientData);

            final HttpURLConnection connection = (HttpURLConnection)
                    new URL(CLIENT_TOKEN_URL).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(8000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Origin", "https://open.spotify.com");
            connection.setRequestProperty("Referer", "https://open.spotify.com");

            final byte[] bodyBytes = requestBody.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bodyBytes.length);
            try (OutputStream os = connection.getOutputStream()) {
                os.write(bodyBytes);
            }

            final int code = connection.getResponseCode();
            if (code != 200) {
                connection.disconnect();
                return null;
            }

            final String body = Requester.parseString(connection);
            JSONObject json = new JSONObject(body);
            JSONObject grantedToken = json.optJSONObject("granted_token");
            if (grantedToken == null) {
                connection.disconnect();
                return null;
            }

            final String token = grantedToken.optString("token", "");
            if (token.isEmpty()) {
                connection.disconnect();
                return null;
            }

            final long expiresIn = grantedToken.optLong("expires_after", 3600);
            clientTokenExpiry = now + (expiresIn * 1000) - 60_000;
            cachedClientToken = token;

            connection.disconnect();
            return cachedClientToken;
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not fetch Spotify client token", ex);
            return null;
        }
    }

    private long getServerTime(String spDc) {
        HttpURLConnection connection = null;
        try {
            connection = openServerTimeConnection(spDc, 5000);
            final int code = connection.getResponseCode();
            if (code == 200) {
                final String body = Requester.parseString(connection);
                JSONObject json = new JSONObject(body);
                final long serverTime = json.optLong("serverTime", 0);
                if (serverTime > 0) {
                    return serverTime * 1000;
                }
            }
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not read the Spotify server time", ex);
        } finally {
            if (connection != null) connection.disconnect();
        }
        return System.currentTimeMillis();
    }

    private void ensureTotpSecrets() {
        final long now = System.currentTimeMillis();
        if (cachedTotpSecrets != null && cachedTotpVersion != null
                && (now - lastSecretFetchTime) < SECRET_REFRESH_INTERVAL_MS) {
            return;
        }

        try {
            final String body = fetchSecrets();
            if (body != null) {
                JSONObject secrets = new JSONObject(body);

                int newestVersion = -1;
                Iterator<String> keys = secrets.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    try {
                        int v = Integer.parseInt(key);
                        if (v > newestVersion) {
                            newestVersion = v;
                        }
                    } catch (NumberFormatException ex) {
                        Logger.printDebug(() -> "Could not parse TOTP secret version", ex);
                    }
                }

                if (newestVersion >= 0) {
                    final String previousVersion = cachedTotpVersion;
                    cachedTotpVersion = String.valueOf(newestVersion);
                    final JSONArray arr = secrets.getJSONArray(cachedTotpVersion);
                    final int[] secretData = new int[arr.length()];
                    for (int i = 0; i < arr.length(); i++) {
                        secretData[i] = arr.getInt(i);
                    }

                    final int[] xored = new int[secretData.length];
                    for (int i = 0; i < secretData.length; i++) {
                        xored[i] = secretData[i] ^ ((i % 33) + 9);
                    }

                    cachedTotpSecrets = new String[]{decimalStringFromInts(xored)};

                    if (previousVersion != null && !cachedTotpVersion.equals(previousVersion)) {
                        cachedAccessToken = null;
                    }

                    lastSecretFetchTime = now;
                    return;
                }
            }
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not fetch the Spotify secret", ex);
        }

        if (cachedTotpSecrets == null || cachedTotpVersion == null) {
            cachedTotpSecrets = new String[]{decimalStringFromInts(FALLBACK_SECRET_DATA)};
            cachedTotpVersion = FALLBACK_TOTP_VERSION;
            lastSecretFetchTime = now;
        }
    }

    private record SearchHit(String id, String title, List<String> artists) {
    }
}
