/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to Morphe contributions.
 */

package app.morphe.extension.shared.settings.preference;

import static app.morphe.extension.shared.StringRef.sf;
import static app.morphe.extension.shared.StringRef.str;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Pair;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.patches.DownloadMode;
import app.morphe.extension.shared.settings.Setting;
import app.morphe.extension.shared.settings.SharedYouTubeSettings;
import app.morphe.extension.shared.ui.CustomDialog;
import app.morphe.extension.shared.ui.Dim;

/**
 * A shared base ListPreference for selecting an external downloader package with checkmarks and EditText for custom package names.
 */
@SuppressWarnings({"unused", "deprecation"})
public class ExternalDownloaderPreference extends CustomDialogListPreference {

    /**
     * Enum representing supported external downloaders with their display names, package names, and download URLs.
     */
    private enum Downloader {
        YTDLNIS("YTDLnis",
                "com.deniscerri.ytdl",
                "https://ytdlnis.org",
                true,
                true,
                false),
        YTINDIR("YTindir",
                "com.rl.ytindr",
                "https://github.com/RAMiK4/ytindir/releases",
                false,
                true,
                true),
        SEAL("Seal",
                "com.junkfood.seal",
                "https://github.com/JunkFood02/Seal/releases/latest"),
        SEAL_PREVIEW("Seal",
                "com.junkfood.seal.preview",
                "https://github.com/JunkFood02/Seal/releases"),
        SEAL_PLUS("Seal Plus",
                "com.maheshtechnicals.sealplus",
                "https://github.com/MaheshTechnicals/Sealplus/releases/latest"),
        GRAYJAY("Grayjay",
                "com.futo.platformplayer",
                "https://grayjay.app"),
        LIBRETUBE("LibreTube",
                "com.github.libretube",
                "https://libretube.dev"),
        NEWPIPE("NewPipe",
                "org.schabi.newpipe",
                "https://newpipe.net"),
        PIPEPIPE("PipePipe",
                "InfinityLoop1309.NewPipeEnhanced",
                "https://pipepipe.dev"),
        TUBULAR("Tubular",
                "org.polymorphicshade.tubular",
                "https://github.com/polymorphicshade/Tubular/releases/latest"),
        OTHER(sf("morphe_external_downloader_other_item").toString(),
                null,
                null,
                true);

        private static final Map<String, Downloader> PACKAGE_TO_ENUM = new HashMap<>();

        static {
            for (Downloader downloader : values()) {
                String packageName = downloader.packageName;
                if (packageName != null) {
                    PACKAGE_TO_ENUM.put(packageName, downloader);
                }
            }
        }

        /**
         * Finds a Downloader by its package name. This method can never return {@link #OTHER}.
         * @return The Downloader enum or null if not found.
         */
        @Nullable
        public static Downloader findByPackageName(String packageName) {
            return PACKAGE_TO_ENUM.get(Objects.requireNonNull(packageName));
        }

        public final String name;
        @Nullable
        public final String packageName;
        @Nullable
        public final String downloadUrl;
        /**
         * If a downloader app should be shown in the preference settings
         * if the app is not currently installed.
         */
        public final boolean isPreferred;
        /**
         * If the downloader understands the quick download extras of YTDLnis:
         * {@code TYPE} (audio or video) and {@code BACKGROUND} (queue without showing a window).
         */
        public final boolean supportsQuickDownload;
        /**
         * If the downloader also applies the requested quality:
         * {@code VIDEO_QUALITY} (maximum height) and {@code AUDIO_BITRATE} (kbps).
         */
        public final boolean supportsQuickDownloadQuality;

        Downloader(String name, String packageName, String downloadUrl) {
            this(name, packageName, downloadUrl, false, false, false);
        }

        Downloader(String name, @Nullable String packageName, @Nullable String downloadUrl, boolean isPreferred) {
            this(name, packageName, downloadUrl, isPreferred, false, false);
        }

        Downloader(String name, @Nullable String packageName, @Nullable String downloadUrl,
                   boolean isPreferred, boolean supportsQuickDownload, boolean supportsQuickDownloadQuality) {
            this.name = name;
            this.packageName = packageName;
            this.downloadUrl = downloadUrl;
            this.isPreferred = isPreferred;
            this.supportsQuickDownload = supportsQuickDownload;
            this.supportsQuickDownloadQuality = supportsQuickDownloadQuality;
        }
    }

    /** Maximum video height of a quick video download. */
    public static final int QUICK_DOWNLOAD_VIDEO_HEIGHT = 1080;
    /** Bitrate of a quick audio download. */
    public static final int QUICK_DOWNLOAD_AUDIO_KBPS = 192;

    /**
     * @return If the chosen downloader can queue a download in the background.
     */
    public static boolean supportsQuickDownload() {
        Downloader downloader = getDownloader();
        return downloader != null && downloader.supportsQuickDownload;
    }

    /**
     * @return If the chosen downloader also applies the requested quality,
     *         so the quick download menu can show it.
     */
    public static boolean supportsQuickDownloadQuality() {
        Downloader downloader = getDownloader();
        return downloader != null && downloader.supportsQuickDownloadQuality;
    }

    @Nullable
    private static Downloader getDownloader() {
        return Downloader.findByPackageName(
                SharedYouTubeSettings.EXTERNAL_DOWNLOADER_PACKAGE_NAME.get().trim());
    }

    /**
     * The external downloader is used by the download mode, the player overlay button, or the Download menu.
     */
    public static final class ExternalDownloaderAvailability implements Setting.Availability {
        @Override
        public boolean isAvailable() {
            return SharedYouTubeSettings.DOWNLOAD_MODE.get() == DownloadMode.EXTERNAL
                    || SharedYouTubeSettings.EXTERNAL_DOWNLOADER_OVERLAY_BUTTON.get()
                    || SharedYouTubeSettings.EXTERNAL_DOWNLOADER_MENU.get();
        }

        @Override
        public List<Setting<?>> getParentSettings() {
            return List.of(SharedYouTubeSettings.DOWNLOAD_MODE,
                    SharedYouTubeSettings.EXTERNAL_DOWNLOADER_OVERLAY_BUTTON,
                    SharedYouTubeSettings.EXTERNAL_DOWNLOADER_MENU);
        }
    }

    /**
     * @return If the downloader was opened.
     */
    public static boolean launchExternalDownloader(String videoId, @Nullable Context context, String url) {
        return launchExternalDownloader(videoId, context, url, null);
    }

    /**
     * @param quickDownloadType If not null, the downloader queues the download in the background
     *                          as this type ("audio" or "video") using its default settings,
     *                          capped at {@link #QUICK_DOWNLOAD_VIDEO_HEIGHT} / {@link #QUICK_DOWNLOAD_AUDIO_KBPS}
     *                          if the downloader supports it.
     * @return If the downloader was opened.
     */
    public static boolean launchExternalDownloader(String videoId, @Nullable Context context, String url,
                                                   @Nullable String quickDownloadType) {
        try {
            Objects.requireNonNull(videoId);
            if (context == null) {
                context = Utils.getActivity();
            }
            Context contextFinal = context;
            Logger.printDebug(() -> "Launching external downloader: " + videoId + " context: " + contextFinal);

            // Trim string to avoid any accidental whitespace.
            var downloaderPackageName = SharedYouTubeSettings.EXTERNAL_DOWNLOADER_PACKAGE_NAME.get().trim();

            // If the package is not installed, show a dialog.
            if (showDialogIfAppIsNotInstalled(context, downloaderPackageName)) {
                return false;
            }

            //noinspection ExtractMethodRecommender
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.setPackage(downloaderPackageName);
            intent.putExtra("android.intent.extra.TEXT", url);
            if (quickDownloadType != null) {
                intent.putExtra("TYPE", quickDownloadType);
                intent.putExtra("BACKGROUND", true);
                intent.putExtra("VIDEO_QUALITY", QUICK_DOWNLOAD_VIDEO_HEIGHT);
                intent.putExtra("AUDIO_BITRATE", QUICK_DOWNLOAD_AUDIO_KBPS);
            }
            // Opening the downloader is not the user leaving the app.
            // Without this flag a playing video enters picture-in-picture,
            // and the downloader's window opens over the home screen instead of over the video.
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            if (!(context instanceof Activity)) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(intent);
            return true;
        } catch (Exception ex) {
            Logger.printException(() -> "launchExternalDownloader failure", ex);
        }
        return false;
    }

    private static boolean isAppInstalledAndEnabled(String packageName) {
        try {
            if (Utils.getContext().getPackageManager().getApplicationInfo(packageName, 0).enabled) {
                Logger.printDebug(() -> "App installed: " + packageName);
                return true;
            }
        } catch (PackageManager.NameNotFoundException error) {
            Logger.printDebug(() -> "App not installed: " + packageName);
        }
        return false;
    }

    private EditText editText;
    private CustomDialogListPreference.ListPreferenceArrayAdapter adapter;

    public ExternalDownloaderPreference(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public ExternalDownloaderPreference(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public ExternalDownloaderPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ExternalDownloaderPreference(Context context) {
        super(context);
    }

    protected String getCurrentPackageName() {
        return SharedYouTubeSettings.EXTERNAL_DOWNLOADER_PACKAGE_NAME.get();
    }

    protected String getDefaultPackageName() {
        return SharedYouTubeSettings.EXTERNAL_DOWNLOADER_PACKAGE_NAME.defaultValue;
    }

    private void updateEntries() {
        List<CharSequence> entries = new ArrayList<>();
        List<CharSequence> entryValues = new ArrayList<>();

        for (Downloader downloader : Downloader.values()) {
            if (downloader.isPreferred || (downloader.packageName != null
                    && isAppInstalledAndEnabled(downloader.packageName))) {
                String packageName = downloader.packageName;

                entries.add(downloader.name);
                entryValues.add(packageName != null
                        ? packageName
                        : Downloader.OTHER.name);
            }
        }

        setEntries(entries.toArray(new CharSequence[0]));
        setEntryValues(entryValues.toArray(new CharSequence[0]));
    }

    /**
     * Sets the summary for this ListPreference.
     */
    @Override
    public void setSummary(CharSequence summary) {
        // Ignore calls to set the summary.
        // Summary is always the description of the category.
        //
        // This is required otherwise the Morphe preference fragment
        // sets all ListPreference summaries to show the current selection.
    }

    /**
     * Shows a custom dialog with a ListView for predefined downloader packages and EditText for custom package input.
     */
    @Override
    protected void showDialog(@Nullable Bundle state) {
        // Must set entries before showing the dialog, to handle if
        // an app is installed while the settings are open in the background.
        updateEntries();

        Context context = getContext();
        String packageName = getCurrentPackageName();

        // Create the main layout for the dialog content.
        LinearLayout contentLayout = new LinearLayout(context);
        contentLayout.setOrientation(LinearLayout.VERTICAL);

        // Create ListView for predefined downloader apps.
        ListView listView = new ListView(context);
        listView.setId(android.R.id.list);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Create custom adapter for the ListView.
        final boolean usingCustomDownloader = Downloader.findByPackageName(packageName) == null;
        adapter = new CustomDialogListPreference.ListPreferenceArrayAdapter(
                context,
                getEntries(),
                getEntryValues(),
                usingCustomDownloader
                        ? Downloader.OTHER.name
                        : packageName
        );
        listView.setAdapter(adapter);

        Function<String, Void> updateListViewSelection = (updatedPackageName) -> {
            String entryValueName = Downloader.findByPackageName(updatedPackageName) == null
                    ? Downloader.OTHER.name
                    : updatedPackageName;
            CharSequence[] entryValues = getEntryValues();

            for (int i = 0, length = entryValues.length; i < length; i++) {
                String entryString = entryValues[i].toString();
                if (entryString.equals(entryValueName)) {
                    listView.setItemChecked(i, true);
                    listView.setSelection(i);
                    adapter.setSelectedValue(entryString);
                    adapter.notifyDataSetChanged();
                    break;
                }
            }
            return null;
        };
        updateListViewSelection.apply(packageName);

        // Handle item click to select value.
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedValue = getEntryValues()[position].toString();
            Downloader selectedApp = Downloader.findByPackageName(selectedValue);

            if (selectedApp != null) {
                editText.setText(selectedApp.packageName);
                editText.setEnabled(false); // Disable editing for predefined options.
            } else {
                String savedPackageName = getCurrentPackageName();
                editText.setText(Downloader.findByPackageName(savedPackageName) == null
                        ? savedPackageName // If the user is clicking through options then retain existing other app.
                        : ""
                );
                editText.setEnabled(true); // Enable editing for Custom.
                editText.requestFocus();
            }
            editText.setSelection(editText.getText().length());
            adapter.setSelectedValue(selectedValue);
            adapter.notifyDataSetChanged();
        });

        // Add ListView to content layout with initial height.
        LinearLayout.LayoutParams listViewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        listViewParams.bottomMargin = Dim.dp16;
        contentLayout.addView(listView, listViewParams);

        // Add EditText for custom package name.
        editText = createEditText(context, packageName, usingCustomDownloader, updateListViewSelection);
        contentLayout.addView(editText);

        // Create the custom dialog.
        Pair<Dialog, LinearLayout> dialogPair = CustomDialog.create(
                context,
                getTitle() != null ? getTitle().toString() : "",
                null,
                null,
                null,
                () -> {
                    String newValue = editText.getText().toString().trim();
                    if (newValue.isEmpty()) {
                        // Show dialog if EditText is empty.
                        CustomDialog.create(
                                context,
                                str("morphe_external_downloader_name_title"),
                                str("morphe_external_downloader_empty_warning"),
                                null,
                                null,
                                () -> {}, // OK button does nothing (dismiss only).
                                null,
                                null,
                                null,
                                false
                        ).first.show();
                        return;
                    }

                    if (showDialogIfAppIsNotInstalled(getContext(), newValue)) {
                        return; // Invalid package. Do not save.
                    }

                    // Save custom package name.
                    if (callChangeListener(newValue)) {
                        setValue(newValue);
                    }
                },
                () -> {}, // Cancel button action (dismiss only).
                str("morphe_settings_reset"),
                () -> { // Reset action.
                    String defaultValue = getDefaultPackageName();
                    editText.setText(defaultValue);
                    editText.setSelection(defaultValue.length());
                    editText.setEnabled(false); // Disable editing on reset.
                    updateListViewSelection.apply(defaultValue);
                },
                false
        );

        // Add the content layout directly to the dialog's main layout.
        LinearLayout mainLayout = dialogPair.second;
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);

        // Insert content before the dialog button row.
        mainLayout.addView(contentLayout, mainLayout.getChildCount() - 1, contentParams);

        Dialog dialog = dialogPair.first;
        dialog.show();
    }

    /**
     * Creates and configures the EditText for the custom package name.
     *
     * @param context            Context for creating views.
     * @param initialPackageName The package name to pre-fill.
     * @param isCustom           Whether the "Other" option is selected.
     * @param textChangeCallback Callback to run when text changes.
     * @return A configured EditText.
     */
    private EditText createEditText(Context context,
                                    String initialPackageName, boolean isCustom,
                                    Function<String, Void> textChangeCallback) {
        EditText editText = CustomDialog.createEditText(context);
        editText.setText(initialPackageName);
        editText.setSelection(initialPackageName.length());
        editText.setHint(str("morphe_external_downloader_other_item_hint"));
        editText.setSingleLine(true);
        editText.setEnabled(isCustom);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable edit) {
                String updatedPackageName = edit.toString().trim();
                textChangeCallback.apply(updatedPackageName);
            }
        });

        return editText;
    }

    /**
     * @return If the app is not installed and a dialog was shown.
     */
    public static boolean showDialogIfAppIsNotInstalled(Context context, String packageName) {
        if (isAppInstalledAndEnabled(packageName)) {
            return false;
        }

        Downloader downloader = Downloader.findByPackageName(packageName);
        String downloadUrl = downloader != null
                ? downloader.downloadUrl
                : null;
        String okButtonText = downloadUrl != null
                ? str("gms_core_dialog_open_website_text") // Open website.
                : null; // Ok.
        // Show a dialog if the recommended app is not installed or if the custom package cannot be found.
        String message = downloader != null
                ? str("morphe_external_downloader_not_installed_warning", downloader.name)
                : str("morphe_external_downloader_package_not_found_warning", packageName);

        CustomDialog.create(
                context,
                str("morphe_external_downloader_not_found_title"),
                message,
                null,
                okButtonText,
                () -> {
                    try {
                        // OK button action: open the downloader's URL if available.
                        if (downloadUrl != null) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                        }
                    } catch (Exception ex) {
                        Logger.printException(() -> "Failed to open downloader URL: " + downloader, ex);
                    }
                },
                () -> {}, // Cancel button action (dismiss only).
                null,
                null,
                false
        ).first.show();

        return true;
    }

    @Override
    public boolean tracksNewEntries() {
        return false; // Entries depend on the installed apps.
    }
}
