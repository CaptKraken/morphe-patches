/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches
 *
 * Original hard forked code:
 * https://github.com/ReVanced/revanced-patches/commit/724e6d61b2ecd868c1a9a37d465a688e83a74799
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to Morphe contributions.
 */

package app.morphe.extension.shared.settings;

import static app.morphe.extension.shared.StringRef.str;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceFragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceType;
import app.morphe.extension.shared.ResourceUtils;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.shared.patches.SettingsNamePatch;
import app.morphe.extension.shared.settings.preference.AbstractPreferenceFragment;
import app.morphe.extension.shared.settings.preference.ToolbarPreferenceFragment;
import app.morphe.extension.shared.theme.ThemeUtils;
import app.morphe.extension.shared.ui.Dim;

/**
 * Base class for hooking activities to inject a custom PreferenceFragment with a toolbar.
 * Provides common logic for initializing the activity and setting up the toolbar.
 */
@SuppressWarnings({"deprecation"})
public abstract class BaseActivityHook extends Activity {

    public static final String MORPHE_SETTINGS_INTENT = "morphe_settings_intent";
    public static final String MORPHE_DOWNLOADS_INTENT = "morphe_downloads_intent";
    protected static final int ID_MORPHE_SETTINGS_FRAGMENTS =
            ResourceUtils.getIdentifierOrThrow(ResourceType.ID, "morphe_settings_fragments");
    private static final int ID_MORPHE_TOOLBAR_PARENT =
            ResourceUtils.getIdentifierOrThrow(ResourceType.ID, "morphe_toolbar_parent");
    public static final int LAYOUT_MORPHE_SETTINGS_WITH_TOOLBAR =
            ResourceUtils.getIdentifierOrThrow(ResourceType.LAYOUT, "morphe_settings_with_toolbar");

    /**
     * Layout parameters for the toolbar, extracted from the dummy toolbar.
     */
    protected static ViewGroup.LayoutParams toolbarLayoutParams;

    /**
     * Sets the layout parameters for the toolbar.
     */
    public static void setToolbarLayoutParams(Toolbar toolbar) {
        if (toolbarLayoutParams != null) {
            toolbar.setLayoutParams(toolbarLayoutParams);
        }
    }

    /**
     * Set this to true in the future if stock YouTube ever fully implements
     * Android's predictive back gestures for its settings menus.
     */
    private static final boolean ENABLE_PREDICTIVE_BACK_ANIMATION = false;

    /**
     * Initializes the activity by setting the theme, content view and injecting a PreferenceFragment.
     */
    public static void initialize(BaseActivityHook hook, Activity activity) {
        try {
            hook.customizeActivityTheme(activity);
            activity.setContentView(hook.getContentViewResourceId());

            // Sanity check.
            String dataString = activity.getIntent().getDataString();
            if (!MORPHE_SETTINGS_INTENT.equals(dataString)
                    && !MORPHE_DOWNLOADS_INTENT.equals(dataString)) {
                Logger.printException(() -> "Unknown intent: " + dataString);
                return;
            }

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU
                    && !ENABLE_PREDICTIVE_BACK_ANIMATION) {
                activity.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                        android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                        () -> closeSettings(activity)
                );
            }

            PreferenceFragment fragment = hook.createPreferenceFragment();
            hook.createToolbar(activity, fragment);

            activity.getFragmentManager()
                    .beginTransaction()
                    .replace(ID_MORPHE_SETTINGS_FRAGMENTS, fragment)
                    .commit();
        } catch (Exception ex) {
            Logger.printException(() -> "initialize failure", ex);
        }
    }

    /**
     * Closes the settings, after first showing the restart dialog if a changed setting requires it.
     */
    public static void closeSettings(Activity activity) {
        if (!AbstractPreferenceFragment.showRestartDialogIfNeeded(activity)) {
            activity.finish();
        }
    }

    /**
     * Injection point.
     * Overrides the Morphe settings language.
     */
    @SuppressWarnings("unused")
    public static Context getAttachBaseContext(Context original) {
        AppLanguage language = BaseSettings.MORPHE_LANGUAGE.get();
        if (language == AppLanguage.DEFAULT) {
            return original;
        }

        return Utils.getContext();
    }

    /**
     * Creates and configures a toolbar for the activity, replacing a dummy placeholder.
     */
    @SuppressLint("UseCompatLoadingForDrawables")
    protected void createToolbar(Activity activity, PreferenceFragment fragment) {
        // Replace dummy placeholder toolbar.
        // This is required to fix submenu title alignment issue with Android ASOP 15+
        ViewGroup toolBarParent = activity.findViewById(ID_MORPHE_TOOLBAR_PARENT);
        ViewGroup dummyToolbar = Utils.getChildViewByResourceName(toolBarParent, "morphe_toolbar");
        toolbarLayoutParams = dummyToolbar.getLayoutParams();
        toolBarParent.removeView(dummyToolbar);

        // Sets appropriate system navigation bar color for the activity.
        ToolbarPreferenceFragment.setNavigationBarColor(activity.getWindow());

        Toolbar toolbar = new Toolbar(toolBarParent.getContext());
        toolbar.setBackgroundColor(getToolbarBackgroundColor());
        toolbar.setNavigationIcon(getNavigationIcon());
        toolbar.setNavigationContentDescription(str("morphe_settings_navigate_up"));
        toolbar.setNavigationOnClickListener(getNavigationClickListener(activity));
        toolbar.setTitle(SettingsNamePatch.getSettingsName());

        toolbar.setTitleMarginStart(Dim.dp16);
        toolbar.setTitleMarginEnd(Dim.dp16);
        TextView toolbarTextView = Utils.getChildView(toolbar, false, view -> view instanceof TextView);
        if (toolbarTextView != null) {
            toolbarTextView.setTextColor(ThemeUtils.getAppForegroundColor());
            toolbarTextView.setTextSize(20);
        }
        setToolbarLayoutParams(toolbar);

        onPostToolbarSetup(activity, toolbar, fragment);

        toolBarParent.addView(toolbar, 0);
    }

    /**
     * Returns the resource ID for the content view layout.
     */
    protected int getContentViewResourceId() {
        return LAYOUT_MORPHE_SETTINGS_WITH_TOOLBAR;
    }

    /**
     * Customizes the activity's theme.
     */
    protected abstract void customizeActivityTheme(Activity activity);

    /**
     * Returns the background color for the toolbar.
     */
    protected abstract int getToolbarBackgroundColor();

    /**
     * Returns the navigation icon drawable for the toolbar.
     */
    protected abstract Drawable getNavigationIcon();

    /**
     * Returns the click listener for the toolbar's navigation icon.
     */
    protected abstract View.OnClickListener getNavigationClickListener(Activity activity);

    /**
     * Creates the PreferenceFragment to be injected into the activity.
     */
    protected PreferenceFragment createPreferenceFragment() {
        return new ToolbarPreferenceFragment();
    }

    /**
     * Performs additional setup after the toolbar is configured.
     *
     * @param activity The activity hosting the toolbar.
     * @param toolbar  The configured toolbar.
     * @param fragment The PreferenceFragment associated with the activity.
     */
    protected void onPostToolbarSetup(Activity activity, Toolbar toolbar, PreferenceFragment fragment) {}
}
