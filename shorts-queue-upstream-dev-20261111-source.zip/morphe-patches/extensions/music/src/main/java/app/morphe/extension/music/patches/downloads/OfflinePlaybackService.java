/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2528
 * https://github.com/MorpheApp/morphe-patches/pull/4436
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.downloads;

import static app.morphe.extension.shared.StringRef.str;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.audiofx.AudioEffect;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.view.KeyEvent;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import app.morphe.extension.shared.Logger;

/** Foreground offline player with audio focus, MediaSession and lock-screen controls. */
public final class OfflinePlaybackService extends Service {
    public interface PlaybackListener {
        void onPlaybackChanged(String path, String title, boolean playing, int position, int duration);
    }

    enum RepeatMode {
        OFF, ALL, ONE;

        RepeatMode next() {
            return values()[(ordinal() + 1) % values().length];
        }
    }

    private static final Set<PlaybackListener> listeners = new CopyOnWriteArraySet<>();
    private static volatile String currentPath = "";
    private static volatile String currentTitle = "";
    private static volatile boolean currentPlaying;
    private static volatile int currentPosition;
    private static volatile int currentDuration;
    private static volatile boolean shuffleEnabled;
    private static volatile RepeatMode repeatMode = RepeatMode.OFF;
    private static volatile OfflinePlaybackService instance;

    private static final float DUCK_VOLUME = 0.2f;
    private static final float FULL_VOLUME = 1.0f;

    private boolean shouldResumeAfterFocusGain;

    public static void addListener(PlaybackListener listener) {
        listeners.add(listener);
        listener.onPlaybackChanged(currentPath, currentTitle, currentPlaying, currentPosition, currentDuration);
    }

    public static void removeListener(PlaybackListener listener) {
        listeners.remove(listener);
    }

    private record PlayRequest(OfflineTrack track, List<String> queue, int queueIndex) {
    }

    /**
     * The last play request, until a start of the service takes it. A catalogue of thousands of
     * tracks does not fit in the Intent the service is started with, so it is handed over in
     * memory: the service runs in the process of the app, and both ends are on the main thread.
     */
    @Nullable
    private static PlayRequest pendingPlayRequest;

    /**
     * Must be called on the main thread.
     *
     * @param queue      The tracks that Previous and Next move through, including this track.
     * @param queueIndex The position of this track in the queue.
     */
    static void play(Context context, OfflineTrack track, List<String> queue, int queueIndex) {
        pendingPlayRequest = new PlayRequest(track, queue, queueIndex);
        context.startForegroundService(new Intent(context, OfflinePlaybackService.class)
                .setAction(ACTION_PLAY_FILE));
    }

    static boolean hasPrevious() {
        OfflinePlaybackService service = instance;
        return service != null && service.queueIndex > 0;
    }

    static boolean hasNext() {
        OfflinePlaybackService service = instance;
        if (service == null || service.queue.isEmpty()) return false;
        return service.queueIndex + 1 < service.queue.size() || repeatMode == RepeatMode.ALL;
    }

    static boolean isShuffleEnabled() {
        return shuffleEnabled;
    }

    static RepeatMode getRepeatMode() {
        return repeatMode;
    }

    static List<String> getQueue() {
        OfflinePlaybackService service = instance;
        return service != null ? new ArrayList<>(service.queue) : Collections.emptyList();
    }

    static int getQueueIndex() {
        OfflinePlaybackService service = instance;
        return service != null ? service.queueIndex : -1;
    }

    static void playQueueIndex(int index) {
        OfflinePlaybackService service = instance;
        if (service != null) service.playQueueFrom(index, 1);
    }

    static void moveQueueItem(int fromIndex, int toIndex) {
        OfflinePlaybackService service = instance;
        if (service == null) return;
        int size = service.queue.size();
        if (fromIndex < 0 || fromIndex >= size || toIndex < 0 || toIndex >= size || fromIndex == toIndex) {
            return;
        }
        service.queue.add(toIndex, service.queue.remove(fromIndex));

        if (fromIndex == service.queueIndex) {
            service.queueIndex = toIndex;
        } else if (fromIndex < service.queueIndex && toIndex >= service.queueIndex) {
            service.queueIndex--;
        } else if (fromIndex > service.queueIndex && toIndex <= service.queueIndex) {
            service.queueIndex++;
        }
        service.publishState();
    }

    static void removeQueueItem(int index) {
        OfflinePlaybackService service = instance;
        if (service == null || index < 0 || index >= service.queue.size()) return;

        service.originalQueue.remove(service.queue.remove(index));

        if (index == service.queueIndex) {
            // The next track moved up to this index. The queue goes around if this was the last.
            if (!service.playQueueFrom(index, 1) && !service.playQueueFrom(0, 1)) {
                service.stopPlayback();
            }
            return;
        }
        if (index < service.queueIndex) service.queueIndex--;
        service.publishState();
    }

    static void toggleShuffle() {
        shuffleEnabled = !shuffleEnabled;
        OfflinePlaybackService service = instance;
        if (service == null || service.queue.isEmpty()) return;

        if (shuffleEnabled) service.shuffleQueue();
        else service.restoreQueueOrder();
        service.publishState();
    }

    static void cycleRepeatMode() {
        repeatMode = repeatMode.next();
        OfflinePlaybackService service = instance;
        if (service != null) service.publishState();
    }

    public static void toggle(Context context) {
        context.startService(new Intent(context, OfflinePlaybackService.class).setAction(ACTION_TOGGLE));
    }

    public static void skipNext(Context context) {
        context.startService(new Intent(context, OfflinePlaybackService.class).setAction(ACTION_NEXT));
    }

    public static void skipPrevious(Context context) {
        context.startService(new Intent(context, OfflinePlaybackService.class).setAction(ACTION_PREVIOUS));
    }

    public static void seekTo(int position) {
        OfflinePlaybackService service = instance;
        if (service != null && service.playerReady()) {
            service.player.seekTo(Math.max(0, Math.min(position, service.player.getDuration())));
            service.publishState();
        }
    }

    public static final String ACTION_PLAY_FILE = "app.morphe.action.PLAY_OFFLINE_FILE";
    public static final String ACTION_TOGGLE = "app.morphe.action.TOGGLE_OFFLINE_PLAYBACK";
    public static final String ACTION_STOP = "app.morphe.action.STOP_OFFLINE_PLAYBACK";
    public static final String ACTION_NEXT = "app.morphe.action.NEXT_OFFLINE_TRACK";
    public static final String ACTION_PREVIOUS = "app.morphe.action.PREVIOUS_OFFLINE_TRACK";

    private static final String CHANNEL_ID = "morphe_offline_playback";
    private static final int NOTIFICATION_ID = 8841;

    private MediaPlayer player;
    private boolean prepared;
    private MediaSession session;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private int audioEffectSessionId;
    private String path = "";
    private String publishedMetadataPath = "";
    private String title = "YouTube Music";
    private String artist = "YouTube Music";
    private Bitmap artwork;
    private List<String> queue = new ArrayList<>();
    /** The order to go back to when shuffle is turned off. */
    private List<String> originalQueue = new ArrayList<>();
    private int queueIndex = -1;
    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressTicker = new Runnable() {
        @Override
        public void run() {
            publishState();
            if (player != null) progressHandler.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        createFocusRequest();
        createChannel();
        session = new MediaSession(this, "MorpheOfflinePlayback");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                resume();
            }

            @Override
            public void onPause() {
                pause();
            }

            @Override
            public void onSkipToNext() {
                playNextInQueue();
            }

            @Override
            public void onSkipToPrevious() {
                playPreviousInQueue();
            }

            @Override
            public void onStop() {
                stopPlayback();
            }

            @Override
            public void onSeekTo(long pos) {
                if (playerReady()) player.seekTo((int) Math.min(Integer.MAX_VALUE, pos));
                publishState();
            }
        });
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) session.setSessionActivity(PendingIntent.getActivity(this, 3, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_PLAY_FILE.equals(action)) {
            // The request was made with startForegroundService, so the service has to reach the
            // foreground before anything can stop it, or the system closes the app.
            startForeground(NOTIFICATION_ID, notification());

            // Taps in quick succession each start the service, and the first start takes the
            // last request.
            PlayRequest request = pendingPlayRequest;
            pendingPlayRequest = null;
            if (request != null) {
                queue = request.queue();
                queueIndex = request.queueIndex();
                if (shuffleEnabled && !queue.isEmpty()) shuffleQueue();
                playTrack(request.track());
            }
        } else if (ACTION_TOGGLE.equals(action)) {
            if (playerReady() && player.isPlaying()) pause();
            else resume();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
        } else if (ACTION_NEXT.equals(action)) {
            playNextInQueue();
        } else if (ACTION_PREVIOUS.equals(action)) {
            playPreviousInQueue();
        }
        return START_NOT_STICKY;
    }

    /** The current track moves to the front, so what was already played is not played again. */
    private void shuffleQueue() {
        originalQueue = new ArrayList<>(queue);
        String current = queue.remove(queueIndex);
        Collections.shuffle(queue);
        queue.add(0, current);
        queueIndex = 0;
    }

    private void restoreQueueOrder() {
        String current = queue.get(queueIndex);
        queue = originalQueue;
        originalQueue = new ArrayList<>();
        queueIndex = queue.indexOf(current);
    }

    private boolean playNextInQueue() {
        return playQueueFrom(queueIndex + 1, 1)
                || (repeatMode == RepeatMode.ALL && playQueueFrom(0, 1));
    }

    private void playPreviousInQueue() {
        playQueueFrom(queueIndex - 1, -1);
    }

    /**
     * Only runs once the service is in the foreground, so playback can be stopped at any point.
     */
    private void playTrack(OfflineTrack track) {
        File audioFile = track.audioFile();
        if (!audioFile.isFile()) {
            // Whatever was playing or preparing goes on. Otherwise the service has nothing to do.
            if (player == null) stopPlayback();
            return;
        }
        path = audioFile.getAbsolutePath();
        title = track.displayTitle();
        artist = track.displayArtist();
        // A track saved without a cover has no file, and decoding it would log an error a second.
        File artworkFile = track.artworkFile();
        artwork = artworkFile.isFile()
                ? BitmapFactory.decodeFile(artworkFile.getAbsolutePath())
                : null;
        releasePlayer();
        try {
            pauseOtherMedia();
            if (audioFocusDenied()) {
                stopPlayback();
                return;
            }
            player = new MediaPlayer();
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(path);
            // Skipping quickly leaves the previous player mid prepare. Its callbacks are
            // cleared on release, and each one still checks that it belongs to the current
            // track, so a discarded player can never tear down the one that replaced it.
            player.setOnPreparedListener(mp -> {
                if (mp != player) return;
                prepared = true;
                openAudioEffectSession(mp);
                mp.start();
                setPlayerVolume(FULL_VOLUME);
                publishState();
                startForeground(NOTIFICATION_ID, notification());
                progressHandler.removeCallbacks(progressTicker);
                progressHandler.post(progressTicker);
            });
            player.setOnCompletionListener(mp -> {
                if (mp != player) return;
                if (repeatMode == RepeatMode.ONE) {
                    mp.seekTo(0);
                    mp.start();
                    publishState();
                } else if (!playNextInQueue()) {
                    stopPlayback();
                }
            });
            player.setOnErrorListener((mp, what, extra) -> {
                if (mp != player) return true;
                Logger.printException(() -> "Offline player error: " + what + "/" + extra);
                stopPlayback();
                return true;
            });
            player.prepareAsync();
            startForeground(NOTIFICATION_ID, notification());
        } catch (Exception ex) {
            Logger.printException(() -> "Could not start offline playback", ex);
            stopPlayback();
        }
    }

    /**
     * Plays the first track from an index of the queue in one direction, passing over tracks that
     * have been deleted since the queue was made.
     *
     * @param direction 1 to look further down the queue, or -1 to look back.
     * @return If a track was found to play.
     */
    private boolean playQueueFrom(int index, int direction) {
        int target = index;
        while (target >= 0 && target < queue.size() && !new File(queue.get(target)).isFile()) {
            target += direction;
        }
        if (target < 0 || target >= queue.size()) return false;

        queueIndex = target;
        playTrack(OfflineTrack.load(new File(queue.get(target))));
        return true;
    }

    private void resume() {
        if (!playerReady()) return;
        if (audioFocusDenied()) return;

        player.start();
        setPlayerVolume(FULL_VOLUME);
        shouldResumeAfterFocusGain = false;
        publishState();
        notifyChanged();
    }

    private void pause() {
        pause(false);
    }

    private void pause(boolean keepResumeState) {
        if (!playerReady() || !player.isPlaying()) return;
        if (!keepResumeState) shouldResumeAfterFocusGain = false;
        player.pause();
        publishState();
        notifyChanged();
    }

    private void stopPlayback() {
        releasePlayer();
        progressHandler.removeCallbacks(progressTicker);
        if (audioManager != null && focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest);
        shouldResumeAfterFocusGain = false;
        publishedMetadataPath = "";
        if (session != null) session.setPlaybackState(new PlaybackState.Builder().setState(
                PlaybackState.STATE_STOPPED, 0, 0).build());
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    /**
     * Asking a player that is still preparing about its state is an invalid operation, which it
     * answers with an error that stops playback, so nothing may reach it before it is ready.
     */
    private boolean playerReady() {
        return prepared && player != null;
    }

    private void setPlayerVolume(float volume) {
        if (player != null) player.setVolume(volume, volume);
    }

    private void openAudioEffectSession(MediaPlayer mediaPlayer) {
        int sessionId = mediaPlayer.getAudioSessionId();
        if (sessionId <= 0) return;

        audioEffectSessionId = sessionId;
        sendBroadcast(new Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, getPackageName())
                .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC));
    }

    private void closeAudioEffectSession() {
        int sessionId = audioEffectSessionId;
        if (sessionId <= 0) return;

        audioEffectSessionId = 0;
        sendBroadcast(new Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
                .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, getPackageName()));
    }

    private void releasePlayer() {
        prepared = false;
        progressHandler.removeCallbacks(progressTicker);
        closeAudioEffectSession();

        MediaPlayer released = player;
        if (released == null) return;
        // Cleared first, otherwise releasing a player that is still preparing reports an error
        // that would stop whatever is playing by then.
        player = null;
        released.setOnPreparedListener(null);
        released.setOnCompletionListener(null);
        released.setOnErrorListener(null);
        released.reset();
        released.release();
    }

    private void createFocusRequest() {
        if (audioManager == null) return;
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attributes)
                .setWillPauseWhenDucked(true)
                .setOnAudioFocusChangeListener(change -> {
                    switch (change) {
                        case AudioManager.AUDIOFOCUS_LOSS:
                            shouldResumeAfterFocusGain = false;
                            pause(true);
                            break;
                        case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                            shouldResumeAfterFocusGain = playerReady() && player.isPlaying();
                            pause(true);
                            break;
                        case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                            if (playerReady()) {
                                setPlayerVolume(DUCK_VOLUME);
                                shouldResumeAfterFocusGain = player.isPlaying();
                            }
                            break;
                        case AudioManager.AUDIOFOCUS_GAIN:
                            setPlayerVolume(FULL_VOLUME);
                            if (shouldResumeAfterFocusGain && playerReady()) {
                                player.start();
                                publishState();
                                notifyChanged();
                            }
                            shouldResumeAfterFocusGain = false;
                            break;
                        default:
                            break;
                    }
                })
                .build();
    }

    /**
     * @return Whether the system refused audio focus, so playback must not start.
     */
    private boolean audioFocusDenied() {
        return audioManager == null || focusRequest == null
                || audioManager.requestAudioFocus(focusRequest) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    /** Pause the currently routed system player before this session becomes active. */
    private void pauseOtherMedia() {
        if (audioManager == null || !audioManager.isMusicActive()) return;
        KeyEvent down = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE);
        KeyEvent up = new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE);
        audioManager.dispatchMediaKeyEvent(down);
        audioManager.dispatchMediaKeyEvent(up);
    }

    private void publishState() {
        MediaSession currentSession = session;
        if (currentSession == null) return;

        final boolean playing = playerReady() && player.isPlaying();
        final long position = playerReady() ? player.getCurrentPosition() : 0;
        currentSession.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
                        PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP |
                        PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_SKIP_TO_NEXT |
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        position, playing ? 1f : 0f)
                .build());
        currentPath = path == null ? "" : path;
        currentTitle = title;
        currentPlaying = playing;
        currentPosition = (int) position;
        currentDuration = playerReady() ? player.getDuration() : 0;
        notifyListeners();
        // Rebuilding the metadata copies the artwork, so only do it when the track changed.
        if (!currentPath.equals(publishedMetadataPath)) {
            publishedMetadataPath = currentPath;
            MediaMetadata.Builder metadata = new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, currentDuration);
            if (artwork != null) {
                metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artwork)
                        .putBitmap(MediaMetadata.METADATA_KEY_ART, artwork)
                        .putBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON, artwork);
            }
            currentSession.setMetadata(metadata.build());
        }
    }

    private static void notifyListeners() {
        for (PlaybackListener listener : listeners) {
            listener.onPlaybackChanged(currentPath, currentTitle, currentPlaying, currentPosition, currentDuration);
        }
    }

    /** Lets the screens drop their player, including the ones that open later. */
    private static void publishStopped() {
        currentPath = "";
        currentTitle = "";
        currentPlaying = false;
        currentPosition = 0;
        currentDuration = 0;
        notifyListeners();
    }

    @SuppressLint("WrongConstant")
    private Notification notification() {
        final boolean playing = playerReady() && player.isPlaying();
        PendingIntent toggle = serviceIntent(ACTION_TOGGLE, 1);
        PendingIntent stop = serviceIntent(ACTION_STOP, 2);
        PendingIntent previous = serviceIntent(ACTION_PREVIOUS, 4);
        PendingIntent next = serviceIntent(ACTION_NEXT, 5);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent content = PendingIntent.getActivity(this, 3, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_headset)
                .setContentTitle(title)
                .setContentText(artist)
                .setLargeIcon(artwork)
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(true)
                .addAction(action(android.R.drawable.ic_media_previous,
                        str("morphe_music_downloads_previous"), previous))
                .addAction(action(
                        playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        str(playing ? "morphe_music_downloads_pause" : "morphe_music_downloads_play"),
                        toggle))
                .addAction(action(android.R.drawable.ic_media_next,
                        str("morphe_music_downloads_next"), next))
                .addAction(action(android.R.drawable.ic_menu_close_clear_cancel,
                        str("morphe_music_downloads_close"), stop))
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private Notification.Action action(int iconResource, String title, PendingIntent intent) {
        return new Notification.Action.Builder(
                Icon.createWithResource(this, iconResource), title, intent).build();
    }

    private PendingIntent serviceIntent(String action, int code) {
        Intent intent = new Intent(this, OfflinePlaybackService.class).setAction(action);
        //noinspection WrongConstant
        return PendingIntent.getService(this, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @SuppressLint("NotificationPermission") // The patch declares POST_NOTIFICATIONS.
    private void notifyChanged() {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification());
    }

    private void createChannel() {
        //noinspection WrongConstant
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                str("morphe_music_downloads_playback_channel"), NotificationManager.IMPORTANCE_LOW);
        channel.setSound(null, null);
        channel.setShowBadge(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }

    @Override
    public void onDestroy() {
        progressHandler.removeCallbacks(progressTicker);
        releasePlayer();
        artwork = null;
        if (audioManager != null && focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest);
        if (session != null) {
            session.release();
            session = null;
        }
        if (instance == this) {
            instance = null;
            publishStopped();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
