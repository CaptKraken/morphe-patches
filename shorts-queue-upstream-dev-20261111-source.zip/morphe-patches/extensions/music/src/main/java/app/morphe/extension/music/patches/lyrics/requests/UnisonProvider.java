/*
 * Copyright 2026 Morphe.
 * https://github.com/MorpheApp/morphe-patches/pull/2625
 *
 * See the included NOTICE file for GPLv3 Section 7 terms that apply to this code.
 */

package app.morphe.extension.music.patches.lyrics.requests;

import android.util.Base64;

import androidx.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.util.List;
import java.util.Locale;

import app.morphe.extension.music.patches.lyrics.model.Lyrics;
import app.morphe.extension.music.patches.lyrics.model.LyricsLine;
import app.morphe.extension.music.patches.lyrics.model.LyricsMerge;
import app.morphe.extension.music.patches.lyrics.model.TrackInfo;
import app.morphe.extension.music.patches.lyrics.parsers.LRCParser;
import app.morphe.extension.music.patches.lyrics.parsers.TTMLParser;
import app.morphe.extension.music.shared.VideoInformation;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.requests.Requester;

public final class UnisonProvider implements LyricsProvider {

    private static final String BASE_URL = "https://unison.boidu.dev/lyrics";

    private static final String FALLBACK_KEY_ID =
            "0000000000000000000000000000000000000000000000000000000000000000";
    private static volatile String cachedKeyId;

    private static String getKeyId() {
        String cached = cachedKeyId;
        if (cached != null) {
            return cached;
        }
        synchronized (UnisonProvider.class) {
            if (cachedKeyId != null) {
                return cachedKeyId;
            }
            cachedKeyId = computeKeyId();
            return cachedKeyId;
        }
    }

    private static String computeKeyId() {
        try {
            final KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
            generator.initialize(new ECGenParameterSpec("secp256r1"));
            final ECPublicKey publicKey = (ECPublicKey) generator.generateKeyPair().getPublic();
            final String x = base64Url(publicKey.getW().getAffineX());
            final String y = base64Url(publicKey.getW().getAffineY());
            final String canonical = "{\"crv\":\"P-256\",\"kty\":\"EC\",\"x\":\"" + x + "\",\"y\":\"" + y + "\"}";
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            final byte[] hash = digest.digest(canonical.getBytes(StandardCharsets.UTF_8));
            return toHex(hash);
        } catch (Exception ex) {
            Logger.printDebug(() -> "Could not compute Unison key ID", ex);
            return FALLBACK_KEY_ID;
        }
    }

    private static String base64Url(BigInteger value) {
        final byte[] bytes = value.toByteArray();
        final byte[] coordinate = new byte[32];
        int srcPos = 0;
        if (bytes.length > 32 && bytes[0] == 0) {
            srcPos = 1;
        }
        final int copyLen = Math.min(32, bytes.length - srcPos);
        System.arraycopy(bytes, srcPos, coordinate, 32 - copyLen, copyLen);
        return Base64.encodeToString(coordinate,
                Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
    }

    private static String toHex(byte[] bytes) {
        final StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            builder.append(Character.forDigit((b >> 4) & 0xF, 16));
            builder.append(Character.forDigit(b & 0xF, 16));
        }
        return builder.toString();
    }

    private static String sourceUrl(String videoId) {
        return "https://unison.boidu.dev/song/" + videoId;
    }

    private static Lyrics withSubmitter(@Nullable Lyrics lyrics, @Nullable String submitter) {
        return LyricsMerge.addCredit(lyrics, submitter == null ? null : "Submitted by " + submitter);
    }

    @Override
    public String name() {
        return "Unison";
    }

    @Nullable
    @Override
    public FetchResult fetch(TrackInfo track) throws Exception {
        final String videoId = VideoInformation.getVideoId();
        if (videoId.isEmpty()) {
            return null;
        }
        final String title = track.title() != null ? track.title() : "";
        final String artist = track.artist() != null ? track.artist() : "";
        final long videoLengthMs = VideoInformation.getVideoLength();
        final int duration = videoLengthMs > 0
                ? (int) (videoLengthMs / 1000)
                : track.durationSeconds();
        final String album = track.album();

        return FetchResult.of(fetchByVideoId(videoId, title, artist, duration, album));
    }

    @Nullable
    private Lyrics fetchByVideoId(String videoId, String title, String artist,
                                  int duration, String album) {
        HttpURLConnection connection = null;
        try {
            final StringBuilder url = new StringBuilder(BASE_URL)
                    .append("?v=").append(LyricsRequests.encode(videoId));
            if (!title.isEmpty()) {
                url.append("&song=").append(LyricsRequests.encode(title));
            }
            if (!artist.isEmpty()) {
                url.append("&artist=").append(LyricsRequests.encode(artist));
            }
            if (duration > 0) {
                url.append("&duration=").append(duration);
            }
            if (album != null && !album.isEmpty()) {
                url.append("&album=").append(LyricsRequests.encode(album));
            }

            connection = LyricsRequests.openConnection(url.toString());
            connection.setRequestProperty("X-Key-ID", getKeyId());
            final int code = connection.getResponseCode();
            if (code == 404) {
                connection.disconnect();
                return null;
            }
            if (code != 200) {
                LyricsRequests.logFailure(name(), connection);
                return null;
            }
            JSONObject root = Requester.parseJSONObject(connection);
            JSONObject data = root.optJSONObject("data");
            if (data == null) {
                return null;
            }
            final String format = LyricsRequests.optString(data, "format");
            final String lyrics = LyricsRequests.optString(data, "lyrics");
            if (format == null || lyrics == null) {
                return null;
            }
            final JSONObject submitter = data.optJSONObject("submitter");
            final String submitterName = submitter != null
                    ? LyricsRequests.optString(submitter, "displayName")
                    : null;
            return parseLyrics(format, lyrics, videoId, submitterName);
        } catch (IOException | JSONException ex) {
            Logger.printDebug(() -> "Could not fetch Unison lyrics", ex);
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @Nullable
    private Lyrics parseLyrics(String format, String lyrics, String videoId,
                               @Nullable String submitter) {
        switch (format.toLowerCase(Locale.ROOT)) {
            case "ttml":
                return withSubmitter(
                        TTMLParser.ttmlToLyrics(lyrics, name(), sourceUrl(videoId)), submitter);
            case "lrc":
                LRCParser.LrcParseResult result = LRCParser.parseSyncedWithCreditLines(lyrics);
                if (result.lines.isEmpty()) {
                    return null;
                }
                return withSubmitter(new Lyrics(result.lines, name(), true,
                        null, null, null,
                        null, result.creditLines.isEmpty() ? null : result.creditLines,
                        lyrics, "lrc", sourceUrl(videoId), null, null), submitter);
            case "plain":
                final List<LyricsLine> plain = LRCParser.parsePlain(lyrics);
                if (plain.isEmpty()) {
                    return null;
                }
                return withSubmitter(new Lyrics(plain, name(), false,
                        null, null, null, null, lyrics, "plain", sourceUrl(videoId)), submitter);
            default:
                return null;
        }
    }
}
